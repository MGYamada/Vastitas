import Lake
open Lake DSL System
package production_thread_test where
  moreLinkArgs := #["-fno-lto", "-L", "/Users/masa/.elan/toolchains/leanprover--lean4---v4.35.0/lib"]
require vastitas_storage_native from "./native"
input_file threadSource where path := "production_thread.c"
target threadObject pkg : FilePath := do
  let source ← threadSource.fetch
  buildLeanO (pkg.buildDir / "thread.o") source #[] #["-std=c11", "-O3", "-fno-lto", "-Wall", "-Wextra", "-Werror", "-I/private/tmp/vastitas-production-unit-final/production-thread-test/native"]
extern_lib threadNative pkg := do
  buildStaticLib (pkg.staticLibDir / nameToStaticLib "thread_native") #[← threadObject.fetch]
lean_exe test where
  root := `Main
