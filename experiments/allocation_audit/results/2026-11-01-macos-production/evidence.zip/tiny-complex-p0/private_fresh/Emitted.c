// Lean compiler output
// Module: Main
// Imports: public import Init public meta import Init public import VastitasStorageNative public import VastitasGemmNative public import VastitasKernel.IndexedRuntime
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* vastitas_storage_new(uint64_t);
lean_object* vastitas_storage_close(lean_object*);
lean_object* vastitas_storage_allocate(lean_object*, uint32_t, uint8_t, uint64_t);
lean_object* vastitas_storage_fill(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_store(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_pack3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_gemm_execute(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t);
lean_object* vastitas_storage_regroup3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_storage_expect(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_drop(lean_object*, uint32_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_List_get_x21Internal___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_String_Slice_toNat_x21(lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
uint32_t lean_uint32_of_nat(lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
lean_object* lean_io_error_to_string(lean_object*);
static lean_once_cell_t lp_allocation__audit_VastitasGenerated_f__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_allocation__audit_VastitasGenerated_f__0___closed__0;
LEAN_EXPORT lean_object* lp_allocation__audit_VastitasGenerated_f__0;
lean_object* bench_begin_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_stop_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object*);
lean_object* bench_report_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object*);
lean_object* bench_c_run_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_verify_lean(lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object*);
lean_object* audit_mark_lean(uint32_t);
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_allocation__audit_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 1, .m_capacity = 1, .m_length = 0, .m_data = ""};
static const lean_object* lp_allocation__audit_main___closed__0 = (const lean_object*)&lp_allocation__audit_main___closed__0_value;
static const lean_string_object lp_allocation__audit_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "1"};
static const lean_object* lp_allocation__audit_main___closed__1 = (const lean_object*)&lp_allocation__audit_main___closed__1_value;
static const lean_string_object lp_allocation__audit_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "failure"};
static const lean_object* lp_allocation__audit_main___closed__2 = (const lean_object*)&lp_allocation__audit_main___closed__2_value;
static const lean_string_object lp_allocation__audit_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "c"};
static const lean_object* lp_allocation__audit_main___closed__3 = (const lean_object*)&lp_allocation__audit_main___closed__3_value;
static const lean_string_object lp_allocation__audit_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "expected injected native failure"};
static const lean_object* lp_allocation__audit_main___closed__4 = (const lean_object*)&lp_allocation__audit_main___closed__4_value;
static const lean_ctor_object lp_allocation__audit_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_allocation__audit_main___closed__4_value)}};
static const lean_object* lp_allocation__audit_main___closed__5 = (const lean_object*)&lp_allocation__audit_main___closed__5_value;
static const lean_string_object lp_allocation__audit_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 44, .m_capacity = 44, .m_length = 43, .m_data = "E_NATIVE_EXPECT: stored bit pattern differs"};
static const lean_object* lp_allocation__audit_main___closed__6 = (const lean_object*)&lp_allocation__audit_main___closed__6_value;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(0u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0(void){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_obj_once(&lp_allocation__audit_VastitasGenerated_f__0___closed__0, &lp_allocation__audit_VastitasGenerated_f__0___closed__0_once, _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object* v_scope_8_, lean_object* v_reps_9_, lean_object* v_verify_10_, lean_object* v_a_00___x40___internal___hyg_11_){
_start:
{
uint32_t v_scope_boxed_12_; uint64_t v_reps_boxed_13_; uint8_t v_verify_boxed_14_; lean_object* v_res_15_; 
v_scope_boxed_12_ = lean_unbox_uint32(v_scope_8_);
lean_dec(v_scope_8_);
v_reps_boxed_13_ = lean_unbox_uint64(v_reps_9_);
lean_dec_ref(v_reps_9_);
v_verify_boxed_14_ = lean_unbox(v_verify_10_);
v_res_15_ = bench_begin_lean(v_scope_boxed_12_, v_reps_boxed_13_, v_verify_boxed_14_);
return v_res_15_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object* v_a_00___x40___internal___hyg_17_){
_start:
{
lean_object* v_res_18_; 
v_res_18_ = bench_stop_lean();
return v_res_18_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object* v_a_00___x40___internal___hyg_20_){
_start:
{
lean_object* v_res_21_; 
v_res_21_ = bench_report_lean();
return v_res_21_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object* v_scope_26_, lean_object* v_reps_27_, lean_object* v_verify_28_, lean_object* v_a_00___x40___internal___hyg_29_){
_start:
{
uint32_t v_scope_boxed_30_; uint64_t v_reps_boxed_31_; uint8_t v_verify_boxed_32_; lean_object* v_res_33_; 
v_scope_boxed_30_ = lean_unbox_uint32(v_scope_26_);
lean_dec(v_scope_26_);
v_reps_boxed_31_ = lean_unbox_uint64(v_reps_27_);
lean_dec_ref(v_reps_27_);
v_verify_boxed_32_ = lean_unbox(v_verify_28_);
v_res_33_ = bench_c_run_lean(v_scope_boxed_30_, v_reps_boxed_31_, v_verify_boxed_32_);
return v_res_33_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object* v_arena_37_, lean_object* v_reps_38_, lean_object* v_a_00___x40___internal___hyg_39_){
_start:
{
uint64_t v_reps_boxed_40_; lean_object* v_res_41_; 
v_reps_boxed_40_ = lean_unbox_uint64(v_reps_38_);
lean_dec_ref(v_reps_38_);
v_res_41_ = bench_verify_lean(v_arena_37_, v_reps_boxed_40_);
lean_dec(v_arena_37_);
return v_res_41_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce(){
_start:
{
uint64_t v___x_43_; lean_object* v___x_44_; 
v___x_43_ = 9223372036854775807ULL;
v___x_44_ = vastitas_storage_new(v___x_43_);
if (lean_obj_tag(v___x_44_) == 0)
{
lean_object* v_a_45_; lean_object* v_a_47_; lean_object* v___y_58_; uint32_t v___x_70_; uint8_t v___x_71_; uint64_t v___x_72_; lean_object* v___x_73_; 
v_a_45_ = lean_ctor_get(v___x_44_, 0);
lean_inc(v_a_45_);
lean_dec_ref_known(v___x_44_, 1);
v___x_70_ = 0;
v___x_71_ = 1;
v___x_72_ = 24ULL;
v___x_73_ = vastitas_storage_allocate(v_a_45_, v___x_70_, v___x_71_, v___x_72_);
if (lean_obj_tag(v___x_73_) == 0)
{
uint64_t v___x_74_; uint64_t v___x_75_; uint8_t v___x_76_; uint64_t v___x_77_; uint64_t v___x_78_; lean_object* v___x_79_; 
lean_dec_ref_known(v___x_73_, 1);
v___x_74_ = 0ULL;
v___x_75_ = 1ULL;
v___x_76_ = 0;
v___x_77_ = 13842939354630062080ULL;
v___x_78_ = 4613937818241073152ULL;
v___x_79_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_74_, v___x_72_, v___x_75_, v___x_72_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_79_) == 0)
{
uint64_t v___x_80_; uint64_t v___x_81_; uint64_t v___x_82_; uint64_t v___x_83_; lean_object* v___x_84_; 
lean_dec_ref_known(v___x_79_, 1);
v___x_80_ = 2ULL;
v___x_81_ = 12ULL;
v___x_82_ = 4593671619917905920ULL;
v___x_83_ = 4598175219545276416ULL;
v___x_84_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_74_, v___x_80_, v___x_81_, v___x_80_, v___x_76_, v___x_71_, v___x_82_, v___x_83_);
if (lean_obj_tag(v___x_84_) == 0)
{
uint64_t v___x_85_; uint64_t v___x_86_; lean_object* v___x_87_; 
lean_dec_ref_known(v___x_84_, 1);
v___x_85_ = 4607182418800017408ULL;
v___x_86_ = 13826050856027422720ULL;
v___x_87_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_74_, v___x_80_, v___x_81_, v___x_80_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_85_, v___x_86_);
if (lean_obj_tag(v___x_87_) == 0)
{
uint64_t v___x_88_; lean_object* v___x_89_; 
lean_dec_ref_known(v___x_87_, 1);
v___x_88_ = 4604930618986332160ULL;
v___x_89_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_74_, v___x_80_, v___x_81_, v___x_80_, v___x_76_, v___x_75_, v___x_75_, v___x_71_, v___x_86_, v___x_88_);
if (lean_obj_tag(v___x_89_) == 0)
{
uint32_t v___x_90_; uint64_t v___x_91_; lean_object* v___x_92_; 
lean_dec_ref_known(v___x_89_, 1);
v___x_90_ = 1;
v___x_91_ = 15ULL;
v___x_92_ = vastitas_storage_allocate(v_a_45_, v___x_90_, v___x_71_, v___x_91_);
if (lean_obj_tag(v___x_92_) == 0)
{
lean_object* v___x_93_; 
lean_dec_ref_known(v___x_92_, 1);
v___x_93_ = vastitas_storage_fill(v_a_45_, v___x_90_, v___x_74_, v___x_91_, v___x_75_, v___x_91_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_93_) == 0)
{
uint64_t v___x_94_; uint64_t v___x_95_; uint64_t v___x_96_; lean_object* v___x_97_; 
lean_dec_ref_known(v___x_93_, 1);
v___x_94_ = 3ULL;
v___x_95_ = 5ULL;
v___x_96_ = 13821547256400052224ULL;
v___x_97_ = vastitas_storage_fill(v_a_45_, v___x_90_, v___x_74_, v___x_94_, v___x_95_, v___x_94_, v___x_76_, v___x_71_, v___x_96_, v___x_82_);
if (lean_obj_tag(v___x_97_) == 0)
{
uint64_t v___x_98_; uint64_t v___x_99_; lean_object* v___x_100_; 
lean_dec_ref_known(v___x_97_, 1);
v___x_98_ = 4ULL;
v___x_99_ = 4602678819172646912ULL;
v___x_100_ = vastitas_storage_store(v_a_45_, v___x_90_, v___x_74_, v___x_94_, v___x_95_, v___x_94_, v___x_76_, v___x_74_, v___x_98_, v___x_71_, v___x_99_, v___x_83_);
if (lean_obj_tag(v___x_100_) == 0)
{
uint64_t v___x_101_; lean_object* v___x_102_; 
lean_dec_ref_known(v___x_100_, 1);
v___x_101_ = 13828302655841107968ULL;
v___x_102_ = vastitas_storage_store(v_a_45_, v___x_90_, v___x_74_, v___x_94_, v___x_95_, v___x_94_, v___x_76_, v___x_80_, v___x_74_, v___x_71_, v___x_101_, v___x_86_);
if (lean_obj_tag(v___x_102_) == 0)
{
uint32_t v___x_103_; lean_object* v___x_104_; 
lean_dec_ref_known(v___x_102_, 1);
v___x_103_ = 2;
v___x_104_ = vastitas_storage_allocate(v_a_45_, v___x_103_, v___x_71_, v___x_72_);
if (lean_obj_tag(v___x_104_) == 0)
{
lean_object* v___x_105_; 
lean_dec_ref_known(v___x_104_, 1);
v___x_105_ = vastitas_storage_fill(v_a_45_, v___x_103_, v___x_74_, v___x_72_, v___x_75_, v___x_72_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_105_) == 0)
{
uint64_t v___x_106_; lean_object* v___x_107_; 
lean_dec_ref_known(v___x_105_, 1);
v___x_106_ = 6ULL;
v___x_107_ = vastitas_storage_fill(v_a_45_, v___x_103_, v___x_74_, v___x_98_, v___x_106_, v___x_98_, v___x_76_, v___x_71_, v___x_99_, v___x_96_);
if (lean_obj_tag(v___x_107_) == 0)
{
lean_object* v___x_108_; 
lean_dec_ref_known(v___x_107_, 1);
v___x_108_ = vastitas_storage_store(v_a_45_, v___x_103_, v___x_74_, v___x_98_, v___x_106_, v___x_98_, v___x_76_, v___x_94_, v___x_74_, v___x_71_, v___x_96_, v___x_99_);
if (lean_obj_tag(v___x_108_) == 0)
{
lean_object* v___x_109_; 
lean_dec_ref_known(v___x_108_, 1);
v___x_109_ = vastitas_storage_store(v_a_45_, v___x_103_, v___x_74_, v___x_98_, v___x_106_, v___x_98_, v___x_76_, v___x_74_, v___x_95_, v___x_71_, v___x_88_, v___x_101_);
if (lean_obj_tag(v___x_109_) == 0)
{
uint32_t v___x_110_; uint64_t v___x_111_; lean_object* v___x_112_; 
lean_dec_ref_known(v___x_109_, 1);
v___x_110_ = 3;
v___x_111_ = 40ULL;
v___x_112_ = vastitas_storage_allocate(v_a_45_, v___x_110_, v___x_71_, v___x_111_);
if (lean_obj_tag(v___x_112_) == 0)
{
lean_object* v___x_113_; 
lean_dec_ref_known(v___x_112_, 1);
v___x_113_ = vastitas_storage_fill(v_a_45_, v___x_110_, v___x_74_, v___x_111_, v___x_75_, v___x_111_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_113_) == 0)
{
uint32_t v___x_114_; lean_object* v___x_115_; 
lean_dec_ref_known(v___x_113_, 1);
v___x_114_ = 4;
v___x_115_ = vastitas_storage_allocate(v_a_45_, v___x_114_, v___x_71_, v___x_111_);
if (lean_obj_tag(v___x_115_) == 0)
{
lean_object* v___x_116_; 
lean_dec_ref_known(v___x_115_, 1);
v___x_116_ = vastitas_storage_fill(v_a_45_, v___x_114_, v___x_74_, v___x_111_, v___x_75_, v___x_111_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_116_) == 0)
{
uint32_t v___x_117_; uint64_t v___x_118_; lean_object* v___x_119_; 
lean_dec_ref_known(v___x_116_, 1);
v___x_117_ = 5;
v___x_118_ = 60ULL;
v___x_119_ = vastitas_storage_allocate(v_a_45_, v___x_117_, v___x_71_, v___x_118_);
if (lean_obj_tag(v___x_119_) == 0)
{
lean_object* v___x_120_; 
lean_dec_ref_known(v___x_119_, 1);
v___x_120_ = vastitas_storage_fill(v_a_45_, v___x_117_, v___x_74_, v___x_118_, v___x_75_, v___x_118_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_120_) == 0)
{
uint64_t v___x_121_; lean_object* v___x_122_; 
lean_dec_ref_known(v___x_120_, 1);
v___x_121_ = 8ULL;
v___x_122_ = vastitas_storage_pack3(v_a_45_, v___x_70_, v___x_74_, v___x_80_, v___x_81_, v___x_80_, v___x_76_, v___x_110_, v___x_74_, v___x_121_, v___x_94_, v___x_121_, v___x_76_, v___x_80_, v___x_94_, v___x_98_);
if (lean_obj_tag(v___x_122_) == 0)
{
uint8_t v___x_123_; lean_object* v___x_124_; 
lean_dec_ref_known(v___x_122_, 1);
v___x_123_ = 0;
v___x_124_ = vastitas_gemm_execute(v_a_45_, v___x_110_, v___x_74_, v___x_121_, v___x_94_, v___x_121_, v___x_76_, v___x_76_, v___x_90_, v___x_74_, v___x_94_, v___x_95_, v___x_94_, v___x_76_, v___x_76_, v___x_114_, v___x_74_, v___x_121_, v___x_95_, v___x_121_, v___x_76_, v___x_123_);
if (lean_obj_tag(v___x_124_) == 0)
{
uint64_t v___x_125_; uint64_t v___x_126_; uint64_t v___x_127_; lean_object* v___x_128_; 
lean_dec_ref_known(v___x_124_, 1);
v___x_125_ = 10ULL;
v___x_126_ = 48ULL;
v___x_127_ = 42ULL;
v___x_128_ = vastitas_storage_regroup3(v_a_45_, v___x_114_, v___x_74_, v___x_121_, v___x_95_, v___x_121_, v___x_76_, v___x_110_, v___x_74_, v___x_125_, v___x_98_, v___x_125_, v___x_76_, v___x_80_, v___x_98_, v___x_95_, v___x_126_, v___x_127_);
if (lean_obj_tag(v___x_128_) == 0)
{
lean_object* v___x_129_; 
lean_dec_ref_known(v___x_128_, 1);
v___x_129_ = vastitas_gemm_execute(v_a_45_, v___x_110_, v___x_74_, v___x_125_, v___x_98_, v___x_125_, v___x_76_, v___x_76_, v___x_103_, v___x_74_, v___x_98_, v___x_106_, v___x_98_, v___x_76_, v___x_76_, v___x_117_, v___x_74_, v___x_125_, v___x_106_, v___x_125_, v___x_76_, v___x_123_);
if (lean_obj_tag(v___x_129_) == 0)
{
uint64_t v___x_130_; uint64_t v___x_131_; lean_object* v___x_132_; 
lean_dec_ref_known(v___x_129_, 1);
v___x_130_ = 13819436194074722304ULL;
v___x_131_ = 13820702831469920256ULL;
v___x_132_ = vastitas_storage_expect(v_a_45_, v___x_117_, v___x_74_, v___x_125_, v___x_106_, v___x_125_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_130_, v___x_131_);
if (lean_obj_tag(v___x_132_) == 0)
{
uint64_t v___x_133_; uint64_t v___x_134_; lean_object* v___x_135_; 
lean_dec_ref_known(v___x_132_, 1);
v___x_133_ = 13828830421422440448ULL;
v___x_134_ = 13829252633887506432ULL;
v___x_135_ = vastitas_storage_expect(v_a_45_, v___x_117_, v___x_74_, v___x_125_, v___x_106_, v___x_125_, v___x_76_, v___x_75_, v___x_95_, v___x_71_, v___x_133_, v___x_134_);
if (lean_obj_tag(v___x_135_) == 0)
{
uint64_t v___x_136_; uint64_t v___x_137_; uint64_t v___x_138_; lean_object* v___x_139_; 
lean_dec_ref_known(v___x_135_, 1);
v___x_136_ = 9ULL;
v___x_137_ = 13817747344214458368ULL;
v___x_138_ = 13803532857890570240ULL;
v___x_139_ = vastitas_storage_expect(v_a_45_, v___x_117_, v___x_74_, v___x_125_, v___x_106_, v___x_125_, v___x_76_, v___x_136_, v___x_74_, v___x_71_, v___x_137_, v___x_138_);
if (lean_obj_tag(v___x_139_) == 0)
{
lean_object* v___x_140_; 
lean_dec_ref_known(v___x_139_, 1);
v___x_140_ = vastitas_storage_drop(v_a_45_, v___x_117_);
if (lean_obj_tag(v___x_140_) == 0)
{
lean_object* v___x_141_; 
lean_dec_ref_known(v___x_140_, 1);
v___x_141_ = vastitas_storage_drop(v_a_45_, v___x_114_);
if (lean_obj_tag(v___x_141_) == 0)
{
lean_object* v___x_142_; 
lean_dec_ref_known(v___x_141_, 1);
v___x_142_ = vastitas_storage_drop(v_a_45_, v___x_110_);
if (lean_obj_tag(v___x_142_) == 0)
{
lean_object* v___x_143_; 
lean_dec_ref_known(v___x_142_, 1);
v___x_143_ = vastitas_storage_drop(v_a_45_, v___x_103_);
if (lean_obj_tag(v___x_143_) == 0)
{
lean_object* v___x_144_; 
lean_dec_ref_known(v___x_143_, 1);
v___x_144_ = vastitas_storage_drop(v_a_45_, v___x_90_);
if (lean_obj_tag(v___x_144_) == 0)
{
lean_object* v___x_145_; 
lean_dec_ref_known(v___x_144_, 1);
v___x_145_ = vastitas_storage_drop(v_a_45_, v___x_70_);
if (lean_obj_tag(v___x_145_) == 0)
{
lean_object* v___x_146_; 
lean_dec_ref_known(v___x_145_, 1);
v___x_146_ = lean_box(0);
v_a_47_ = v___x_146_;
goto v___jp_46_;
}
else
{
v___y_58_ = v___x_145_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_144_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_143_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_142_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_141_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_140_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_139_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_135_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_132_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_129_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_128_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_124_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_122_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_120_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_119_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_116_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_115_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_113_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_112_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_109_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_108_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_107_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_105_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_104_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_102_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_100_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_97_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_93_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_92_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_89_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_87_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_84_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_79_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_73_;
goto v___jp_57_;
}
v___jp_46_:
{
lean_object* v___x_48_; 
v___x_48_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_48_) == 0)
{
lean_object* v___x_50_; uint8_t v_isShared_51_; uint8_t v_isSharedCheck_55_; 
v_isSharedCheck_55_ = !lean_is_exclusive(v___x_48_);
if (v_isSharedCheck_55_ == 0)
{
lean_object* v_unused_56_; 
v_unused_56_ = lean_ctor_get(v___x_48_, 0);
lean_dec(v_unused_56_);
v___x_50_ = v___x_48_;
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
else
{
lean_dec(v___x_48_);
v___x_50_ = lean_box(0);
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
v_resetjp_49_:
{
lean_object* v___x_53_; 
if (v_isShared_51_ == 0)
{
lean_ctor_set(v___x_50_, 0, v_a_47_);
v___x_53_ = v___x_50_;
goto v_reusejp_52_;
}
else
{
lean_object* v_reuseFailAlloc_54_; 
v_reuseFailAlloc_54_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_54_, 0, v_a_47_);
v___x_53_ = v_reuseFailAlloc_54_;
goto v_reusejp_52_;
}
v_reusejp_52_:
{
return v___x_53_;
}
}
}
else
{
return v___x_48_;
}
}
v___jp_57_:
{
if (lean_obj_tag(v___y_58_) == 0)
{
lean_object* v_a_59_; 
v_a_59_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_59_);
lean_dec_ref_known(v___y_58_, 1);
v_a_47_ = v_a_59_;
goto v___jp_46_;
}
else
{
lean_object* v_a_60_; lean_object* v___x_61_; 
v_a_60_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_60_);
lean_dec_ref_known(v___y_58_, 1);
v___x_61_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_61_) == 0)
{
lean_object* v___x_63_; uint8_t v_isShared_64_; uint8_t v_isSharedCheck_68_; 
v_isSharedCheck_68_ = !lean_is_exclusive(v___x_61_);
if (v_isSharedCheck_68_ == 0)
{
lean_object* v_unused_69_; 
v_unused_69_ = lean_ctor_get(v___x_61_, 0);
lean_dec(v_unused_69_);
v___x_63_ = v___x_61_;
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
else
{
lean_dec(v___x_61_);
v___x_63_ = lean_box(0);
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
v_resetjp_62_:
{
lean_object* v___x_66_; 
if (v_isShared_64_ == 0)
{
lean_ctor_set_tag(v___x_63_, 1);
lean_ctor_set(v___x_63_, 0, v_a_60_);
v___x_66_ = v___x_63_;
goto v_reusejp_65_;
}
else
{
lean_object* v_reuseFailAlloc_67_; 
v_reuseFailAlloc_67_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_67_, 0, v_a_60_);
v___x_66_ = v_reuseFailAlloc_67_;
goto v_reusejp_65_;
}
v_reusejp_65_:
{
return v___x_66_;
}
}
}
else
{
lean_dec(v_a_60_);
return v___x_61_;
}
}
}
}
else
{
lean_object* v_a_147_; lean_object* v___x_149_; uint8_t v_isShared_150_; uint8_t v_isSharedCheck_154_; 
v_a_147_ = lean_ctor_get(v___x_44_, 0);
v_isSharedCheck_154_ = !lean_is_exclusive(v___x_44_);
if (v_isSharedCheck_154_ == 0)
{
v___x_149_ = v___x_44_;
v_isShared_150_ = v_isSharedCheck_154_;
goto v_resetjp_148_;
}
else
{
lean_inc(v_a_147_);
lean_dec(v___x_44_);
v___x_149_ = lean_box(0);
v_isShared_150_ = v_isSharedCheck_154_;
goto v_resetjp_148_;
}
v_resetjp_148_:
{
lean_object* v___x_152_; 
if (v_isShared_150_ == 0)
{
v___x_152_ = v___x_149_;
goto v_reusejp_151_;
}
else
{
lean_object* v_reuseFailAlloc_153_; 
v_reuseFailAlloc_153_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_153_, 0, v_a_147_);
v___x_152_ = v_reuseFailAlloc_153_;
goto v_reusejp_151_;
}
v_reusejp_151_:
{
return v___x_152_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object* v_a_155_){
_start:
{
lean_object* v_res_156_; 
v_res_156_ = lp_allocation__audit_generatedOnce();
return v_res_156_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure(){
_start:
{
uint64_t v___x_158_; lean_object* v___x_159_; 
v___x_158_ = 9223372036854775807ULL;
v___x_159_ = vastitas_storage_new(v___x_158_);
if (lean_obj_tag(v___x_159_) == 0)
{
lean_object* v_a_160_; lean_object* v_a_162_; lean_object* v___y_173_; uint32_t v___x_185_; uint8_t v___x_186_; uint64_t v___x_187_; lean_object* v___x_188_; 
v_a_160_ = lean_ctor_get(v___x_159_, 0);
lean_inc(v_a_160_);
lean_dec_ref_known(v___x_159_, 1);
v___x_185_ = 0;
v___x_186_ = 1;
v___x_187_ = 24ULL;
v___x_188_ = vastitas_storage_allocate(v_a_160_, v___x_185_, v___x_186_, v___x_187_);
if (lean_obj_tag(v___x_188_) == 0)
{
uint64_t v___x_189_; uint64_t v___x_190_; uint8_t v___x_191_; uint64_t v___x_192_; uint64_t v___x_193_; lean_object* v___x_194_; 
lean_dec_ref_known(v___x_188_, 1);
v___x_189_ = 0ULL;
v___x_190_ = 1ULL;
v___x_191_ = 0;
v___x_192_ = 13842939354630062080ULL;
v___x_193_ = 4613937818241073152ULL;
v___x_194_ = vastitas_storage_fill(v_a_160_, v___x_185_, v___x_189_, v___x_187_, v___x_190_, v___x_187_, v___x_191_, v___x_186_, v___x_192_, v___x_193_);
if (lean_obj_tag(v___x_194_) == 0)
{
uint64_t v___x_195_; uint64_t v___x_196_; uint64_t v___x_197_; uint64_t v___x_198_; lean_object* v___x_199_; 
lean_dec_ref_known(v___x_194_, 1);
v___x_195_ = 2ULL;
v___x_196_ = 12ULL;
v___x_197_ = 4593671619917905920ULL;
v___x_198_ = 4598175219545276416ULL;
v___x_199_ = vastitas_storage_fill(v_a_160_, v___x_185_, v___x_189_, v___x_195_, v___x_196_, v___x_195_, v___x_191_, v___x_186_, v___x_197_, v___x_198_);
if (lean_obj_tag(v___x_199_) == 0)
{
uint64_t v___x_200_; uint64_t v___x_201_; lean_object* v___x_202_; 
lean_dec_ref_known(v___x_199_, 1);
v___x_200_ = 4607182418800017408ULL;
v___x_201_ = 13826050856027422720ULL;
v___x_202_ = vastitas_storage_store(v_a_160_, v___x_185_, v___x_189_, v___x_195_, v___x_196_, v___x_195_, v___x_191_, v___x_189_, v___x_189_, v___x_186_, v___x_200_, v___x_201_);
if (lean_obj_tag(v___x_202_) == 0)
{
uint64_t v___x_203_; lean_object* v___x_204_; 
lean_dec_ref_known(v___x_202_, 1);
v___x_203_ = 4604930618986332160ULL;
v___x_204_ = vastitas_storage_store(v_a_160_, v___x_185_, v___x_189_, v___x_195_, v___x_196_, v___x_195_, v___x_191_, v___x_190_, v___x_190_, v___x_186_, v___x_201_, v___x_203_);
if (lean_obj_tag(v___x_204_) == 0)
{
uint32_t v___x_205_; uint64_t v___x_206_; lean_object* v___x_207_; 
lean_dec_ref_known(v___x_204_, 1);
v___x_205_ = 1;
v___x_206_ = 15ULL;
v___x_207_ = vastitas_storage_allocate(v_a_160_, v___x_205_, v___x_186_, v___x_206_);
if (lean_obj_tag(v___x_207_) == 0)
{
lean_object* v___x_208_; 
lean_dec_ref_known(v___x_207_, 1);
v___x_208_ = vastitas_storage_fill(v_a_160_, v___x_205_, v___x_189_, v___x_206_, v___x_190_, v___x_206_, v___x_191_, v___x_186_, v___x_192_, v___x_193_);
if (lean_obj_tag(v___x_208_) == 0)
{
uint64_t v___x_209_; uint64_t v___x_210_; uint64_t v___x_211_; lean_object* v___x_212_; 
lean_dec_ref_known(v___x_208_, 1);
v___x_209_ = 3ULL;
v___x_210_ = 5ULL;
v___x_211_ = 13821547256400052224ULL;
v___x_212_ = vastitas_storage_fill(v_a_160_, v___x_205_, v___x_189_, v___x_209_, v___x_210_, v___x_209_, v___x_191_, v___x_186_, v___x_211_, v___x_197_);
if (lean_obj_tag(v___x_212_) == 0)
{
uint64_t v___x_213_; uint64_t v___x_214_; lean_object* v___x_215_; 
lean_dec_ref_known(v___x_212_, 1);
v___x_213_ = 4ULL;
v___x_214_ = 4602678819172646912ULL;
v___x_215_ = vastitas_storage_store(v_a_160_, v___x_205_, v___x_189_, v___x_209_, v___x_210_, v___x_209_, v___x_191_, v___x_189_, v___x_213_, v___x_186_, v___x_214_, v___x_198_);
if (lean_obj_tag(v___x_215_) == 0)
{
uint64_t v___x_216_; lean_object* v___x_217_; 
lean_dec_ref_known(v___x_215_, 1);
v___x_216_ = 13828302655841107968ULL;
v___x_217_ = vastitas_storage_store(v_a_160_, v___x_205_, v___x_189_, v___x_209_, v___x_210_, v___x_209_, v___x_191_, v___x_195_, v___x_189_, v___x_186_, v___x_216_, v___x_201_);
if (lean_obj_tag(v___x_217_) == 0)
{
uint32_t v___x_218_; lean_object* v___x_219_; 
lean_dec_ref_known(v___x_217_, 1);
v___x_218_ = 2;
v___x_219_ = vastitas_storage_allocate(v_a_160_, v___x_218_, v___x_186_, v___x_187_);
if (lean_obj_tag(v___x_219_) == 0)
{
lean_object* v___x_220_; 
lean_dec_ref_known(v___x_219_, 1);
v___x_220_ = vastitas_storage_fill(v_a_160_, v___x_218_, v___x_189_, v___x_187_, v___x_190_, v___x_187_, v___x_191_, v___x_186_, v___x_192_, v___x_193_);
if (lean_obj_tag(v___x_220_) == 0)
{
uint64_t v___x_221_; lean_object* v___x_222_; 
lean_dec_ref_known(v___x_220_, 1);
v___x_221_ = 6ULL;
v___x_222_ = vastitas_storage_fill(v_a_160_, v___x_218_, v___x_189_, v___x_213_, v___x_221_, v___x_213_, v___x_191_, v___x_186_, v___x_214_, v___x_211_);
if (lean_obj_tag(v___x_222_) == 0)
{
lean_object* v___x_223_; 
lean_dec_ref_known(v___x_222_, 1);
v___x_223_ = vastitas_storage_store(v_a_160_, v___x_218_, v___x_189_, v___x_213_, v___x_221_, v___x_213_, v___x_191_, v___x_209_, v___x_189_, v___x_186_, v___x_211_, v___x_214_);
if (lean_obj_tag(v___x_223_) == 0)
{
lean_object* v___x_224_; 
lean_dec_ref_known(v___x_223_, 1);
v___x_224_ = vastitas_storage_store(v_a_160_, v___x_218_, v___x_189_, v___x_213_, v___x_221_, v___x_213_, v___x_191_, v___x_189_, v___x_210_, v___x_186_, v___x_203_, v___x_216_);
if (lean_obj_tag(v___x_224_) == 0)
{
uint32_t v___x_225_; uint64_t v___x_226_; lean_object* v___x_227_; 
lean_dec_ref_known(v___x_224_, 1);
v___x_225_ = 3;
v___x_226_ = 40ULL;
v___x_227_ = vastitas_storage_allocate(v_a_160_, v___x_225_, v___x_186_, v___x_226_);
if (lean_obj_tag(v___x_227_) == 0)
{
lean_object* v___x_228_; 
lean_dec_ref_known(v___x_227_, 1);
v___x_228_ = vastitas_storage_fill(v_a_160_, v___x_225_, v___x_189_, v___x_226_, v___x_190_, v___x_226_, v___x_191_, v___x_186_, v___x_192_, v___x_193_);
if (lean_obj_tag(v___x_228_) == 0)
{
uint32_t v___x_229_; lean_object* v___x_230_; 
lean_dec_ref_known(v___x_228_, 1);
v___x_229_ = 4;
v___x_230_ = vastitas_storage_allocate(v_a_160_, v___x_229_, v___x_186_, v___x_226_);
if (lean_obj_tag(v___x_230_) == 0)
{
lean_object* v___x_231_; 
lean_dec_ref_known(v___x_230_, 1);
v___x_231_ = vastitas_storage_fill(v_a_160_, v___x_229_, v___x_189_, v___x_226_, v___x_190_, v___x_226_, v___x_191_, v___x_186_, v___x_192_, v___x_193_);
if (lean_obj_tag(v___x_231_) == 0)
{
uint32_t v___x_232_; uint64_t v___x_233_; lean_object* v___x_234_; 
lean_dec_ref_known(v___x_231_, 1);
v___x_232_ = 5;
v___x_233_ = 60ULL;
v___x_234_ = vastitas_storage_allocate(v_a_160_, v___x_232_, v___x_186_, v___x_233_);
if (lean_obj_tag(v___x_234_) == 0)
{
lean_object* v___x_235_; 
lean_dec_ref_known(v___x_234_, 1);
v___x_235_ = vastitas_storage_fill(v_a_160_, v___x_232_, v___x_189_, v___x_233_, v___x_190_, v___x_233_, v___x_191_, v___x_186_, v___x_192_, v___x_193_);
if (lean_obj_tag(v___x_235_) == 0)
{
uint64_t v___x_236_; lean_object* v___x_237_; 
lean_dec_ref_known(v___x_235_, 1);
v___x_236_ = 8ULL;
v___x_237_ = vastitas_storage_pack3(v_a_160_, v___x_185_, v___x_189_, v___x_195_, v___x_196_, v___x_195_, v___x_191_, v___x_225_, v___x_189_, v___x_236_, v___x_209_, v___x_236_, v___x_191_, v___x_195_, v___x_209_, v___x_213_);
if (lean_obj_tag(v___x_237_) == 0)
{
uint8_t v___x_238_; lean_object* v___x_239_; 
lean_dec_ref_known(v___x_237_, 1);
v___x_238_ = 0;
v___x_239_ = vastitas_gemm_execute(v_a_160_, v___x_225_, v___x_189_, v___x_236_, v___x_209_, v___x_236_, v___x_191_, v___x_191_, v___x_205_, v___x_189_, v___x_209_, v___x_210_, v___x_209_, v___x_191_, v___x_191_, v___x_229_, v___x_189_, v___x_236_, v___x_210_, v___x_236_, v___x_191_, v___x_238_);
if (lean_obj_tag(v___x_239_) == 0)
{
uint64_t v___x_240_; uint64_t v___x_241_; uint64_t v___x_242_; lean_object* v___x_243_; 
lean_dec_ref_known(v___x_239_, 1);
v___x_240_ = 10ULL;
v___x_241_ = 48ULL;
v___x_242_ = 42ULL;
v___x_243_ = vastitas_storage_regroup3(v_a_160_, v___x_229_, v___x_189_, v___x_236_, v___x_210_, v___x_236_, v___x_191_, v___x_225_, v___x_189_, v___x_240_, v___x_213_, v___x_240_, v___x_191_, v___x_195_, v___x_213_, v___x_210_, v___x_241_, v___x_242_);
if (lean_obj_tag(v___x_243_) == 0)
{
lean_object* v___x_244_; 
lean_dec_ref_known(v___x_243_, 1);
v___x_244_ = vastitas_gemm_execute(v_a_160_, v___x_225_, v___x_189_, v___x_240_, v___x_213_, v___x_240_, v___x_191_, v___x_191_, v___x_218_, v___x_189_, v___x_213_, v___x_221_, v___x_213_, v___x_191_, v___x_191_, v___x_232_, v___x_189_, v___x_240_, v___x_221_, v___x_240_, v___x_191_, v___x_238_);
if (lean_obj_tag(v___x_244_) == 0)
{
uint64_t v___x_245_; uint64_t v___x_246_; lean_object* v___x_247_; 
lean_dec_ref_known(v___x_244_, 1);
v___x_245_ = 13819436194074722305ULL;
v___x_246_ = 13820702831469920256ULL;
v___x_247_ = vastitas_storage_expect(v_a_160_, v___x_232_, v___x_189_, v___x_240_, v___x_221_, v___x_240_, v___x_191_, v___x_189_, v___x_189_, v___x_186_, v___x_245_, v___x_246_);
if (lean_obj_tag(v___x_247_) == 0)
{
uint64_t v___x_248_; uint64_t v___x_249_; lean_object* v___x_250_; 
lean_dec_ref_known(v___x_247_, 1);
v___x_248_ = 13828830421422440448ULL;
v___x_249_ = 13829252633887506432ULL;
v___x_250_ = vastitas_storage_expect(v_a_160_, v___x_232_, v___x_189_, v___x_240_, v___x_221_, v___x_240_, v___x_191_, v___x_190_, v___x_210_, v___x_186_, v___x_248_, v___x_249_);
if (lean_obj_tag(v___x_250_) == 0)
{
uint64_t v___x_251_; uint64_t v___x_252_; uint64_t v___x_253_; lean_object* v___x_254_; 
lean_dec_ref_known(v___x_250_, 1);
v___x_251_ = 9ULL;
v___x_252_ = 13817747344214458368ULL;
v___x_253_ = 13803532857890570240ULL;
v___x_254_ = vastitas_storage_expect(v_a_160_, v___x_232_, v___x_189_, v___x_240_, v___x_221_, v___x_240_, v___x_191_, v___x_251_, v___x_189_, v___x_186_, v___x_252_, v___x_253_);
if (lean_obj_tag(v___x_254_) == 0)
{
lean_object* v___x_255_; 
lean_dec_ref_known(v___x_254_, 1);
v___x_255_ = vastitas_storage_drop(v_a_160_, v___x_232_);
if (lean_obj_tag(v___x_255_) == 0)
{
lean_object* v___x_256_; 
lean_dec_ref_known(v___x_255_, 1);
v___x_256_ = vastitas_storage_drop(v_a_160_, v___x_229_);
if (lean_obj_tag(v___x_256_) == 0)
{
lean_object* v___x_257_; 
lean_dec_ref_known(v___x_256_, 1);
v___x_257_ = vastitas_storage_drop(v_a_160_, v___x_225_);
if (lean_obj_tag(v___x_257_) == 0)
{
lean_object* v___x_258_; 
lean_dec_ref_known(v___x_257_, 1);
v___x_258_ = vastitas_storage_drop(v_a_160_, v___x_218_);
if (lean_obj_tag(v___x_258_) == 0)
{
lean_object* v___x_259_; 
lean_dec_ref_known(v___x_258_, 1);
v___x_259_ = vastitas_storage_drop(v_a_160_, v___x_205_);
if (lean_obj_tag(v___x_259_) == 0)
{
lean_object* v___x_260_; 
lean_dec_ref_known(v___x_259_, 1);
v___x_260_ = vastitas_storage_drop(v_a_160_, v___x_185_);
if (lean_obj_tag(v___x_260_) == 0)
{
lean_object* v___x_261_; 
lean_dec_ref_known(v___x_260_, 1);
v___x_261_ = lean_box(0);
v_a_162_ = v___x_261_;
goto v___jp_161_;
}
else
{
v___y_173_ = v___x_260_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_259_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_258_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_257_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_256_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_255_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_254_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_250_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_247_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_244_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_243_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_239_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_237_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_235_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_234_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_231_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_230_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_228_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_227_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_224_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_223_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_222_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_220_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_219_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_217_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_215_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_212_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_208_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_207_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_204_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_202_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_199_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_194_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_188_;
goto v___jp_172_;
}
v___jp_161_:
{
lean_object* v___x_163_; 
v___x_163_ = vastitas_storage_close(v_a_160_);
lean_dec(v_a_160_);
if (lean_obj_tag(v___x_163_) == 0)
{
lean_object* v___x_165_; uint8_t v_isShared_166_; uint8_t v_isSharedCheck_170_; 
v_isSharedCheck_170_ = !lean_is_exclusive(v___x_163_);
if (v_isSharedCheck_170_ == 0)
{
lean_object* v_unused_171_; 
v_unused_171_ = lean_ctor_get(v___x_163_, 0);
lean_dec(v_unused_171_);
v___x_165_ = v___x_163_;
v_isShared_166_ = v_isSharedCheck_170_;
goto v_resetjp_164_;
}
else
{
lean_dec(v___x_163_);
v___x_165_ = lean_box(0);
v_isShared_166_ = v_isSharedCheck_170_;
goto v_resetjp_164_;
}
v_resetjp_164_:
{
lean_object* v___x_168_; 
if (v_isShared_166_ == 0)
{
lean_ctor_set(v___x_165_, 0, v_a_162_);
v___x_168_ = v___x_165_;
goto v_reusejp_167_;
}
else
{
lean_object* v_reuseFailAlloc_169_; 
v_reuseFailAlloc_169_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_169_, 0, v_a_162_);
v___x_168_ = v_reuseFailAlloc_169_;
goto v_reusejp_167_;
}
v_reusejp_167_:
{
return v___x_168_;
}
}
}
else
{
return v___x_163_;
}
}
v___jp_172_:
{
if (lean_obj_tag(v___y_173_) == 0)
{
lean_object* v_a_174_; 
v_a_174_ = lean_ctor_get(v___y_173_, 0);
lean_inc(v_a_174_);
lean_dec_ref_known(v___y_173_, 1);
v_a_162_ = v_a_174_;
goto v___jp_161_;
}
else
{
lean_object* v_a_175_; lean_object* v___x_176_; 
v_a_175_ = lean_ctor_get(v___y_173_, 0);
lean_inc(v_a_175_);
lean_dec_ref_known(v___y_173_, 1);
v___x_176_ = vastitas_storage_close(v_a_160_);
lean_dec(v_a_160_);
if (lean_obj_tag(v___x_176_) == 0)
{
lean_object* v___x_178_; uint8_t v_isShared_179_; uint8_t v_isSharedCheck_183_; 
v_isSharedCheck_183_ = !lean_is_exclusive(v___x_176_);
if (v_isSharedCheck_183_ == 0)
{
lean_object* v_unused_184_; 
v_unused_184_ = lean_ctor_get(v___x_176_, 0);
lean_dec(v_unused_184_);
v___x_178_ = v___x_176_;
v_isShared_179_ = v_isSharedCheck_183_;
goto v_resetjp_177_;
}
else
{
lean_dec(v___x_176_);
v___x_178_ = lean_box(0);
v_isShared_179_ = v_isSharedCheck_183_;
goto v_resetjp_177_;
}
v_resetjp_177_:
{
lean_object* v___x_181_; 
if (v_isShared_179_ == 0)
{
lean_ctor_set_tag(v___x_178_, 1);
lean_ctor_set(v___x_178_, 0, v_a_175_);
v___x_181_ = v___x_178_;
goto v_reusejp_180_;
}
else
{
lean_object* v_reuseFailAlloc_182_; 
v_reuseFailAlloc_182_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_182_, 0, v_a_175_);
v___x_181_ = v_reuseFailAlloc_182_;
goto v_reusejp_180_;
}
v_reusejp_180_:
{
return v___x_181_;
}
}
}
else
{
lean_dec(v_a_175_);
return v___x_176_;
}
}
}
}
else
{
lean_object* v_a_262_; lean_object* v___x_264_; uint8_t v_isShared_265_; uint8_t v_isSharedCheck_269_; 
v_a_262_ = lean_ctor_get(v___x_159_, 0);
v_isSharedCheck_269_ = !lean_is_exclusive(v___x_159_);
if (v_isSharedCheck_269_ == 0)
{
v___x_264_ = v___x_159_;
v_isShared_265_ = v_isSharedCheck_269_;
goto v_resetjp_263_;
}
else
{
lean_inc(v_a_262_);
lean_dec(v___x_159_);
v___x_264_ = lean_box(0);
v_isShared_265_ = v_isSharedCheck_269_;
goto v_resetjp_263_;
}
v_resetjp_263_:
{
lean_object* v___x_267_; 
if (v_isShared_265_ == 0)
{
v___x_267_ = v___x_264_;
goto v_reusejp_266_;
}
else
{
lean_object* v_reuseFailAlloc_268_; 
v_reuseFailAlloc_268_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_268_, 0, v_a_262_);
v___x_267_ = v_reuseFailAlloc_268_;
goto v_reusejp_266_;
}
v_reusejp_266_:
{
return v___x_267_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object* v_a_270_){
_start:
{
lean_object* v_res_271_; 
v_res_271_ = lp_allocation__audit_generatedFailure();
return v_res_271_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object* v_phase_274_, lean_object* v_a_00___x40___internal___hyg_275_){
_start:
{
uint32_t v_phase_boxed_276_; lean_object* v_res_277_; 
v_phase_boxed_276_ = lean_unbox_uint32(v_phase_274_);
lean_dec(v_phase_274_);
v_res_277_ = audit_mark_lean(v_phase_boxed_276_);
return v_res_277_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object* v_a_278_, lean_object* v_scope_279_, lean_object* v_range_280_, lean_object* v_b_281_, lean_object* v_i_282_){
_start:
{
lean_object* v_stop_284_; lean_object* v_step_285_; uint8_t v___x_286_; 
v_stop_284_ = lean_ctor_get(v_range_280_, 1);
v_step_285_ = lean_ctor_get(v_range_280_, 2);
v___x_286_ = lean_nat_dec_lt(v_i_282_, v_stop_284_);
if (v___x_286_ == 0)
{
lean_object* v___x_287_; 
lean_dec(v_i_282_);
v___x_287_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_287_, 0, v_b_281_);
return v___x_287_;
}
else
{
uint32_t v___x_288_; uint64_t v___x_289_; uint64_t v___x_290_; uint64_t v___x_291_; lean_object* v___x_292_; uint8_t v___x_293_; uint32_t v___x_294_; uint64_t v___x_295_; uint64_t v___x_296_; uint32_t v___x_297_; uint64_t v___x_298_; uint32_t v___x_299_; uint32_t v___x_300_; uint64_t v___x_301_; uint32_t v___x_302_; lean_object* v___x_303_; uint64_t v___x_304_; lean_object* v___x_305_; 
v___x_288_ = 0;
v___x_289_ = 0ULL;
v___x_290_ = 2ULL;
v___x_291_ = 12ULL;
v___x_292_ = lean_unsigned_to_nat(0u);
v___x_293_ = lean_nat_dec_eq(v_scope_279_, v___x_292_);
v___x_294_ = 3;
v___x_295_ = 3ULL;
v___x_296_ = 4ULL;
v___x_297_ = 1;
v___x_298_ = 5ULL;
v___x_299_ = 4;
v___x_300_ = 2;
v___x_301_ = 6ULL;
v___x_302_ = 5;
v___x_303_ = lean_box(0);
v___x_304_ = 8ULL;
v___x_305_ = vastitas_storage_pack3(v_a_278_, v___x_288_, v___x_289_, v___x_290_, v___x_291_, v___x_290_, v___x_293_, v___x_294_, v___x_289_, v___x_304_, v___x_295_, v___x_304_, v___x_293_, v___x_290_, v___x_295_, v___x_296_);
if (lean_obj_tag(v___x_305_) == 0)
{
uint8_t v___x_306_; lean_object* v___x_307_; 
lean_dec_ref_known(v___x_305_, 1);
v___x_306_ = 0;
v___x_307_ = vastitas_gemm_execute(v_a_278_, v___x_294_, v___x_289_, v___x_304_, v___x_295_, v___x_304_, v___x_293_, v___x_293_, v___x_297_, v___x_289_, v___x_295_, v___x_298_, v___x_295_, v___x_293_, v___x_293_, v___x_299_, v___x_289_, v___x_304_, v___x_298_, v___x_304_, v___x_293_, v___x_306_);
if (lean_obj_tag(v___x_307_) == 0)
{
uint64_t v___x_308_; uint64_t v___x_309_; uint64_t v___x_310_; lean_object* v___x_311_; 
lean_dec_ref_known(v___x_307_, 1);
v___x_308_ = 10ULL;
v___x_309_ = 48ULL;
v___x_310_ = 42ULL;
v___x_311_ = vastitas_storage_regroup3(v_a_278_, v___x_299_, v___x_289_, v___x_304_, v___x_298_, v___x_304_, v___x_293_, v___x_294_, v___x_289_, v___x_308_, v___x_296_, v___x_308_, v___x_293_, v___x_290_, v___x_296_, v___x_298_, v___x_309_, v___x_310_);
if (lean_obj_tag(v___x_311_) == 0)
{
lean_object* v___x_312_; 
lean_dec_ref_known(v___x_311_, 1);
v___x_312_ = vastitas_gemm_execute(v_a_278_, v___x_294_, v___x_289_, v___x_308_, v___x_296_, v___x_308_, v___x_293_, v___x_293_, v___x_300_, v___x_289_, v___x_296_, v___x_301_, v___x_296_, v___x_293_, v___x_293_, v___x_302_, v___x_289_, v___x_308_, v___x_301_, v___x_308_, v___x_293_, v___x_306_);
if (lean_obj_tag(v___x_312_) == 0)
{
lean_object* v___x_313_; 
lean_dec_ref_known(v___x_312_, 1);
v___x_313_ = lean_nat_add(v_i_282_, v_step_285_);
lean_dec(v_i_282_);
v_b_281_ = v___x_303_;
v_i_282_ = v___x_313_;
goto _start;
}
else
{
lean_dec(v_i_282_);
return v___x_312_;
}
}
else
{
lean_dec(v_i_282_);
return v___x_311_;
}
}
else
{
lean_dec(v_i_282_);
return v___x_307_;
}
}
else
{
lean_dec(v_i_282_);
return v___x_305_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object* v_a_315_, lean_object* v_scope_316_, lean_object* v_range_317_, lean_object* v_b_318_, lean_object* v_i_319_, lean_object* v___y_320_){
_start:
{
lean_object* v_res_321_; 
v_res_321_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_315_, v_scope_316_, v_range_317_, v_b_318_, v_i_319_);
lean_dec_ref(v_range_317_);
lean_dec(v_scope_316_);
lean_dec(v_a_315_);
return v_res_321_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object* v_range_322_, lean_object* v_b_323_, lean_object* v_i_324_){
_start:
{
lean_object* v_stop_326_; lean_object* v_step_327_; uint8_t v___x_328_; 
v_stop_326_ = lean_ctor_get(v_range_322_, 1);
v_step_327_ = lean_ctor_get(v_range_322_, 2);
v___x_328_ = lean_nat_dec_lt(v_i_324_, v_stop_326_);
if (v___x_328_ == 0)
{
lean_object* v___x_329_; 
lean_dec(v_i_324_);
v___x_329_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_329_, 0, v_b_323_);
return v___x_329_;
}
else
{
lean_object* v___x_330_; lean_object* v___x_331_; 
v___x_330_ = lean_box(0);
v___x_331_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_331_) == 0)
{
lean_object* v___x_332_; 
lean_dec_ref_known(v___x_331_, 1);
v___x_332_ = lean_nat_add(v_i_324_, v_step_327_);
lean_dec(v_i_324_);
v_b_323_ = v___x_330_;
v_i_324_ = v___x_332_;
goto _start;
}
else
{
lean_dec(v_i_324_);
return v___x_331_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object* v_range_334_, lean_object* v_b_335_, lean_object* v_i_336_, lean_object* v___y_337_){
_start:
{
lean_object* v_res_338_; 
v_res_338_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_334_, v_b_335_, v_i_336_);
lean_dec_ref(v_range_334_);
return v_res_338_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_347_){
_start:
{
lean_object* v___x_349_; lean_object* v___x_350_; lean_object* v_impl_351_; lean_object* v___x_352_; lean_object* v___x_353_; lean_object* v___x_354_; lean_object* v___x_355_; lean_object* v_scope_356_; lean_object* v___x_357_; lean_object* v___x_358_; lean_object* v___x_359_; lean_object* v___x_360_; lean_object* v_reps_361_; lean_object* v___x_362_; lean_object* v___x_363_; lean_object* v___x_364_; uint8_t v_verify_365_; uint32_t v___x_366_; lean_object* v___x_367_; 
v___x_349_ = ((lean_object*)(lp_allocation__audit_main___closed__0));
v___x_350_ = lean_unsigned_to_nat(0u);
v_impl_351_ = l_List_get_x21Internal___redArg(v___x_349_, v_args_347_, v___x_350_);
v___x_352_ = lean_unsigned_to_nat(1u);
v___x_353_ = l_List_get_x21Internal___redArg(v___x_349_, v_args_347_, v___x_352_);
v___x_354_ = lean_string_utf8_byte_size(v___x_353_);
v___x_355_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_355_, 0, v___x_353_);
lean_ctor_set(v___x_355_, 1, v___x_350_);
lean_ctor_set(v___x_355_, 2, v___x_354_);
v_scope_356_ = l_String_Slice_toNat_x21(v___x_355_);
lean_dec_ref_known(v___x_355_, 3);
v___x_357_ = lean_unsigned_to_nat(2u);
v___x_358_ = l_List_get_x21Internal___redArg(v___x_349_, v_args_347_, v___x_357_);
v___x_359_ = lean_string_utf8_byte_size(v___x_358_);
v___x_360_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_360_, 0, v___x_358_);
lean_ctor_set(v___x_360_, 1, v___x_350_);
lean_ctor_set(v___x_360_, 2, v___x_359_);
v_reps_361_ = l_String_Slice_toNat_x21(v___x_360_);
lean_dec_ref_known(v___x_360_, 3);
v___x_362_ = lean_unsigned_to_nat(3u);
v___x_363_ = l_List_get_x21Internal___redArg(v___x_349_, v_args_347_, v___x_362_);
lean_dec(v_args_347_);
v___x_364_ = ((lean_object*)(lp_allocation__audit_main___closed__1));
v_verify_365_ = lean_string_dec_eq(v___x_363_, v___x_364_);
lean_dec(v___x_363_);
v___x_366_ = 1;
v___x_367_ = audit_mark_lean(v___x_366_);
if (lean_obj_tag(v___x_367_) == 0)
{
lean_object* v___x_368_; 
lean_dec_ref_known(v___x_367_, 1);
v___x_368_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_368_) == 0)
{
uint32_t v___x_369_; lean_object* v___x_370_; 
lean_dec_ref_known(v___x_368_, 1);
v___x_369_ = 2;
v___x_370_ = audit_mark_lean(v___x_369_);
if (lean_obj_tag(v___x_370_) == 0)
{
lean_object* v___x_371_; uint8_t v___x_372_; 
lean_dec_ref_known(v___x_370_, 1);
v___x_371_ = ((lean_object*)(lp_allocation__audit_main___closed__2));
v___x_372_ = lean_string_dec_eq(v_impl_351_, v___x_371_);
if (v___x_372_ == 0)
{
lean_object* v___x_373_; uint8_t v___x_374_; 
v___x_373_ = ((lean_object*)(lp_allocation__audit_main___closed__3));
v___x_374_ = lean_string_dec_eq(v_impl_351_, v___x_373_);
lean_dec(v_impl_351_);
if (v___x_374_ == 0)
{
uint8_t v___x_375_; 
v___x_375_ = lean_nat_dec_eq(v_scope_356_, v___x_350_);
if (v___x_375_ == 0)
{
uint64_t v___x_376_; lean_object* v___x_377_; 
v___x_376_ = 9223372036854775807ULL;
v___x_377_ = vastitas_storage_new(v___x_376_);
if (lean_obj_tag(v___x_377_) == 0)
{
lean_object* v_a_378_; lean_object* v___y_380_; uint32_t v___x_393_; uint8_t v___x_394_; uint64_t v___x_395_; lean_object* v___x_396_; 
v_a_378_ = lean_ctor_get(v___x_377_, 0);
lean_inc(v_a_378_);
lean_dec_ref_known(v___x_377_, 1);
v___x_393_ = 0;
v___x_394_ = 1;
v___x_395_ = 24ULL;
v___x_396_ = vastitas_storage_allocate(v_a_378_, v___x_393_, v___x_394_, v___x_395_);
if (lean_obj_tag(v___x_396_) == 0)
{
uint64_t v___x_397_; uint64_t v___x_398_; uint64_t v___x_399_; uint64_t v___x_400_; lean_object* v___x_401_; 
lean_dec_ref_known(v___x_396_, 1);
v___x_397_ = 0ULL;
v___x_398_ = 1ULL;
v___x_399_ = 13842939354630062080ULL;
v___x_400_ = 4613937818241073152ULL;
v___x_401_ = vastitas_storage_fill(v_a_378_, v___x_393_, v___x_397_, v___x_395_, v___x_398_, v___x_395_, v___x_375_, v___x_394_, v___x_399_, v___x_400_);
if (lean_obj_tag(v___x_401_) == 0)
{
uint64_t v___x_402_; uint64_t v___x_403_; uint64_t v___x_404_; uint64_t v___x_405_; lean_object* v___x_406_; 
lean_dec_ref_known(v___x_401_, 1);
v___x_402_ = 2ULL;
v___x_403_ = 12ULL;
v___x_404_ = 4593671619917905920ULL;
v___x_405_ = 4598175219545276416ULL;
v___x_406_ = vastitas_storage_fill(v_a_378_, v___x_393_, v___x_397_, v___x_402_, v___x_403_, v___x_402_, v___x_375_, v___x_394_, v___x_404_, v___x_405_);
if (lean_obj_tag(v___x_406_) == 0)
{
uint64_t v___x_407_; uint64_t v___x_408_; lean_object* v___x_409_; 
lean_dec_ref_known(v___x_406_, 1);
v___x_407_ = 4607182418800017408ULL;
v___x_408_ = 13826050856027422720ULL;
v___x_409_ = vastitas_storage_store(v_a_378_, v___x_393_, v___x_397_, v___x_402_, v___x_403_, v___x_402_, v___x_375_, v___x_397_, v___x_397_, v___x_394_, v___x_407_, v___x_408_);
if (lean_obj_tag(v___x_409_) == 0)
{
uint64_t v___x_410_; lean_object* v___x_411_; 
lean_dec_ref_known(v___x_409_, 1);
v___x_410_ = 4604930618986332160ULL;
v___x_411_ = vastitas_storage_store(v_a_378_, v___x_393_, v___x_397_, v___x_402_, v___x_403_, v___x_402_, v___x_375_, v___x_398_, v___x_398_, v___x_394_, v___x_408_, v___x_410_);
if (lean_obj_tag(v___x_411_) == 0)
{
uint64_t v___x_412_; lean_object* v___x_413_; 
lean_dec_ref_known(v___x_411_, 1);
v___x_412_ = 15ULL;
v___x_413_ = vastitas_storage_allocate(v_a_378_, v___x_366_, v___x_394_, v___x_412_);
if (lean_obj_tag(v___x_413_) == 0)
{
lean_object* v___x_414_; 
lean_dec_ref_known(v___x_413_, 1);
v___x_414_ = vastitas_storage_fill(v_a_378_, v___x_366_, v___x_397_, v___x_412_, v___x_398_, v___x_412_, v___x_375_, v___x_394_, v___x_399_, v___x_400_);
if (lean_obj_tag(v___x_414_) == 0)
{
uint64_t v___x_415_; uint64_t v___x_416_; uint64_t v___x_417_; lean_object* v___x_418_; 
lean_dec_ref_known(v___x_414_, 1);
v___x_415_ = 3ULL;
v___x_416_ = 5ULL;
v___x_417_ = 13821547256400052224ULL;
v___x_418_ = vastitas_storage_fill(v_a_378_, v___x_366_, v___x_397_, v___x_415_, v___x_416_, v___x_415_, v___x_375_, v___x_394_, v___x_417_, v___x_404_);
if (lean_obj_tag(v___x_418_) == 0)
{
uint64_t v___x_419_; uint64_t v___x_420_; lean_object* v___x_421_; 
lean_dec_ref_known(v___x_418_, 1);
v___x_419_ = 4ULL;
v___x_420_ = 4602678819172646912ULL;
v___x_421_ = vastitas_storage_store(v_a_378_, v___x_366_, v___x_397_, v___x_415_, v___x_416_, v___x_415_, v___x_375_, v___x_397_, v___x_419_, v___x_394_, v___x_420_, v___x_405_);
if (lean_obj_tag(v___x_421_) == 0)
{
uint64_t v___x_422_; lean_object* v___x_423_; 
lean_dec_ref_known(v___x_421_, 1);
v___x_422_ = 13828302655841107968ULL;
v___x_423_ = vastitas_storage_store(v_a_378_, v___x_366_, v___x_397_, v___x_415_, v___x_416_, v___x_415_, v___x_375_, v___x_402_, v___x_397_, v___x_394_, v___x_422_, v___x_408_);
if (lean_obj_tag(v___x_423_) == 0)
{
lean_object* v___x_424_; 
lean_dec_ref_known(v___x_423_, 1);
v___x_424_ = vastitas_storage_allocate(v_a_378_, v___x_369_, v___x_394_, v___x_395_);
if (lean_obj_tag(v___x_424_) == 0)
{
lean_object* v___x_425_; 
lean_dec_ref_known(v___x_424_, 1);
v___x_425_ = vastitas_storage_fill(v_a_378_, v___x_369_, v___x_397_, v___x_395_, v___x_398_, v___x_395_, v___x_375_, v___x_394_, v___x_399_, v___x_400_);
if (lean_obj_tag(v___x_425_) == 0)
{
uint64_t v___x_426_; lean_object* v___x_427_; 
lean_dec_ref_known(v___x_425_, 1);
v___x_426_ = 6ULL;
v___x_427_ = vastitas_storage_fill(v_a_378_, v___x_369_, v___x_397_, v___x_419_, v___x_426_, v___x_419_, v___x_375_, v___x_394_, v___x_420_, v___x_417_);
if (lean_obj_tag(v___x_427_) == 0)
{
lean_object* v___x_428_; 
lean_dec_ref_known(v___x_427_, 1);
v___x_428_ = vastitas_storage_store(v_a_378_, v___x_369_, v___x_397_, v___x_419_, v___x_426_, v___x_419_, v___x_375_, v___x_415_, v___x_397_, v___x_394_, v___x_417_, v___x_420_);
if (lean_obj_tag(v___x_428_) == 0)
{
lean_object* v___x_429_; 
lean_dec_ref_known(v___x_428_, 1);
v___x_429_ = vastitas_storage_store(v_a_378_, v___x_369_, v___x_397_, v___x_419_, v___x_426_, v___x_419_, v___x_375_, v___x_397_, v___x_416_, v___x_394_, v___x_410_, v___x_422_);
if (lean_obj_tag(v___x_429_) == 0)
{
uint32_t v___x_430_; uint64_t v___x_431_; lean_object* v___x_432_; 
lean_dec_ref_known(v___x_429_, 1);
v___x_430_ = 3;
v___x_431_ = 40ULL;
v___x_432_ = vastitas_storage_allocate(v_a_378_, v___x_430_, v___x_394_, v___x_431_);
if (lean_obj_tag(v___x_432_) == 0)
{
lean_object* v___x_433_; 
lean_dec_ref_known(v___x_432_, 1);
v___x_433_ = vastitas_storage_fill(v_a_378_, v___x_430_, v___x_397_, v___x_431_, v___x_398_, v___x_431_, v___x_375_, v___x_394_, v___x_399_, v___x_400_);
if (lean_obj_tag(v___x_433_) == 0)
{
uint32_t v___x_434_; lean_object* v___x_435_; 
lean_dec_ref_known(v___x_433_, 1);
v___x_434_ = 4;
v___x_435_ = vastitas_storage_allocate(v_a_378_, v___x_434_, v___x_394_, v___x_431_);
if (lean_obj_tag(v___x_435_) == 0)
{
lean_object* v___x_436_; 
lean_dec_ref_known(v___x_435_, 1);
v___x_436_ = vastitas_storage_fill(v_a_378_, v___x_434_, v___x_397_, v___x_431_, v___x_398_, v___x_431_, v___x_375_, v___x_394_, v___x_399_, v___x_400_);
if (lean_obj_tag(v___x_436_) == 0)
{
uint32_t v___x_437_; uint64_t v___x_438_; lean_object* v___x_439_; 
lean_dec_ref_known(v___x_436_, 1);
v___x_437_ = 5;
v___x_438_ = 60ULL;
v___x_439_ = vastitas_storage_allocate(v_a_378_, v___x_437_, v___x_394_, v___x_438_);
if (lean_obj_tag(v___x_439_) == 0)
{
lean_object* v___x_440_; 
lean_dec_ref_known(v___x_439_, 1);
v___x_440_ = vastitas_storage_fill(v_a_378_, v___x_437_, v___x_397_, v___x_438_, v___x_398_, v___x_438_, v___x_375_, v___x_394_, v___x_399_, v___x_400_);
if (lean_obj_tag(v___x_440_) == 0)
{
uint32_t v___x_441_; uint64_t v___x_442_; lean_object* v___x_443_; 
lean_dec_ref_known(v___x_440_, 1);
v___x_441_ = lean_uint32_of_nat(v_scope_356_);
v___x_442_ = lean_uint64_of_nat(v_reps_361_);
v___x_443_ = bench_begin_lean(v___x_441_, v___x_442_, v_verify_365_);
if (lean_obj_tag(v___x_443_) == 0)
{
lean_object* v___x_444_; lean_object* v___x_445_; lean_object* v___x_446_; 
lean_dec_ref_known(v___x_443_, 1);
v___x_444_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_444_, 0, v___x_350_);
lean_ctor_set(v___x_444_, 1, v_reps_361_);
lean_ctor_set(v___x_444_, 2, v___x_352_);
v___x_445_ = lean_box(0);
v___x_446_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_378_, v_scope_356_, v___x_444_, v___x_445_, v___x_350_);
lean_dec_ref_known(v___x_444_, 3);
lean_dec(v_scope_356_);
if (lean_obj_tag(v___x_446_) == 0)
{
lean_object* v___x_447_; 
lean_dec_ref_known(v___x_446_, 1);
v___x_447_ = bench_stop_lean();
if (lean_obj_tag(v___x_447_) == 0)
{
lean_object* v___x_448_; 
lean_dec_ref_known(v___x_447_, 1);
v___x_448_ = bench_verify_lean(v_a_378_, v___x_442_);
if (lean_obj_tag(v___x_448_) == 0)
{
uint64_t v___x_449_; uint64_t v___x_450_; uint64_t v___x_451_; lean_object* v___x_452_; 
lean_dec_ref_known(v___x_448_, 1);
v___x_449_ = 10ULL;
v___x_450_ = 13819436194074722304ULL;
v___x_451_ = 13820702831469920256ULL;
v___x_452_ = vastitas_storage_expect(v_a_378_, v___x_437_, v___x_397_, v___x_449_, v___x_426_, v___x_449_, v___x_375_, v___x_397_, v___x_397_, v___x_394_, v___x_450_, v___x_451_);
if (lean_obj_tag(v___x_452_) == 0)
{
uint64_t v___x_453_; uint64_t v___x_454_; lean_object* v___x_455_; 
lean_dec_ref_known(v___x_452_, 1);
v___x_453_ = 13828830421422440448ULL;
v___x_454_ = 13829252633887506432ULL;
v___x_455_ = vastitas_storage_expect(v_a_378_, v___x_437_, v___x_397_, v___x_449_, v___x_426_, v___x_449_, v___x_375_, v___x_398_, v___x_416_, v___x_394_, v___x_453_, v___x_454_);
if (lean_obj_tag(v___x_455_) == 0)
{
uint64_t v___x_456_; uint64_t v___x_457_; uint64_t v___x_458_; lean_object* v___x_459_; 
lean_dec_ref_known(v___x_455_, 1);
v___x_456_ = 9ULL;
v___x_457_ = 13817747344214458368ULL;
v___x_458_ = 13803532857890570240ULL;
v___x_459_ = vastitas_storage_expect(v_a_378_, v___x_437_, v___x_397_, v___x_449_, v___x_426_, v___x_449_, v___x_375_, v___x_456_, v___x_397_, v___x_394_, v___x_457_, v___x_458_);
if (lean_obj_tag(v___x_459_) == 0)
{
lean_object* v___x_460_; 
lean_dec_ref_known(v___x_459_, 1);
v___x_460_ = vastitas_storage_drop(v_a_378_, v___x_437_);
if (lean_obj_tag(v___x_460_) == 0)
{
lean_object* v___x_461_; 
lean_dec_ref_known(v___x_460_, 1);
v___x_461_ = vastitas_storage_drop(v_a_378_, v___x_434_);
if (lean_obj_tag(v___x_461_) == 0)
{
lean_object* v___x_462_; 
lean_dec_ref_known(v___x_461_, 1);
v___x_462_ = vastitas_storage_drop(v_a_378_, v___x_430_);
if (lean_obj_tag(v___x_462_) == 0)
{
lean_object* v___x_463_; 
lean_dec_ref_known(v___x_462_, 1);
v___x_463_ = vastitas_storage_drop(v_a_378_, v___x_369_);
if (lean_obj_tag(v___x_463_) == 0)
{
lean_object* v___x_464_; 
lean_dec_ref_known(v___x_463_, 1);
v___x_464_ = vastitas_storage_drop(v_a_378_, v___x_366_);
if (lean_obj_tag(v___x_464_) == 0)
{
lean_object* v___x_465_; 
lean_dec_ref_known(v___x_464_, 1);
v___x_465_ = vastitas_storage_drop(v_a_378_, v___x_393_);
v___y_380_ = v___x_465_;
goto v___jp_379_;
}
else
{
v___y_380_ = v___x_464_;
goto v___jp_379_;
}
}
else
{
v___y_380_ = v___x_463_;
goto v___jp_379_;
}
}
else
{
v___y_380_ = v___x_462_;
goto v___jp_379_;
}
}
else
{
v___y_380_ = v___x_461_;
goto v___jp_379_;
}
}
else
{
v___y_380_ = v___x_460_;
goto v___jp_379_;
}
}
else
{
v___y_380_ = v___x_459_;
goto v___jp_379_;
}
}
else
{
v___y_380_ = v___x_455_;
goto v___jp_379_;
}
}
else
{
v___y_380_ = v___x_452_;
goto v___jp_379_;
}
}
else
{
v___y_380_ = v___x_448_;
goto v___jp_379_;
}
}
else
{
v___y_380_ = v___x_447_;
goto v___jp_379_;
}
}
else
{
v___y_380_ = v___x_446_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_443_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_440_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_439_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_436_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_435_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_433_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_432_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_429_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_428_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_427_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_425_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_424_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_423_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_421_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_418_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_414_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_413_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_411_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_409_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_406_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_401_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_396_;
goto v___jp_379_;
}
v___jp_379_:
{
if (lean_obj_tag(v___y_380_) == 0)
{
lean_object* v___x_381_; 
lean_dec_ref_known(v___y_380_, 1);
v___x_381_ = vastitas_storage_close(v_a_378_);
lean_dec(v_a_378_);
if (lean_obj_tag(v___x_381_) == 0)
{
lean_object* v___x_382_; 
lean_dec_ref_known(v___x_381_, 1);
v___x_382_ = bench_report_lean();
return v___x_382_;
}
else
{
return v___x_381_;
}
}
else
{
lean_object* v_a_383_; lean_object* v___x_384_; 
v_a_383_ = lean_ctor_get(v___y_380_, 0);
lean_inc(v_a_383_);
lean_dec_ref_known(v___y_380_, 1);
v___x_384_ = vastitas_storage_close(v_a_378_);
lean_dec(v_a_378_);
if (lean_obj_tag(v___x_384_) == 0)
{
lean_object* v___x_386_; uint8_t v_isShared_387_; uint8_t v_isSharedCheck_391_; 
v_isSharedCheck_391_ = !lean_is_exclusive(v___x_384_);
if (v_isSharedCheck_391_ == 0)
{
lean_object* v_unused_392_; 
v_unused_392_ = lean_ctor_get(v___x_384_, 0);
lean_dec(v_unused_392_);
v___x_386_ = v___x_384_;
v_isShared_387_ = v_isSharedCheck_391_;
goto v_resetjp_385_;
}
else
{
lean_dec(v___x_384_);
v___x_386_ = lean_box(0);
v_isShared_387_ = v_isSharedCheck_391_;
goto v_resetjp_385_;
}
v_resetjp_385_:
{
lean_object* v___x_389_; 
if (v_isShared_387_ == 0)
{
lean_ctor_set_tag(v___x_386_, 1);
lean_ctor_set(v___x_386_, 0, v_a_383_);
v___x_389_ = v___x_386_;
goto v_reusejp_388_;
}
else
{
lean_object* v_reuseFailAlloc_390_; 
v_reuseFailAlloc_390_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_390_, 0, v_a_383_);
v___x_389_ = v_reuseFailAlloc_390_;
goto v_reusejp_388_;
}
v_reusejp_388_:
{
return v___x_389_;
}
}
}
else
{
lean_dec(v_a_383_);
return v___x_384_;
}
}
}
}
else
{
lean_object* v_a_466_; lean_object* v___x_468_; uint8_t v_isShared_469_; uint8_t v_isSharedCheck_473_; 
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v_a_466_ = lean_ctor_get(v___x_377_, 0);
v_isSharedCheck_473_ = !lean_is_exclusive(v___x_377_);
if (v_isSharedCheck_473_ == 0)
{
v___x_468_ = v___x_377_;
v_isShared_469_ = v_isSharedCheck_473_;
goto v_resetjp_467_;
}
else
{
lean_inc(v_a_466_);
lean_dec(v___x_377_);
v___x_468_ = lean_box(0);
v_isShared_469_ = v_isSharedCheck_473_;
goto v_resetjp_467_;
}
v_resetjp_467_:
{
lean_object* v___x_471_; 
if (v_isShared_469_ == 0)
{
v___x_471_ = v___x_468_;
goto v_reusejp_470_;
}
else
{
lean_object* v_reuseFailAlloc_472_; 
v_reuseFailAlloc_472_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_472_, 0, v_a_466_);
v___x_471_ = v_reuseFailAlloc_472_;
goto v_reusejp_470_;
}
v_reusejp_470_:
{
return v___x_471_;
}
}
}
}
else
{
uint32_t v___x_474_; uint64_t v___x_475_; lean_object* v___x_476_; 
lean_dec(v_scope_356_);
v___x_474_ = 0;
v___x_475_ = lean_uint64_of_nat(v_reps_361_);
v___x_476_ = bench_begin_lean(v___x_474_, v___x_475_, v_verify_365_);
if (lean_obj_tag(v___x_476_) == 0)
{
lean_object* v___x_477_; lean_object* v___x_478_; lean_object* v___x_479_; 
lean_dec_ref_known(v___x_476_, 1);
v___x_477_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_477_, 0, v___x_350_);
lean_ctor_set(v___x_477_, 1, v_reps_361_);
lean_ctor_set(v___x_477_, 2, v___x_352_);
v___x_478_ = lean_box(0);
v___x_479_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v___x_477_, v___x_478_, v___x_350_);
lean_dec_ref_known(v___x_477_, 3);
if (lean_obj_tag(v___x_479_) == 0)
{
lean_object* v___x_480_; 
lean_dec_ref_known(v___x_479_, 1);
v___x_480_ = bench_stop_lean();
if (lean_obj_tag(v___x_480_) == 0)
{
lean_object* v___x_481_; 
lean_dec_ref_known(v___x_480_, 1);
v___x_481_ = bench_report_lean();
return v___x_481_;
}
else
{
return v___x_480_;
}
}
else
{
return v___x_479_;
}
}
else
{
lean_dec(v_reps_361_);
return v___x_476_;
}
}
}
else
{
uint32_t v___x_482_; uint64_t v___x_483_; lean_object* v___x_484_; 
v___x_482_ = lean_uint32_of_nat(v_scope_356_);
lean_dec(v_scope_356_);
v___x_483_ = lean_uint64_of_nat(v_reps_361_);
lean_dec(v_reps_361_);
v___x_484_ = bench_c_run_lean(v___x_482_, v___x_483_, v_verify_365_);
if (lean_obj_tag(v___x_484_) == 0)
{
lean_object* v___x_485_; 
lean_dec_ref_known(v___x_484_, 1);
v___x_485_ = bench_report_lean();
return v___x_485_;
}
else
{
return v___x_484_;
}
}
}
else
{
uint32_t v___x_486_; uint64_t v___x_487_; lean_object* v___x_488_; 
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
lean_dec(v_impl_351_);
v___x_486_ = 0;
v___x_487_ = 1ULL;
v___x_488_ = bench_begin_lean(v___x_486_, v___x_487_, v___x_372_);
if (lean_obj_tag(v___x_488_) == 0)
{
lean_object* v___x_489_; 
lean_dec_ref_known(v___x_488_, 1);
v___x_489_ = lp_allocation__audit_generatedFailure();
if (lean_obj_tag(v___x_489_) == 0)
{
lean_object* v___x_491_; uint8_t v_isShared_492_; uint8_t v_isSharedCheck_497_; 
v_isSharedCheck_497_ = !lean_is_exclusive(v___x_489_);
if (v_isSharedCheck_497_ == 0)
{
lean_object* v_unused_498_; 
v_unused_498_ = lean_ctor_get(v___x_489_, 0);
lean_dec(v_unused_498_);
v___x_491_ = v___x_489_;
v_isShared_492_ = v_isSharedCheck_497_;
goto v_resetjp_490_;
}
else
{
lean_dec(v___x_489_);
v___x_491_ = lean_box(0);
v_isShared_492_ = v_isSharedCheck_497_;
goto v_resetjp_490_;
}
v_resetjp_490_:
{
lean_object* v___x_493_; lean_object* v___x_495_; 
v___x_493_ = ((lean_object*)(lp_allocation__audit_main___closed__5));
if (v_isShared_492_ == 0)
{
lean_ctor_set_tag(v___x_491_, 1);
lean_ctor_set(v___x_491_, 0, v___x_493_);
v___x_495_ = v___x_491_;
goto v_reusejp_494_;
}
else
{
lean_object* v_reuseFailAlloc_496_; 
v_reuseFailAlloc_496_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_496_, 0, v___x_493_);
v___x_495_ = v_reuseFailAlloc_496_;
goto v_reusejp_494_;
}
v_reusejp_494_:
{
return v___x_495_;
}
}
}
else
{
lean_object* v_a_499_; lean_object* v___x_500_; lean_object* v___x_501_; uint8_t v___x_502_; 
v_a_499_ = lean_ctor_get(v___x_489_, 0);
lean_inc(v_a_499_);
v___x_500_ = lean_io_error_to_string(v_a_499_);
v___x_501_ = ((lean_object*)(lp_allocation__audit_main___closed__6));
v___x_502_ = lean_string_dec_eq(v___x_500_, v___x_501_);
lean_dec_ref(v___x_500_);
if (v___x_502_ == 0)
{
return v___x_489_;
}
else
{
lean_object* v___x_503_; 
lean_dec_ref_known(v___x_489_, 1);
v___x_503_ = bench_stop_lean();
if (lean_obj_tag(v___x_503_) == 0)
{
lean_object* v___x_504_; 
lean_dec_ref_known(v___x_503_, 1);
v___x_504_ = bench_report_lean();
return v___x_504_;
}
else
{
return v___x_503_;
}
}
}
}
else
{
return v___x_488_;
}
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
lean_dec(v_impl_351_);
return v___x_370_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
lean_dec(v_impl_351_);
return v___x_368_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
lean_dec(v_impl_351_);
return v___x_367_;
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object* v_args_505_, lean_object* v_a_506_){
_start:
{
lean_object* v_res_507_; 
v_res_507_ = _lean_main(v_args_505_);
return v_res_507_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object* v_a_508_, lean_object* v_scope_509_, lean_object* v_range_510_, lean_object* v_b_511_, lean_object* v_i_512_, lean_object* v_hs_513_, lean_object* v_hl_514_){
_start:
{
lean_object* v___x_516_; 
v___x_516_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_508_, v_scope_509_, v_range_510_, v_b_511_, v_i_512_);
return v___x_516_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object* v_a_517_, lean_object* v_scope_518_, lean_object* v_range_519_, lean_object* v_b_520_, lean_object* v_i_521_, lean_object* v_hs_522_, lean_object* v_hl_523_, lean_object* v___y_524_){
_start:
{
lean_object* v_res_525_; 
v_res_525_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(v_a_517_, v_scope_518_, v_range_519_, v_b_520_, v_i_521_, v_hs_522_, v_hl_523_);
lean_dec_ref(v_range_519_);
lean_dec(v_scope_518_);
lean_dec(v_a_517_);
return v_res_525_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object* v_range_526_, lean_object* v_b_527_, lean_object* v_i_528_, lean_object* v_hs_529_, lean_object* v_hl_530_){
_start:
{
lean_object* v___x_532_; 
v___x_532_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_526_, v_b_527_, v_i_528_);
return v___x_532_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object* v_range_533_, lean_object* v_b_534_, lean_object* v_i_535_, lean_object* v_hs_536_, lean_object* v_hl_537_, lean_object* v___y_538_){
_start:
{
lean_object* v_res_539_; 
v_res_539_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(v_range_533_, v_b_534_, v_i_535_, v_hs_536_, v_hl_537_);
lean_dec_ref(v_range_533_);
return v_res_539_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_vastitas__storage__native_VastitasStorageNative(uint8_t builtin);
lean_object* initialize_vastitas__gemm__native_VastitasGemmNative(uint8_t builtin);
lean_object* initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_allocation__audit_Main(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__storage__native_VastitasStorageNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__gemm__native_VastitasGemmNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_allocation__audit_VastitasGenerated_f__0 = _init_lp_allocation__audit_VastitasGenerated_f__0();
lean_mark_persistent(lp_allocation__audit_VastitasGenerated_f__0);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_allocation__audit_Main(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = 0;
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
