// Lean compiler output
// Module: Main
// Imports: public import Init public meta import Init public import VastitasStorageNative public import VastitasGemmNative public import VastitasKernel.IndexedRuntime
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* vastitas_storage_new(uint64_t);
lean_object* vastitas_storage_close(lean_object*);
lean_object* vastitas_storage_allocate(lean_object*, uint32_t, uint8_t, uint64_t);
lean_object* vastitas_storage_fill(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_store(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_pack3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_gemm_execute(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t);
lean_object* vastitas_storage_regroup3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_storage_expect(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_drop(lean_object*, uint32_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_List_get_x21Internal___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_String_Slice_toNat_x21(lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
uint32_t lean_uint32_of_nat(lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
lean_object* lean_io_error_to_string(lean_object*);
static lean_once_cell_t lp_allocation__audit_VastitasGenerated_f__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_allocation__audit_VastitasGenerated_f__0___closed__0;
LEAN_EXPORT lean_object* lp_allocation__audit_VastitasGenerated_f__0;
lean_object* bench_begin_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_stop_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object*);
lean_object* bench_report_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object*);
lean_object* bench_c_run_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_verify_lean(lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object*);
lean_object* audit_mark_lean(uint32_t);
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_allocation__audit_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 1, .m_capacity = 1, .m_length = 0, .m_data = ""};
static const lean_object* lp_allocation__audit_main___closed__0 = (const lean_object*)&lp_allocation__audit_main___closed__0_value;
static const lean_string_object lp_allocation__audit_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "1"};
static const lean_object* lp_allocation__audit_main___closed__1 = (const lean_object*)&lp_allocation__audit_main___closed__1_value;
static const lean_string_object lp_allocation__audit_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "failure"};
static const lean_object* lp_allocation__audit_main___closed__2 = (const lean_object*)&lp_allocation__audit_main___closed__2_value;
static const lean_string_object lp_allocation__audit_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "c"};
static const lean_object* lp_allocation__audit_main___closed__3 = (const lean_object*)&lp_allocation__audit_main___closed__3_value;
static const lean_string_object lp_allocation__audit_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "expected injected native failure"};
static const lean_object* lp_allocation__audit_main___closed__4 = (const lean_object*)&lp_allocation__audit_main___closed__4_value;
static const lean_ctor_object lp_allocation__audit_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_allocation__audit_main___closed__4_value)}};
static const lean_object* lp_allocation__audit_main___closed__5 = (const lean_object*)&lp_allocation__audit_main___closed__5_value;
static const lean_string_object lp_allocation__audit_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 44, .m_capacity = 44, .m_length = 43, .m_data = "E_NATIVE_EXPECT: stored bit pattern differs"};
static const lean_object* lp_allocation__audit_main___closed__6 = (const lean_object*)&lp_allocation__audit_main___closed__6_value;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(0u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0(void){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_obj_once(&lp_allocation__audit_VastitasGenerated_f__0___closed__0, &lp_allocation__audit_VastitasGenerated_f__0___closed__0_once, _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object* v_scope_8_, lean_object* v_reps_9_, lean_object* v_verify_10_, lean_object* v_a_00___x40___internal___hyg_11_){
_start:
{
uint32_t v_scope_boxed_12_; uint64_t v_reps_boxed_13_; uint8_t v_verify_boxed_14_; lean_object* v_res_15_; 
v_scope_boxed_12_ = lean_unbox_uint32(v_scope_8_);
lean_dec(v_scope_8_);
v_reps_boxed_13_ = lean_unbox_uint64(v_reps_9_);
lean_dec_ref(v_reps_9_);
v_verify_boxed_14_ = lean_unbox(v_verify_10_);
v_res_15_ = bench_begin_lean(v_scope_boxed_12_, v_reps_boxed_13_, v_verify_boxed_14_);
return v_res_15_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object* v_a_00___x40___internal___hyg_17_){
_start:
{
lean_object* v_res_18_; 
v_res_18_ = bench_stop_lean();
return v_res_18_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object* v_a_00___x40___internal___hyg_20_){
_start:
{
lean_object* v_res_21_; 
v_res_21_ = bench_report_lean();
return v_res_21_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object* v_scope_26_, lean_object* v_reps_27_, lean_object* v_verify_28_, lean_object* v_a_00___x40___internal___hyg_29_){
_start:
{
uint32_t v_scope_boxed_30_; uint64_t v_reps_boxed_31_; uint8_t v_verify_boxed_32_; lean_object* v_res_33_; 
v_scope_boxed_30_ = lean_unbox_uint32(v_scope_26_);
lean_dec(v_scope_26_);
v_reps_boxed_31_ = lean_unbox_uint64(v_reps_27_);
lean_dec_ref(v_reps_27_);
v_verify_boxed_32_ = lean_unbox(v_verify_28_);
v_res_33_ = bench_c_run_lean(v_scope_boxed_30_, v_reps_boxed_31_, v_verify_boxed_32_);
return v_res_33_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object* v_arena_37_, lean_object* v_reps_38_, lean_object* v_a_00___x40___internal___hyg_39_){
_start:
{
uint64_t v_reps_boxed_40_; lean_object* v_res_41_; 
v_reps_boxed_40_ = lean_unbox_uint64(v_reps_38_);
lean_dec_ref(v_reps_38_);
v_res_41_ = bench_verify_lean(v_arena_37_, v_reps_boxed_40_);
lean_dec(v_arena_37_);
return v_res_41_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce(){
_start:
{
uint64_t v___x_43_; lean_object* v___x_44_; 
v___x_43_ = 9223372036854775807ULL;
v___x_44_ = vastitas_storage_new(v___x_43_);
if (lean_obj_tag(v___x_44_) == 0)
{
lean_object* v_a_45_; lean_object* v_a_47_; lean_object* v___y_58_; uint32_t v___x_70_; uint8_t v___x_71_; uint64_t v___x_72_; lean_object* v___x_73_; 
v_a_45_ = lean_ctor_get(v___x_44_, 0);
lean_inc(v_a_45_);
lean_dec_ref_known(v___x_44_, 1);
v___x_70_ = 0;
v___x_71_ = 1;
v___x_72_ = 52ULL;
v___x_73_ = vastitas_storage_allocate(v_a_45_, v___x_70_, v___x_71_, v___x_72_);
if (lean_obj_tag(v___x_73_) == 0)
{
uint64_t v___x_74_; uint64_t v___x_75_; uint8_t v___x_76_; uint64_t v___x_77_; uint64_t v___x_78_; lean_object* v___x_79_; 
lean_dec_ref_known(v___x_73_, 1);
v___x_74_ = 0ULL;
v___x_75_ = 1ULL;
v___x_76_ = 0;
v___x_77_ = 13842939354630062080ULL;
v___x_78_ = 4613937818241073152ULL;
v___x_79_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_74_, v___x_72_, v___x_75_, v___x_72_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_79_) == 0)
{
uint64_t v___x_80_; uint64_t v___x_81_; uint64_t v___x_82_; uint64_t v___x_83_; uint64_t v___x_84_; uint64_t v___x_85_; lean_object* v___x_86_; 
lean_dec_ref_known(v___x_79_, 1);
v___x_80_ = 16ULL;
v___x_81_ = 2ULL;
v___x_82_ = 12ULL;
v___x_83_ = 4ULL;
v___x_84_ = 4593671619917905920ULL;
v___x_85_ = 4598175219545276416ULL;
v___x_86_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_80_, v___x_81_, v___x_82_, v___x_83_, v___x_76_, v___x_71_, v___x_84_, v___x_85_);
if (lean_obj_tag(v___x_86_) == 0)
{
uint64_t v___x_87_; uint64_t v___x_88_; lean_object* v___x_89_; 
lean_dec_ref_known(v___x_86_, 1);
v___x_87_ = 4607182418800017408ULL;
v___x_88_ = 13826050856027422720ULL;
v___x_89_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_80_, v___x_81_, v___x_82_, v___x_83_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_87_, v___x_88_);
if (lean_obj_tag(v___x_89_) == 0)
{
uint64_t v___x_90_; lean_object* v___x_91_; 
lean_dec_ref_known(v___x_89_, 1);
v___x_90_ = 4604930618986332160ULL;
v___x_91_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_80_, v___x_81_, v___x_82_, v___x_83_, v___x_76_, v___x_75_, v___x_75_, v___x_71_, v___x_88_, v___x_90_);
if (lean_obj_tag(v___x_91_) == 0)
{
uint32_t v___x_92_; uint64_t v___x_93_; lean_object* v___x_94_; 
lean_dec_ref_known(v___x_91_, 1);
v___x_92_ = 1;
v___x_93_ = 35ULL;
v___x_94_ = vastitas_storage_allocate(v_a_45_, v___x_92_, v___x_71_, v___x_93_);
if (lean_obj_tag(v___x_94_) == 0)
{
lean_object* v___x_95_; 
lean_dec_ref_known(v___x_94_, 1);
v___x_95_ = vastitas_storage_fill(v_a_45_, v___x_92_, v___x_74_, v___x_93_, v___x_75_, v___x_93_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_95_) == 0)
{
uint64_t v___x_96_; uint64_t v___x_97_; uint64_t v___x_98_; uint64_t v___x_99_; uint64_t v___x_100_; lean_object* v___x_101_; 
lean_dec_ref_known(v___x_95_, 1);
v___x_96_ = 32ULL;
v___x_97_ = 3ULL;
v___x_98_ = 5ULL;
v___x_99_ = 6ULL;
v___x_100_ = 13821547256400052224ULL;
v___x_101_ = vastitas_storage_fill(v_a_45_, v___x_92_, v___x_96_, v___x_97_, v___x_98_, v___x_99_, v___x_76_, v___x_71_, v___x_100_, v___x_84_);
if (lean_obj_tag(v___x_101_) == 0)
{
uint64_t v___x_102_; lean_object* v___x_103_; 
lean_dec_ref_known(v___x_101_, 1);
v___x_102_ = 4602678819172646912ULL;
v___x_103_ = vastitas_storage_store(v_a_45_, v___x_92_, v___x_96_, v___x_97_, v___x_98_, v___x_99_, v___x_76_, v___x_74_, v___x_83_, v___x_71_, v___x_102_, v___x_85_);
if (lean_obj_tag(v___x_103_) == 0)
{
uint64_t v___x_104_; lean_object* v___x_105_; 
lean_dec_ref_known(v___x_103_, 1);
v___x_104_ = 13828302655841107968ULL;
v___x_105_ = vastitas_storage_store(v_a_45_, v___x_92_, v___x_96_, v___x_97_, v___x_98_, v___x_99_, v___x_76_, v___x_81_, v___x_74_, v___x_71_, v___x_104_, v___x_88_);
if (lean_obj_tag(v___x_105_) == 0)
{
uint32_t v___x_106_; uint64_t v___x_107_; lean_object* v___x_108_; 
lean_dec_ref_known(v___x_105_, 1);
v___x_106_ = 2;
v___x_107_ = 54ULL;
v___x_108_ = vastitas_storage_allocate(v_a_45_, v___x_106_, v___x_71_, v___x_107_);
if (lean_obj_tag(v___x_108_) == 0)
{
lean_object* v___x_109_; 
lean_dec_ref_known(v___x_108_, 1);
v___x_109_ = vastitas_storage_fill(v_a_45_, v___x_106_, v___x_74_, v___x_107_, v___x_75_, v___x_107_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_109_) == 0)
{
uint64_t v___x_110_; uint64_t v___x_111_; lean_object* v___x_112_; 
lean_dec_ref_known(v___x_109_, 1);
v___x_110_ = 48ULL;
v___x_111_ = 8ULL;
v___x_112_ = vastitas_storage_fill(v_a_45_, v___x_106_, v___x_110_, v___x_83_, v___x_99_, v___x_111_, v___x_76_, v___x_71_, v___x_102_, v___x_100_);
if (lean_obj_tag(v___x_112_) == 0)
{
lean_object* v___x_113_; 
lean_dec_ref_known(v___x_112_, 1);
v___x_113_ = vastitas_storage_store(v_a_45_, v___x_106_, v___x_110_, v___x_83_, v___x_99_, v___x_111_, v___x_76_, v___x_97_, v___x_74_, v___x_71_, v___x_100_, v___x_102_);
if (lean_obj_tag(v___x_113_) == 0)
{
lean_object* v___x_114_; 
lean_dec_ref_known(v___x_113_, 1);
v___x_114_ = vastitas_storage_store(v_a_45_, v___x_106_, v___x_110_, v___x_83_, v___x_99_, v___x_111_, v___x_76_, v___x_74_, v___x_98_, v___x_71_, v___x_90_, v___x_104_);
if (lean_obj_tag(v___x_114_) == 0)
{
uint32_t v___x_115_; uint64_t v___x_116_; lean_object* v___x_117_; 
lean_dec_ref_known(v___x_114_, 1);
v___x_115_ = 3;
v___x_116_ = 82ULL;
v___x_117_ = vastitas_storage_allocate(v_a_45_, v___x_115_, v___x_71_, v___x_116_);
if (lean_obj_tag(v___x_117_) == 0)
{
lean_object* v___x_118_; 
lean_dec_ref_known(v___x_117_, 1);
v___x_118_ = vastitas_storage_fill(v_a_45_, v___x_115_, v___x_74_, v___x_116_, v___x_75_, v___x_116_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_118_) == 0)
{
uint32_t v___x_119_; uint64_t v___x_120_; lean_object* v___x_121_; 
lean_dec_ref_known(v___x_118_, 1);
v___x_119_ = 4;
v___x_120_ = 78ULL;
v___x_121_ = vastitas_storage_allocate(v_a_45_, v___x_119_, v___x_71_, v___x_120_);
if (lean_obj_tag(v___x_121_) == 0)
{
lean_object* v___x_122_; 
lean_dec_ref_known(v___x_121_, 1);
v___x_122_ = vastitas_storage_fill(v_a_45_, v___x_119_, v___x_74_, v___x_120_, v___x_75_, v___x_120_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_122_) == 0)
{
uint32_t v___x_123_; uint64_t v___x_124_; lean_object* v___x_125_; 
lean_dec_ref_known(v___x_122_, 1);
v___x_123_ = 5;
v___x_124_ = 111ULL;
v___x_125_ = vastitas_storage_allocate(v_a_45_, v___x_123_, v___x_71_, v___x_124_);
if (lean_obj_tag(v___x_125_) == 0)
{
lean_object* v___x_126_; 
lean_dec_ref_known(v___x_125_, 1);
v___x_126_ = vastitas_storage_fill(v_a_45_, v___x_123_, v___x_74_, v___x_124_, v___x_75_, v___x_124_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_126_) == 0)
{
uint64_t v___x_127_; uint64_t v___x_128_; lean_object* v___x_129_; 
lean_dec_ref_known(v___x_126_, 1);
v___x_127_ = 64ULL;
v___x_128_ = 13ULL;
v___x_129_ = vastitas_storage_pack3(v_a_45_, v___x_70_, v___x_80_, v___x_81_, v___x_82_, v___x_83_, v___x_76_, v___x_115_, v___x_127_, v___x_111_, v___x_97_, v___x_128_, v___x_76_, v___x_81_, v___x_97_, v___x_83_);
if (lean_obj_tag(v___x_129_) == 0)
{
uint64_t v___x_130_; uint64_t v___x_131_; uint8_t v___x_132_; lean_object* v___x_133_; 
lean_dec_ref_known(v___x_129_, 1);
v___x_130_ = 80ULL;
v___x_131_ = 14ULL;
v___x_132_ = 0;
v___x_133_ = vastitas_gemm_execute(v_a_45_, v___x_115_, v___x_127_, v___x_111_, v___x_97_, v___x_128_, v___x_76_, v___x_76_, v___x_92_, v___x_96_, v___x_97_, v___x_98_, v___x_99_, v___x_76_, v___x_76_, v___x_119_, v___x_130_, v___x_111_, v___x_98_, v___x_131_, v___x_76_, v___x_132_);
if (lean_obj_tag(v___x_133_) == 0)
{
uint64_t v___x_134_; uint64_t v___x_135_; uint64_t v___x_136_; uint64_t v___x_137_; lean_object* v___x_138_; 
lean_dec_ref_known(v___x_133_, 1);
v___x_134_ = 112ULL;
v___x_135_ = 10ULL;
v___x_136_ = 18ULL;
v___x_137_ = 42ULL;
v___x_138_ = vastitas_storage_regroup3(v_a_45_, v___x_119_, v___x_130_, v___x_111_, v___x_98_, v___x_131_, v___x_76_, v___x_115_, v___x_134_, v___x_135_, v___x_83_, v___x_136_, v___x_76_, v___x_81_, v___x_83_, v___x_98_, v___x_110_, v___x_137_);
if (lean_obj_tag(v___x_138_) == 0)
{
uint64_t v___x_139_; uint64_t v___x_140_; lean_object* v___x_141_; 
lean_dec_ref_known(v___x_138_, 1);
v___x_139_ = 96ULL;
v___x_140_ = 17ULL;
v___x_141_ = vastitas_gemm_execute(v_a_45_, v___x_115_, v___x_134_, v___x_135_, v___x_83_, v___x_136_, v___x_76_, v___x_76_, v___x_106_, v___x_110_, v___x_83_, v___x_99_, v___x_111_, v___x_76_, v___x_76_, v___x_123_, v___x_139_, v___x_135_, v___x_99_, v___x_140_, v___x_76_, v___x_132_);
if (lean_obj_tag(v___x_141_) == 0)
{
uint64_t v___x_142_; uint64_t v___x_143_; lean_object* v___x_144_; 
lean_dec_ref_known(v___x_141_, 1);
v___x_142_ = 13819436194074722304ULL;
v___x_143_ = 13820702831469920256ULL;
v___x_144_ = vastitas_storage_expect(v_a_45_, v___x_123_, v___x_139_, v___x_135_, v___x_99_, v___x_140_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_142_, v___x_143_);
if (lean_obj_tag(v___x_144_) == 0)
{
uint64_t v___x_145_; uint64_t v___x_146_; lean_object* v___x_147_; 
lean_dec_ref_known(v___x_144_, 1);
v___x_145_ = 13828830421422440448ULL;
v___x_146_ = 13829252633887506432ULL;
v___x_147_ = vastitas_storage_expect(v_a_45_, v___x_123_, v___x_139_, v___x_135_, v___x_99_, v___x_140_, v___x_76_, v___x_75_, v___x_98_, v___x_71_, v___x_145_, v___x_146_);
if (lean_obj_tag(v___x_147_) == 0)
{
uint64_t v___x_148_; uint64_t v___x_149_; uint64_t v___x_150_; lean_object* v___x_151_; 
lean_dec_ref_known(v___x_147_, 1);
v___x_148_ = 9ULL;
v___x_149_ = 13817747344214458368ULL;
v___x_150_ = 13803532857890570240ULL;
v___x_151_ = vastitas_storage_expect(v_a_45_, v___x_123_, v___x_139_, v___x_135_, v___x_99_, v___x_140_, v___x_76_, v___x_148_, v___x_74_, v___x_71_, v___x_149_, v___x_150_);
if (lean_obj_tag(v___x_151_) == 0)
{
lean_object* v___x_152_; 
lean_dec_ref_known(v___x_151_, 1);
v___x_152_ = vastitas_storage_drop(v_a_45_, v___x_123_);
if (lean_obj_tag(v___x_152_) == 0)
{
lean_object* v___x_153_; 
lean_dec_ref_known(v___x_152_, 1);
v___x_153_ = vastitas_storage_drop(v_a_45_, v___x_119_);
if (lean_obj_tag(v___x_153_) == 0)
{
lean_object* v___x_154_; 
lean_dec_ref_known(v___x_153_, 1);
v___x_154_ = vastitas_storage_drop(v_a_45_, v___x_115_);
if (lean_obj_tag(v___x_154_) == 0)
{
lean_object* v___x_155_; 
lean_dec_ref_known(v___x_154_, 1);
v___x_155_ = vastitas_storage_drop(v_a_45_, v___x_106_);
if (lean_obj_tag(v___x_155_) == 0)
{
lean_object* v___x_156_; 
lean_dec_ref_known(v___x_155_, 1);
v___x_156_ = vastitas_storage_drop(v_a_45_, v___x_92_);
if (lean_obj_tag(v___x_156_) == 0)
{
lean_object* v___x_157_; 
lean_dec_ref_known(v___x_156_, 1);
v___x_157_ = vastitas_storage_drop(v_a_45_, v___x_70_);
if (lean_obj_tag(v___x_157_) == 0)
{
lean_object* v___x_158_; 
lean_dec_ref_known(v___x_157_, 1);
v___x_158_ = lean_box(0);
v_a_47_ = v___x_158_;
goto v___jp_46_;
}
else
{
v___y_58_ = v___x_157_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_156_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_155_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_154_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_153_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_152_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_151_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_147_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_144_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_141_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_138_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_133_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_129_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_126_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_125_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_122_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_121_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_118_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_117_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_114_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_113_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_112_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_109_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_108_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_105_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_103_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_101_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_95_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_94_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_91_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_89_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_86_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_79_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_73_;
goto v___jp_57_;
}
v___jp_46_:
{
lean_object* v___x_48_; 
v___x_48_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_48_) == 0)
{
lean_object* v___x_50_; uint8_t v_isShared_51_; uint8_t v_isSharedCheck_55_; 
v_isSharedCheck_55_ = !lean_is_exclusive(v___x_48_);
if (v_isSharedCheck_55_ == 0)
{
lean_object* v_unused_56_; 
v_unused_56_ = lean_ctor_get(v___x_48_, 0);
lean_dec(v_unused_56_);
v___x_50_ = v___x_48_;
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
else
{
lean_dec(v___x_48_);
v___x_50_ = lean_box(0);
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
v_resetjp_49_:
{
lean_object* v___x_53_; 
if (v_isShared_51_ == 0)
{
lean_ctor_set(v___x_50_, 0, v_a_47_);
v___x_53_ = v___x_50_;
goto v_reusejp_52_;
}
else
{
lean_object* v_reuseFailAlloc_54_; 
v_reuseFailAlloc_54_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_54_, 0, v_a_47_);
v___x_53_ = v_reuseFailAlloc_54_;
goto v_reusejp_52_;
}
v_reusejp_52_:
{
return v___x_53_;
}
}
}
else
{
return v___x_48_;
}
}
v___jp_57_:
{
if (lean_obj_tag(v___y_58_) == 0)
{
lean_object* v_a_59_; 
v_a_59_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_59_);
lean_dec_ref_known(v___y_58_, 1);
v_a_47_ = v_a_59_;
goto v___jp_46_;
}
else
{
lean_object* v_a_60_; lean_object* v___x_61_; 
v_a_60_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_60_);
lean_dec_ref_known(v___y_58_, 1);
v___x_61_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_61_) == 0)
{
lean_object* v___x_63_; uint8_t v_isShared_64_; uint8_t v_isSharedCheck_68_; 
v_isSharedCheck_68_ = !lean_is_exclusive(v___x_61_);
if (v_isSharedCheck_68_ == 0)
{
lean_object* v_unused_69_; 
v_unused_69_ = lean_ctor_get(v___x_61_, 0);
lean_dec(v_unused_69_);
v___x_63_ = v___x_61_;
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
else
{
lean_dec(v___x_61_);
v___x_63_ = lean_box(0);
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
v_resetjp_62_:
{
lean_object* v___x_66_; 
if (v_isShared_64_ == 0)
{
lean_ctor_set_tag(v___x_63_, 1);
lean_ctor_set(v___x_63_, 0, v_a_60_);
v___x_66_ = v___x_63_;
goto v_reusejp_65_;
}
else
{
lean_object* v_reuseFailAlloc_67_; 
v_reuseFailAlloc_67_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_67_, 0, v_a_60_);
v___x_66_ = v_reuseFailAlloc_67_;
goto v_reusejp_65_;
}
v_reusejp_65_:
{
return v___x_66_;
}
}
}
else
{
lean_dec(v_a_60_);
return v___x_61_;
}
}
}
}
else
{
lean_object* v_a_159_; lean_object* v___x_161_; uint8_t v_isShared_162_; uint8_t v_isSharedCheck_166_; 
v_a_159_ = lean_ctor_get(v___x_44_, 0);
v_isSharedCheck_166_ = !lean_is_exclusive(v___x_44_);
if (v_isSharedCheck_166_ == 0)
{
v___x_161_ = v___x_44_;
v_isShared_162_ = v_isSharedCheck_166_;
goto v_resetjp_160_;
}
else
{
lean_inc(v_a_159_);
lean_dec(v___x_44_);
v___x_161_ = lean_box(0);
v_isShared_162_ = v_isSharedCheck_166_;
goto v_resetjp_160_;
}
v_resetjp_160_:
{
lean_object* v___x_164_; 
if (v_isShared_162_ == 0)
{
v___x_164_ = v___x_161_;
goto v_reusejp_163_;
}
else
{
lean_object* v_reuseFailAlloc_165_; 
v_reuseFailAlloc_165_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_165_, 0, v_a_159_);
v___x_164_ = v_reuseFailAlloc_165_;
goto v_reusejp_163_;
}
v_reusejp_163_:
{
return v___x_164_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object* v_a_167_){
_start:
{
lean_object* v_res_168_; 
v_res_168_ = lp_allocation__audit_generatedOnce();
return v_res_168_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure(){
_start:
{
uint64_t v___x_170_; lean_object* v___x_171_; 
v___x_170_ = 9223372036854775807ULL;
v___x_171_ = vastitas_storage_new(v___x_170_);
if (lean_obj_tag(v___x_171_) == 0)
{
lean_object* v_a_172_; lean_object* v_a_174_; lean_object* v___y_185_; uint32_t v___x_197_; uint8_t v___x_198_; uint64_t v___x_199_; lean_object* v___x_200_; 
v_a_172_ = lean_ctor_get(v___x_171_, 0);
lean_inc(v_a_172_);
lean_dec_ref_known(v___x_171_, 1);
v___x_197_ = 0;
v___x_198_ = 1;
v___x_199_ = 52ULL;
v___x_200_ = vastitas_storage_allocate(v_a_172_, v___x_197_, v___x_198_, v___x_199_);
if (lean_obj_tag(v___x_200_) == 0)
{
uint64_t v___x_201_; uint64_t v___x_202_; uint8_t v___x_203_; uint64_t v___x_204_; uint64_t v___x_205_; lean_object* v___x_206_; 
lean_dec_ref_known(v___x_200_, 1);
v___x_201_ = 0ULL;
v___x_202_ = 1ULL;
v___x_203_ = 0;
v___x_204_ = 13842939354630062080ULL;
v___x_205_ = 4613937818241073152ULL;
v___x_206_ = vastitas_storage_fill(v_a_172_, v___x_197_, v___x_201_, v___x_199_, v___x_202_, v___x_199_, v___x_203_, v___x_198_, v___x_204_, v___x_205_);
if (lean_obj_tag(v___x_206_) == 0)
{
uint64_t v___x_207_; uint64_t v___x_208_; uint64_t v___x_209_; uint64_t v___x_210_; uint64_t v___x_211_; uint64_t v___x_212_; lean_object* v___x_213_; 
lean_dec_ref_known(v___x_206_, 1);
v___x_207_ = 16ULL;
v___x_208_ = 2ULL;
v___x_209_ = 12ULL;
v___x_210_ = 4ULL;
v___x_211_ = 4593671619917905920ULL;
v___x_212_ = 4598175219545276416ULL;
v___x_213_ = vastitas_storage_fill(v_a_172_, v___x_197_, v___x_207_, v___x_208_, v___x_209_, v___x_210_, v___x_203_, v___x_198_, v___x_211_, v___x_212_);
if (lean_obj_tag(v___x_213_) == 0)
{
uint64_t v___x_214_; uint64_t v___x_215_; lean_object* v___x_216_; 
lean_dec_ref_known(v___x_213_, 1);
v___x_214_ = 4607182418800017408ULL;
v___x_215_ = 13826050856027422720ULL;
v___x_216_ = vastitas_storage_store(v_a_172_, v___x_197_, v___x_207_, v___x_208_, v___x_209_, v___x_210_, v___x_203_, v___x_201_, v___x_201_, v___x_198_, v___x_214_, v___x_215_);
if (lean_obj_tag(v___x_216_) == 0)
{
uint64_t v___x_217_; lean_object* v___x_218_; 
lean_dec_ref_known(v___x_216_, 1);
v___x_217_ = 4604930618986332160ULL;
v___x_218_ = vastitas_storage_store(v_a_172_, v___x_197_, v___x_207_, v___x_208_, v___x_209_, v___x_210_, v___x_203_, v___x_202_, v___x_202_, v___x_198_, v___x_215_, v___x_217_);
if (lean_obj_tag(v___x_218_) == 0)
{
uint32_t v___x_219_; uint64_t v___x_220_; lean_object* v___x_221_; 
lean_dec_ref_known(v___x_218_, 1);
v___x_219_ = 1;
v___x_220_ = 35ULL;
v___x_221_ = vastitas_storage_allocate(v_a_172_, v___x_219_, v___x_198_, v___x_220_);
if (lean_obj_tag(v___x_221_) == 0)
{
lean_object* v___x_222_; 
lean_dec_ref_known(v___x_221_, 1);
v___x_222_ = vastitas_storage_fill(v_a_172_, v___x_219_, v___x_201_, v___x_220_, v___x_202_, v___x_220_, v___x_203_, v___x_198_, v___x_204_, v___x_205_);
if (lean_obj_tag(v___x_222_) == 0)
{
uint64_t v___x_223_; uint64_t v___x_224_; uint64_t v___x_225_; uint64_t v___x_226_; uint64_t v___x_227_; lean_object* v___x_228_; 
lean_dec_ref_known(v___x_222_, 1);
v___x_223_ = 32ULL;
v___x_224_ = 3ULL;
v___x_225_ = 5ULL;
v___x_226_ = 6ULL;
v___x_227_ = 13821547256400052224ULL;
v___x_228_ = vastitas_storage_fill(v_a_172_, v___x_219_, v___x_223_, v___x_224_, v___x_225_, v___x_226_, v___x_203_, v___x_198_, v___x_227_, v___x_211_);
if (lean_obj_tag(v___x_228_) == 0)
{
uint64_t v___x_229_; lean_object* v___x_230_; 
lean_dec_ref_known(v___x_228_, 1);
v___x_229_ = 4602678819172646912ULL;
v___x_230_ = vastitas_storage_store(v_a_172_, v___x_219_, v___x_223_, v___x_224_, v___x_225_, v___x_226_, v___x_203_, v___x_201_, v___x_210_, v___x_198_, v___x_229_, v___x_212_);
if (lean_obj_tag(v___x_230_) == 0)
{
uint64_t v___x_231_; lean_object* v___x_232_; 
lean_dec_ref_known(v___x_230_, 1);
v___x_231_ = 13828302655841107968ULL;
v___x_232_ = vastitas_storage_store(v_a_172_, v___x_219_, v___x_223_, v___x_224_, v___x_225_, v___x_226_, v___x_203_, v___x_208_, v___x_201_, v___x_198_, v___x_231_, v___x_215_);
if (lean_obj_tag(v___x_232_) == 0)
{
uint32_t v___x_233_; uint64_t v___x_234_; lean_object* v___x_235_; 
lean_dec_ref_known(v___x_232_, 1);
v___x_233_ = 2;
v___x_234_ = 54ULL;
v___x_235_ = vastitas_storage_allocate(v_a_172_, v___x_233_, v___x_198_, v___x_234_);
if (lean_obj_tag(v___x_235_) == 0)
{
lean_object* v___x_236_; 
lean_dec_ref_known(v___x_235_, 1);
v___x_236_ = vastitas_storage_fill(v_a_172_, v___x_233_, v___x_201_, v___x_234_, v___x_202_, v___x_234_, v___x_203_, v___x_198_, v___x_204_, v___x_205_);
if (lean_obj_tag(v___x_236_) == 0)
{
uint64_t v___x_237_; uint64_t v___x_238_; lean_object* v___x_239_; 
lean_dec_ref_known(v___x_236_, 1);
v___x_237_ = 48ULL;
v___x_238_ = 8ULL;
v___x_239_ = vastitas_storage_fill(v_a_172_, v___x_233_, v___x_237_, v___x_210_, v___x_226_, v___x_238_, v___x_203_, v___x_198_, v___x_229_, v___x_227_);
if (lean_obj_tag(v___x_239_) == 0)
{
lean_object* v___x_240_; 
lean_dec_ref_known(v___x_239_, 1);
v___x_240_ = vastitas_storage_store(v_a_172_, v___x_233_, v___x_237_, v___x_210_, v___x_226_, v___x_238_, v___x_203_, v___x_224_, v___x_201_, v___x_198_, v___x_227_, v___x_229_);
if (lean_obj_tag(v___x_240_) == 0)
{
lean_object* v___x_241_; 
lean_dec_ref_known(v___x_240_, 1);
v___x_241_ = vastitas_storage_store(v_a_172_, v___x_233_, v___x_237_, v___x_210_, v___x_226_, v___x_238_, v___x_203_, v___x_201_, v___x_225_, v___x_198_, v___x_217_, v___x_231_);
if (lean_obj_tag(v___x_241_) == 0)
{
uint32_t v___x_242_; uint64_t v___x_243_; lean_object* v___x_244_; 
lean_dec_ref_known(v___x_241_, 1);
v___x_242_ = 3;
v___x_243_ = 82ULL;
v___x_244_ = vastitas_storage_allocate(v_a_172_, v___x_242_, v___x_198_, v___x_243_);
if (lean_obj_tag(v___x_244_) == 0)
{
lean_object* v___x_245_; 
lean_dec_ref_known(v___x_244_, 1);
v___x_245_ = vastitas_storage_fill(v_a_172_, v___x_242_, v___x_201_, v___x_243_, v___x_202_, v___x_243_, v___x_203_, v___x_198_, v___x_204_, v___x_205_);
if (lean_obj_tag(v___x_245_) == 0)
{
uint32_t v___x_246_; uint64_t v___x_247_; lean_object* v___x_248_; 
lean_dec_ref_known(v___x_245_, 1);
v___x_246_ = 4;
v___x_247_ = 78ULL;
v___x_248_ = vastitas_storage_allocate(v_a_172_, v___x_246_, v___x_198_, v___x_247_);
if (lean_obj_tag(v___x_248_) == 0)
{
lean_object* v___x_249_; 
lean_dec_ref_known(v___x_248_, 1);
v___x_249_ = vastitas_storage_fill(v_a_172_, v___x_246_, v___x_201_, v___x_247_, v___x_202_, v___x_247_, v___x_203_, v___x_198_, v___x_204_, v___x_205_);
if (lean_obj_tag(v___x_249_) == 0)
{
uint32_t v___x_250_; uint64_t v___x_251_; lean_object* v___x_252_; 
lean_dec_ref_known(v___x_249_, 1);
v___x_250_ = 5;
v___x_251_ = 111ULL;
v___x_252_ = vastitas_storage_allocate(v_a_172_, v___x_250_, v___x_198_, v___x_251_);
if (lean_obj_tag(v___x_252_) == 0)
{
lean_object* v___x_253_; 
lean_dec_ref_known(v___x_252_, 1);
v___x_253_ = vastitas_storage_fill(v_a_172_, v___x_250_, v___x_201_, v___x_251_, v___x_202_, v___x_251_, v___x_203_, v___x_198_, v___x_204_, v___x_205_);
if (lean_obj_tag(v___x_253_) == 0)
{
uint64_t v___x_254_; uint64_t v___x_255_; lean_object* v___x_256_; 
lean_dec_ref_known(v___x_253_, 1);
v___x_254_ = 64ULL;
v___x_255_ = 13ULL;
v___x_256_ = vastitas_storage_pack3(v_a_172_, v___x_197_, v___x_207_, v___x_208_, v___x_209_, v___x_210_, v___x_203_, v___x_242_, v___x_254_, v___x_238_, v___x_224_, v___x_255_, v___x_203_, v___x_208_, v___x_224_, v___x_210_);
if (lean_obj_tag(v___x_256_) == 0)
{
uint64_t v___x_257_; uint64_t v___x_258_; uint8_t v___x_259_; lean_object* v___x_260_; 
lean_dec_ref_known(v___x_256_, 1);
v___x_257_ = 80ULL;
v___x_258_ = 14ULL;
v___x_259_ = 0;
v___x_260_ = vastitas_gemm_execute(v_a_172_, v___x_242_, v___x_254_, v___x_238_, v___x_224_, v___x_255_, v___x_203_, v___x_203_, v___x_219_, v___x_223_, v___x_224_, v___x_225_, v___x_226_, v___x_203_, v___x_203_, v___x_246_, v___x_257_, v___x_238_, v___x_225_, v___x_258_, v___x_203_, v___x_259_);
if (lean_obj_tag(v___x_260_) == 0)
{
uint64_t v___x_261_; uint64_t v___x_262_; uint64_t v___x_263_; uint64_t v___x_264_; lean_object* v___x_265_; 
lean_dec_ref_known(v___x_260_, 1);
v___x_261_ = 112ULL;
v___x_262_ = 10ULL;
v___x_263_ = 18ULL;
v___x_264_ = 42ULL;
v___x_265_ = vastitas_storage_regroup3(v_a_172_, v___x_246_, v___x_257_, v___x_238_, v___x_225_, v___x_258_, v___x_203_, v___x_242_, v___x_261_, v___x_262_, v___x_210_, v___x_263_, v___x_203_, v___x_208_, v___x_210_, v___x_225_, v___x_237_, v___x_264_);
if (lean_obj_tag(v___x_265_) == 0)
{
uint64_t v___x_266_; uint64_t v___x_267_; lean_object* v___x_268_; 
lean_dec_ref_known(v___x_265_, 1);
v___x_266_ = 96ULL;
v___x_267_ = 17ULL;
v___x_268_ = vastitas_gemm_execute(v_a_172_, v___x_242_, v___x_261_, v___x_262_, v___x_210_, v___x_263_, v___x_203_, v___x_203_, v___x_233_, v___x_237_, v___x_210_, v___x_226_, v___x_238_, v___x_203_, v___x_203_, v___x_250_, v___x_266_, v___x_262_, v___x_226_, v___x_267_, v___x_203_, v___x_259_);
if (lean_obj_tag(v___x_268_) == 0)
{
uint64_t v___x_269_; uint64_t v___x_270_; lean_object* v___x_271_; 
lean_dec_ref_known(v___x_268_, 1);
v___x_269_ = 13819436194074722305ULL;
v___x_270_ = 13820702831469920256ULL;
v___x_271_ = vastitas_storage_expect(v_a_172_, v___x_250_, v___x_266_, v___x_262_, v___x_226_, v___x_267_, v___x_203_, v___x_201_, v___x_201_, v___x_198_, v___x_269_, v___x_270_);
if (lean_obj_tag(v___x_271_) == 0)
{
uint64_t v___x_272_; uint64_t v___x_273_; lean_object* v___x_274_; 
lean_dec_ref_known(v___x_271_, 1);
v___x_272_ = 13828830421422440448ULL;
v___x_273_ = 13829252633887506432ULL;
v___x_274_ = vastitas_storage_expect(v_a_172_, v___x_250_, v___x_266_, v___x_262_, v___x_226_, v___x_267_, v___x_203_, v___x_202_, v___x_225_, v___x_198_, v___x_272_, v___x_273_);
if (lean_obj_tag(v___x_274_) == 0)
{
uint64_t v___x_275_; uint64_t v___x_276_; uint64_t v___x_277_; lean_object* v___x_278_; 
lean_dec_ref_known(v___x_274_, 1);
v___x_275_ = 9ULL;
v___x_276_ = 13817747344214458368ULL;
v___x_277_ = 13803532857890570240ULL;
v___x_278_ = vastitas_storage_expect(v_a_172_, v___x_250_, v___x_266_, v___x_262_, v___x_226_, v___x_267_, v___x_203_, v___x_275_, v___x_201_, v___x_198_, v___x_276_, v___x_277_);
if (lean_obj_tag(v___x_278_) == 0)
{
lean_object* v___x_279_; 
lean_dec_ref_known(v___x_278_, 1);
v___x_279_ = vastitas_storage_drop(v_a_172_, v___x_250_);
if (lean_obj_tag(v___x_279_) == 0)
{
lean_object* v___x_280_; 
lean_dec_ref_known(v___x_279_, 1);
v___x_280_ = vastitas_storage_drop(v_a_172_, v___x_246_);
if (lean_obj_tag(v___x_280_) == 0)
{
lean_object* v___x_281_; 
lean_dec_ref_known(v___x_280_, 1);
v___x_281_ = vastitas_storage_drop(v_a_172_, v___x_242_);
if (lean_obj_tag(v___x_281_) == 0)
{
lean_object* v___x_282_; 
lean_dec_ref_known(v___x_281_, 1);
v___x_282_ = vastitas_storage_drop(v_a_172_, v___x_233_);
if (lean_obj_tag(v___x_282_) == 0)
{
lean_object* v___x_283_; 
lean_dec_ref_known(v___x_282_, 1);
v___x_283_ = vastitas_storage_drop(v_a_172_, v___x_219_);
if (lean_obj_tag(v___x_283_) == 0)
{
lean_object* v___x_284_; 
lean_dec_ref_known(v___x_283_, 1);
v___x_284_ = vastitas_storage_drop(v_a_172_, v___x_197_);
if (lean_obj_tag(v___x_284_) == 0)
{
lean_object* v___x_285_; 
lean_dec_ref_known(v___x_284_, 1);
v___x_285_ = lean_box(0);
v_a_174_ = v___x_285_;
goto v___jp_173_;
}
else
{
v___y_185_ = v___x_284_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_283_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_282_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_281_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_280_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_279_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_278_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_274_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_271_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_268_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_265_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_260_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_256_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_253_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_252_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_249_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_248_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_245_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_244_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_241_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_240_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_239_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_236_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_235_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_232_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_230_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_228_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_222_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_221_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_218_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_216_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_213_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_206_;
goto v___jp_184_;
}
}
else
{
v___y_185_ = v___x_200_;
goto v___jp_184_;
}
v___jp_173_:
{
lean_object* v___x_175_; 
v___x_175_ = vastitas_storage_close(v_a_172_);
lean_dec(v_a_172_);
if (lean_obj_tag(v___x_175_) == 0)
{
lean_object* v___x_177_; uint8_t v_isShared_178_; uint8_t v_isSharedCheck_182_; 
v_isSharedCheck_182_ = !lean_is_exclusive(v___x_175_);
if (v_isSharedCheck_182_ == 0)
{
lean_object* v_unused_183_; 
v_unused_183_ = lean_ctor_get(v___x_175_, 0);
lean_dec(v_unused_183_);
v___x_177_ = v___x_175_;
v_isShared_178_ = v_isSharedCheck_182_;
goto v_resetjp_176_;
}
else
{
lean_dec(v___x_175_);
v___x_177_ = lean_box(0);
v_isShared_178_ = v_isSharedCheck_182_;
goto v_resetjp_176_;
}
v_resetjp_176_:
{
lean_object* v___x_180_; 
if (v_isShared_178_ == 0)
{
lean_ctor_set(v___x_177_, 0, v_a_174_);
v___x_180_ = v___x_177_;
goto v_reusejp_179_;
}
else
{
lean_object* v_reuseFailAlloc_181_; 
v_reuseFailAlloc_181_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_181_, 0, v_a_174_);
v___x_180_ = v_reuseFailAlloc_181_;
goto v_reusejp_179_;
}
v_reusejp_179_:
{
return v___x_180_;
}
}
}
else
{
return v___x_175_;
}
}
v___jp_184_:
{
if (lean_obj_tag(v___y_185_) == 0)
{
lean_object* v_a_186_; 
v_a_186_ = lean_ctor_get(v___y_185_, 0);
lean_inc(v_a_186_);
lean_dec_ref_known(v___y_185_, 1);
v_a_174_ = v_a_186_;
goto v___jp_173_;
}
else
{
lean_object* v_a_187_; lean_object* v___x_188_; 
v_a_187_ = lean_ctor_get(v___y_185_, 0);
lean_inc(v_a_187_);
lean_dec_ref_known(v___y_185_, 1);
v___x_188_ = vastitas_storage_close(v_a_172_);
lean_dec(v_a_172_);
if (lean_obj_tag(v___x_188_) == 0)
{
lean_object* v___x_190_; uint8_t v_isShared_191_; uint8_t v_isSharedCheck_195_; 
v_isSharedCheck_195_ = !lean_is_exclusive(v___x_188_);
if (v_isSharedCheck_195_ == 0)
{
lean_object* v_unused_196_; 
v_unused_196_ = lean_ctor_get(v___x_188_, 0);
lean_dec(v_unused_196_);
v___x_190_ = v___x_188_;
v_isShared_191_ = v_isSharedCheck_195_;
goto v_resetjp_189_;
}
else
{
lean_dec(v___x_188_);
v___x_190_ = lean_box(0);
v_isShared_191_ = v_isSharedCheck_195_;
goto v_resetjp_189_;
}
v_resetjp_189_:
{
lean_object* v___x_193_; 
if (v_isShared_191_ == 0)
{
lean_ctor_set_tag(v___x_190_, 1);
lean_ctor_set(v___x_190_, 0, v_a_187_);
v___x_193_ = v___x_190_;
goto v_reusejp_192_;
}
else
{
lean_object* v_reuseFailAlloc_194_; 
v_reuseFailAlloc_194_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_194_, 0, v_a_187_);
v___x_193_ = v_reuseFailAlloc_194_;
goto v_reusejp_192_;
}
v_reusejp_192_:
{
return v___x_193_;
}
}
}
else
{
lean_dec(v_a_187_);
return v___x_188_;
}
}
}
}
else
{
lean_object* v_a_286_; lean_object* v___x_288_; uint8_t v_isShared_289_; uint8_t v_isSharedCheck_293_; 
v_a_286_ = lean_ctor_get(v___x_171_, 0);
v_isSharedCheck_293_ = !lean_is_exclusive(v___x_171_);
if (v_isSharedCheck_293_ == 0)
{
v___x_288_ = v___x_171_;
v_isShared_289_ = v_isSharedCheck_293_;
goto v_resetjp_287_;
}
else
{
lean_inc(v_a_286_);
lean_dec(v___x_171_);
v___x_288_ = lean_box(0);
v_isShared_289_ = v_isSharedCheck_293_;
goto v_resetjp_287_;
}
v_resetjp_287_:
{
lean_object* v___x_291_; 
if (v_isShared_289_ == 0)
{
v___x_291_ = v___x_288_;
goto v_reusejp_290_;
}
else
{
lean_object* v_reuseFailAlloc_292_; 
v_reuseFailAlloc_292_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_292_, 0, v_a_286_);
v___x_291_ = v_reuseFailAlloc_292_;
goto v_reusejp_290_;
}
v_reusejp_290_:
{
return v___x_291_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object* v_a_294_){
_start:
{
lean_object* v_res_295_; 
v_res_295_ = lp_allocation__audit_generatedFailure();
return v_res_295_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object* v_phase_298_, lean_object* v_a_00___x40___internal___hyg_299_){
_start:
{
uint32_t v_phase_boxed_300_; lean_object* v_res_301_; 
v_phase_boxed_300_ = lean_unbox_uint32(v_phase_298_);
lean_dec(v_phase_298_);
v_res_301_ = audit_mark_lean(v_phase_boxed_300_);
return v_res_301_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object* v_a_302_, lean_object* v_scope_303_, lean_object* v_range_304_, lean_object* v_b_305_, lean_object* v_i_306_){
_start:
{
lean_object* v_stop_308_; lean_object* v_step_309_; uint8_t v___x_310_; 
v_stop_308_ = lean_ctor_get(v_range_304_, 1);
v_step_309_ = lean_ctor_get(v_range_304_, 2);
v___x_310_ = lean_nat_dec_lt(v_i_306_, v_stop_308_);
if (v___x_310_ == 0)
{
lean_object* v___x_311_; 
lean_dec(v_i_306_);
v___x_311_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_311_, 0, v_b_305_);
return v___x_311_;
}
else
{
uint32_t v___x_312_; uint64_t v___x_313_; uint64_t v___x_314_; uint64_t v___x_315_; uint64_t v___x_316_; lean_object* v___x_317_; uint8_t v___x_318_; uint32_t v___x_319_; uint64_t v___x_320_; uint64_t v___x_321_; uint32_t v___x_322_; uint64_t v___x_323_; uint64_t v___x_324_; uint64_t v___x_325_; uint32_t v___x_326_; uint64_t v___x_327_; uint32_t v___x_328_; uint32_t v___x_329_; lean_object* v___x_330_; uint64_t v___x_331_; uint64_t v___x_332_; lean_object* v___x_333_; 
v___x_312_ = 0;
v___x_313_ = 16ULL;
v___x_314_ = 2ULL;
v___x_315_ = 12ULL;
v___x_316_ = 4ULL;
v___x_317_ = lean_unsigned_to_nat(0u);
v___x_318_ = lean_nat_dec_eq(v_scope_303_, v___x_317_);
v___x_319_ = 3;
v___x_320_ = 8ULL;
v___x_321_ = 3ULL;
v___x_322_ = 1;
v___x_323_ = 32ULL;
v___x_324_ = 5ULL;
v___x_325_ = 6ULL;
v___x_326_ = 4;
v___x_327_ = 48ULL;
v___x_328_ = 2;
v___x_329_ = 5;
v___x_330_ = lean_box(0);
v___x_331_ = 64ULL;
v___x_332_ = 13ULL;
v___x_333_ = vastitas_storage_pack3(v_a_302_, v___x_312_, v___x_313_, v___x_314_, v___x_315_, v___x_316_, v___x_318_, v___x_319_, v___x_331_, v___x_320_, v___x_321_, v___x_332_, v___x_318_, v___x_314_, v___x_321_, v___x_316_);
if (lean_obj_tag(v___x_333_) == 0)
{
uint64_t v___x_334_; uint64_t v___x_335_; uint8_t v___x_336_; lean_object* v___x_337_; 
lean_dec_ref_known(v___x_333_, 1);
v___x_334_ = 80ULL;
v___x_335_ = 14ULL;
v___x_336_ = 0;
v___x_337_ = vastitas_gemm_execute(v_a_302_, v___x_319_, v___x_331_, v___x_320_, v___x_321_, v___x_332_, v___x_318_, v___x_318_, v___x_322_, v___x_323_, v___x_321_, v___x_324_, v___x_325_, v___x_318_, v___x_318_, v___x_326_, v___x_334_, v___x_320_, v___x_324_, v___x_335_, v___x_318_, v___x_336_);
if (lean_obj_tag(v___x_337_) == 0)
{
uint64_t v___x_338_; uint64_t v___x_339_; uint64_t v___x_340_; uint64_t v___x_341_; lean_object* v___x_342_; 
lean_dec_ref_known(v___x_337_, 1);
v___x_338_ = 112ULL;
v___x_339_ = 10ULL;
v___x_340_ = 18ULL;
v___x_341_ = 42ULL;
v___x_342_ = vastitas_storage_regroup3(v_a_302_, v___x_326_, v___x_334_, v___x_320_, v___x_324_, v___x_335_, v___x_318_, v___x_319_, v___x_338_, v___x_339_, v___x_316_, v___x_340_, v___x_318_, v___x_314_, v___x_316_, v___x_324_, v___x_327_, v___x_341_);
if (lean_obj_tag(v___x_342_) == 0)
{
uint64_t v___x_343_; uint64_t v___x_344_; lean_object* v___x_345_; 
lean_dec_ref_known(v___x_342_, 1);
v___x_343_ = 96ULL;
v___x_344_ = 17ULL;
v___x_345_ = vastitas_gemm_execute(v_a_302_, v___x_319_, v___x_338_, v___x_339_, v___x_316_, v___x_340_, v___x_318_, v___x_318_, v___x_328_, v___x_327_, v___x_316_, v___x_325_, v___x_320_, v___x_318_, v___x_318_, v___x_329_, v___x_343_, v___x_339_, v___x_325_, v___x_344_, v___x_318_, v___x_336_);
if (lean_obj_tag(v___x_345_) == 0)
{
lean_object* v___x_346_; 
lean_dec_ref_known(v___x_345_, 1);
v___x_346_ = lean_nat_add(v_i_306_, v_step_309_);
lean_dec(v_i_306_);
v_b_305_ = v___x_330_;
v_i_306_ = v___x_346_;
goto _start;
}
else
{
lean_dec(v_i_306_);
return v___x_345_;
}
}
else
{
lean_dec(v_i_306_);
return v___x_342_;
}
}
else
{
lean_dec(v_i_306_);
return v___x_337_;
}
}
else
{
lean_dec(v_i_306_);
return v___x_333_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object* v_a_348_, lean_object* v_scope_349_, lean_object* v_range_350_, lean_object* v_b_351_, lean_object* v_i_352_, lean_object* v___y_353_){
_start:
{
lean_object* v_res_354_; 
v_res_354_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_348_, v_scope_349_, v_range_350_, v_b_351_, v_i_352_);
lean_dec_ref(v_range_350_);
lean_dec(v_scope_349_);
lean_dec(v_a_348_);
return v_res_354_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object* v_range_355_, lean_object* v_b_356_, lean_object* v_i_357_){
_start:
{
lean_object* v_stop_359_; lean_object* v_step_360_; uint8_t v___x_361_; 
v_stop_359_ = lean_ctor_get(v_range_355_, 1);
v_step_360_ = lean_ctor_get(v_range_355_, 2);
v___x_361_ = lean_nat_dec_lt(v_i_357_, v_stop_359_);
if (v___x_361_ == 0)
{
lean_object* v___x_362_; 
lean_dec(v_i_357_);
v___x_362_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_362_, 0, v_b_356_);
return v___x_362_;
}
else
{
lean_object* v___x_363_; lean_object* v___x_364_; 
v___x_363_ = lean_box(0);
v___x_364_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_364_) == 0)
{
lean_object* v___x_365_; 
lean_dec_ref_known(v___x_364_, 1);
v___x_365_ = lean_nat_add(v_i_357_, v_step_360_);
lean_dec(v_i_357_);
v_b_356_ = v___x_363_;
v_i_357_ = v___x_365_;
goto _start;
}
else
{
lean_dec(v_i_357_);
return v___x_364_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object* v_range_367_, lean_object* v_b_368_, lean_object* v_i_369_, lean_object* v___y_370_){
_start:
{
lean_object* v_res_371_; 
v_res_371_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_367_, v_b_368_, v_i_369_);
lean_dec_ref(v_range_367_);
return v_res_371_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_380_){
_start:
{
lean_object* v___x_382_; lean_object* v___x_383_; lean_object* v_impl_384_; lean_object* v___x_385_; lean_object* v___x_386_; lean_object* v___x_387_; lean_object* v___x_388_; lean_object* v_scope_389_; lean_object* v___x_390_; lean_object* v___x_391_; lean_object* v___x_392_; lean_object* v___x_393_; lean_object* v_reps_394_; lean_object* v___x_395_; lean_object* v___x_396_; lean_object* v___x_397_; uint8_t v_verify_398_; uint32_t v___x_399_; lean_object* v___x_400_; 
v___x_382_ = ((lean_object*)(lp_allocation__audit_main___closed__0));
v___x_383_ = lean_unsigned_to_nat(0u);
v_impl_384_ = l_List_get_x21Internal___redArg(v___x_382_, v_args_380_, v___x_383_);
v___x_385_ = lean_unsigned_to_nat(1u);
v___x_386_ = l_List_get_x21Internal___redArg(v___x_382_, v_args_380_, v___x_385_);
v___x_387_ = lean_string_utf8_byte_size(v___x_386_);
v___x_388_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_388_, 0, v___x_386_);
lean_ctor_set(v___x_388_, 1, v___x_383_);
lean_ctor_set(v___x_388_, 2, v___x_387_);
v_scope_389_ = l_String_Slice_toNat_x21(v___x_388_);
lean_dec_ref_known(v___x_388_, 3);
v___x_390_ = lean_unsigned_to_nat(2u);
v___x_391_ = l_List_get_x21Internal___redArg(v___x_382_, v_args_380_, v___x_390_);
v___x_392_ = lean_string_utf8_byte_size(v___x_391_);
v___x_393_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_393_, 0, v___x_391_);
lean_ctor_set(v___x_393_, 1, v___x_383_);
lean_ctor_set(v___x_393_, 2, v___x_392_);
v_reps_394_ = l_String_Slice_toNat_x21(v___x_393_);
lean_dec_ref_known(v___x_393_, 3);
v___x_395_ = lean_unsigned_to_nat(3u);
v___x_396_ = l_List_get_x21Internal___redArg(v___x_382_, v_args_380_, v___x_395_);
lean_dec(v_args_380_);
v___x_397_ = ((lean_object*)(lp_allocation__audit_main___closed__1));
v_verify_398_ = lean_string_dec_eq(v___x_396_, v___x_397_);
lean_dec(v___x_396_);
v___x_399_ = 1;
v___x_400_ = audit_mark_lean(v___x_399_);
if (lean_obj_tag(v___x_400_) == 0)
{
lean_object* v___x_401_; 
lean_dec_ref_known(v___x_400_, 1);
v___x_401_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_401_) == 0)
{
uint32_t v___x_402_; lean_object* v___x_403_; 
lean_dec_ref_known(v___x_401_, 1);
v___x_402_ = 2;
v___x_403_ = audit_mark_lean(v___x_402_);
if (lean_obj_tag(v___x_403_) == 0)
{
lean_object* v___x_404_; uint8_t v___x_405_; 
lean_dec_ref_known(v___x_403_, 1);
v___x_404_ = ((lean_object*)(lp_allocation__audit_main___closed__2));
v___x_405_ = lean_string_dec_eq(v_impl_384_, v___x_404_);
if (v___x_405_ == 0)
{
lean_object* v___x_406_; uint8_t v___x_407_; 
v___x_406_ = ((lean_object*)(lp_allocation__audit_main___closed__3));
v___x_407_ = lean_string_dec_eq(v_impl_384_, v___x_406_);
lean_dec(v_impl_384_);
if (v___x_407_ == 0)
{
uint8_t v___x_408_; 
v___x_408_ = lean_nat_dec_eq(v_scope_389_, v___x_383_);
if (v___x_408_ == 0)
{
uint64_t v___x_409_; lean_object* v___x_410_; 
v___x_409_ = 9223372036854775807ULL;
v___x_410_ = vastitas_storage_new(v___x_409_);
if (lean_obj_tag(v___x_410_) == 0)
{
lean_object* v_a_411_; lean_object* v___y_413_; uint32_t v___x_426_; uint8_t v___x_427_; uint64_t v___x_428_; lean_object* v___x_429_; 
v_a_411_ = lean_ctor_get(v___x_410_, 0);
lean_inc(v_a_411_);
lean_dec_ref_known(v___x_410_, 1);
v___x_426_ = 0;
v___x_427_ = 1;
v___x_428_ = 52ULL;
v___x_429_ = vastitas_storage_allocate(v_a_411_, v___x_426_, v___x_427_, v___x_428_);
if (lean_obj_tag(v___x_429_) == 0)
{
uint64_t v___x_430_; uint64_t v___x_431_; uint64_t v___x_432_; uint64_t v___x_433_; lean_object* v___x_434_; 
lean_dec_ref_known(v___x_429_, 1);
v___x_430_ = 0ULL;
v___x_431_ = 1ULL;
v___x_432_ = 13842939354630062080ULL;
v___x_433_ = 4613937818241073152ULL;
v___x_434_ = vastitas_storage_fill(v_a_411_, v___x_426_, v___x_430_, v___x_428_, v___x_431_, v___x_428_, v___x_408_, v___x_427_, v___x_432_, v___x_433_);
if (lean_obj_tag(v___x_434_) == 0)
{
uint64_t v___x_435_; uint64_t v___x_436_; uint64_t v___x_437_; uint64_t v___x_438_; uint64_t v___x_439_; uint64_t v___x_440_; lean_object* v___x_441_; 
lean_dec_ref_known(v___x_434_, 1);
v___x_435_ = 16ULL;
v___x_436_ = 2ULL;
v___x_437_ = 12ULL;
v___x_438_ = 4ULL;
v___x_439_ = 4593671619917905920ULL;
v___x_440_ = 4598175219545276416ULL;
v___x_441_ = vastitas_storage_fill(v_a_411_, v___x_426_, v___x_435_, v___x_436_, v___x_437_, v___x_438_, v___x_408_, v___x_427_, v___x_439_, v___x_440_);
if (lean_obj_tag(v___x_441_) == 0)
{
uint64_t v___x_442_; uint64_t v___x_443_; lean_object* v___x_444_; 
lean_dec_ref_known(v___x_441_, 1);
v___x_442_ = 4607182418800017408ULL;
v___x_443_ = 13826050856027422720ULL;
v___x_444_ = vastitas_storage_store(v_a_411_, v___x_426_, v___x_435_, v___x_436_, v___x_437_, v___x_438_, v___x_408_, v___x_430_, v___x_430_, v___x_427_, v___x_442_, v___x_443_);
if (lean_obj_tag(v___x_444_) == 0)
{
uint64_t v___x_445_; lean_object* v___x_446_; 
lean_dec_ref_known(v___x_444_, 1);
v___x_445_ = 4604930618986332160ULL;
v___x_446_ = vastitas_storage_store(v_a_411_, v___x_426_, v___x_435_, v___x_436_, v___x_437_, v___x_438_, v___x_408_, v___x_431_, v___x_431_, v___x_427_, v___x_443_, v___x_445_);
if (lean_obj_tag(v___x_446_) == 0)
{
uint64_t v___x_447_; lean_object* v___x_448_; 
lean_dec_ref_known(v___x_446_, 1);
v___x_447_ = 35ULL;
v___x_448_ = vastitas_storage_allocate(v_a_411_, v___x_399_, v___x_427_, v___x_447_);
if (lean_obj_tag(v___x_448_) == 0)
{
lean_object* v___x_449_; 
lean_dec_ref_known(v___x_448_, 1);
v___x_449_ = vastitas_storage_fill(v_a_411_, v___x_399_, v___x_430_, v___x_447_, v___x_431_, v___x_447_, v___x_408_, v___x_427_, v___x_432_, v___x_433_);
if (lean_obj_tag(v___x_449_) == 0)
{
uint64_t v___x_450_; uint64_t v___x_451_; uint64_t v___x_452_; uint64_t v___x_453_; uint64_t v___x_454_; lean_object* v___x_455_; 
lean_dec_ref_known(v___x_449_, 1);
v___x_450_ = 32ULL;
v___x_451_ = 3ULL;
v___x_452_ = 5ULL;
v___x_453_ = 6ULL;
v___x_454_ = 13821547256400052224ULL;
v___x_455_ = vastitas_storage_fill(v_a_411_, v___x_399_, v___x_450_, v___x_451_, v___x_452_, v___x_453_, v___x_408_, v___x_427_, v___x_454_, v___x_439_);
if (lean_obj_tag(v___x_455_) == 0)
{
uint64_t v___x_456_; lean_object* v___x_457_; 
lean_dec_ref_known(v___x_455_, 1);
v___x_456_ = 4602678819172646912ULL;
v___x_457_ = vastitas_storage_store(v_a_411_, v___x_399_, v___x_450_, v___x_451_, v___x_452_, v___x_453_, v___x_408_, v___x_430_, v___x_438_, v___x_427_, v___x_456_, v___x_440_);
if (lean_obj_tag(v___x_457_) == 0)
{
uint64_t v___x_458_; lean_object* v___x_459_; 
lean_dec_ref_known(v___x_457_, 1);
v___x_458_ = 13828302655841107968ULL;
v___x_459_ = vastitas_storage_store(v_a_411_, v___x_399_, v___x_450_, v___x_451_, v___x_452_, v___x_453_, v___x_408_, v___x_436_, v___x_430_, v___x_427_, v___x_458_, v___x_443_);
if (lean_obj_tag(v___x_459_) == 0)
{
uint64_t v___x_460_; lean_object* v___x_461_; 
lean_dec_ref_known(v___x_459_, 1);
v___x_460_ = 54ULL;
v___x_461_ = vastitas_storage_allocate(v_a_411_, v___x_402_, v___x_427_, v___x_460_);
if (lean_obj_tag(v___x_461_) == 0)
{
lean_object* v___x_462_; 
lean_dec_ref_known(v___x_461_, 1);
v___x_462_ = vastitas_storage_fill(v_a_411_, v___x_402_, v___x_430_, v___x_460_, v___x_431_, v___x_460_, v___x_408_, v___x_427_, v___x_432_, v___x_433_);
if (lean_obj_tag(v___x_462_) == 0)
{
uint64_t v___x_463_; uint64_t v___x_464_; lean_object* v___x_465_; 
lean_dec_ref_known(v___x_462_, 1);
v___x_463_ = 48ULL;
v___x_464_ = 8ULL;
v___x_465_ = vastitas_storage_fill(v_a_411_, v___x_402_, v___x_463_, v___x_438_, v___x_453_, v___x_464_, v___x_408_, v___x_427_, v___x_456_, v___x_454_);
if (lean_obj_tag(v___x_465_) == 0)
{
lean_object* v___x_466_; 
lean_dec_ref_known(v___x_465_, 1);
v___x_466_ = vastitas_storage_store(v_a_411_, v___x_402_, v___x_463_, v___x_438_, v___x_453_, v___x_464_, v___x_408_, v___x_451_, v___x_430_, v___x_427_, v___x_454_, v___x_456_);
if (lean_obj_tag(v___x_466_) == 0)
{
lean_object* v___x_467_; 
lean_dec_ref_known(v___x_466_, 1);
v___x_467_ = vastitas_storage_store(v_a_411_, v___x_402_, v___x_463_, v___x_438_, v___x_453_, v___x_464_, v___x_408_, v___x_430_, v___x_452_, v___x_427_, v___x_445_, v___x_458_);
if (lean_obj_tag(v___x_467_) == 0)
{
uint32_t v___x_468_; uint64_t v___x_469_; lean_object* v___x_470_; 
lean_dec_ref_known(v___x_467_, 1);
v___x_468_ = 3;
v___x_469_ = 82ULL;
v___x_470_ = vastitas_storage_allocate(v_a_411_, v___x_468_, v___x_427_, v___x_469_);
if (lean_obj_tag(v___x_470_) == 0)
{
lean_object* v___x_471_; 
lean_dec_ref_known(v___x_470_, 1);
v___x_471_ = vastitas_storage_fill(v_a_411_, v___x_468_, v___x_430_, v___x_469_, v___x_431_, v___x_469_, v___x_408_, v___x_427_, v___x_432_, v___x_433_);
if (lean_obj_tag(v___x_471_) == 0)
{
uint32_t v___x_472_; uint64_t v___x_473_; lean_object* v___x_474_; 
lean_dec_ref_known(v___x_471_, 1);
v___x_472_ = 4;
v___x_473_ = 78ULL;
v___x_474_ = vastitas_storage_allocate(v_a_411_, v___x_472_, v___x_427_, v___x_473_);
if (lean_obj_tag(v___x_474_) == 0)
{
lean_object* v___x_475_; 
lean_dec_ref_known(v___x_474_, 1);
v___x_475_ = vastitas_storage_fill(v_a_411_, v___x_472_, v___x_430_, v___x_473_, v___x_431_, v___x_473_, v___x_408_, v___x_427_, v___x_432_, v___x_433_);
if (lean_obj_tag(v___x_475_) == 0)
{
uint32_t v___x_476_; uint64_t v___x_477_; lean_object* v___x_478_; 
lean_dec_ref_known(v___x_475_, 1);
v___x_476_ = 5;
v___x_477_ = 111ULL;
v___x_478_ = vastitas_storage_allocate(v_a_411_, v___x_476_, v___x_427_, v___x_477_);
if (lean_obj_tag(v___x_478_) == 0)
{
lean_object* v___x_479_; 
lean_dec_ref_known(v___x_478_, 1);
v___x_479_ = vastitas_storage_fill(v_a_411_, v___x_476_, v___x_430_, v___x_477_, v___x_431_, v___x_477_, v___x_408_, v___x_427_, v___x_432_, v___x_433_);
if (lean_obj_tag(v___x_479_) == 0)
{
uint32_t v___x_480_; uint64_t v___x_481_; lean_object* v___x_482_; 
lean_dec_ref_known(v___x_479_, 1);
v___x_480_ = lean_uint32_of_nat(v_scope_389_);
v___x_481_ = lean_uint64_of_nat(v_reps_394_);
v___x_482_ = bench_begin_lean(v___x_480_, v___x_481_, v_verify_398_);
if (lean_obj_tag(v___x_482_) == 0)
{
lean_object* v___x_483_; lean_object* v___x_484_; lean_object* v___x_485_; 
lean_dec_ref_known(v___x_482_, 1);
v___x_483_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_483_, 0, v___x_383_);
lean_ctor_set(v___x_483_, 1, v_reps_394_);
lean_ctor_set(v___x_483_, 2, v___x_385_);
v___x_484_ = lean_box(0);
v___x_485_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_411_, v_scope_389_, v___x_483_, v___x_484_, v___x_383_);
lean_dec_ref_known(v___x_483_, 3);
lean_dec(v_scope_389_);
if (lean_obj_tag(v___x_485_) == 0)
{
lean_object* v___x_486_; 
lean_dec_ref_known(v___x_485_, 1);
v___x_486_ = bench_stop_lean();
if (lean_obj_tag(v___x_486_) == 0)
{
lean_object* v___x_487_; 
lean_dec_ref_known(v___x_486_, 1);
v___x_487_ = bench_verify_lean(v_a_411_, v___x_481_);
if (lean_obj_tag(v___x_487_) == 0)
{
uint64_t v___x_488_; uint64_t v___x_489_; uint64_t v___x_490_; uint64_t v___x_491_; uint64_t v___x_492_; lean_object* v___x_493_; 
lean_dec_ref_known(v___x_487_, 1);
v___x_488_ = 96ULL;
v___x_489_ = 10ULL;
v___x_490_ = 17ULL;
v___x_491_ = 13819436194074722304ULL;
v___x_492_ = 13820702831469920256ULL;
v___x_493_ = vastitas_storage_expect(v_a_411_, v___x_476_, v___x_488_, v___x_489_, v___x_453_, v___x_490_, v___x_408_, v___x_430_, v___x_430_, v___x_427_, v___x_491_, v___x_492_);
if (lean_obj_tag(v___x_493_) == 0)
{
uint64_t v___x_494_; uint64_t v___x_495_; lean_object* v___x_496_; 
lean_dec_ref_known(v___x_493_, 1);
v___x_494_ = 13828830421422440448ULL;
v___x_495_ = 13829252633887506432ULL;
v___x_496_ = vastitas_storage_expect(v_a_411_, v___x_476_, v___x_488_, v___x_489_, v___x_453_, v___x_490_, v___x_408_, v___x_431_, v___x_452_, v___x_427_, v___x_494_, v___x_495_);
if (lean_obj_tag(v___x_496_) == 0)
{
uint64_t v___x_497_; uint64_t v___x_498_; uint64_t v___x_499_; lean_object* v___x_500_; 
lean_dec_ref_known(v___x_496_, 1);
v___x_497_ = 9ULL;
v___x_498_ = 13817747344214458368ULL;
v___x_499_ = 13803532857890570240ULL;
v___x_500_ = vastitas_storage_expect(v_a_411_, v___x_476_, v___x_488_, v___x_489_, v___x_453_, v___x_490_, v___x_408_, v___x_497_, v___x_430_, v___x_427_, v___x_498_, v___x_499_);
if (lean_obj_tag(v___x_500_) == 0)
{
lean_object* v___x_501_; 
lean_dec_ref_known(v___x_500_, 1);
v___x_501_ = vastitas_storage_drop(v_a_411_, v___x_476_);
if (lean_obj_tag(v___x_501_) == 0)
{
lean_object* v___x_502_; 
lean_dec_ref_known(v___x_501_, 1);
v___x_502_ = vastitas_storage_drop(v_a_411_, v___x_472_);
if (lean_obj_tag(v___x_502_) == 0)
{
lean_object* v___x_503_; 
lean_dec_ref_known(v___x_502_, 1);
v___x_503_ = vastitas_storage_drop(v_a_411_, v___x_468_);
if (lean_obj_tag(v___x_503_) == 0)
{
lean_object* v___x_504_; 
lean_dec_ref_known(v___x_503_, 1);
v___x_504_ = vastitas_storage_drop(v_a_411_, v___x_402_);
if (lean_obj_tag(v___x_504_) == 0)
{
lean_object* v___x_505_; 
lean_dec_ref_known(v___x_504_, 1);
v___x_505_ = vastitas_storage_drop(v_a_411_, v___x_399_);
if (lean_obj_tag(v___x_505_) == 0)
{
lean_object* v___x_506_; 
lean_dec_ref_known(v___x_505_, 1);
v___x_506_ = vastitas_storage_drop(v_a_411_, v___x_426_);
v___y_413_ = v___x_506_;
goto v___jp_412_;
}
else
{
v___y_413_ = v___x_505_;
goto v___jp_412_;
}
}
else
{
v___y_413_ = v___x_504_;
goto v___jp_412_;
}
}
else
{
v___y_413_ = v___x_503_;
goto v___jp_412_;
}
}
else
{
v___y_413_ = v___x_502_;
goto v___jp_412_;
}
}
else
{
v___y_413_ = v___x_501_;
goto v___jp_412_;
}
}
else
{
v___y_413_ = v___x_500_;
goto v___jp_412_;
}
}
else
{
v___y_413_ = v___x_496_;
goto v___jp_412_;
}
}
else
{
v___y_413_ = v___x_493_;
goto v___jp_412_;
}
}
else
{
v___y_413_ = v___x_487_;
goto v___jp_412_;
}
}
else
{
v___y_413_ = v___x_486_;
goto v___jp_412_;
}
}
else
{
v___y_413_ = v___x_485_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_482_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_479_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_478_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_475_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_474_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_471_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_470_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_467_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_466_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_465_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_462_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_461_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_459_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_457_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_455_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_449_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_448_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_446_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_444_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_441_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_434_;
goto v___jp_412_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v___y_413_ = v___x_429_;
goto v___jp_412_;
}
v___jp_412_:
{
if (lean_obj_tag(v___y_413_) == 0)
{
lean_object* v___x_414_; 
lean_dec_ref_known(v___y_413_, 1);
v___x_414_ = vastitas_storage_close(v_a_411_);
lean_dec(v_a_411_);
if (lean_obj_tag(v___x_414_) == 0)
{
lean_object* v___x_415_; 
lean_dec_ref_known(v___x_414_, 1);
v___x_415_ = bench_report_lean();
return v___x_415_;
}
else
{
return v___x_414_;
}
}
else
{
lean_object* v_a_416_; lean_object* v___x_417_; 
v_a_416_ = lean_ctor_get(v___y_413_, 0);
lean_inc(v_a_416_);
lean_dec_ref_known(v___y_413_, 1);
v___x_417_ = vastitas_storage_close(v_a_411_);
lean_dec(v_a_411_);
if (lean_obj_tag(v___x_417_) == 0)
{
lean_object* v___x_419_; uint8_t v_isShared_420_; uint8_t v_isSharedCheck_424_; 
v_isSharedCheck_424_ = !lean_is_exclusive(v___x_417_);
if (v_isSharedCheck_424_ == 0)
{
lean_object* v_unused_425_; 
v_unused_425_ = lean_ctor_get(v___x_417_, 0);
lean_dec(v_unused_425_);
v___x_419_ = v___x_417_;
v_isShared_420_ = v_isSharedCheck_424_;
goto v_resetjp_418_;
}
else
{
lean_dec(v___x_417_);
v___x_419_ = lean_box(0);
v_isShared_420_ = v_isSharedCheck_424_;
goto v_resetjp_418_;
}
v_resetjp_418_:
{
lean_object* v___x_422_; 
if (v_isShared_420_ == 0)
{
lean_ctor_set_tag(v___x_419_, 1);
lean_ctor_set(v___x_419_, 0, v_a_416_);
v___x_422_ = v___x_419_;
goto v_reusejp_421_;
}
else
{
lean_object* v_reuseFailAlloc_423_; 
v_reuseFailAlloc_423_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_423_, 0, v_a_416_);
v___x_422_ = v_reuseFailAlloc_423_;
goto v_reusejp_421_;
}
v_reusejp_421_:
{
return v___x_422_;
}
}
}
else
{
lean_dec(v_a_416_);
return v___x_417_;
}
}
}
}
else
{
lean_object* v_a_507_; lean_object* v___x_509_; uint8_t v_isShared_510_; uint8_t v_isSharedCheck_514_; 
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
v_a_507_ = lean_ctor_get(v___x_410_, 0);
v_isSharedCheck_514_ = !lean_is_exclusive(v___x_410_);
if (v_isSharedCheck_514_ == 0)
{
v___x_509_ = v___x_410_;
v_isShared_510_ = v_isSharedCheck_514_;
goto v_resetjp_508_;
}
else
{
lean_inc(v_a_507_);
lean_dec(v___x_410_);
v___x_509_ = lean_box(0);
v_isShared_510_ = v_isSharedCheck_514_;
goto v_resetjp_508_;
}
v_resetjp_508_:
{
lean_object* v___x_512_; 
if (v_isShared_510_ == 0)
{
v___x_512_ = v___x_509_;
goto v_reusejp_511_;
}
else
{
lean_object* v_reuseFailAlloc_513_; 
v_reuseFailAlloc_513_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_513_, 0, v_a_507_);
v___x_512_ = v_reuseFailAlloc_513_;
goto v_reusejp_511_;
}
v_reusejp_511_:
{
return v___x_512_;
}
}
}
}
else
{
uint32_t v___x_515_; uint64_t v___x_516_; lean_object* v___x_517_; 
lean_dec(v_scope_389_);
v___x_515_ = 0;
v___x_516_ = lean_uint64_of_nat(v_reps_394_);
v___x_517_ = bench_begin_lean(v___x_515_, v___x_516_, v_verify_398_);
if (lean_obj_tag(v___x_517_) == 0)
{
lean_object* v___x_518_; lean_object* v___x_519_; lean_object* v___x_520_; 
lean_dec_ref_known(v___x_517_, 1);
v___x_518_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_518_, 0, v___x_383_);
lean_ctor_set(v___x_518_, 1, v_reps_394_);
lean_ctor_set(v___x_518_, 2, v___x_385_);
v___x_519_ = lean_box(0);
v___x_520_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v___x_518_, v___x_519_, v___x_383_);
lean_dec_ref_known(v___x_518_, 3);
if (lean_obj_tag(v___x_520_) == 0)
{
lean_object* v___x_521_; 
lean_dec_ref_known(v___x_520_, 1);
v___x_521_ = bench_stop_lean();
if (lean_obj_tag(v___x_521_) == 0)
{
lean_object* v___x_522_; 
lean_dec_ref_known(v___x_521_, 1);
v___x_522_ = bench_report_lean();
return v___x_522_;
}
else
{
return v___x_521_;
}
}
else
{
return v___x_520_;
}
}
else
{
lean_dec(v_reps_394_);
return v___x_517_;
}
}
}
else
{
uint32_t v___x_523_; uint64_t v___x_524_; lean_object* v___x_525_; 
v___x_523_ = lean_uint32_of_nat(v_scope_389_);
lean_dec(v_scope_389_);
v___x_524_ = lean_uint64_of_nat(v_reps_394_);
lean_dec(v_reps_394_);
v___x_525_ = bench_c_run_lean(v___x_523_, v___x_524_, v_verify_398_);
if (lean_obj_tag(v___x_525_) == 0)
{
lean_object* v___x_526_; 
lean_dec_ref_known(v___x_525_, 1);
v___x_526_ = bench_report_lean();
return v___x_526_;
}
else
{
return v___x_525_;
}
}
}
else
{
uint32_t v___x_527_; uint64_t v___x_528_; lean_object* v___x_529_; 
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
lean_dec(v_impl_384_);
v___x_527_ = 0;
v___x_528_ = 1ULL;
v___x_529_ = bench_begin_lean(v___x_527_, v___x_528_, v___x_405_);
if (lean_obj_tag(v___x_529_) == 0)
{
lean_object* v___x_530_; 
lean_dec_ref_known(v___x_529_, 1);
v___x_530_ = lp_allocation__audit_generatedFailure();
if (lean_obj_tag(v___x_530_) == 0)
{
lean_object* v___x_532_; uint8_t v_isShared_533_; uint8_t v_isSharedCheck_538_; 
v_isSharedCheck_538_ = !lean_is_exclusive(v___x_530_);
if (v_isSharedCheck_538_ == 0)
{
lean_object* v_unused_539_; 
v_unused_539_ = lean_ctor_get(v___x_530_, 0);
lean_dec(v_unused_539_);
v___x_532_ = v___x_530_;
v_isShared_533_ = v_isSharedCheck_538_;
goto v_resetjp_531_;
}
else
{
lean_dec(v___x_530_);
v___x_532_ = lean_box(0);
v_isShared_533_ = v_isSharedCheck_538_;
goto v_resetjp_531_;
}
v_resetjp_531_:
{
lean_object* v___x_534_; lean_object* v___x_536_; 
v___x_534_ = ((lean_object*)(lp_allocation__audit_main___closed__5));
if (v_isShared_533_ == 0)
{
lean_ctor_set_tag(v___x_532_, 1);
lean_ctor_set(v___x_532_, 0, v___x_534_);
v___x_536_ = v___x_532_;
goto v_reusejp_535_;
}
else
{
lean_object* v_reuseFailAlloc_537_; 
v_reuseFailAlloc_537_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_537_, 0, v___x_534_);
v___x_536_ = v_reuseFailAlloc_537_;
goto v_reusejp_535_;
}
v_reusejp_535_:
{
return v___x_536_;
}
}
}
else
{
lean_object* v_a_540_; lean_object* v___x_541_; lean_object* v___x_542_; uint8_t v___x_543_; 
v_a_540_ = lean_ctor_get(v___x_530_, 0);
lean_inc(v_a_540_);
v___x_541_ = lean_io_error_to_string(v_a_540_);
v___x_542_ = ((lean_object*)(lp_allocation__audit_main___closed__6));
v___x_543_ = lean_string_dec_eq(v___x_541_, v___x_542_);
lean_dec_ref(v___x_541_);
if (v___x_543_ == 0)
{
return v___x_530_;
}
else
{
lean_object* v___x_544_; 
lean_dec_ref_known(v___x_530_, 1);
v___x_544_ = bench_stop_lean();
if (lean_obj_tag(v___x_544_) == 0)
{
lean_object* v___x_545_; 
lean_dec_ref_known(v___x_544_, 1);
v___x_545_ = bench_report_lean();
return v___x_545_;
}
else
{
return v___x_544_;
}
}
}
}
else
{
return v___x_529_;
}
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
lean_dec(v_impl_384_);
return v___x_403_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
lean_dec(v_impl_384_);
return v___x_401_;
}
}
else
{
lean_dec(v_reps_394_);
lean_dec(v_scope_389_);
lean_dec(v_impl_384_);
return v___x_400_;
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object* v_args_546_, lean_object* v_a_547_){
_start:
{
lean_object* v_res_548_; 
v_res_548_ = _lean_main(v_args_546_);
return v_res_548_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object* v_a_549_, lean_object* v_scope_550_, lean_object* v_range_551_, lean_object* v_b_552_, lean_object* v_i_553_, lean_object* v_hs_554_, lean_object* v_hl_555_){
_start:
{
lean_object* v___x_557_; 
v___x_557_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_549_, v_scope_550_, v_range_551_, v_b_552_, v_i_553_);
return v___x_557_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object* v_a_558_, lean_object* v_scope_559_, lean_object* v_range_560_, lean_object* v_b_561_, lean_object* v_i_562_, lean_object* v_hs_563_, lean_object* v_hl_564_, lean_object* v___y_565_){
_start:
{
lean_object* v_res_566_; 
v_res_566_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(v_a_558_, v_scope_559_, v_range_560_, v_b_561_, v_i_562_, v_hs_563_, v_hl_564_);
lean_dec_ref(v_range_560_);
lean_dec(v_scope_559_);
lean_dec(v_a_558_);
return v_res_566_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object* v_range_567_, lean_object* v_b_568_, lean_object* v_i_569_, lean_object* v_hs_570_, lean_object* v_hl_571_){
_start:
{
lean_object* v___x_573_; 
v___x_573_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_567_, v_b_568_, v_i_569_);
return v___x_573_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object* v_range_574_, lean_object* v_b_575_, lean_object* v_i_576_, lean_object* v_hs_577_, lean_object* v_hl_578_, lean_object* v___y_579_){
_start:
{
lean_object* v_res_580_; 
v_res_580_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(v_range_574_, v_b_575_, v_i_576_, v_hs_577_, v_hl_578_);
lean_dec_ref(v_range_574_);
return v_res_580_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_vastitas__storage__native_VastitasStorageNative(uint8_t builtin);
lean_object* initialize_vastitas__gemm__native_VastitasGemmNative(uint8_t builtin);
lean_object* initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_allocation__audit_Main(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__storage__native_VastitasStorageNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__gemm__native_VastitasGemmNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_allocation__audit_VastitasGenerated_f__0 = _init_lp_allocation__audit_VastitasGenerated_f__0();
lean_mark_persistent(lp_allocation__audit_VastitasGenerated_f__0);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_allocation__audit_Main(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = 0;
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
