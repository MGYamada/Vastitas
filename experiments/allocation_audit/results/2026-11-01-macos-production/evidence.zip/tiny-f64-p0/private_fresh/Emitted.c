// Lean compiler output
// Module: Main
// Imports: public import Init public meta import Init public import VastitasStorageNative public import VastitasGemmNative public import VastitasKernel.IndexedRuntime
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* vastitas_storage_new(uint64_t);
lean_object* vastitas_storage_close(lean_object*);
lean_object* vastitas_storage_allocate(lean_object*, uint32_t, uint8_t, uint64_t);
lean_object* vastitas_storage_fill(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_store(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_pack3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_gemm_execute(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t);
lean_object* vastitas_storage_regroup3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_storage_expect(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_drop(lean_object*, uint32_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_List_get_x21Internal___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_String_Slice_toNat_x21(lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
uint32_t lean_uint32_of_nat(lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
lean_object* lean_io_error_to_string(lean_object*);
static lean_once_cell_t lp_allocation__audit_VastitasGenerated_f__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_allocation__audit_VastitasGenerated_f__0___closed__0;
LEAN_EXPORT lean_object* lp_allocation__audit_VastitasGenerated_f__0;
lean_object* bench_begin_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_stop_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object*);
lean_object* bench_report_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object*);
lean_object* bench_c_run_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_verify_lean(lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object*);
lean_object* audit_mark_lean(uint32_t);
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_allocation__audit_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 1, .m_capacity = 1, .m_length = 0, .m_data = ""};
static const lean_object* lp_allocation__audit_main___closed__0 = (const lean_object*)&lp_allocation__audit_main___closed__0_value;
static const lean_string_object lp_allocation__audit_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "1"};
static const lean_object* lp_allocation__audit_main___closed__1 = (const lean_object*)&lp_allocation__audit_main___closed__1_value;
static const lean_string_object lp_allocation__audit_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "failure"};
static const lean_object* lp_allocation__audit_main___closed__2 = (const lean_object*)&lp_allocation__audit_main___closed__2_value;
static const lean_string_object lp_allocation__audit_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "c"};
static const lean_object* lp_allocation__audit_main___closed__3 = (const lean_object*)&lp_allocation__audit_main___closed__3_value;
static const lean_string_object lp_allocation__audit_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "expected injected native failure"};
static const lean_object* lp_allocation__audit_main___closed__4 = (const lean_object*)&lp_allocation__audit_main___closed__4_value;
static const lean_ctor_object lp_allocation__audit_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_allocation__audit_main___closed__4_value)}};
static const lean_object* lp_allocation__audit_main___closed__5 = (const lean_object*)&lp_allocation__audit_main___closed__5_value;
static const lean_string_object lp_allocation__audit_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 44, .m_capacity = 44, .m_length = 43, .m_data = "E_NATIVE_EXPECT: stored bit pattern differs"};
static const lean_object* lp_allocation__audit_main___closed__6 = (const lean_object*)&lp_allocation__audit_main___closed__6_value;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(0u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0(void){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_obj_once(&lp_allocation__audit_VastitasGenerated_f__0___closed__0, &lp_allocation__audit_VastitasGenerated_f__0___closed__0_once, _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object* v_scope_8_, lean_object* v_reps_9_, lean_object* v_verify_10_, lean_object* v_a_00___x40___internal___hyg_11_){
_start:
{
uint32_t v_scope_boxed_12_; uint64_t v_reps_boxed_13_; uint8_t v_verify_boxed_14_; lean_object* v_res_15_; 
v_scope_boxed_12_ = lean_unbox_uint32(v_scope_8_);
lean_dec(v_scope_8_);
v_reps_boxed_13_ = lean_unbox_uint64(v_reps_9_);
lean_dec_ref(v_reps_9_);
v_verify_boxed_14_ = lean_unbox(v_verify_10_);
v_res_15_ = bench_begin_lean(v_scope_boxed_12_, v_reps_boxed_13_, v_verify_boxed_14_);
return v_res_15_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object* v_a_00___x40___internal___hyg_17_){
_start:
{
lean_object* v_res_18_; 
v_res_18_ = bench_stop_lean();
return v_res_18_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object* v_a_00___x40___internal___hyg_20_){
_start:
{
lean_object* v_res_21_; 
v_res_21_ = bench_report_lean();
return v_res_21_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object* v_scope_26_, lean_object* v_reps_27_, lean_object* v_verify_28_, lean_object* v_a_00___x40___internal___hyg_29_){
_start:
{
uint32_t v_scope_boxed_30_; uint64_t v_reps_boxed_31_; uint8_t v_verify_boxed_32_; lean_object* v_res_33_; 
v_scope_boxed_30_ = lean_unbox_uint32(v_scope_26_);
lean_dec(v_scope_26_);
v_reps_boxed_31_ = lean_unbox_uint64(v_reps_27_);
lean_dec_ref(v_reps_27_);
v_verify_boxed_32_ = lean_unbox(v_verify_28_);
v_res_33_ = bench_c_run_lean(v_scope_boxed_30_, v_reps_boxed_31_, v_verify_boxed_32_);
return v_res_33_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object* v_arena_37_, lean_object* v_reps_38_, lean_object* v_a_00___x40___internal___hyg_39_){
_start:
{
uint64_t v_reps_boxed_40_; lean_object* v_res_41_; 
v_reps_boxed_40_ = lean_unbox_uint64(v_reps_38_);
lean_dec_ref(v_reps_38_);
v_res_41_ = bench_verify_lean(v_arena_37_, v_reps_boxed_40_);
lean_dec(v_arena_37_);
return v_res_41_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce(){
_start:
{
uint64_t v___x_43_; lean_object* v___x_44_; 
v___x_43_ = 9223372036854775807ULL;
v___x_44_ = vastitas_storage_new(v___x_43_);
if (lean_obj_tag(v___x_44_) == 0)
{
lean_object* v_a_45_; lean_object* v_a_47_; lean_object* v___y_58_; uint32_t v___x_70_; uint8_t v___x_71_; uint64_t v___x_72_; lean_object* v___x_73_; 
v_a_45_ = lean_ctor_get(v___x_44_, 0);
lean_inc(v_a_45_);
lean_dec_ref_known(v___x_44_, 1);
v___x_70_ = 0;
v___x_71_ = 0;
v___x_72_ = 24ULL;
v___x_73_ = vastitas_storage_allocate(v_a_45_, v___x_70_, v___x_71_, v___x_72_);
if (lean_obj_tag(v___x_73_) == 0)
{
uint64_t v___x_74_; uint64_t v___x_75_; uint8_t v___x_76_; uint64_t v___x_77_; lean_object* v___x_78_; 
lean_dec_ref_known(v___x_73_, 1);
v___x_74_ = 0ULL;
v___x_75_ = 1ULL;
v___x_76_ = 0;
v___x_77_ = 13842939354630062080ULL;
v___x_78_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_74_, v___x_72_, v___x_75_, v___x_72_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_78_) == 0)
{
uint64_t v___x_79_; uint64_t v___x_80_; uint64_t v___x_81_; lean_object* v___x_82_; 
lean_dec_ref_known(v___x_78_, 1);
v___x_79_ = 2ULL;
v___x_80_ = 12ULL;
v___x_81_ = 4593671619917905920ULL;
v___x_82_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_74_, v___x_79_, v___x_80_, v___x_79_, v___x_76_, v___x_71_, v___x_81_, v___x_74_);
if (lean_obj_tag(v___x_82_) == 0)
{
uint64_t v___x_83_; lean_object* v___x_84_; 
lean_dec_ref_known(v___x_82_, 1);
v___x_83_ = 4607182418800017408ULL;
v___x_84_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_74_, v___x_79_, v___x_80_, v___x_79_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_83_, v___x_74_);
if (lean_obj_tag(v___x_84_) == 0)
{
uint64_t v___x_85_; lean_object* v___x_86_; 
lean_dec_ref_known(v___x_84_, 1);
v___x_85_ = 13826050856027422720ULL;
v___x_86_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_74_, v___x_79_, v___x_80_, v___x_79_, v___x_76_, v___x_75_, v___x_75_, v___x_71_, v___x_85_, v___x_74_);
if (lean_obj_tag(v___x_86_) == 0)
{
uint32_t v___x_87_; uint64_t v___x_88_; lean_object* v___x_89_; 
lean_dec_ref_known(v___x_86_, 1);
v___x_87_ = 1;
v___x_88_ = 15ULL;
v___x_89_ = vastitas_storage_allocate(v_a_45_, v___x_87_, v___x_71_, v___x_88_);
if (lean_obj_tag(v___x_89_) == 0)
{
lean_object* v___x_90_; 
lean_dec_ref_known(v___x_89_, 1);
v___x_90_ = vastitas_storage_fill(v_a_45_, v___x_87_, v___x_74_, v___x_88_, v___x_75_, v___x_88_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_90_) == 0)
{
uint64_t v___x_91_; uint64_t v___x_92_; uint64_t v___x_93_; lean_object* v___x_94_; 
lean_dec_ref_known(v___x_90_, 1);
v___x_91_ = 3ULL;
v___x_92_ = 5ULL;
v___x_93_ = 13821547256400052224ULL;
v___x_94_ = vastitas_storage_fill(v_a_45_, v___x_87_, v___x_74_, v___x_91_, v___x_92_, v___x_91_, v___x_76_, v___x_71_, v___x_93_, v___x_74_);
if (lean_obj_tag(v___x_94_) == 0)
{
uint64_t v___x_95_; uint64_t v___x_96_; lean_object* v___x_97_; 
lean_dec_ref_known(v___x_94_, 1);
v___x_95_ = 4ULL;
v___x_96_ = 4602678819172646912ULL;
v___x_97_ = vastitas_storage_store(v_a_45_, v___x_87_, v___x_74_, v___x_91_, v___x_92_, v___x_91_, v___x_76_, v___x_74_, v___x_95_, v___x_71_, v___x_96_, v___x_74_);
if (lean_obj_tag(v___x_97_) == 0)
{
uint64_t v___x_98_; lean_object* v___x_99_; 
lean_dec_ref_known(v___x_97_, 1);
v___x_98_ = 13828302655841107968ULL;
v___x_99_ = vastitas_storage_store(v_a_45_, v___x_87_, v___x_74_, v___x_91_, v___x_92_, v___x_91_, v___x_76_, v___x_79_, v___x_74_, v___x_71_, v___x_98_, v___x_74_);
if (lean_obj_tag(v___x_99_) == 0)
{
uint32_t v___x_100_; lean_object* v___x_101_; 
lean_dec_ref_known(v___x_99_, 1);
v___x_100_ = 2;
v___x_101_ = vastitas_storage_allocate(v_a_45_, v___x_100_, v___x_71_, v___x_72_);
if (lean_obj_tag(v___x_101_) == 0)
{
lean_object* v___x_102_; 
lean_dec_ref_known(v___x_101_, 1);
v___x_102_ = vastitas_storage_fill(v_a_45_, v___x_100_, v___x_74_, v___x_72_, v___x_75_, v___x_72_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_102_) == 0)
{
uint64_t v___x_103_; lean_object* v___x_104_; 
lean_dec_ref_known(v___x_102_, 1);
v___x_103_ = 6ULL;
v___x_104_ = vastitas_storage_fill(v_a_45_, v___x_100_, v___x_74_, v___x_95_, v___x_103_, v___x_95_, v___x_76_, v___x_71_, v___x_96_, v___x_74_);
if (lean_obj_tag(v___x_104_) == 0)
{
lean_object* v___x_105_; 
lean_dec_ref_known(v___x_104_, 1);
v___x_105_ = vastitas_storage_store(v_a_45_, v___x_100_, v___x_74_, v___x_95_, v___x_103_, v___x_95_, v___x_76_, v___x_91_, v___x_74_, v___x_71_, v___x_93_, v___x_74_);
if (lean_obj_tag(v___x_105_) == 0)
{
uint64_t v___x_106_; lean_object* v___x_107_; 
lean_dec_ref_known(v___x_105_, 1);
v___x_106_ = 4604930618986332160ULL;
v___x_107_ = vastitas_storage_store(v_a_45_, v___x_100_, v___x_74_, v___x_95_, v___x_103_, v___x_95_, v___x_76_, v___x_74_, v___x_92_, v___x_71_, v___x_106_, v___x_74_);
if (lean_obj_tag(v___x_107_) == 0)
{
uint32_t v___x_108_; uint64_t v___x_109_; lean_object* v___x_110_; 
lean_dec_ref_known(v___x_107_, 1);
v___x_108_ = 3;
v___x_109_ = 40ULL;
v___x_110_ = vastitas_storage_allocate(v_a_45_, v___x_108_, v___x_71_, v___x_109_);
if (lean_obj_tag(v___x_110_) == 0)
{
lean_object* v___x_111_; 
lean_dec_ref_known(v___x_110_, 1);
v___x_111_ = vastitas_storage_fill(v_a_45_, v___x_108_, v___x_74_, v___x_109_, v___x_75_, v___x_109_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_111_) == 0)
{
uint32_t v___x_112_; lean_object* v___x_113_; 
lean_dec_ref_known(v___x_111_, 1);
v___x_112_ = 4;
v___x_113_ = vastitas_storage_allocate(v_a_45_, v___x_112_, v___x_71_, v___x_109_);
if (lean_obj_tag(v___x_113_) == 0)
{
lean_object* v___x_114_; 
lean_dec_ref_known(v___x_113_, 1);
v___x_114_ = vastitas_storage_fill(v_a_45_, v___x_112_, v___x_74_, v___x_109_, v___x_75_, v___x_109_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_114_) == 0)
{
uint32_t v___x_115_; uint64_t v___x_116_; lean_object* v___x_117_; 
lean_dec_ref_known(v___x_114_, 1);
v___x_115_ = 5;
v___x_116_ = 60ULL;
v___x_117_ = vastitas_storage_allocate(v_a_45_, v___x_115_, v___x_71_, v___x_116_);
if (lean_obj_tag(v___x_117_) == 0)
{
lean_object* v___x_118_; 
lean_dec_ref_known(v___x_117_, 1);
v___x_118_ = vastitas_storage_fill(v_a_45_, v___x_115_, v___x_74_, v___x_116_, v___x_75_, v___x_116_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_118_) == 0)
{
uint64_t v___x_119_; lean_object* v___x_120_; 
lean_dec_ref_known(v___x_118_, 1);
v___x_119_ = 8ULL;
v___x_120_ = vastitas_storage_pack3(v_a_45_, v___x_70_, v___x_74_, v___x_79_, v___x_80_, v___x_79_, v___x_76_, v___x_108_, v___x_74_, v___x_119_, v___x_91_, v___x_119_, v___x_76_, v___x_79_, v___x_91_, v___x_95_);
if (lean_obj_tag(v___x_120_) == 0)
{
lean_object* v___x_121_; 
lean_dec_ref_known(v___x_120_, 1);
v___x_121_ = vastitas_gemm_execute(v_a_45_, v___x_108_, v___x_74_, v___x_119_, v___x_91_, v___x_119_, v___x_76_, v___x_76_, v___x_87_, v___x_74_, v___x_91_, v___x_92_, v___x_91_, v___x_76_, v___x_76_, v___x_112_, v___x_74_, v___x_119_, v___x_92_, v___x_119_, v___x_76_, v___x_71_);
if (lean_obj_tag(v___x_121_) == 0)
{
uint64_t v___x_122_; uint64_t v___x_123_; uint64_t v___x_124_; lean_object* v___x_125_; 
lean_dec_ref_known(v___x_121_, 1);
v___x_122_ = 10ULL;
v___x_123_ = 48ULL;
v___x_124_ = 42ULL;
v___x_125_ = vastitas_storage_regroup3(v_a_45_, v___x_112_, v___x_74_, v___x_119_, v___x_92_, v___x_119_, v___x_76_, v___x_108_, v___x_74_, v___x_122_, v___x_95_, v___x_122_, v___x_76_, v___x_79_, v___x_95_, v___x_92_, v___x_123_, v___x_124_);
if (lean_obj_tag(v___x_125_) == 0)
{
lean_object* v___x_126_; 
lean_dec_ref_known(v___x_125_, 1);
v___x_126_ = vastitas_gemm_execute(v_a_45_, v___x_108_, v___x_74_, v___x_122_, v___x_95_, v___x_122_, v___x_76_, v___x_76_, v___x_100_, v___x_74_, v___x_95_, v___x_103_, v___x_95_, v___x_76_, v___x_76_, v___x_115_, v___x_74_, v___x_122_, v___x_103_, v___x_122_, v___x_76_, v___x_71_);
if (lean_obj_tag(v___x_126_) == 0)
{
uint64_t v___x_127_; lean_object* v___x_128_; 
lean_dec_ref_known(v___x_126_, 1);
v___x_127_ = 13822532418818539520ULL;
v___x_128_ = vastitas_storage_expect(v_a_45_, v___x_115_, v___x_74_, v___x_122_, v___x_103_, v___x_122_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_127_, v___x_74_);
if (lean_obj_tag(v___x_128_) == 0)
{
uint64_t v___x_129_; lean_object* v___x_130_; 
lean_dec_ref_known(v___x_128_, 1);
v___x_129_ = 13820984306446630912ULL;
v___x_130_ = vastitas_storage_expect(v_a_45_, v___x_115_, v___x_74_, v___x_122_, v___x_103_, v___x_122_, v___x_76_, v___x_75_, v___x_92_, v___x_71_, v___x_129_, v___x_74_);
if (lean_obj_tag(v___x_130_) == 0)
{
uint64_t v___x_131_; uint64_t v___x_132_; lean_object* v___x_133_; 
lean_dec_ref_known(v___x_130_, 1);
v___x_131_ = 9ULL;
v___x_132_ = 4590293920197378048ULL;
v___x_133_ = vastitas_storage_expect(v_a_45_, v___x_115_, v___x_74_, v___x_122_, v___x_103_, v___x_122_, v___x_76_, v___x_131_, v___x_74_, v___x_71_, v___x_132_, v___x_74_);
if (lean_obj_tag(v___x_133_) == 0)
{
lean_object* v___x_134_; 
lean_dec_ref_known(v___x_133_, 1);
v___x_134_ = vastitas_storage_drop(v_a_45_, v___x_115_);
if (lean_obj_tag(v___x_134_) == 0)
{
lean_object* v___x_135_; 
lean_dec_ref_known(v___x_134_, 1);
v___x_135_ = vastitas_storage_drop(v_a_45_, v___x_112_);
if (lean_obj_tag(v___x_135_) == 0)
{
lean_object* v___x_136_; 
lean_dec_ref_known(v___x_135_, 1);
v___x_136_ = vastitas_storage_drop(v_a_45_, v___x_108_);
if (lean_obj_tag(v___x_136_) == 0)
{
lean_object* v___x_137_; 
lean_dec_ref_known(v___x_136_, 1);
v___x_137_ = vastitas_storage_drop(v_a_45_, v___x_100_);
if (lean_obj_tag(v___x_137_) == 0)
{
lean_object* v___x_138_; 
lean_dec_ref_known(v___x_137_, 1);
v___x_138_ = vastitas_storage_drop(v_a_45_, v___x_87_);
if (lean_obj_tag(v___x_138_) == 0)
{
lean_object* v___x_139_; 
lean_dec_ref_known(v___x_138_, 1);
v___x_139_ = vastitas_storage_drop(v_a_45_, v___x_70_);
if (lean_obj_tag(v___x_139_) == 0)
{
lean_object* v___x_140_; 
lean_dec_ref_known(v___x_139_, 1);
v___x_140_ = lean_box(0);
v_a_47_ = v___x_140_;
goto v___jp_46_;
}
else
{
v___y_58_ = v___x_139_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_138_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_137_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_136_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_135_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_134_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_133_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_130_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_128_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_126_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_125_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_121_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_120_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_118_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_117_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_114_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_113_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_111_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_110_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_107_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_105_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_104_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_102_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_101_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_99_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_97_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_94_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_90_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_89_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_86_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_84_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_82_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_78_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_73_;
goto v___jp_57_;
}
v___jp_46_:
{
lean_object* v___x_48_; 
v___x_48_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_48_) == 0)
{
lean_object* v___x_50_; uint8_t v_isShared_51_; uint8_t v_isSharedCheck_55_; 
v_isSharedCheck_55_ = !lean_is_exclusive(v___x_48_);
if (v_isSharedCheck_55_ == 0)
{
lean_object* v_unused_56_; 
v_unused_56_ = lean_ctor_get(v___x_48_, 0);
lean_dec(v_unused_56_);
v___x_50_ = v___x_48_;
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
else
{
lean_dec(v___x_48_);
v___x_50_ = lean_box(0);
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
v_resetjp_49_:
{
lean_object* v___x_53_; 
if (v_isShared_51_ == 0)
{
lean_ctor_set(v___x_50_, 0, v_a_47_);
v___x_53_ = v___x_50_;
goto v_reusejp_52_;
}
else
{
lean_object* v_reuseFailAlloc_54_; 
v_reuseFailAlloc_54_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_54_, 0, v_a_47_);
v___x_53_ = v_reuseFailAlloc_54_;
goto v_reusejp_52_;
}
v_reusejp_52_:
{
return v___x_53_;
}
}
}
else
{
return v___x_48_;
}
}
v___jp_57_:
{
if (lean_obj_tag(v___y_58_) == 0)
{
lean_object* v_a_59_; 
v_a_59_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_59_);
lean_dec_ref_known(v___y_58_, 1);
v_a_47_ = v_a_59_;
goto v___jp_46_;
}
else
{
lean_object* v_a_60_; lean_object* v___x_61_; 
v_a_60_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_60_);
lean_dec_ref_known(v___y_58_, 1);
v___x_61_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_61_) == 0)
{
lean_object* v___x_63_; uint8_t v_isShared_64_; uint8_t v_isSharedCheck_68_; 
v_isSharedCheck_68_ = !lean_is_exclusive(v___x_61_);
if (v_isSharedCheck_68_ == 0)
{
lean_object* v_unused_69_; 
v_unused_69_ = lean_ctor_get(v___x_61_, 0);
lean_dec(v_unused_69_);
v___x_63_ = v___x_61_;
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
else
{
lean_dec(v___x_61_);
v___x_63_ = lean_box(0);
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
v_resetjp_62_:
{
lean_object* v___x_66_; 
if (v_isShared_64_ == 0)
{
lean_ctor_set_tag(v___x_63_, 1);
lean_ctor_set(v___x_63_, 0, v_a_60_);
v___x_66_ = v___x_63_;
goto v_reusejp_65_;
}
else
{
lean_object* v_reuseFailAlloc_67_; 
v_reuseFailAlloc_67_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_67_, 0, v_a_60_);
v___x_66_ = v_reuseFailAlloc_67_;
goto v_reusejp_65_;
}
v_reusejp_65_:
{
return v___x_66_;
}
}
}
else
{
lean_dec(v_a_60_);
return v___x_61_;
}
}
}
}
else
{
lean_object* v_a_141_; lean_object* v___x_143_; uint8_t v_isShared_144_; uint8_t v_isSharedCheck_148_; 
v_a_141_ = lean_ctor_get(v___x_44_, 0);
v_isSharedCheck_148_ = !lean_is_exclusive(v___x_44_);
if (v_isSharedCheck_148_ == 0)
{
v___x_143_ = v___x_44_;
v_isShared_144_ = v_isSharedCheck_148_;
goto v_resetjp_142_;
}
else
{
lean_inc(v_a_141_);
lean_dec(v___x_44_);
v___x_143_ = lean_box(0);
v_isShared_144_ = v_isSharedCheck_148_;
goto v_resetjp_142_;
}
v_resetjp_142_:
{
lean_object* v___x_146_; 
if (v_isShared_144_ == 0)
{
v___x_146_ = v___x_143_;
goto v_reusejp_145_;
}
else
{
lean_object* v_reuseFailAlloc_147_; 
v_reuseFailAlloc_147_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_147_, 0, v_a_141_);
v___x_146_ = v_reuseFailAlloc_147_;
goto v_reusejp_145_;
}
v_reusejp_145_:
{
return v___x_146_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object* v_a_149_){
_start:
{
lean_object* v_res_150_; 
v_res_150_ = lp_allocation__audit_generatedOnce();
return v_res_150_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure(){
_start:
{
uint64_t v___x_152_; lean_object* v___x_153_; 
v___x_152_ = 9223372036854775807ULL;
v___x_153_ = vastitas_storage_new(v___x_152_);
if (lean_obj_tag(v___x_153_) == 0)
{
lean_object* v_a_154_; lean_object* v_a_156_; lean_object* v___y_167_; uint32_t v___x_179_; uint8_t v___x_180_; uint64_t v___x_181_; lean_object* v___x_182_; 
v_a_154_ = lean_ctor_get(v___x_153_, 0);
lean_inc(v_a_154_);
lean_dec_ref_known(v___x_153_, 1);
v___x_179_ = 0;
v___x_180_ = 0;
v___x_181_ = 24ULL;
v___x_182_ = vastitas_storage_allocate(v_a_154_, v___x_179_, v___x_180_, v___x_181_);
if (lean_obj_tag(v___x_182_) == 0)
{
uint64_t v___x_183_; uint64_t v___x_184_; uint8_t v___x_185_; uint64_t v___x_186_; lean_object* v___x_187_; 
lean_dec_ref_known(v___x_182_, 1);
v___x_183_ = 0ULL;
v___x_184_ = 1ULL;
v___x_185_ = 0;
v___x_186_ = 13842939354630062080ULL;
v___x_187_ = vastitas_storage_fill(v_a_154_, v___x_179_, v___x_183_, v___x_181_, v___x_184_, v___x_181_, v___x_185_, v___x_180_, v___x_186_, v___x_183_);
if (lean_obj_tag(v___x_187_) == 0)
{
uint64_t v___x_188_; uint64_t v___x_189_; uint64_t v___x_190_; lean_object* v___x_191_; 
lean_dec_ref_known(v___x_187_, 1);
v___x_188_ = 2ULL;
v___x_189_ = 12ULL;
v___x_190_ = 4593671619917905920ULL;
v___x_191_ = vastitas_storage_fill(v_a_154_, v___x_179_, v___x_183_, v___x_188_, v___x_189_, v___x_188_, v___x_185_, v___x_180_, v___x_190_, v___x_183_);
if (lean_obj_tag(v___x_191_) == 0)
{
uint64_t v___x_192_; lean_object* v___x_193_; 
lean_dec_ref_known(v___x_191_, 1);
v___x_192_ = 4607182418800017408ULL;
v___x_193_ = vastitas_storage_store(v_a_154_, v___x_179_, v___x_183_, v___x_188_, v___x_189_, v___x_188_, v___x_185_, v___x_183_, v___x_183_, v___x_180_, v___x_192_, v___x_183_);
if (lean_obj_tag(v___x_193_) == 0)
{
uint64_t v___x_194_; lean_object* v___x_195_; 
lean_dec_ref_known(v___x_193_, 1);
v___x_194_ = 13826050856027422720ULL;
v___x_195_ = vastitas_storage_store(v_a_154_, v___x_179_, v___x_183_, v___x_188_, v___x_189_, v___x_188_, v___x_185_, v___x_184_, v___x_184_, v___x_180_, v___x_194_, v___x_183_);
if (lean_obj_tag(v___x_195_) == 0)
{
uint32_t v___x_196_; uint64_t v___x_197_; lean_object* v___x_198_; 
lean_dec_ref_known(v___x_195_, 1);
v___x_196_ = 1;
v___x_197_ = 15ULL;
v___x_198_ = vastitas_storage_allocate(v_a_154_, v___x_196_, v___x_180_, v___x_197_);
if (lean_obj_tag(v___x_198_) == 0)
{
lean_object* v___x_199_; 
lean_dec_ref_known(v___x_198_, 1);
v___x_199_ = vastitas_storage_fill(v_a_154_, v___x_196_, v___x_183_, v___x_197_, v___x_184_, v___x_197_, v___x_185_, v___x_180_, v___x_186_, v___x_183_);
if (lean_obj_tag(v___x_199_) == 0)
{
uint64_t v___x_200_; uint64_t v___x_201_; uint64_t v___x_202_; lean_object* v___x_203_; 
lean_dec_ref_known(v___x_199_, 1);
v___x_200_ = 3ULL;
v___x_201_ = 5ULL;
v___x_202_ = 13821547256400052224ULL;
v___x_203_ = vastitas_storage_fill(v_a_154_, v___x_196_, v___x_183_, v___x_200_, v___x_201_, v___x_200_, v___x_185_, v___x_180_, v___x_202_, v___x_183_);
if (lean_obj_tag(v___x_203_) == 0)
{
uint64_t v___x_204_; uint64_t v___x_205_; lean_object* v___x_206_; 
lean_dec_ref_known(v___x_203_, 1);
v___x_204_ = 4ULL;
v___x_205_ = 4602678819172646912ULL;
v___x_206_ = vastitas_storage_store(v_a_154_, v___x_196_, v___x_183_, v___x_200_, v___x_201_, v___x_200_, v___x_185_, v___x_183_, v___x_204_, v___x_180_, v___x_205_, v___x_183_);
if (lean_obj_tag(v___x_206_) == 0)
{
uint64_t v___x_207_; lean_object* v___x_208_; 
lean_dec_ref_known(v___x_206_, 1);
v___x_207_ = 13828302655841107968ULL;
v___x_208_ = vastitas_storage_store(v_a_154_, v___x_196_, v___x_183_, v___x_200_, v___x_201_, v___x_200_, v___x_185_, v___x_188_, v___x_183_, v___x_180_, v___x_207_, v___x_183_);
if (lean_obj_tag(v___x_208_) == 0)
{
uint32_t v___x_209_; lean_object* v___x_210_; 
lean_dec_ref_known(v___x_208_, 1);
v___x_209_ = 2;
v___x_210_ = vastitas_storage_allocate(v_a_154_, v___x_209_, v___x_180_, v___x_181_);
if (lean_obj_tag(v___x_210_) == 0)
{
lean_object* v___x_211_; 
lean_dec_ref_known(v___x_210_, 1);
v___x_211_ = vastitas_storage_fill(v_a_154_, v___x_209_, v___x_183_, v___x_181_, v___x_184_, v___x_181_, v___x_185_, v___x_180_, v___x_186_, v___x_183_);
if (lean_obj_tag(v___x_211_) == 0)
{
uint64_t v___x_212_; lean_object* v___x_213_; 
lean_dec_ref_known(v___x_211_, 1);
v___x_212_ = 6ULL;
v___x_213_ = vastitas_storage_fill(v_a_154_, v___x_209_, v___x_183_, v___x_204_, v___x_212_, v___x_204_, v___x_185_, v___x_180_, v___x_205_, v___x_183_);
if (lean_obj_tag(v___x_213_) == 0)
{
lean_object* v___x_214_; 
lean_dec_ref_known(v___x_213_, 1);
v___x_214_ = vastitas_storage_store(v_a_154_, v___x_209_, v___x_183_, v___x_204_, v___x_212_, v___x_204_, v___x_185_, v___x_200_, v___x_183_, v___x_180_, v___x_202_, v___x_183_);
if (lean_obj_tag(v___x_214_) == 0)
{
uint64_t v___x_215_; lean_object* v___x_216_; 
lean_dec_ref_known(v___x_214_, 1);
v___x_215_ = 4604930618986332160ULL;
v___x_216_ = vastitas_storage_store(v_a_154_, v___x_209_, v___x_183_, v___x_204_, v___x_212_, v___x_204_, v___x_185_, v___x_183_, v___x_201_, v___x_180_, v___x_215_, v___x_183_);
if (lean_obj_tag(v___x_216_) == 0)
{
uint32_t v___x_217_; uint64_t v___x_218_; lean_object* v___x_219_; 
lean_dec_ref_known(v___x_216_, 1);
v___x_217_ = 3;
v___x_218_ = 40ULL;
v___x_219_ = vastitas_storage_allocate(v_a_154_, v___x_217_, v___x_180_, v___x_218_);
if (lean_obj_tag(v___x_219_) == 0)
{
lean_object* v___x_220_; 
lean_dec_ref_known(v___x_219_, 1);
v___x_220_ = vastitas_storage_fill(v_a_154_, v___x_217_, v___x_183_, v___x_218_, v___x_184_, v___x_218_, v___x_185_, v___x_180_, v___x_186_, v___x_183_);
if (lean_obj_tag(v___x_220_) == 0)
{
uint32_t v___x_221_; lean_object* v___x_222_; 
lean_dec_ref_known(v___x_220_, 1);
v___x_221_ = 4;
v___x_222_ = vastitas_storage_allocate(v_a_154_, v___x_221_, v___x_180_, v___x_218_);
if (lean_obj_tag(v___x_222_) == 0)
{
lean_object* v___x_223_; 
lean_dec_ref_known(v___x_222_, 1);
v___x_223_ = vastitas_storage_fill(v_a_154_, v___x_221_, v___x_183_, v___x_218_, v___x_184_, v___x_218_, v___x_185_, v___x_180_, v___x_186_, v___x_183_);
if (lean_obj_tag(v___x_223_) == 0)
{
uint32_t v___x_224_; uint64_t v___x_225_; lean_object* v___x_226_; 
lean_dec_ref_known(v___x_223_, 1);
v___x_224_ = 5;
v___x_225_ = 60ULL;
v___x_226_ = vastitas_storage_allocate(v_a_154_, v___x_224_, v___x_180_, v___x_225_);
if (lean_obj_tag(v___x_226_) == 0)
{
lean_object* v___x_227_; 
lean_dec_ref_known(v___x_226_, 1);
v___x_227_ = vastitas_storage_fill(v_a_154_, v___x_224_, v___x_183_, v___x_225_, v___x_184_, v___x_225_, v___x_185_, v___x_180_, v___x_186_, v___x_183_);
if (lean_obj_tag(v___x_227_) == 0)
{
uint64_t v___x_228_; lean_object* v___x_229_; 
lean_dec_ref_known(v___x_227_, 1);
v___x_228_ = 8ULL;
v___x_229_ = vastitas_storage_pack3(v_a_154_, v___x_179_, v___x_183_, v___x_188_, v___x_189_, v___x_188_, v___x_185_, v___x_217_, v___x_183_, v___x_228_, v___x_200_, v___x_228_, v___x_185_, v___x_188_, v___x_200_, v___x_204_);
if (lean_obj_tag(v___x_229_) == 0)
{
lean_object* v___x_230_; 
lean_dec_ref_known(v___x_229_, 1);
v___x_230_ = vastitas_gemm_execute(v_a_154_, v___x_217_, v___x_183_, v___x_228_, v___x_200_, v___x_228_, v___x_185_, v___x_185_, v___x_196_, v___x_183_, v___x_200_, v___x_201_, v___x_200_, v___x_185_, v___x_185_, v___x_221_, v___x_183_, v___x_228_, v___x_201_, v___x_228_, v___x_185_, v___x_180_);
if (lean_obj_tag(v___x_230_) == 0)
{
uint64_t v___x_231_; uint64_t v___x_232_; uint64_t v___x_233_; lean_object* v___x_234_; 
lean_dec_ref_known(v___x_230_, 1);
v___x_231_ = 10ULL;
v___x_232_ = 48ULL;
v___x_233_ = 42ULL;
v___x_234_ = vastitas_storage_regroup3(v_a_154_, v___x_221_, v___x_183_, v___x_228_, v___x_201_, v___x_228_, v___x_185_, v___x_217_, v___x_183_, v___x_231_, v___x_204_, v___x_231_, v___x_185_, v___x_188_, v___x_204_, v___x_201_, v___x_232_, v___x_233_);
if (lean_obj_tag(v___x_234_) == 0)
{
lean_object* v___x_235_; 
lean_dec_ref_known(v___x_234_, 1);
v___x_235_ = vastitas_gemm_execute(v_a_154_, v___x_217_, v___x_183_, v___x_231_, v___x_204_, v___x_231_, v___x_185_, v___x_185_, v___x_209_, v___x_183_, v___x_204_, v___x_212_, v___x_204_, v___x_185_, v___x_185_, v___x_224_, v___x_183_, v___x_231_, v___x_212_, v___x_231_, v___x_185_, v___x_180_);
if (lean_obj_tag(v___x_235_) == 0)
{
uint64_t v___x_236_; lean_object* v___x_237_; 
lean_dec_ref_known(v___x_235_, 1);
v___x_236_ = 13822532418818539521ULL;
v___x_237_ = vastitas_storage_expect(v_a_154_, v___x_224_, v___x_183_, v___x_231_, v___x_212_, v___x_231_, v___x_185_, v___x_183_, v___x_183_, v___x_180_, v___x_236_, v___x_183_);
if (lean_obj_tag(v___x_237_) == 0)
{
uint64_t v___x_238_; lean_object* v___x_239_; 
lean_dec_ref_known(v___x_237_, 1);
v___x_238_ = 13820984306446630912ULL;
v___x_239_ = vastitas_storage_expect(v_a_154_, v___x_224_, v___x_183_, v___x_231_, v___x_212_, v___x_231_, v___x_185_, v___x_184_, v___x_201_, v___x_180_, v___x_238_, v___x_183_);
if (lean_obj_tag(v___x_239_) == 0)
{
uint64_t v___x_240_; uint64_t v___x_241_; lean_object* v___x_242_; 
lean_dec_ref_known(v___x_239_, 1);
v___x_240_ = 9ULL;
v___x_241_ = 4590293920197378048ULL;
v___x_242_ = vastitas_storage_expect(v_a_154_, v___x_224_, v___x_183_, v___x_231_, v___x_212_, v___x_231_, v___x_185_, v___x_240_, v___x_183_, v___x_180_, v___x_241_, v___x_183_);
if (lean_obj_tag(v___x_242_) == 0)
{
lean_object* v___x_243_; 
lean_dec_ref_known(v___x_242_, 1);
v___x_243_ = vastitas_storage_drop(v_a_154_, v___x_224_);
if (lean_obj_tag(v___x_243_) == 0)
{
lean_object* v___x_244_; 
lean_dec_ref_known(v___x_243_, 1);
v___x_244_ = vastitas_storage_drop(v_a_154_, v___x_221_);
if (lean_obj_tag(v___x_244_) == 0)
{
lean_object* v___x_245_; 
lean_dec_ref_known(v___x_244_, 1);
v___x_245_ = vastitas_storage_drop(v_a_154_, v___x_217_);
if (lean_obj_tag(v___x_245_) == 0)
{
lean_object* v___x_246_; 
lean_dec_ref_known(v___x_245_, 1);
v___x_246_ = vastitas_storage_drop(v_a_154_, v___x_209_);
if (lean_obj_tag(v___x_246_) == 0)
{
lean_object* v___x_247_; 
lean_dec_ref_known(v___x_246_, 1);
v___x_247_ = vastitas_storage_drop(v_a_154_, v___x_196_);
if (lean_obj_tag(v___x_247_) == 0)
{
lean_object* v___x_248_; 
lean_dec_ref_known(v___x_247_, 1);
v___x_248_ = vastitas_storage_drop(v_a_154_, v___x_179_);
if (lean_obj_tag(v___x_248_) == 0)
{
lean_object* v___x_249_; 
lean_dec_ref_known(v___x_248_, 1);
v___x_249_ = lean_box(0);
v_a_156_ = v___x_249_;
goto v___jp_155_;
}
else
{
v___y_167_ = v___x_248_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_247_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_246_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_245_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_244_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_243_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_242_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_239_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_237_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_235_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_234_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_230_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_229_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_227_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_226_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_223_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_222_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_220_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_219_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_216_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_214_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_213_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_211_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_210_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_208_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_206_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_203_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_199_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_198_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_195_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_193_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_191_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_187_;
goto v___jp_166_;
}
}
else
{
v___y_167_ = v___x_182_;
goto v___jp_166_;
}
v___jp_155_:
{
lean_object* v___x_157_; 
v___x_157_ = vastitas_storage_close(v_a_154_);
lean_dec(v_a_154_);
if (lean_obj_tag(v___x_157_) == 0)
{
lean_object* v___x_159_; uint8_t v_isShared_160_; uint8_t v_isSharedCheck_164_; 
v_isSharedCheck_164_ = !lean_is_exclusive(v___x_157_);
if (v_isSharedCheck_164_ == 0)
{
lean_object* v_unused_165_; 
v_unused_165_ = lean_ctor_get(v___x_157_, 0);
lean_dec(v_unused_165_);
v___x_159_ = v___x_157_;
v_isShared_160_ = v_isSharedCheck_164_;
goto v_resetjp_158_;
}
else
{
lean_dec(v___x_157_);
v___x_159_ = lean_box(0);
v_isShared_160_ = v_isSharedCheck_164_;
goto v_resetjp_158_;
}
v_resetjp_158_:
{
lean_object* v___x_162_; 
if (v_isShared_160_ == 0)
{
lean_ctor_set(v___x_159_, 0, v_a_156_);
v___x_162_ = v___x_159_;
goto v_reusejp_161_;
}
else
{
lean_object* v_reuseFailAlloc_163_; 
v_reuseFailAlloc_163_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_163_, 0, v_a_156_);
v___x_162_ = v_reuseFailAlloc_163_;
goto v_reusejp_161_;
}
v_reusejp_161_:
{
return v___x_162_;
}
}
}
else
{
return v___x_157_;
}
}
v___jp_166_:
{
if (lean_obj_tag(v___y_167_) == 0)
{
lean_object* v_a_168_; 
v_a_168_ = lean_ctor_get(v___y_167_, 0);
lean_inc(v_a_168_);
lean_dec_ref_known(v___y_167_, 1);
v_a_156_ = v_a_168_;
goto v___jp_155_;
}
else
{
lean_object* v_a_169_; lean_object* v___x_170_; 
v_a_169_ = lean_ctor_get(v___y_167_, 0);
lean_inc(v_a_169_);
lean_dec_ref_known(v___y_167_, 1);
v___x_170_ = vastitas_storage_close(v_a_154_);
lean_dec(v_a_154_);
if (lean_obj_tag(v___x_170_) == 0)
{
lean_object* v___x_172_; uint8_t v_isShared_173_; uint8_t v_isSharedCheck_177_; 
v_isSharedCheck_177_ = !lean_is_exclusive(v___x_170_);
if (v_isSharedCheck_177_ == 0)
{
lean_object* v_unused_178_; 
v_unused_178_ = lean_ctor_get(v___x_170_, 0);
lean_dec(v_unused_178_);
v___x_172_ = v___x_170_;
v_isShared_173_ = v_isSharedCheck_177_;
goto v_resetjp_171_;
}
else
{
lean_dec(v___x_170_);
v___x_172_ = lean_box(0);
v_isShared_173_ = v_isSharedCheck_177_;
goto v_resetjp_171_;
}
v_resetjp_171_:
{
lean_object* v___x_175_; 
if (v_isShared_173_ == 0)
{
lean_ctor_set_tag(v___x_172_, 1);
lean_ctor_set(v___x_172_, 0, v_a_169_);
v___x_175_ = v___x_172_;
goto v_reusejp_174_;
}
else
{
lean_object* v_reuseFailAlloc_176_; 
v_reuseFailAlloc_176_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_176_, 0, v_a_169_);
v___x_175_ = v_reuseFailAlloc_176_;
goto v_reusejp_174_;
}
v_reusejp_174_:
{
return v___x_175_;
}
}
}
else
{
lean_dec(v_a_169_);
return v___x_170_;
}
}
}
}
else
{
lean_object* v_a_250_; lean_object* v___x_252_; uint8_t v_isShared_253_; uint8_t v_isSharedCheck_257_; 
v_a_250_ = lean_ctor_get(v___x_153_, 0);
v_isSharedCheck_257_ = !lean_is_exclusive(v___x_153_);
if (v_isSharedCheck_257_ == 0)
{
v___x_252_ = v___x_153_;
v_isShared_253_ = v_isSharedCheck_257_;
goto v_resetjp_251_;
}
else
{
lean_inc(v_a_250_);
lean_dec(v___x_153_);
v___x_252_ = lean_box(0);
v_isShared_253_ = v_isSharedCheck_257_;
goto v_resetjp_251_;
}
v_resetjp_251_:
{
lean_object* v___x_255_; 
if (v_isShared_253_ == 0)
{
v___x_255_ = v___x_252_;
goto v_reusejp_254_;
}
else
{
lean_object* v_reuseFailAlloc_256_; 
v_reuseFailAlloc_256_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_256_, 0, v_a_250_);
v___x_255_ = v_reuseFailAlloc_256_;
goto v_reusejp_254_;
}
v_reusejp_254_:
{
return v___x_255_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object* v_a_258_){
_start:
{
lean_object* v_res_259_; 
v_res_259_ = lp_allocation__audit_generatedFailure();
return v_res_259_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object* v_phase_262_, lean_object* v_a_00___x40___internal___hyg_263_){
_start:
{
uint32_t v_phase_boxed_264_; lean_object* v_res_265_; 
v_phase_boxed_264_ = lean_unbox_uint32(v_phase_262_);
lean_dec(v_phase_262_);
v_res_265_ = audit_mark_lean(v_phase_boxed_264_);
return v_res_265_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object* v_a_266_, lean_object* v_scope_267_, lean_object* v_range_268_, lean_object* v_b_269_, lean_object* v_i_270_){
_start:
{
lean_object* v_stop_272_; lean_object* v_step_273_; uint8_t v___x_274_; 
v_stop_272_ = lean_ctor_get(v_range_268_, 1);
v_step_273_ = lean_ctor_get(v_range_268_, 2);
v___x_274_ = lean_nat_dec_lt(v_i_270_, v_stop_272_);
if (v___x_274_ == 0)
{
lean_object* v___x_275_; 
lean_dec(v_i_270_);
v___x_275_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_275_, 0, v_b_269_);
return v___x_275_;
}
else
{
uint32_t v___x_276_; uint64_t v___x_277_; uint64_t v___x_278_; uint64_t v___x_279_; lean_object* v___x_280_; uint8_t v___x_281_; uint32_t v___x_282_; uint64_t v___x_283_; uint64_t v___x_284_; uint32_t v___x_285_; uint64_t v___x_286_; uint32_t v___x_287_; uint8_t v___x_288_; uint32_t v___x_289_; uint64_t v___x_290_; uint32_t v___x_291_; lean_object* v___x_292_; uint64_t v___x_293_; lean_object* v___x_294_; 
v___x_276_ = 0;
v___x_277_ = 0ULL;
v___x_278_ = 2ULL;
v___x_279_ = 12ULL;
v___x_280_ = lean_unsigned_to_nat(0u);
v___x_281_ = lean_nat_dec_eq(v_scope_267_, v___x_280_);
v___x_282_ = 3;
v___x_283_ = 3ULL;
v___x_284_ = 4ULL;
v___x_285_ = 1;
v___x_286_ = 5ULL;
v___x_287_ = 4;
v___x_288_ = 0;
v___x_289_ = 2;
v___x_290_ = 6ULL;
v___x_291_ = 5;
v___x_292_ = lean_box(0);
v___x_293_ = 8ULL;
v___x_294_ = vastitas_storage_pack3(v_a_266_, v___x_276_, v___x_277_, v___x_278_, v___x_279_, v___x_278_, v___x_281_, v___x_282_, v___x_277_, v___x_293_, v___x_283_, v___x_293_, v___x_281_, v___x_278_, v___x_283_, v___x_284_);
if (lean_obj_tag(v___x_294_) == 0)
{
lean_object* v___x_295_; 
lean_dec_ref_known(v___x_294_, 1);
v___x_295_ = vastitas_gemm_execute(v_a_266_, v___x_282_, v___x_277_, v___x_293_, v___x_283_, v___x_293_, v___x_281_, v___x_281_, v___x_285_, v___x_277_, v___x_283_, v___x_286_, v___x_283_, v___x_281_, v___x_281_, v___x_287_, v___x_277_, v___x_293_, v___x_286_, v___x_293_, v___x_281_, v___x_288_);
if (lean_obj_tag(v___x_295_) == 0)
{
uint64_t v___x_296_; uint64_t v___x_297_; uint64_t v___x_298_; lean_object* v___x_299_; 
lean_dec_ref_known(v___x_295_, 1);
v___x_296_ = 10ULL;
v___x_297_ = 48ULL;
v___x_298_ = 42ULL;
v___x_299_ = vastitas_storage_regroup3(v_a_266_, v___x_287_, v___x_277_, v___x_293_, v___x_286_, v___x_293_, v___x_281_, v___x_282_, v___x_277_, v___x_296_, v___x_284_, v___x_296_, v___x_281_, v___x_278_, v___x_284_, v___x_286_, v___x_297_, v___x_298_);
if (lean_obj_tag(v___x_299_) == 0)
{
lean_object* v___x_300_; 
lean_dec_ref_known(v___x_299_, 1);
v___x_300_ = vastitas_gemm_execute(v_a_266_, v___x_282_, v___x_277_, v___x_296_, v___x_284_, v___x_296_, v___x_281_, v___x_281_, v___x_289_, v___x_277_, v___x_284_, v___x_290_, v___x_284_, v___x_281_, v___x_281_, v___x_291_, v___x_277_, v___x_296_, v___x_290_, v___x_296_, v___x_281_, v___x_288_);
if (lean_obj_tag(v___x_300_) == 0)
{
lean_object* v___x_301_; 
lean_dec_ref_known(v___x_300_, 1);
v___x_301_ = lean_nat_add(v_i_270_, v_step_273_);
lean_dec(v_i_270_);
v_b_269_ = v___x_292_;
v_i_270_ = v___x_301_;
goto _start;
}
else
{
lean_dec(v_i_270_);
return v___x_300_;
}
}
else
{
lean_dec(v_i_270_);
return v___x_299_;
}
}
else
{
lean_dec(v_i_270_);
return v___x_295_;
}
}
else
{
lean_dec(v_i_270_);
return v___x_294_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object* v_a_303_, lean_object* v_scope_304_, lean_object* v_range_305_, lean_object* v_b_306_, lean_object* v_i_307_, lean_object* v___y_308_){
_start:
{
lean_object* v_res_309_; 
v_res_309_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_303_, v_scope_304_, v_range_305_, v_b_306_, v_i_307_);
lean_dec_ref(v_range_305_);
lean_dec(v_scope_304_);
lean_dec(v_a_303_);
return v_res_309_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object* v_range_310_, lean_object* v_b_311_, lean_object* v_i_312_){
_start:
{
lean_object* v_stop_314_; lean_object* v_step_315_; uint8_t v___x_316_; 
v_stop_314_ = lean_ctor_get(v_range_310_, 1);
v_step_315_ = lean_ctor_get(v_range_310_, 2);
v___x_316_ = lean_nat_dec_lt(v_i_312_, v_stop_314_);
if (v___x_316_ == 0)
{
lean_object* v___x_317_; 
lean_dec(v_i_312_);
v___x_317_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_317_, 0, v_b_311_);
return v___x_317_;
}
else
{
lean_object* v___x_318_; lean_object* v___x_319_; 
v___x_318_ = lean_box(0);
v___x_319_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_319_) == 0)
{
lean_object* v___x_320_; 
lean_dec_ref_known(v___x_319_, 1);
v___x_320_ = lean_nat_add(v_i_312_, v_step_315_);
lean_dec(v_i_312_);
v_b_311_ = v___x_318_;
v_i_312_ = v___x_320_;
goto _start;
}
else
{
lean_dec(v_i_312_);
return v___x_319_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object* v_range_322_, lean_object* v_b_323_, lean_object* v_i_324_, lean_object* v___y_325_){
_start:
{
lean_object* v_res_326_; 
v_res_326_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_322_, v_b_323_, v_i_324_);
lean_dec_ref(v_range_322_);
return v_res_326_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_335_){
_start:
{
lean_object* v___x_337_; lean_object* v___x_338_; lean_object* v_impl_339_; lean_object* v___x_340_; lean_object* v___x_341_; lean_object* v___x_342_; lean_object* v___x_343_; lean_object* v_scope_344_; lean_object* v___x_345_; lean_object* v___x_346_; lean_object* v___x_347_; lean_object* v___x_348_; lean_object* v_reps_349_; lean_object* v___x_350_; lean_object* v___x_351_; lean_object* v___x_352_; uint8_t v_verify_353_; uint32_t v___x_354_; lean_object* v___x_355_; 
v___x_337_ = ((lean_object*)(lp_allocation__audit_main___closed__0));
v___x_338_ = lean_unsigned_to_nat(0u);
v_impl_339_ = l_List_get_x21Internal___redArg(v___x_337_, v_args_335_, v___x_338_);
v___x_340_ = lean_unsigned_to_nat(1u);
v___x_341_ = l_List_get_x21Internal___redArg(v___x_337_, v_args_335_, v___x_340_);
v___x_342_ = lean_string_utf8_byte_size(v___x_341_);
v___x_343_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_343_, 0, v___x_341_);
lean_ctor_set(v___x_343_, 1, v___x_338_);
lean_ctor_set(v___x_343_, 2, v___x_342_);
v_scope_344_ = l_String_Slice_toNat_x21(v___x_343_);
lean_dec_ref_known(v___x_343_, 3);
v___x_345_ = lean_unsigned_to_nat(2u);
v___x_346_ = l_List_get_x21Internal___redArg(v___x_337_, v_args_335_, v___x_345_);
v___x_347_ = lean_string_utf8_byte_size(v___x_346_);
v___x_348_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_348_, 0, v___x_346_);
lean_ctor_set(v___x_348_, 1, v___x_338_);
lean_ctor_set(v___x_348_, 2, v___x_347_);
v_reps_349_ = l_String_Slice_toNat_x21(v___x_348_);
lean_dec_ref_known(v___x_348_, 3);
v___x_350_ = lean_unsigned_to_nat(3u);
v___x_351_ = l_List_get_x21Internal___redArg(v___x_337_, v_args_335_, v___x_350_);
lean_dec(v_args_335_);
v___x_352_ = ((lean_object*)(lp_allocation__audit_main___closed__1));
v_verify_353_ = lean_string_dec_eq(v___x_351_, v___x_352_);
lean_dec(v___x_351_);
v___x_354_ = 1;
v___x_355_ = audit_mark_lean(v___x_354_);
if (lean_obj_tag(v___x_355_) == 0)
{
lean_object* v___x_356_; 
lean_dec_ref_known(v___x_355_, 1);
v___x_356_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_356_) == 0)
{
uint32_t v___x_357_; lean_object* v___x_358_; 
lean_dec_ref_known(v___x_356_, 1);
v___x_357_ = 2;
v___x_358_ = audit_mark_lean(v___x_357_);
if (lean_obj_tag(v___x_358_) == 0)
{
lean_object* v___x_359_; uint8_t v___x_360_; 
lean_dec_ref_known(v___x_358_, 1);
v___x_359_ = ((lean_object*)(lp_allocation__audit_main___closed__2));
v___x_360_ = lean_string_dec_eq(v_impl_339_, v___x_359_);
if (v___x_360_ == 0)
{
lean_object* v___x_361_; uint8_t v___x_362_; 
v___x_361_ = ((lean_object*)(lp_allocation__audit_main___closed__3));
v___x_362_ = lean_string_dec_eq(v_impl_339_, v___x_361_);
lean_dec(v_impl_339_);
if (v___x_362_ == 0)
{
uint8_t v___x_363_; 
v___x_363_ = lean_nat_dec_eq(v_scope_344_, v___x_338_);
if (v___x_363_ == 0)
{
uint64_t v___x_364_; lean_object* v___x_365_; 
v___x_364_ = 9223372036854775807ULL;
v___x_365_ = vastitas_storage_new(v___x_364_);
if (lean_obj_tag(v___x_365_) == 0)
{
lean_object* v_a_366_; lean_object* v___y_368_; uint32_t v___x_381_; uint8_t v___x_382_; uint64_t v___x_383_; lean_object* v___x_384_; 
v_a_366_ = lean_ctor_get(v___x_365_, 0);
lean_inc(v_a_366_);
lean_dec_ref_known(v___x_365_, 1);
v___x_381_ = 0;
v___x_382_ = 0;
v___x_383_ = 24ULL;
v___x_384_ = vastitas_storage_allocate(v_a_366_, v___x_381_, v___x_382_, v___x_383_);
if (lean_obj_tag(v___x_384_) == 0)
{
uint64_t v___x_385_; uint64_t v___x_386_; uint64_t v___x_387_; lean_object* v___x_388_; 
lean_dec_ref_known(v___x_384_, 1);
v___x_385_ = 0ULL;
v___x_386_ = 1ULL;
v___x_387_ = 13842939354630062080ULL;
v___x_388_ = vastitas_storage_fill(v_a_366_, v___x_381_, v___x_385_, v___x_383_, v___x_386_, v___x_383_, v___x_363_, v___x_382_, v___x_387_, v___x_385_);
if (lean_obj_tag(v___x_388_) == 0)
{
uint64_t v___x_389_; uint64_t v___x_390_; uint64_t v___x_391_; lean_object* v___x_392_; 
lean_dec_ref_known(v___x_388_, 1);
v___x_389_ = 2ULL;
v___x_390_ = 12ULL;
v___x_391_ = 4593671619917905920ULL;
v___x_392_ = vastitas_storage_fill(v_a_366_, v___x_381_, v___x_385_, v___x_389_, v___x_390_, v___x_389_, v___x_363_, v___x_382_, v___x_391_, v___x_385_);
if (lean_obj_tag(v___x_392_) == 0)
{
uint64_t v___x_393_; lean_object* v___x_394_; 
lean_dec_ref_known(v___x_392_, 1);
v___x_393_ = 4607182418800017408ULL;
v___x_394_ = vastitas_storage_store(v_a_366_, v___x_381_, v___x_385_, v___x_389_, v___x_390_, v___x_389_, v___x_363_, v___x_385_, v___x_385_, v___x_382_, v___x_393_, v___x_385_);
if (lean_obj_tag(v___x_394_) == 0)
{
uint64_t v___x_395_; lean_object* v___x_396_; 
lean_dec_ref_known(v___x_394_, 1);
v___x_395_ = 13826050856027422720ULL;
v___x_396_ = vastitas_storage_store(v_a_366_, v___x_381_, v___x_385_, v___x_389_, v___x_390_, v___x_389_, v___x_363_, v___x_386_, v___x_386_, v___x_382_, v___x_395_, v___x_385_);
if (lean_obj_tag(v___x_396_) == 0)
{
uint64_t v___x_397_; lean_object* v___x_398_; 
lean_dec_ref_known(v___x_396_, 1);
v___x_397_ = 15ULL;
v___x_398_ = vastitas_storage_allocate(v_a_366_, v___x_354_, v___x_382_, v___x_397_);
if (lean_obj_tag(v___x_398_) == 0)
{
lean_object* v___x_399_; 
lean_dec_ref_known(v___x_398_, 1);
v___x_399_ = vastitas_storage_fill(v_a_366_, v___x_354_, v___x_385_, v___x_397_, v___x_386_, v___x_397_, v___x_363_, v___x_382_, v___x_387_, v___x_385_);
if (lean_obj_tag(v___x_399_) == 0)
{
uint64_t v___x_400_; uint64_t v___x_401_; uint64_t v___x_402_; lean_object* v___x_403_; 
lean_dec_ref_known(v___x_399_, 1);
v___x_400_ = 3ULL;
v___x_401_ = 5ULL;
v___x_402_ = 13821547256400052224ULL;
v___x_403_ = vastitas_storage_fill(v_a_366_, v___x_354_, v___x_385_, v___x_400_, v___x_401_, v___x_400_, v___x_363_, v___x_382_, v___x_402_, v___x_385_);
if (lean_obj_tag(v___x_403_) == 0)
{
uint64_t v___x_404_; uint64_t v___x_405_; lean_object* v___x_406_; 
lean_dec_ref_known(v___x_403_, 1);
v___x_404_ = 4ULL;
v___x_405_ = 4602678819172646912ULL;
v___x_406_ = vastitas_storage_store(v_a_366_, v___x_354_, v___x_385_, v___x_400_, v___x_401_, v___x_400_, v___x_363_, v___x_385_, v___x_404_, v___x_382_, v___x_405_, v___x_385_);
if (lean_obj_tag(v___x_406_) == 0)
{
uint64_t v___x_407_; lean_object* v___x_408_; 
lean_dec_ref_known(v___x_406_, 1);
v___x_407_ = 13828302655841107968ULL;
v___x_408_ = vastitas_storage_store(v_a_366_, v___x_354_, v___x_385_, v___x_400_, v___x_401_, v___x_400_, v___x_363_, v___x_389_, v___x_385_, v___x_382_, v___x_407_, v___x_385_);
if (lean_obj_tag(v___x_408_) == 0)
{
lean_object* v___x_409_; 
lean_dec_ref_known(v___x_408_, 1);
v___x_409_ = vastitas_storage_allocate(v_a_366_, v___x_357_, v___x_382_, v___x_383_);
if (lean_obj_tag(v___x_409_) == 0)
{
lean_object* v___x_410_; 
lean_dec_ref_known(v___x_409_, 1);
v___x_410_ = vastitas_storage_fill(v_a_366_, v___x_357_, v___x_385_, v___x_383_, v___x_386_, v___x_383_, v___x_363_, v___x_382_, v___x_387_, v___x_385_);
if (lean_obj_tag(v___x_410_) == 0)
{
uint64_t v___x_411_; lean_object* v___x_412_; 
lean_dec_ref_known(v___x_410_, 1);
v___x_411_ = 6ULL;
v___x_412_ = vastitas_storage_fill(v_a_366_, v___x_357_, v___x_385_, v___x_404_, v___x_411_, v___x_404_, v___x_363_, v___x_382_, v___x_405_, v___x_385_);
if (lean_obj_tag(v___x_412_) == 0)
{
lean_object* v___x_413_; 
lean_dec_ref_known(v___x_412_, 1);
v___x_413_ = vastitas_storage_store(v_a_366_, v___x_357_, v___x_385_, v___x_404_, v___x_411_, v___x_404_, v___x_363_, v___x_400_, v___x_385_, v___x_382_, v___x_402_, v___x_385_);
if (lean_obj_tag(v___x_413_) == 0)
{
uint64_t v___x_414_; lean_object* v___x_415_; 
lean_dec_ref_known(v___x_413_, 1);
v___x_414_ = 4604930618986332160ULL;
v___x_415_ = vastitas_storage_store(v_a_366_, v___x_357_, v___x_385_, v___x_404_, v___x_411_, v___x_404_, v___x_363_, v___x_385_, v___x_401_, v___x_382_, v___x_414_, v___x_385_);
if (lean_obj_tag(v___x_415_) == 0)
{
uint32_t v___x_416_; uint64_t v___x_417_; lean_object* v___x_418_; 
lean_dec_ref_known(v___x_415_, 1);
v___x_416_ = 3;
v___x_417_ = 40ULL;
v___x_418_ = vastitas_storage_allocate(v_a_366_, v___x_416_, v___x_382_, v___x_417_);
if (lean_obj_tag(v___x_418_) == 0)
{
lean_object* v___x_419_; 
lean_dec_ref_known(v___x_418_, 1);
v___x_419_ = vastitas_storage_fill(v_a_366_, v___x_416_, v___x_385_, v___x_417_, v___x_386_, v___x_417_, v___x_363_, v___x_382_, v___x_387_, v___x_385_);
if (lean_obj_tag(v___x_419_) == 0)
{
uint32_t v___x_420_; lean_object* v___x_421_; 
lean_dec_ref_known(v___x_419_, 1);
v___x_420_ = 4;
v___x_421_ = vastitas_storage_allocate(v_a_366_, v___x_420_, v___x_382_, v___x_417_);
if (lean_obj_tag(v___x_421_) == 0)
{
lean_object* v___x_422_; 
lean_dec_ref_known(v___x_421_, 1);
v___x_422_ = vastitas_storage_fill(v_a_366_, v___x_420_, v___x_385_, v___x_417_, v___x_386_, v___x_417_, v___x_363_, v___x_382_, v___x_387_, v___x_385_);
if (lean_obj_tag(v___x_422_) == 0)
{
uint32_t v___x_423_; uint64_t v___x_424_; lean_object* v___x_425_; 
lean_dec_ref_known(v___x_422_, 1);
v___x_423_ = 5;
v___x_424_ = 60ULL;
v___x_425_ = vastitas_storage_allocate(v_a_366_, v___x_423_, v___x_382_, v___x_424_);
if (lean_obj_tag(v___x_425_) == 0)
{
lean_object* v___x_426_; 
lean_dec_ref_known(v___x_425_, 1);
v___x_426_ = vastitas_storage_fill(v_a_366_, v___x_423_, v___x_385_, v___x_424_, v___x_386_, v___x_424_, v___x_363_, v___x_382_, v___x_387_, v___x_385_);
if (lean_obj_tag(v___x_426_) == 0)
{
uint32_t v___x_427_; uint64_t v___x_428_; lean_object* v___x_429_; 
lean_dec_ref_known(v___x_426_, 1);
v___x_427_ = lean_uint32_of_nat(v_scope_344_);
v___x_428_ = lean_uint64_of_nat(v_reps_349_);
v___x_429_ = bench_begin_lean(v___x_427_, v___x_428_, v_verify_353_);
if (lean_obj_tag(v___x_429_) == 0)
{
lean_object* v___x_430_; lean_object* v___x_431_; lean_object* v___x_432_; 
lean_dec_ref_known(v___x_429_, 1);
v___x_430_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_430_, 0, v___x_338_);
lean_ctor_set(v___x_430_, 1, v_reps_349_);
lean_ctor_set(v___x_430_, 2, v___x_340_);
v___x_431_ = lean_box(0);
v___x_432_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_366_, v_scope_344_, v___x_430_, v___x_431_, v___x_338_);
lean_dec_ref_known(v___x_430_, 3);
lean_dec(v_scope_344_);
if (lean_obj_tag(v___x_432_) == 0)
{
lean_object* v___x_433_; 
lean_dec_ref_known(v___x_432_, 1);
v___x_433_ = bench_stop_lean();
if (lean_obj_tag(v___x_433_) == 0)
{
lean_object* v___x_434_; 
lean_dec_ref_known(v___x_433_, 1);
v___x_434_ = bench_verify_lean(v_a_366_, v___x_428_);
if (lean_obj_tag(v___x_434_) == 0)
{
uint64_t v___x_435_; uint64_t v___x_436_; lean_object* v___x_437_; 
lean_dec_ref_known(v___x_434_, 1);
v___x_435_ = 10ULL;
v___x_436_ = 13822532418818539520ULL;
v___x_437_ = vastitas_storage_expect(v_a_366_, v___x_423_, v___x_385_, v___x_435_, v___x_411_, v___x_435_, v___x_363_, v___x_385_, v___x_385_, v___x_382_, v___x_436_, v___x_385_);
if (lean_obj_tag(v___x_437_) == 0)
{
uint64_t v___x_438_; lean_object* v___x_439_; 
lean_dec_ref_known(v___x_437_, 1);
v___x_438_ = 13820984306446630912ULL;
v___x_439_ = vastitas_storage_expect(v_a_366_, v___x_423_, v___x_385_, v___x_435_, v___x_411_, v___x_435_, v___x_363_, v___x_386_, v___x_401_, v___x_382_, v___x_438_, v___x_385_);
if (lean_obj_tag(v___x_439_) == 0)
{
uint64_t v___x_440_; uint64_t v___x_441_; lean_object* v___x_442_; 
lean_dec_ref_known(v___x_439_, 1);
v___x_440_ = 9ULL;
v___x_441_ = 4590293920197378048ULL;
v___x_442_ = vastitas_storage_expect(v_a_366_, v___x_423_, v___x_385_, v___x_435_, v___x_411_, v___x_435_, v___x_363_, v___x_440_, v___x_385_, v___x_382_, v___x_441_, v___x_385_);
if (lean_obj_tag(v___x_442_) == 0)
{
lean_object* v___x_443_; 
lean_dec_ref_known(v___x_442_, 1);
v___x_443_ = vastitas_storage_drop(v_a_366_, v___x_423_);
if (lean_obj_tag(v___x_443_) == 0)
{
lean_object* v___x_444_; 
lean_dec_ref_known(v___x_443_, 1);
v___x_444_ = vastitas_storage_drop(v_a_366_, v___x_420_);
if (lean_obj_tag(v___x_444_) == 0)
{
lean_object* v___x_445_; 
lean_dec_ref_known(v___x_444_, 1);
v___x_445_ = vastitas_storage_drop(v_a_366_, v___x_416_);
if (lean_obj_tag(v___x_445_) == 0)
{
lean_object* v___x_446_; 
lean_dec_ref_known(v___x_445_, 1);
v___x_446_ = vastitas_storage_drop(v_a_366_, v___x_357_);
if (lean_obj_tag(v___x_446_) == 0)
{
lean_object* v___x_447_; 
lean_dec_ref_known(v___x_446_, 1);
v___x_447_ = vastitas_storage_drop(v_a_366_, v___x_354_);
if (lean_obj_tag(v___x_447_) == 0)
{
lean_object* v___x_448_; 
lean_dec_ref_known(v___x_447_, 1);
v___x_448_ = vastitas_storage_drop(v_a_366_, v___x_381_);
v___y_368_ = v___x_448_;
goto v___jp_367_;
}
else
{
v___y_368_ = v___x_447_;
goto v___jp_367_;
}
}
else
{
v___y_368_ = v___x_446_;
goto v___jp_367_;
}
}
else
{
v___y_368_ = v___x_445_;
goto v___jp_367_;
}
}
else
{
v___y_368_ = v___x_444_;
goto v___jp_367_;
}
}
else
{
v___y_368_ = v___x_443_;
goto v___jp_367_;
}
}
else
{
v___y_368_ = v___x_442_;
goto v___jp_367_;
}
}
else
{
v___y_368_ = v___x_439_;
goto v___jp_367_;
}
}
else
{
v___y_368_ = v___x_437_;
goto v___jp_367_;
}
}
else
{
v___y_368_ = v___x_434_;
goto v___jp_367_;
}
}
else
{
v___y_368_ = v___x_433_;
goto v___jp_367_;
}
}
else
{
v___y_368_ = v___x_432_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_429_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_426_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_425_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_422_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_421_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_419_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_418_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_415_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_413_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_412_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_410_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_409_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_408_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_406_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_403_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_399_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_398_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_396_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_394_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_392_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_388_;
goto v___jp_367_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v___y_368_ = v___x_384_;
goto v___jp_367_;
}
v___jp_367_:
{
if (lean_obj_tag(v___y_368_) == 0)
{
lean_object* v___x_369_; 
lean_dec_ref_known(v___y_368_, 1);
v___x_369_ = vastitas_storage_close(v_a_366_);
lean_dec(v_a_366_);
if (lean_obj_tag(v___x_369_) == 0)
{
lean_object* v___x_370_; 
lean_dec_ref_known(v___x_369_, 1);
v___x_370_ = bench_report_lean();
return v___x_370_;
}
else
{
return v___x_369_;
}
}
else
{
lean_object* v_a_371_; lean_object* v___x_372_; 
v_a_371_ = lean_ctor_get(v___y_368_, 0);
lean_inc(v_a_371_);
lean_dec_ref_known(v___y_368_, 1);
v___x_372_ = vastitas_storage_close(v_a_366_);
lean_dec(v_a_366_);
if (lean_obj_tag(v___x_372_) == 0)
{
lean_object* v___x_374_; uint8_t v_isShared_375_; uint8_t v_isSharedCheck_379_; 
v_isSharedCheck_379_ = !lean_is_exclusive(v___x_372_);
if (v_isSharedCheck_379_ == 0)
{
lean_object* v_unused_380_; 
v_unused_380_ = lean_ctor_get(v___x_372_, 0);
lean_dec(v_unused_380_);
v___x_374_ = v___x_372_;
v_isShared_375_ = v_isSharedCheck_379_;
goto v_resetjp_373_;
}
else
{
lean_dec(v___x_372_);
v___x_374_ = lean_box(0);
v_isShared_375_ = v_isSharedCheck_379_;
goto v_resetjp_373_;
}
v_resetjp_373_:
{
lean_object* v___x_377_; 
if (v_isShared_375_ == 0)
{
lean_ctor_set_tag(v___x_374_, 1);
lean_ctor_set(v___x_374_, 0, v_a_371_);
v___x_377_ = v___x_374_;
goto v_reusejp_376_;
}
else
{
lean_object* v_reuseFailAlloc_378_; 
v_reuseFailAlloc_378_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_378_, 0, v_a_371_);
v___x_377_ = v_reuseFailAlloc_378_;
goto v_reusejp_376_;
}
v_reusejp_376_:
{
return v___x_377_;
}
}
}
else
{
lean_dec(v_a_371_);
return v___x_372_;
}
}
}
}
else
{
lean_object* v_a_449_; lean_object* v___x_451_; uint8_t v_isShared_452_; uint8_t v_isSharedCheck_456_; 
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
v_a_449_ = lean_ctor_get(v___x_365_, 0);
v_isSharedCheck_456_ = !lean_is_exclusive(v___x_365_);
if (v_isSharedCheck_456_ == 0)
{
v___x_451_ = v___x_365_;
v_isShared_452_ = v_isSharedCheck_456_;
goto v_resetjp_450_;
}
else
{
lean_inc(v_a_449_);
lean_dec(v___x_365_);
v___x_451_ = lean_box(0);
v_isShared_452_ = v_isSharedCheck_456_;
goto v_resetjp_450_;
}
v_resetjp_450_:
{
lean_object* v___x_454_; 
if (v_isShared_452_ == 0)
{
v___x_454_ = v___x_451_;
goto v_reusejp_453_;
}
else
{
lean_object* v_reuseFailAlloc_455_; 
v_reuseFailAlloc_455_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_455_, 0, v_a_449_);
v___x_454_ = v_reuseFailAlloc_455_;
goto v_reusejp_453_;
}
v_reusejp_453_:
{
return v___x_454_;
}
}
}
}
else
{
uint32_t v___x_457_; uint64_t v___x_458_; lean_object* v___x_459_; 
lean_dec(v_scope_344_);
v___x_457_ = 0;
v___x_458_ = lean_uint64_of_nat(v_reps_349_);
v___x_459_ = bench_begin_lean(v___x_457_, v___x_458_, v_verify_353_);
if (lean_obj_tag(v___x_459_) == 0)
{
lean_object* v___x_460_; lean_object* v___x_461_; lean_object* v___x_462_; 
lean_dec_ref_known(v___x_459_, 1);
v___x_460_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_460_, 0, v___x_338_);
lean_ctor_set(v___x_460_, 1, v_reps_349_);
lean_ctor_set(v___x_460_, 2, v___x_340_);
v___x_461_ = lean_box(0);
v___x_462_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v___x_460_, v___x_461_, v___x_338_);
lean_dec_ref_known(v___x_460_, 3);
if (lean_obj_tag(v___x_462_) == 0)
{
lean_object* v___x_463_; 
lean_dec_ref_known(v___x_462_, 1);
v___x_463_ = bench_stop_lean();
if (lean_obj_tag(v___x_463_) == 0)
{
lean_object* v___x_464_; 
lean_dec_ref_known(v___x_463_, 1);
v___x_464_ = bench_report_lean();
return v___x_464_;
}
else
{
return v___x_463_;
}
}
else
{
return v___x_462_;
}
}
else
{
lean_dec(v_reps_349_);
return v___x_459_;
}
}
}
else
{
uint32_t v___x_465_; uint64_t v___x_466_; lean_object* v___x_467_; 
v___x_465_ = lean_uint32_of_nat(v_scope_344_);
lean_dec(v_scope_344_);
v___x_466_ = lean_uint64_of_nat(v_reps_349_);
lean_dec(v_reps_349_);
v___x_467_ = bench_c_run_lean(v___x_465_, v___x_466_, v_verify_353_);
if (lean_obj_tag(v___x_467_) == 0)
{
lean_object* v___x_468_; 
lean_dec_ref_known(v___x_467_, 1);
v___x_468_ = bench_report_lean();
return v___x_468_;
}
else
{
return v___x_467_;
}
}
}
else
{
uint32_t v___x_469_; uint64_t v___x_470_; lean_object* v___x_471_; 
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
lean_dec(v_impl_339_);
v___x_469_ = 0;
v___x_470_ = 1ULL;
v___x_471_ = bench_begin_lean(v___x_469_, v___x_470_, v___x_360_);
if (lean_obj_tag(v___x_471_) == 0)
{
lean_object* v___x_472_; 
lean_dec_ref_known(v___x_471_, 1);
v___x_472_ = lp_allocation__audit_generatedFailure();
if (lean_obj_tag(v___x_472_) == 0)
{
lean_object* v___x_474_; uint8_t v_isShared_475_; uint8_t v_isSharedCheck_480_; 
v_isSharedCheck_480_ = !lean_is_exclusive(v___x_472_);
if (v_isSharedCheck_480_ == 0)
{
lean_object* v_unused_481_; 
v_unused_481_ = lean_ctor_get(v___x_472_, 0);
lean_dec(v_unused_481_);
v___x_474_ = v___x_472_;
v_isShared_475_ = v_isSharedCheck_480_;
goto v_resetjp_473_;
}
else
{
lean_dec(v___x_472_);
v___x_474_ = lean_box(0);
v_isShared_475_ = v_isSharedCheck_480_;
goto v_resetjp_473_;
}
v_resetjp_473_:
{
lean_object* v___x_476_; lean_object* v___x_478_; 
v___x_476_ = ((lean_object*)(lp_allocation__audit_main___closed__5));
if (v_isShared_475_ == 0)
{
lean_ctor_set_tag(v___x_474_, 1);
lean_ctor_set(v___x_474_, 0, v___x_476_);
v___x_478_ = v___x_474_;
goto v_reusejp_477_;
}
else
{
lean_object* v_reuseFailAlloc_479_; 
v_reuseFailAlloc_479_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_479_, 0, v___x_476_);
v___x_478_ = v_reuseFailAlloc_479_;
goto v_reusejp_477_;
}
v_reusejp_477_:
{
return v___x_478_;
}
}
}
else
{
lean_object* v_a_482_; lean_object* v___x_483_; lean_object* v___x_484_; uint8_t v___x_485_; 
v_a_482_ = lean_ctor_get(v___x_472_, 0);
lean_inc(v_a_482_);
v___x_483_ = lean_io_error_to_string(v_a_482_);
v___x_484_ = ((lean_object*)(lp_allocation__audit_main___closed__6));
v___x_485_ = lean_string_dec_eq(v___x_483_, v___x_484_);
lean_dec_ref(v___x_483_);
if (v___x_485_ == 0)
{
return v___x_472_;
}
else
{
lean_object* v___x_486_; 
lean_dec_ref_known(v___x_472_, 1);
v___x_486_ = bench_stop_lean();
if (lean_obj_tag(v___x_486_) == 0)
{
lean_object* v___x_487_; 
lean_dec_ref_known(v___x_486_, 1);
v___x_487_ = bench_report_lean();
return v___x_487_;
}
else
{
return v___x_486_;
}
}
}
}
else
{
return v___x_471_;
}
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
lean_dec(v_impl_339_);
return v___x_358_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
lean_dec(v_impl_339_);
return v___x_356_;
}
}
else
{
lean_dec(v_reps_349_);
lean_dec(v_scope_344_);
lean_dec(v_impl_339_);
return v___x_355_;
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object* v_args_488_, lean_object* v_a_489_){
_start:
{
lean_object* v_res_490_; 
v_res_490_ = _lean_main(v_args_488_);
return v_res_490_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object* v_a_491_, lean_object* v_scope_492_, lean_object* v_range_493_, lean_object* v_b_494_, lean_object* v_i_495_, lean_object* v_hs_496_, lean_object* v_hl_497_){
_start:
{
lean_object* v___x_499_; 
v___x_499_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_491_, v_scope_492_, v_range_493_, v_b_494_, v_i_495_);
return v___x_499_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object* v_a_500_, lean_object* v_scope_501_, lean_object* v_range_502_, lean_object* v_b_503_, lean_object* v_i_504_, lean_object* v_hs_505_, lean_object* v_hl_506_, lean_object* v___y_507_){
_start:
{
lean_object* v_res_508_; 
v_res_508_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(v_a_500_, v_scope_501_, v_range_502_, v_b_503_, v_i_504_, v_hs_505_, v_hl_506_);
lean_dec_ref(v_range_502_);
lean_dec(v_scope_501_);
lean_dec(v_a_500_);
return v_res_508_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object* v_range_509_, lean_object* v_b_510_, lean_object* v_i_511_, lean_object* v_hs_512_, lean_object* v_hl_513_){
_start:
{
lean_object* v___x_515_; 
v___x_515_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_509_, v_b_510_, v_i_511_);
return v___x_515_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object* v_range_516_, lean_object* v_b_517_, lean_object* v_i_518_, lean_object* v_hs_519_, lean_object* v_hl_520_, lean_object* v___y_521_){
_start:
{
lean_object* v_res_522_; 
v_res_522_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(v_range_516_, v_b_517_, v_i_518_, v_hs_519_, v_hl_520_);
lean_dec_ref(v_range_516_);
return v_res_522_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_vastitas__storage__native_VastitasStorageNative(uint8_t builtin);
lean_object* initialize_vastitas__gemm__native_VastitasGemmNative(uint8_t builtin);
lean_object* initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_allocation__audit_Main(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__storage__native_VastitasStorageNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__gemm__native_VastitasGemmNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_allocation__audit_VastitasGenerated_f__0 = _init_lp_allocation__audit_VastitasGenerated_f__0();
lean_mark_persistent(lp_allocation__audit_VastitasGenerated_f__0);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_allocation__audit_Main(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = 0;
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
