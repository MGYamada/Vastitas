// Lean compiler output
// Module: Main
// Imports: public import Init public meta import Init public import VastitasStorageNative public import VastitasGemmNative public import VastitasKernel.IndexedRuntime
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* vastitas_storage_new(uint64_t);
lean_object* vastitas_storage_close(lean_object*);
lean_object* vastitas_storage_allocate(lean_object*, uint32_t, uint8_t, uint64_t);
lean_object* vastitas_storage_fill(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_store(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_pack3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_gemm_execute(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t);
lean_object* vastitas_storage_regroup3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_storage_expect(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_drop(lean_object*, uint32_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_List_get_x21Internal___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_String_Slice_toNat_x21(lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
uint32_t lean_uint32_of_nat(lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
lean_object* lean_io_error_to_string(lean_object*);
static lean_once_cell_t lp_allocation__audit_VastitasGenerated_f__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_allocation__audit_VastitasGenerated_f__0___closed__0;
LEAN_EXPORT lean_object* lp_allocation__audit_VastitasGenerated_f__0;
lean_object* bench_begin_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_stop_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object*);
lean_object* bench_report_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object*);
lean_object* bench_c_run_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_verify_lean(lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object*);
lean_object* audit_mark_lean(uint32_t);
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_allocation__audit_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 1, .m_capacity = 1, .m_length = 0, .m_data = ""};
static const lean_object* lp_allocation__audit_main___closed__0 = (const lean_object*)&lp_allocation__audit_main___closed__0_value;
static const lean_string_object lp_allocation__audit_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "1"};
static const lean_object* lp_allocation__audit_main___closed__1 = (const lean_object*)&lp_allocation__audit_main___closed__1_value;
static const lean_string_object lp_allocation__audit_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "failure"};
static const lean_object* lp_allocation__audit_main___closed__2 = (const lean_object*)&lp_allocation__audit_main___closed__2_value;
static const lean_string_object lp_allocation__audit_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "c"};
static const lean_object* lp_allocation__audit_main___closed__3 = (const lean_object*)&lp_allocation__audit_main___closed__3_value;
static const lean_string_object lp_allocation__audit_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "expected injected native failure"};
static const lean_object* lp_allocation__audit_main___closed__4 = (const lean_object*)&lp_allocation__audit_main___closed__4_value;
static const lean_ctor_object lp_allocation__audit_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_allocation__audit_main___closed__4_value)}};
static const lean_object* lp_allocation__audit_main___closed__5 = (const lean_object*)&lp_allocation__audit_main___closed__5_value;
static const lean_string_object lp_allocation__audit_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 44, .m_capacity = 44, .m_length = 43, .m_data = "E_NATIVE_EXPECT: stored bit pattern differs"};
static const lean_object* lp_allocation__audit_main___closed__6 = (const lean_object*)&lp_allocation__audit_main___closed__6_value;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(0u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0(void){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_obj_once(&lp_allocation__audit_VastitasGenerated_f__0___closed__0, &lp_allocation__audit_VastitasGenerated_f__0___closed__0_once, _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object* v_scope_8_, lean_object* v_reps_9_, lean_object* v_verify_10_, lean_object* v_a_00___x40___internal___hyg_11_){
_start:
{
uint32_t v_scope_boxed_12_; uint64_t v_reps_boxed_13_; uint8_t v_verify_boxed_14_; lean_object* v_res_15_; 
v_scope_boxed_12_ = lean_unbox_uint32(v_scope_8_);
lean_dec(v_scope_8_);
v_reps_boxed_13_ = lean_unbox_uint64(v_reps_9_);
lean_dec_ref(v_reps_9_);
v_verify_boxed_14_ = lean_unbox(v_verify_10_);
v_res_15_ = bench_begin_lean(v_scope_boxed_12_, v_reps_boxed_13_, v_verify_boxed_14_);
return v_res_15_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object* v_a_00___x40___internal___hyg_17_){
_start:
{
lean_object* v_res_18_; 
v_res_18_ = bench_stop_lean();
return v_res_18_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object* v_a_00___x40___internal___hyg_20_){
_start:
{
lean_object* v_res_21_; 
v_res_21_ = bench_report_lean();
return v_res_21_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object* v_scope_26_, lean_object* v_reps_27_, lean_object* v_verify_28_, lean_object* v_a_00___x40___internal___hyg_29_){
_start:
{
uint32_t v_scope_boxed_30_; uint64_t v_reps_boxed_31_; uint8_t v_verify_boxed_32_; lean_object* v_res_33_; 
v_scope_boxed_30_ = lean_unbox_uint32(v_scope_26_);
lean_dec(v_scope_26_);
v_reps_boxed_31_ = lean_unbox_uint64(v_reps_27_);
lean_dec_ref(v_reps_27_);
v_verify_boxed_32_ = lean_unbox(v_verify_28_);
v_res_33_ = bench_c_run_lean(v_scope_boxed_30_, v_reps_boxed_31_, v_verify_boxed_32_);
return v_res_33_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object* v_arena_37_, lean_object* v_reps_38_, lean_object* v_a_00___x40___internal___hyg_39_){
_start:
{
uint64_t v_reps_boxed_40_; lean_object* v_res_41_; 
v_reps_boxed_40_ = lean_unbox_uint64(v_reps_38_);
lean_dec_ref(v_reps_38_);
v_res_41_ = bench_verify_lean(v_arena_37_, v_reps_boxed_40_);
lean_dec(v_arena_37_);
return v_res_41_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce(){
_start:
{
uint64_t v___x_43_; lean_object* v___x_44_; 
v___x_43_ = 9223372036854775807ULL;
v___x_44_ = vastitas_storage_new(v___x_43_);
if (lean_obj_tag(v___x_44_) == 0)
{
lean_object* v_a_45_; lean_object* v_a_47_; lean_object* v___y_58_; uint32_t v___x_70_; uint8_t v___x_71_; uint64_t v___x_72_; lean_object* v___x_73_; 
v_a_45_ = lean_ctor_get(v___x_44_, 0);
lean_inc(v_a_45_);
lean_dec_ref_known(v___x_44_, 1);
v___x_70_ = 0;
v___x_71_ = 0;
v___x_72_ = 52ULL;
v___x_73_ = vastitas_storage_allocate(v_a_45_, v___x_70_, v___x_71_, v___x_72_);
if (lean_obj_tag(v___x_73_) == 0)
{
uint64_t v___x_74_; uint64_t v___x_75_; uint8_t v___x_76_; uint64_t v___x_77_; lean_object* v___x_78_; 
lean_dec_ref_known(v___x_73_, 1);
v___x_74_ = 0ULL;
v___x_75_ = 1ULL;
v___x_76_ = 0;
v___x_77_ = 13842939354630062080ULL;
v___x_78_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_74_, v___x_72_, v___x_75_, v___x_72_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_78_) == 0)
{
uint64_t v___x_79_; uint64_t v___x_80_; uint64_t v___x_81_; uint64_t v___x_82_; uint64_t v___x_83_; lean_object* v___x_84_; 
lean_dec_ref_known(v___x_78_, 1);
v___x_79_ = 8ULL;
v___x_80_ = 2ULL;
v___x_81_ = 12ULL;
v___x_82_ = 4ULL;
v___x_83_ = 4593671619917905920ULL;
v___x_84_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_79_, v___x_80_, v___x_81_, v___x_82_, v___x_76_, v___x_71_, v___x_83_, v___x_74_);
if (lean_obj_tag(v___x_84_) == 0)
{
uint64_t v___x_85_; lean_object* v___x_86_; 
lean_dec_ref_known(v___x_84_, 1);
v___x_85_ = 4607182418800017408ULL;
v___x_86_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_79_, v___x_80_, v___x_81_, v___x_82_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_85_, v___x_74_);
if (lean_obj_tag(v___x_86_) == 0)
{
uint64_t v___x_87_; lean_object* v___x_88_; 
lean_dec_ref_known(v___x_86_, 1);
v___x_87_ = 13826050856027422720ULL;
v___x_88_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_79_, v___x_80_, v___x_81_, v___x_82_, v___x_76_, v___x_75_, v___x_75_, v___x_71_, v___x_87_, v___x_74_);
if (lean_obj_tag(v___x_88_) == 0)
{
uint32_t v___x_89_; uint64_t v___x_90_; lean_object* v___x_91_; 
lean_dec_ref_known(v___x_88_, 1);
v___x_89_ = 1;
v___x_90_ = 35ULL;
v___x_91_ = vastitas_storage_allocate(v_a_45_, v___x_89_, v___x_71_, v___x_90_);
if (lean_obj_tag(v___x_91_) == 0)
{
lean_object* v___x_92_; 
lean_dec_ref_known(v___x_91_, 1);
v___x_92_ = vastitas_storage_fill(v_a_45_, v___x_89_, v___x_74_, v___x_90_, v___x_75_, v___x_90_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_92_) == 0)
{
uint64_t v___x_93_; uint64_t v___x_94_; uint64_t v___x_95_; uint64_t v___x_96_; uint64_t v___x_97_; lean_object* v___x_98_; 
lean_dec_ref_known(v___x_92_, 1);
v___x_93_ = 16ULL;
v___x_94_ = 3ULL;
v___x_95_ = 5ULL;
v___x_96_ = 6ULL;
v___x_97_ = 13821547256400052224ULL;
v___x_98_ = vastitas_storage_fill(v_a_45_, v___x_89_, v___x_93_, v___x_94_, v___x_95_, v___x_96_, v___x_76_, v___x_71_, v___x_97_, v___x_74_);
if (lean_obj_tag(v___x_98_) == 0)
{
uint64_t v___x_99_; lean_object* v___x_100_; 
lean_dec_ref_known(v___x_98_, 1);
v___x_99_ = 4602678819172646912ULL;
v___x_100_ = vastitas_storage_store(v_a_45_, v___x_89_, v___x_93_, v___x_94_, v___x_95_, v___x_96_, v___x_76_, v___x_74_, v___x_82_, v___x_71_, v___x_99_, v___x_74_);
if (lean_obj_tag(v___x_100_) == 0)
{
uint64_t v___x_101_; lean_object* v___x_102_; 
lean_dec_ref_known(v___x_100_, 1);
v___x_101_ = 13828302655841107968ULL;
v___x_102_ = vastitas_storage_store(v_a_45_, v___x_89_, v___x_93_, v___x_94_, v___x_95_, v___x_96_, v___x_76_, v___x_80_, v___x_74_, v___x_71_, v___x_101_, v___x_74_);
if (lean_obj_tag(v___x_102_) == 0)
{
uint32_t v___x_103_; uint64_t v___x_104_; lean_object* v___x_105_; 
lean_dec_ref_known(v___x_102_, 1);
v___x_103_ = 2;
v___x_104_ = 54ULL;
v___x_105_ = vastitas_storage_allocate(v_a_45_, v___x_103_, v___x_71_, v___x_104_);
if (lean_obj_tag(v___x_105_) == 0)
{
lean_object* v___x_106_; 
lean_dec_ref_known(v___x_105_, 1);
v___x_106_ = vastitas_storage_fill(v_a_45_, v___x_103_, v___x_74_, v___x_104_, v___x_75_, v___x_104_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_106_) == 0)
{
uint64_t v___x_107_; lean_object* v___x_108_; 
lean_dec_ref_known(v___x_106_, 1);
v___x_107_ = 24ULL;
v___x_108_ = vastitas_storage_fill(v_a_45_, v___x_103_, v___x_107_, v___x_82_, v___x_96_, v___x_79_, v___x_76_, v___x_71_, v___x_99_, v___x_74_);
if (lean_obj_tag(v___x_108_) == 0)
{
lean_object* v___x_109_; 
lean_dec_ref_known(v___x_108_, 1);
v___x_109_ = vastitas_storage_store(v_a_45_, v___x_103_, v___x_107_, v___x_82_, v___x_96_, v___x_79_, v___x_76_, v___x_94_, v___x_74_, v___x_71_, v___x_97_, v___x_74_);
if (lean_obj_tag(v___x_109_) == 0)
{
uint64_t v___x_110_; lean_object* v___x_111_; 
lean_dec_ref_known(v___x_109_, 1);
v___x_110_ = 4604930618986332160ULL;
v___x_111_ = vastitas_storage_store(v_a_45_, v___x_103_, v___x_107_, v___x_82_, v___x_96_, v___x_79_, v___x_76_, v___x_74_, v___x_95_, v___x_71_, v___x_110_, v___x_74_);
if (lean_obj_tag(v___x_111_) == 0)
{
uint32_t v___x_112_; uint64_t v___x_113_; lean_object* v___x_114_; 
lean_dec_ref_known(v___x_111_, 1);
v___x_112_ = 3;
v___x_113_ = 82ULL;
v___x_114_ = vastitas_storage_allocate(v_a_45_, v___x_112_, v___x_71_, v___x_113_);
if (lean_obj_tag(v___x_114_) == 0)
{
lean_object* v___x_115_; 
lean_dec_ref_known(v___x_114_, 1);
v___x_115_ = vastitas_storage_fill(v_a_45_, v___x_112_, v___x_74_, v___x_113_, v___x_75_, v___x_113_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_115_) == 0)
{
uint32_t v___x_116_; uint64_t v___x_117_; lean_object* v___x_118_; 
lean_dec_ref_known(v___x_115_, 1);
v___x_116_ = 4;
v___x_117_ = 78ULL;
v___x_118_ = vastitas_storage_allocate(v_a_45_, v___x_116_, v___x_71_, v___x_117_);
if (lean_obj_tag(v___x_118_) == 0)
{
lean_object* v___x_119_; 
lean_dec_ref_known(v___x_118_, 1);
v___x_119_ = vastitas_storage_fill(v_a_45_, v___x_116_, v___x_74_, v___x_117_, v___x_75_, v___x_117_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_119_) == 0)
{
uint32_t v___x_120_; uint64_t v___x_121_; lean_object* v___x_122_; 
lean_dec_ref_known(v___x_119_, 1);
v___x_120_ = 5;
v___x_121_ = 111ULL;
v___x_122_ = vastitas_storage_allocate(v_a_45_, v___x_120_, v___x_71_, v___x_121_);
if (lean_obj_tag(v___x_122_) == 0)
{
lean_object* v___x_123_; 
lean_dec_ref_known(v___x_122_, 1);
v___x_123_ = vastitas_storage_fill(v_a_45_, v___x_120_, v___x_74_, v___x_121_, v___x_75_, v___x_121_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_123_) == 0)
{
uint64_t v___x_124_; uint64_t v___x_125_; lean_object* v___x_126_; 
lean_dec_ref_known(v___x_123_, 1);
v___x_124_ = 32ULL;
v___x_125_ = 13ULL;
v___x_126_ = vastitas_storage_pack3(v_a_45_, v___x_70_, v___x_79_, v___x_80_, v___x_81_, v___x_82_, v___x_76_, v___x_112_, v___x_124_, v___x_79_, v___x_94_, v___x_125_, v___x_76_, v___x_80_, v___x_94_, v___x_82_);
if (lean_obj_tag(v___x_126_) == 0)
{
uint64_t v___x_127_; uint64_t v___x_128_; lean_object* v___x_129_; 
lean_dec_ref_known(v___x_126_, 1);
v___x_127_ = 40ULL;
v___x_128_ = 14ULL;
v___x_129_ = vastitas_gemm_execute(v_a_45_, v___x_112_, v___x_124_, v___x_79_, v___x_94_, v___x_125_, v___x_76_, v___x_76_, v___x_89_, v___x_93_, v___x_94_, v___x_95_, v___x_96_, v___x_76_, v___x_76_, v___x_116_, v___x_127_, v___x_79_, v___x_95_, v___x_128_, v___x_76_, v___x_71_);
if (lean_obj_tag(v___x_129_) == 0)
{
uint64_t v___x_130_; uint64_t v___x_131_; uint64_t v___x_132_; uint64_t v___x_133_; uint64_t v___x_134_; lean_object* v___x_135_; 
lean_dec_ref_known(v___x_129_, 1);
v___x_130_ = 56ULL;
v___x_131_ = 10ULL;
v___x_132_ = 18ULL;
v___x_133_ = 48ULL;
v___x_134_ = 42ULL;
v___x_135_ = vastitas_storage_regroup3(v_a_45_, v___x_116_, v___x_127_, v___x_79_, v___x_95_, v___x_128_, v___x_76_, v___x_112_, v___x_130_, v___x_131_, v___x_82_, v___x_132_, v___x_76_, v___x_80_, v___x_82_, v___x_95_, v___x_133_, v___x_134_);
if (lean_obj_tag(v___x_135_) == 0)
{
uint64_t v___x_136_; lean_object* v___x_137_; 
lean_dec_ref_known(v___x_135_, 1);
v___x_136_ = 17ULL;
v___x_137_ = vastitas_gemm_execute(v_a_45_, v___x_112_, v___x_130_, v___x_131_, v___x_82_, v___x_132_, v___x_76_, v___x_76_, v___x_103_, v___x_107_, v___x_82_, v___x_96_, v___x_79_, v___x_76_, v___x_76_, v___x_120_, v___x_133_, v___x_131_, v___x_96_, v___x_136_, v___x_76_, v___x_71_);
if (lean_obj_tag(v___x_137_) == 0)
{
uint64_t v___x_138_; lean_object* v___x_139_; 
lean_dec_ref_known(v___x_137_, 1);
v___x_138_ = 13822532418818539520ULL;
v___x_139_ = vastitas_storage_expect(v_a_45_, v___x_120_, v___x_133_, v___x_131_, v___x_96_, v___x_136_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_138_, v___x_74_);
if (lean_obj_tag(v___x_139_) == 0)
{
uint64_t v___x_140_; lean_object* v___x_141_; 
lean_dec_ref_known(v___x_139_, 1);
v___x_140_ = 13820984306446630912ULL;
v___x_141_ = vastitas_storage_expect(v_a_45_, v___x_120_, v___x_133_, v___x_131_, v___x_96_, v___x_136_, v___x_76_, v___x_75_, v___x_95_, v___x_71_, v___x_140_, v___x_74_);
if (lean_obj_tag(v___x_141_) == 0)
{
uint64_t v___x_142_; uint64_t v___x_143_; lean_object* v___x_144_; 
lean_dec_ref_known(v___x_141_, 1);
v___x_142_ = 9ULL;
v___x_143_ = 4590293920197378048ULL;
v___x_144_ = vastitas_storage_expect(v_a_45_, v___x_120_, v___x_133_, v___x_131_, v___x_96_, v___x_136_, v___x_76_, v___x_142_, v___x_74_, v___x_71_, v___x_143_, v___x_74_);
if (lean_obj_tag(v___x_144_) == 0)
{
lean_object* v___x_145_; 
lean_dec_ref_known(v___x_144_, 1);
v___x_145_ = vastitas_storage_drop(v_a_45_, v___x_120_);
if (lean_obj_tag(v___x_145_) == 0)
{
lean_object* v___x_146_; 
lean_dec_ref_known(v___x_145_, 1);
v___x_146_ = vastitas_storage_drop(v_a_45_, v___x_116_);
if (lean_obj_tag(v___x_146_) == 0)
{
lean_object* v___x_147_; 
lean_dec_ref_known(v___x_146_, 1);
v___x_147_ = vastitas_storage_drop(v_a_45_, v___x_112_);
if (lean_obj_tag(v___x_147_) == 0)
{
lean_object* v___x_148_; 
lean_dec_ref_known(v___x_147_, 1);
v___x_148_ = vastitas_storage_drop(v_a_45_, v___x_103_);
if (lean_obj_tag(v___x_148_) == 0)
{
lean_object* v___x_149_; 
lean_dec_ref_known(v___x_148_, 1);
v___x_149_ = vastitas_storage_drop(v_a_45_, v___x_89_);
if (lean_obj_tag(v___x_149_) == 0)
{
lean_object* v___x_150_; 
lean_dec_ref_known(v___x_149_, 1);
v___x_150_ = vastitas_storage_drop(v_a_45_, v___x_70_);
if (lean_obj_tag(v___x_150_) == 0)
{
lean_object* v___x_151_; 
lean_dec_ref_known(v___x_150_, 1);
v___x_151_ = lean_box(0);
v_a_47_ = v___x_151_;
goto v___jp_46_;
}
else
{
v___y_58_ = v___x_150_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_149_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_148_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_147_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_146_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_145_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_144_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_141_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_139_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_137_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_135_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_129_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_126_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_123_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_122_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_119_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_118_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_115_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_114_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_111_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_109_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_108_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_106_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_105_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_102_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_100_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_98_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_92_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_91_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_88_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_86_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_84_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_78_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_73_;
goto v___jp_57_;
}
v___jp_46_:
{
lean_object* v___x_48_; 
v___x_48_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_48_) == 0)
{
lean_object* v___x_50_; uint8_t v_isShared_51_; uint8_t v_isSharedCheck_55_; 
v_isSharedCheck_55_ = !lean_is_exclusive(v___x_48_);
if (v_isSharedCheck_55_ == 0)
{
lean_object* v_unused_56_; 
v_unused_56_ = lean_ctor_get(v___x_48_, 0);
lean_dec(v_unused_56_);
v___x_50_ = v___x_48_;
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
else
{
lean_dec(v___x_48_);
v___x_50_ = lean_box(0);
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
v_resetjp_49_:
{
lean_object* v___x_53_; 
if (v_isShared_51_ == 0)
{
lean_ctor_set(v___x_50_, 0, v_a_47_);
v___x_53_ = v___x_50_;
goto v_reusejp_52_;
}
else
{
lean_object* v_reuseFailAlloc_54_; 
v_reuseFailAlloc_54_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_54_, 0, v_a_47_);
v___x_53_ = v_reuseFailAlloc_54_;
goto v_reusejp_52_;
}
v_reusejp_52_:
{
return v___x_53_;
}
}
}
else
{
return v___x_48_;
}
}
v___jp_57_:
{
if (lean_obj_tag(v___y_58_) == 0)
{
lean_object* v_a_59_; 
v_a_59_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_59_);
lean_dec_ref_known(v___y_58_, 1);
v_a_47_ = v_a_59_;
goto v___jp_46_;
}
else
{
lean_object* v_a_60_; lean_object* v___x_61_; 
v_a_60_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_60_);
lean_dec_ref_known(v___y_58_, 1);
v___x_61_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_61_) == 0)
{
lean_object* v___x_63_; uint8_t v_isShared_64_; uint8_t v_isSharedCheck_68_; 
v_isSharedCheck_68_ = !lean_is_exclusive(v___x_61_);
if (v_isSharedCheck_68_ == 0)
{
lean_object* v_unused_69_; 
v_unused_69_ = lean_ctor_get(v___x_61_, 0);
lean_dec(v_unused_69_);
v___x_63_ = v___x_61_;
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
else
{
lean_dec(v___x_61_);
v___x_63_ = lean_box(0);
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
v_resetjp_62_:
{
lean_object* v___x_66_; 
if (v_isShared_64_ == 0)
{
lean_ctor_set_tag(v___x_63_, 1);
lean_ctor_set(v___x_63_, 0, v_a_60_);
v___x_66_ = v___x_63_;
goto v_reusejp_65_;
}
else
{
lean_object* v_reuseFailAlloc_67_; 
v_reuseFailAlloc_67_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_67_, 0, v_a_60_);
v___x_66_ = v_reuseFailAlloc_67_;
goto v_reusejp_65_;
}
v_reusejp_65_:
{
return v___x_66_;
}
}
}
else
{
lean_dec(v_a_60_);
return v___x_61_;
}
}
}
}
else
{
lean_object* v_a_152_; lean_object* v___x_154_; uint8_t v_isShared_155_; uint8_t v_isSharedCheck_159_; 
v_a_152_ = lean_ctor_get(v___x_44_, 0);
v_isSharedCheck_159_ = !lean_is_exclusive(v___x_44_);
if (v_isSharedCheck_159_ == 0)
{
v___x_154_ = v___x_44_;
v_isShared_155_ = v_isSharedCheck_159_;
goto v_resetjp_153_;
}
else
{
lean_inc(v_a_152_);
lean_dec(v___x_44_);
v___x_154_ = lean_box(0);
v_isShared_155_ = v_isSharedCheck_159_;
goto v_resetjp_153_;
}
v_resetjp_153_:
{
lean_object* v___x_157_; 
if (v_isShared_155_ == 0)
{
v___x_157_ = v___x_154_;
goto v_reusejp_156_;
}
else
{
lean_object* v_reuseFailAlloc_158_; 
v_reuseFailAlloc_158_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_158_, 0, v_a_152_);
v___x_157_ = v_reuseFailAlloc_158_;
goto v_reusejp_156_;
}
v_reusejp_156_:
{
return v___x_157_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object* v_a_160_){
_start:
{
lean_object* v_res_161_; 
v_res_161_ = lp_allocation__audit_generatedOnce();
return v_res_161_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure(){
_start:
{
uint64_t v___x_163_; lean_object* v___x_164_; 
v___x_163_ = 9223372036854775807ULL;
v___x_164_ = vastitas_storage_new(v___x_163_);
if (lean_obj_tag(v___x_164_) == 0)
{
lean_object* v_a_165_; lean_object* v_a_167_; lean_object* v___y_178_; uint32_t v___x_190_; uint8_t v___x_191_; uint64_t v___x_192_; lean_object* v___x_193_; 
v_a_165_ = lean_ctor_get(v___x_164_, 0);
lean_inc(v_a_165_);
lean_dec_ref_known(v___x_164_, 1);
v___x_190_ = 0;
v___x_191_ = 0;
v___x_192_ = 52ULL;
v___x_193_ = vastitas_storage_allocate(v_a_165_, v___x_190_, v___x_191_, v___x_192_);
if (lean_obj_tag(v___x_193_) == 0)
{
uint64_t v___x_194_; uint64_t v___x_195_; uint8_t v___x_196_; uint64_t v___x_197_; lean_object* v___x_198_; 
lean_dec_ref_known(v___x_193_, 1);
v___x_194_ = 0ULL;
v___x_195_ = 1ULL;
v___x_196_ = 0;
v___x_197_ = 13842939354630062080ULL;
v___x_198_ = vastitas_storage_fill(v_a_165_, v___x_190_, v___x_194_, v___x_192_, v___x_195_, v___x_192_, v___x_196_, v___x_191_, v___x_197_, v___x_194_);
if (lean_obj_tag(v___x_198_) == 0)
{
uint64_t v___x_199_; uint64_t v___x_200_; uint64_t v___x_201_; uint64_t v___x_202_; uint64_t v___x_203_; lean_object* v___x_204_; 
lean_dec_ref_known(v___x_198_, 1);
v___x_199_ = 8ULL;
v___x_200_ = 2ULL;
v___x_201_ = 12ULL;
v___x_202_ = 4ULL;
v___x_203_ = 4593671619917905920ULL;
v___x_204_ = vastitas_storage_fill(v_a_165_, v___x_190_, v___x_199_, v___x_200_, v___x_201_, v___x_202_, v___x_196_, v___x_191_, v___x_203_, v___x_194_);
if (lean_obj_tag(v___x_204_) == 0)
{
uint64_t v___x_205_; lean_object* v___x_206_; 
lean_dec_ref_known(v___x_204_, 1);
v___x_205_ = 4607182418800017408ULL;
v___x_206_ = vastitas_storage_store(v_a_165_, v___x_190_, v___x_199_, v___x_200_, v___x_201_, v___x_202_, v___x_196_, v___x_194_, v___x_194_, v___x_191_, v___x_205_, v___x_194_);
if (lean_obj_tag(v___x_206_) == 0)
{
uint64_t v___x_207_; lean_object* v___x_208_; 
lean_dec_ref_known(v___x_206_, 1);
v___x_207_ = 13826050856027422720ULL;
v___x_208_ = vastitas_storage_store(v_a_165_, v___x_190_, v___x_199_, v___x_200_, v___x_201_, v___x_202_, v___x_196_, v___x_195_, v___x_195_, v___x_191_, v___x_207_, v___x_194_);
if (lean_obj_tag(v___x_208_) == 0)
{
uint32_t v___x_209_; uint64_t v___x_210_; lean_object* v___x_211_; 
lean_dec_ref_known(v___x_208_, 1);
v___x_209_ = 1;
v___x_210_ = 35ULL;
v___x_211_ = vastitas_storage_allocate(v_a_165_, v___x_209_, v___x_191_, v___x_210_);
if (lean_obj_tag(v___x_211_) == 0)
{
lean_object* v___x_212_; 
lean_dec_ref_known(v___x_211_, 1);
v___x_212_ = vastitas_storage_fill(v_a_165_, v___x_209_, v___x_194_, v___x_210_, v___x_195_, v___x_210_, v___x_196_, v___x_191_, v___x_197_, v___x_194_);
if (lean_obj_tag(v___x_212_) == 0)
{
uint64_t v___x_213_; uint64_t v___x_214_; uint64_t v___x_215_; uint64_t v___x_216_; uint64_t v___x_217_; lean_object* v___x_218_; 
lean_dec_ref_known(v___x_212_, 1);
v___x_213_ = 16ULL;
v___x_214_ = 3ULL;
v___x_215_ = 5ULL;
v___x_216_ = 6ULL;
v___x_217_ = 13821547256400052224ULL;
v___x_218_ = vastitas_storage_fill(v_a_165_, v___x_209_, v___x_213_, v___x_214_, v___x_215_, v___x_216_, v___x_196_, v___x_191_, v___x_217_, v___x_194_);
if (lean_obj_tag(v___x_218_) == 0)
{
uint64_t v___x_219_; lean_object* v___x_220_; 
lean_dec_ref_known(v___x_218_, 1);
v___x_219_ = 4602678819172646912ULL;
v___x_220_ = vastitas_storage_store(v_a_165_, v___x_209_, v___x_213_, v___x_214_, v___x_215_, v___x_216_, v___x_196_, v___x_194_, v___x_202_, v___x_191_, v___x_219_, v___x_194_);
if (lean_obj_tag(v___x_220_) == 0)
{
uint64_t v___x_221_; lean_object* v___x_222_; 
lean_dec_ref_known(v___x_220_, 1);
v___x_221_ = 13828302655841107968ULL;
v___x_222_ = vastitas_storage_store(v_a_165_, v___x_209_, v___x_213_, v___x_214_, v___x_215_, v___x_216_, v___x_196_, v___x_200_, v___x_194_, v___x_191_, v___x_221_, v___x_194_);
if (lean_obj_tag(v___x_222_) == 0)
{
uint32_t v___x_223_; uint64_t v___x_224_; lean_object* v___x_225_; 
lean_dec_ref_known(v___x_222_, 1);
v___x_223_ = 2;
v___x_224_ = 54ULL;
v___x_225_ = vastitas_storage_allocate(v_a_165_, v___x_223_, v___x_191_, v___x_224_);
if (lean_obj_tag(v___x_225_) == 0)
{
lean_object* v___x_226_; 
lean_dec_ref_known(v___x_225_, 1);
v___x_226_ = vastitas_storage_fill(v_a_165_, v___x_223_, v___x_194_, v___x_224_, v___x_195_, v___x_224_, v___x_196_, v___x_191_, v___x_197_, v___x_194_);
if (lean_obj_tag(v___x_226_) == 0)
{
uint64_t v___x_227_; lean_object* v___x_228_; 
lean_dec_ref_known(v___x_226_, 1);
v___x_227_ = 24ULL;
v___x_228_ = vastitas_storage_fill(v_a_165_, v___x_223_, v___x_227_, v___x_202_, v___x_216_, v___x_199_, v___x_196_, v___x_191_, v___x_219_, v___x_194_);
if (lean_obj_tag(v___x_228_) == 0)
{
lean_object* v___x_229_; 
lean_dec_ref_known(v___x_228_, 1);
v___x_229_ = vastitas_storage_store(v_a_165_, v___x_223_, v___x_227_, v___x_202_, v___x_216_, v___x_199_, v___x_196_, v___x_214_, v___x_194_, v___x_191_, v___x_217_, v___x_194_);
if (lean_obj_tag(v___x_229_) == 0)
{
uint64_t v___x_230_; lean_object* v___x_231_; 
lean_dec_ref_known(v___x_229_, 1);
v___x_230_ = 4604930618986332160ULL;
v___x_231_ = vastitas_storage_store(v_a_165_, v___x_223_, v___x_227_, v___x_202_, v___x_216_, v___x_199_, v___x_196_, v___x_194_, v___x_215_, v___x_191_, v___x_230_, v___x_194_);
if (lean_obj_tag(v___x_231_) == 0)
{
uint32_t v___x_232_; uint64_t v___x_233_; lean_object* v___x_234_; 
lean_dec_ref_known(v___x_231_, 1);
v___x_232_ = 3;
v___x_233_ = 82ULL;
v___x_234_ = vastitas_storage_allocate(v_a_165_, v___x_232_, v___x_191_, v___x_233_);
if (lean_obj_tag(v___x_234_) == 0)
{
lean_object* v___x_235_; 
lean_dec_ref_known(v___x_234_, 1);
v___x_235_ = vastitas_storage_fill(v_a_165_, v___x_232_, v___x_194_, v___x_233_, v___x_195_, v___x_233_, v___x_196_, v___x_191_, v___x_197_, v___x_194_);
if (lean_obj_tag(v___x_235_) == 0)
{
uint32_t v___x_236_; uint64_t v___x_237_; lean_object* v___x_238_; 
lean_dec_ref_known(v___x_235_, 1);
v___x_236_ = 4;
v___x_237_ = 78ULL;
v___x_238_ = vastitas_storage_allocate(v_a_165_, v___x_236_, v___x_191_, v___x_237_);
if (lean_obj_tag(v___x_238_) == 0)
{
lean_object* v___x_239_; 
lean_dec_ref_known(v___x_238_, 1);
v___x_239_ = vastitas_storage_fill(v_a_165_, v___x_236_, v___x_194_, v___x_237_, v___x_195_, v___x_237_, v___x_196_, v___x_191_, v___x_197_, v___x_194_);
if (lean_obj_tag(v___x_239_) == 0)
{
uint32_t v___x_240_; uint64_t v___x_241_; lean_object* v___x_242_; 
lean_dec_ref_known(v___x_239_, 1);
v___x_240_ = 5;
v___x_241_ = 111ULL;
v___x_242_ = vastitas_storage_allocate(v_a_165_, v___x_240_, v___x_191_, v___x_241_);
if (lean_obj_tag(v___x_242_) == 0)
{
lean_object* v___x_243_; 
lean_dec_ref_known(v___x_242_, 1);
v___x_243_ = vastitas_storage_fill(v_a_165_, v___x_240_, v___x_194_, v___x_241_, v___x_195_, v___x_241_, v___x_196_, v___x_191_, v___x_197_, v___x_194_);
if (lean_obj_tag(v___x_243_) == 0)
{
uint64_t v___x_244_; uint64_t v___x_245_; lean_object* v___x_246_; 
lean_dec_ref_known(v___x_243_, 1);
v___x_244_ = 32ULL;
v___x_245_ = 13ULL;
v___x_246_ = vastitas_storage_pack3(v_a_165_, v___x_190_, v___x_199_, v___x_200_, v___x_201_, v___x_202_, v___x_196_, v___x_232_, v___x_244_, v___x_199_, v___x_214_, v___x_245_, v___x_196_, v___x_200_, v___x_214_, v___x_202_);
if (lean_obj_tag(v___x_246_) == 0)
{
uint64_t v___x_247_; uint64_t v___x_248_; lean_object* v___x_249_; 
lean_dec_ref_known(v___x_246_, 1);
v___x_247_ = 40ULL;
v___x_248_ = 14ULL;
v___x_249_ = vastitas_gemm_execute(v_a_165_, v___x_232_, v___x_244_, v___x_199_, v___x_214_, v___x_245_, v___x_196_, v___x_196_, v___x_209_, v___x_213_, v___x_214_, v___x_215_, v___x_216_, v___x_196_, v___x_196_, v___x_236_, v___x_247_, v___x_199_, v___x_215_, v___x_248_, v___x_196_, v___x_191_);
if (lean_obj_tag(v___x_249_) == 0)
{
uint64_t v___x_250_; uint64_t v___x_251_; uint64_t v___x_252_; uint64_t v___x_253_; uint64_t v___x_254_; lean_object* v___x_255_; 
lean_dec_ref_known(v___x_249_, 1);
v___x_250_ = 56ULL;
v___x_251_ = 10ULL;
v___x_252_ = 18ULL;
v___x_253_ = 48ULL;
v___x_254_ = 42ULL;
v___x_255_ = vastitas_storage_regroup3(v_a_165_, v___x_236_, v___x_247_, v___x_199_, v___x_215_, v___x_248_, v___x_196_, v___x_232_, v___x_250_, v___x_251_, v___x_202_, v___x_252_, v___x_196_, v___x_200_, v___x_202_, v___x_215_, v___x_253_, v___x_254_);
if (lean_obj_tag(v___x_255_) == 0)
{
uint64_t v___x_256_; lean_object* v___x_257_; 
lean_dec_ref_known(v___x_255_, 1);
v___x_256_ = 17ULL;
v___x_257_ = vastitas_gemm_execute(v_a_165_, v___x_232_, v___x_250_, v___x_251_, v___x_202_, v___x_252_, v___x_196_, v___x_196_, v___x_223_, v___x_227_, v___x_202_, v___x_216_, v___x_199_, v___x_196_, v___x_196_, v___x_240_, v___x_253_, v___x_251_, v___x_216_, v___x_256_, v___x_196_, v___x_191_);
if (lean_obj_tag(v___x_257_) == 0)
{
uint64_t v___x_258_; lean_object* v___x_259_; 
lean_dec_ref_known(v___x_257_, 1);
v___x_258_ = 13822532418818539521ULL;
v___x_259_ = vastitas_storage_expect(v_a_165_, v___x_240_, v___x_253_, v___x_251_, v___x_216_, v___x_256_, v___x_196_, v___x_194_, v___x_194_, v___x_191_, v___x_258_, v___x_194_);
if (lean_obj_tag(v___x_259_) == 0)
{
uint64_t v___x_260_; lean_object* v___x_261_; 
lean_dec_ref_known(v___x_259_, 1);
v___x_260_ = 13820984306446630912ULL;
v___x_261_ = vastitas_storage_expect(v_a_165_, v___x_240_, v___x_253_, v___x_251_, v___x_216_, v___x_256_, v___x_196_, v___x_195_, v___x_215_, v___x_191_, v___x_260_, v___x_194_);
if (lean_obj_tag(v___x_261_) == 0)
{
uint64_t v___x_262_; uint64_t v___x_263_; lean_object* v___x_264_; 
lean_dec_ref_known(v___x_261_, 1);
v___x_262_ = 9ULL;
v___x_263_ = 4590293920197378048ULL;
v___x_264_ = vastitas_storage_expect(v_a_165_, v___x_240_, v___x_253_, v___x_251_, v___x_216_, v___x_256_, v___x_196_, v___x_262_, v___x_194_, v___x_191_, v___x_263_, v___x_194_);
if (lean_obj_tag(v___x_264_) == 0)
{
lean_object* v___x_265_; 
lean_dec_ref_known(v___x_264_, 1);
v___x_265_ = vastitas_storage_drop(v_a_165_, v___x_240_);
if (lean_obj_tag(v___x_265_) == 0)
{
lean_object* v___x_266_; 
lean_dec_ref_known(v___x_265_, 1);
v___x_266_ = vastitas_storage_drop(v_a_165_, v___x_236_);
if (lean_obj_tag(v___x_266_) == 0)
{
lean_object* v___x_267_; 
lean_dec_ref_known(v___x_266_, 1);
v___x_267_ = vastitas_storage_drop(v_a_165_, v___x_232_);
if (lean_obj_tag(v___x_267_) == 0)
{
lean_object* v___x_268_; 
lean_dec_ref_known(v___x_267_, 1);
v___x_268_ = vastitas_storage_drop(v_a_165_, v___x_223_);
if (lean_obj_tag(v___x_268_) == 0)
{
lean_object* v___x_269_; 
lean_dec_ref_known(v___x_268_, 1);
v___x_269_ = vastitas_storage_drop(v_a_165_, v___x_209_);
if (lean_obj_tag(v___x_269_) == 0)
{
lean_object* v___x_270_; 
lean_dec_ref_known(v___x_269_, 1);
v___x_270_ = vastitas_storage_drop(v_a_165_, v___x_190_);
if (lean_obj_tag(v___x_270_) == 0)
{
lean_object* v___x_271_; 
lean_dec_ref_known(v___x_270_, 1);
v___x_271_ = lean_box(0);
v_a_167_ = v___x_271_;
goto v___jp_166_;
}
else
{
v___y_178_ = v___x_270_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_269_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_268_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_267_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_266_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_265_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_264_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_261_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_259_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_257_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_255_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_249_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_246_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_243_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_242_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_239_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_238_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_235_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_234_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_231_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_229_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_228_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_226_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_225_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_222_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_220_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_218_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_212_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_211_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_208_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_206_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_204_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_198_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_193_;
goto v___jp_177_;
}
v___jp_166_:
{
lean_object* v___x_168_; 
v___x_168_ = vastitas_storage_close(v_a_165_);
lean_dec(v_a_165_);
if (lean_obj_tag(v___x_168_) == 0)
{
lean_object* v___x_170_; uint8_t v_isShared_171_; uint8_t v_isSharedCheck_175_; 
v_isSharedCheck_175_ = !lean_is_exclusive(v___x_168_);
if (v_isSharedCheck_175_ == 0)
{
lean_object* v_unused_176_; 
v_unused_176_ = lean_ctor_get(v___x_168_, 0);
lean_dec(v_unused_176_);
v___x_170_ = v___x_168_;
v_isShared_171_ = v_isSharedCheck_175_;
goto v_resetjp_169_;
}
else
{
lean_dec(v___x_168_);
v___x_170_ = lean_box(0);
v_isShared_171_ = v_isSharedCheck_175_;
goto v_resetjp_169_;
}
v_resetjp_169_:
{
lean_object* v___x_173_; 
if (v_isShared_171_ == 0)
{
lean_ctor_set(v___x_170_, 0, v_a_167_);
v___x_173_ = v___x_170_;
goto v_reusejp_172_;
}
else
{
lean_object* v_reuseFailAlloc_174_; 
v_reuseFailAlloc_174_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_174_, 0, v_a_167_);
v___x_173_ = v_reuseFailAlloc_174_;
goto v_reusejp_172_;
}
v_reusejp_172_:
{
return v___x_173_;
}
}
}
else
{
return v___x_168_;
}
}
v___jp_177_:
{
if (lean_obj_tag(v___y_178_) == 0)
{
lean_object* v_a_179_; 
v_a_179_ = lean_ctor_get(v___y_178_, 0);
lean_inc(v_a_179_);
lean_dec_ref_known(v___y_178_, 1);
v_a_167_ = v_a_179_;
goto v___jp_166_;
}
else
{
lean_object* v_a_180_; lean_object* v___x_181_; 
v_a_180_ = lean_ctor_get(v___y_178_, 0);
lean_inc(v_a_180_);
lean_dec_ref_known(v___y_178_, 1);
v___x_181_ = vastitas_storage_close(v_a_165_);
lean_dec(v_a_165_);
if (lean_obj_tag(v___x_181_) == 0)
{
lean_object* v___x_183_; uint8_t v_isShared_184_; uint8_t v_isSharedCheck_188_; 
v_isSharedCheck_188_ = !lean_is_exclusive(v___x_181_);
if (v_isSharedCheck_188_ == 0)
{
lean_object* v_unused_189_; 
v_unused_189_ = lean_ctor_get(v___x_181_, 0);
lean_dec(v_unused_189_);
v___x_183_ = v___x_181_;
v_isShared_184_ = v_isSharedCheck_188_;
goto v_resetjp_182_;
}
else
{
lean_dec(v___x_181_);
v___x_183_ = lean_box(0);
v_isShared_184_ = v_isSharedCheck_188_;
goto v_resetjp_182_;
}
v_resetjp_182_:
{
lean_object* v___x_186_; 
if (v_isShared_184_ == 0)
{
lean_ctor_set_tag(v___x_183_, 1);
lean_ctor_set(v___x_183_, 0, v_a_180_);
v___x_186_ = v___x_183_;
goto v_reusejp_185_;
}
else
{
lean_object* v_reuseFailAlloc_187_; 
v_reuseFailAlloc_187_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_187_, 0, v_a_180_);
v___x_186_ = v_reuseFailAlloc_187_;
goto v_reusejp_185_;
}
v_reusejp_185_:
{
return v___x_186_;
}
}
}
else
{
lean_dec(v_a_180_);
return v___x_181_;
}
}
}
}
else
{
lean_object* v_a_272_; lean_object* v___x_274_; uint8_t v_isShared_275_; uint8_t v_isSharedCheck_279_; 
v_a_272_ = lean_ctor_get(v___x_164_, 0);
v_isSharedCheck_279_ = !lean_is_exclusive(v___x_164_);
if (v_isSharedCheck_279_ == 0)
{
v___x_274_ = v___x_164_;
v_isShared_275_ = v_isSharedCheck_279_;
goto v_resetjp_273_;
}
else
{
lean_inc(v_a_272_);
lean_dec(v___x_164_);
v___x_274_ = lean_box(0);
v_isShared_275_ = v_isSharedCheck_279_;
goto v_resetjp_273_;
}
v_resetjp_273_:
{
lean_object* v___x_277_; 
if (v_isShared_275_ == 0)
{
v___x_277_ = v___x_274_;
goto v_reusejp_276_;
}
else
{
lean_object* v_reuseFailAlloc_278_; 
v_reuseFailAlloc_278_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_278_, 0, v_a_272_);
v___x_277_ = v_reuseFailAlloc_278_;
goto v_reusejp_276_;
}
v_reusejp_276_:
{
return v___x_277_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object* v_a_280_){
_start:
{
lean_object* v_res_281_; 
v_res_281_ = lp_allocation__audit_generatedFailure();
return v_res_281_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object* v_phase_284_, lean_object* v_a_00___x40___internal___hyg_285_){
_start:
{
uint32_t v_phase_boxed_286_; lean_object* v_res_287_; 
v_phase_boxed_286_ = lean_unbox_uint32(v_phase_284_);
lean_dec(v_phase_284_);
v_res_287_ = audit_mark_lean(v_phase_boxed_286_);
return v_res_287_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object* v_a_288_, lean_object* v_scope_289_, lean_object* v_range_290_, lean_object* v_b_291_, lean_object* v_i_292_){
_start:
{
lean_object* v_stop_294_; lean_object* v_step_295_; uint8_t v___x_296_; 
v_stop_294_ = lean_ctor_get(v_range_290_, 1);
v_step_295_ = lean_ctor_get(v_range_290_, 2);
v___x_296_ = lean_nat_dec_lt(v_i_292_, v_stop_294_);
if (v___x_296_ == 0)
{
lean_object* v___x_297_; 
lean_dec(v_i_292_);
v___x_297_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_297_, 0, v_b_291_);
return v___x_297_;
}
else
{
uint32_t v___x_298_; uint64_t v___x_299_; uint64_t v___x_300_; uint64_t v___x_301_; uint64_t v___x_302_; lean_object* v___x_303_; uint8_t v___x_304_; uint32_t v___x_305_; uint64_t v___x_306_; uint32_t v___x_307_; uint64_t v___x_308_; uint64_t v___x_309_; uint64_t v___x_310_; uint32_t v___x_311_; uint8_t v___x_312_; uint32_t v___x_313_; uint64_t v___x_314_; uint32_t v___x_315_; lean_object* v___x_316_; uint64_t v___x_317_; uint64_t v___x_318_; lean_object* v___x_319_; 
v___x_298_ = 0;
v___x_299_ = 8ULL;
v___x_300_ = 2ULL;
v___x_301_ = 12ULL;
v___x_302_ = 4ULL;
v___x_303_ = lean_unsigned_to_nat(0u);
v___x_304_ = lean_nat_dec_eq(v_scope_289_, v___x_303_);
v___x_305_ = 3;
v___x_306_ = 3ULL;
v___x_307_ = 1;
v___x_308_ = 16ULL;
v___x_309_ = 5ULL;
v___x_310_ = 6ULL;
v___x_311_ = 4;
v___x_312_ = 0;
v___x_313_ = 2;
v___x_314_ = 24ULL;
v___x_315_ = 5;
v___x_316_ = lean_box(0);
v___x_317_ = 32ULL;
v___x_318_ = 13ULL;
v___x_319_ = vastitas_storage_pack3(v_a_288_, v___x_298_, v___x_299_, v___x_300_, v___x_301_, v___x_302_, v___x_304_, v___x_305_, v___x_317_, v___x_299_, v___x_306_, v___x_318_, v___x_304_, v___x_300_, v___x_306_, v___x_302_);
if (lean_obj_tag(v___x_319_) == 0)
{
uint64_t v___x_320_; uint64_t v___x_321_; lean_object* v___x_322_; 
lean_dec_ref_known(v___x_319_, 1);
v___x_320_ = 40ULL;
v___x_321_ = 14ULL;
v___x_322_ = vastitas_gemm_execute(v_a_288_, v___x_305_, v___x_317_, v___x_299_, v___x_306_, v___x_318_, v___x_304_, v___x_304_, v___x_307_, v___x_308_, v___x_306_, v___x_309_, v___x_310_, v___x_304_, v___x_304_, v___x_311_, v___x_320_, v___x_299_, v___x_309_, v___x_321_, v___x_304_, v___x_312_);
if (lean_obj_tag(v___x_322_) == 0)
{
uint64_t v___x_323_; uint64_t v___x_324_; uint64_t v___x_325_; uint64_t v___x_326_; uint64_t v___x_327_; lean_object* v___x_328_; 
lean_dec_ref_known(v___x_322_, 1);
v___x_323_ = 56ULL;
v___x_324_ = 10ULL;
v___x_325_ = 18ULL;
v___x_326_ = 48ULL;
v___x_327_ = 42ULL;
v___x_328_ = vastitas_storage_regroup3(v_a_288_, v___x_311_, v___x_320_, v___x_299_, v___x_309_, v___x_321_, v___x_304_, v___x_305_, v___x_323_, v___x_324_, v___x_302_, v___x_325_, v___x_304_, v___x_300_, v___x_302_, v___x_309_, v___x_326_, v___x_327_);
if (lean_obj_tag(v___x_328_) == 0)
{
uint64_t v___x_329_; lean_object* v___x_330_; 
lean_dec_ref_known(v___x_328_, 1);
v___x_329_ = 17ULL;
v___x_330_ = vastitas_gemm_execute(v_a_288_, v___x_305_, v___x_323_, v___x_324_, v___x_302_, v___x_325_, v___x_304_, v___x_304_, v___x_313_, v___x_314_, v___x_302_, v___x_310_, v___x_299_, v___x_304_, v___x_304_, v___x_315_, v___x_326_, v___x_324_, v___x_310_, v___x_329_, v___x_304_, v___x_312_);
if (lean_obj_tag(v___x_330_) == 0)
{
lean_object* v___x_331_; 
lean_dec_ref_known(v___x_330_, 1);
v___x_331_ = lean_nat_add(v_i_292_, v_step_295_);
lean_dec(v_i_292_);
v_b_291_ = v___x_316_;
v_i_292_ = v___x_331_;
goto _start;
}
else
{
lean_dec(v_i_292_);
return v___x_330_;
}
}
else
{
lean_dec(v_i_292_);
return v___x_328_;
}
}
else
{
lean_dec(v_i_292_);
return v___x_322_;
}
}
else
{
lean_dec(v_i_292_);
return v___x_319_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object* v_a_333_, lean_object* v_scope_334_, lean_object* v_range_335_, lean_object* v_b_336_, lean_object* v_i_337_, lean_object* v___y_338_){
_start:
{
lean_object* v_res_339_; 
v_res_339_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_333_, v_scope_334_, v_range_335_, v_b_336_, v_i_337_);
lean_dec_ref(v_range_335_);
lean_dec(v_scope_334_);
lean_dec(v_a_333_);
return v_res_339_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object* v_range_340_, lean_object* v_b_341_, lean_object* v_i_342_){
_start:
{
lean_object* v_stop_344_; lean_object* v_step_345_; uint8_t v___x_346_; 
v_stop_344_ = lean_ctor_get(v_range_340_, 1);
v_step_345_ = lean_ctor_get(v_range_340_, 2);
v___x_346_ = lean_nat_dec_lt(v_i_342_, v_stop_344_);
if (v___x_346_ == 0)
{
lean_object* v___x_347_; 
lean_dec(v_i_342_);
v___x_347_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_347_, 0, v_b_341_);
return v___x_347_;
}
else
{
lean_object* v___x_348_; lean_object* v___x_349_; 
v___x_348_ = lean_box(0);
v___x_349_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_349_) == 0)
{
lean_object* v___x_350_; 
lean_dec_ref_known(v___x_349_, 1);
v___x_350_ = lean_nat_add(v_i_342_, v_step_345_);
lean_dec(v_i_342_);
v_b_341_ = v___x_348_;
v_i_342_ = v___x_350_;
goto _start;
}
else
{
lean_dec(v_i_342_);
return v___x_349_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object* v_range_352_, lean_object* v_b_353_, lean_object* v_i_354_, lean_object* v___y_355_){
_start:
{
lean_object* v_res_356_; 
v_res_356_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_352_, v_b_353_, v_i_354_);
lean_dec_ref(v_range_352_);
return v_res_356_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_365_){
_start:
{
lean_object* v___x_367_; lean_object* v___x_368_; lean_object* v_impl_369_; lean_object* v___x_370_; lean_object* v___x_371_; lean_object* v___x_372_; lean_object* v___x_373_; lean_object* v_scope_374_; lean_object* v___x_375_; lean_object* v___x_376_; lean_object* v___x_377_; lean_object* v___x_378_; lean_object* v_reps_379_; lean_object* v___x_380_; lean_object* v___x_381_; lean_object* v___x_382_; uint8_t v_verify_383_; uint32_t v___x_384_; lean_object* v___x_385_; 
v___x_367_ = ((lean_object*)(lp_allocation__audit_main___closed__0));
v___x_368_ = lean_unsigned_to_nat(0u);
v_impl_369_ = l_List_get_x21Internal___redArg(v___x_367_, v_args_365_, v___x_368_);
v___x_370_ = lean_unsigned_to_nat(1u);
v___x_371_ = l_List_get_x21Internal___redArg(v___x_367_, v_args_365_, v___x_370_);
v___x_372_ = lean_string_utf8_byte_size(v___x_371_);
v___x_373_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_373_, 0, v___x_371_);
lean_ctor_set(v___x_373_, 1, v___x_368_);
lean_ctor_set(v___x_373_, 2, v___x_372_);
v_scope_374_ = l_String_Slice_toNat_x21(v___x_373_);
lean_dec_ref_known(v___x_373_, 3);
v___x_375_ = lean_unsigned_to_nat(2u);
v___x_376_ = l_List_get_x21Internal___redArg(v___x_367_, v_args_365_, v___x_375_);
v___x_377_ = lean_string_utf8_byte_size(v___x_376_);
v___x_378_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_378_, 0, v___x_376_);
lean_ctor_set(v___x_378_, 1, v___x_368_);
lean_ctor_set(v___x_378_, 2, v___x_377_);
v_reps_379_ = l_String_Slice_toNat_x21(v___x_378_);
lean_dec_ref_known(v___x_378_, 3);
v___x_380_ = lean_unsigned_to_nat(3u);
v___x_381_ = l_List_get_x21Internal___redArg(v___x_367_, v_args_365_, v___x_380_);
lean_dec(v_args_365_);
v___x_382_ = ((lean_object*)(lp_allocation__audit_main___closed__1));
v_verify_383_ = lean_string_dec_eq(v___x_381_, v___x_382_);
lean_dec(v___x_381_);
v___x_384_ = 1;
v___x_385_ = audit_mark_lean(v___x_384_);
if (lean_obj_tag(v___x_385_) == 0)
{
lean_object* v___x_386_; 
lean_dec_ref_known(v___x_385_, 1);
v___x_386_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_386_) == 0)
{
uint32_t v___x_387_; lean_object* v___x_388_; 
lean_dec_ref_known(v___x_386_, 1);
v___x_387_ = 2;
v___x_388_ = audit_mark_lean(v___x_387_);
if (lean_obj_tag(v___x_388_) == 0)
{
lean_object* v___x_389_; uint8_t v___x_390_; 
lean_dec_ref_known(v___x_388_, 1);
v___x_389_ = ((lean_object*)(lp_allocation__audit_main___closed__2));
v___x_390_ = lean_string_dec_eq(v_impl_369_, v___x_389_);
if (v___x_390_ == 0)
{
lean_object* v___x_391_; uint8_t v___x_392_; 
v___x_391_ = ((lean_object*)(lp_allocation__audit_main___closed__3));
v___x_392_ = lean_string_dec_eq(v_impl_369_, v___x_391_);
lean_dec(v_impl_369_);
if (v___x_392_ == 0)
{
uint8_t v___x_393_; 
v___x_393_ = lean_nat_dec_eq(v_scope_374_, v___x_368_);
if (v___x_393_ == 0)
{
uint64_t v___x_394_; lean_object* v___x_395_; 
v___x_394_ = 9223372036854775807ULL;
v___x_395_ = vastitas_storage_new(v___x_394_);
if (lean_obj_tag(v___x_395_) == 0)
{
lean_object* v_a_396_; lean_object* v___y_398_; uint32_t v___x_411_; uint8_t v___x_412_; uint64_t v___x_413_; lean_object* v___x_414_; 
v_a_396_ = lean_ctor_get(v___x_395_, 0);
lean_inc(v_a_396_);
lean_dec_ref_known(v___x_395_, 1);
v___x_411_ = 0;
v___x_412_ = 0;
v___x_413_ = 52ULL;
v___x_414_ = vastitas_storage_allocate(v_a_396_, v___x_411_, v___x_412_, v___x_413_);
if (lean_obj_tag(v___x_414_) == 0)
{
uint64_t v___x_415_; uint64_t v___x_416_; uint64_t v___x_417_; lean_object* v___x_418_; 
lean_dec_ref_known(v___x_414_, 1);
v___x_415_ = 0ULL;
v___x_416_ = 1ULL;
v___x_417_ = 13842939354630062080ULL;
v___x_418_ = vastitas_storage_fill(v_a_396_, v___x_411_, v___x_415_, v___x_413_, v___x_416_, v___x_413_, v___x_393_, v___x_412_, v___x_417_, v___x_415_);
if (lean_obj_tag(v___x_418_) == 0)
{
uint64_t v___x_419_; uint64_t v___x_420_; uint64_t v___x_421_; uint64_t v___x_422_; uint64_t v___x_423_; lean_object* v___x_424_; 
lean_dec_ref_known(v___x_418_, 1);
v___x_419_ = 8ULL;
v___x_420_ = 2ULL;
v___x_421_ = 12ULL;
v___x_422_ = 4ULL;
v___x_423_ = 4593671619917905920ULL;
v___x_424_ = vastitas_storage_fill(v_a_396_, v___x_411_, v___x_419_, v___x_420_, v___x_421_, v___x_422_, v___x_393_, v___x_412_, v___x_423_, v___x_415_);
if (lean_obj_tag(v___x_424_) == 0)
{
uint64_t v___x_425_; lean_object* v___x_426_; 
lean_dec_ref_known(v___x_424_, 1);
v___x_425_ = 4607182418800017408ULL;
v___x_426_ = vastitas_storage_store(v_a_396_, v___x_411_, v___x_419_, v___x_420_, v___x_421_, v___x_422_, v___x_393_, v___x_415_, v___x_415_, v___x_412_, v___x_425_, v___x_415_);
if (lean_obj_tag(v___x_426_) == 0)
{
uint64_t v___x_427_; lean_object* v___x_428_; 
lean_dec_ref_known(v___x_426_, 1);
v___x_427_ = 13826050856027422720ULL;
v___x_428_ = vastitas_storage_store(v_a_396_, v___x_411_, v___x_419_, v___x_420_, v___x_421_, v___x_422_, v___x_393_, v___x_416_, v___x_416_, v___x_412_, v___x_427_, v___x_415_);
if (lean_obj_tag(v___x_428_) == 0)
{
uint64_t v___x_429_; lean_object* v___x_430_; 
lean_dec_ref_known(v___x_428_, 1);
v___x_429_ = 35ULL;
v___x_430_ = vastitas_storage_allocate(v_a_396_, v___x_384_, v___x_412_, v___x_429_);
if (lean_obj_tag(v___x_430_) == 0)
{
lean_object* v___x_431_; 
lean_dec_ref_known(v___x_430_, 1);
v___x_431_ = vastitas_storage_fill(v_a_396_, v___x_384_, v___x_415_, v___x_429_, v___x_416_, v___x_429_, v___x_393_, v___x_412_, v___x_417_, v___x_415_);
if (lean_obj_tag(v___x_431_) == 0)
{
uint64_t v___x_432_; uint64_t v___x_433_; uint64_t v___x_434_; uint64_t v___x_435_; uint64_t v___x_436_; lean_object* v___x_437_; 
lean_dec_ref_known(v___x_431_, 1);
v___x_432_ = 16ULL;
v___x_433_ = 3ULL;
v___x_434_ = 5ULL;
v___x_435_ = 6ULL;
v___x_436_ = 13821547256400052224ULL;
v___x_437_ = vastitas_storage_fill(v_a_396_, v___x_384_, v___x_432_, v___x_433_, v___x_434_, v___x_435_, v___x_393_, v___x_412_, v___x_436_, v___x_415_);
if (lean_obj_tag(v___x_437_) == 0)
{
uint64_t v___x_438_; lean_object* v___x_439_; 
lean_dec_ref_known(v___x_437_, 1);
v___x_438_ = 4602678819172646912ULL;
v___x_439_ = vastitas_storage_store(v_a_396_, v___x_384_, v___x_432_, v___x_433_, v___x_434_, v___x_435_, v___x_393_, v___x_415_, v___x_422_, v___x_412_, v___x_438_, v___x_415_);
if (lean_obj_tag(v___x_439_) == 0)
{
uint64_t v___x_440_; lean_object* v___x_441_; 
lean_dec_ref_known(v___x_439_, 1);
v___x_440_ = 13828302655841107968ULL;
v___x_441_ = vastitas_storage_store(v_a_396_, v___x_384_, v___x_432_, v___x_433_, v___x_434_, v___x_435_, v___x_393_, v___x_420_, v___x_415_, v___x_412_, v___x_440_, v___x_415_);
if (lean_obj_tag(v___x_441_) == 0)
{
uint64_t v___x_442_; lean_object* v___x_443_; 
lean_dec_ref_known(v___x_441_, 1);
v___x_442_ = 54ULL;
v___x_443_ = vastitas_storage_allocate(v_a_396_, v___x_387_, v___x_412_, v___x_442_);
if (lean_obj_tag(v___x_443_) == 0)
{
lean_object* v___x_444_; 
lean_dec_ref_known(v___x_443_, 1);
v___x_444_ = vastitas_storage_fill(v_a_396_, v___x_387_, v___x_415_, v___x_442_, v___x_416_, v___x_442_, v___x_393_, v___x_412_, v___x_417_, v___x_415_);
if (lean_obj_tag(v___x_444_) == 0)
{
uint64_t v___x_445_; lean_object* v___x_446_; 
lean_dec_ref_known(v___x_444_, 1);
v___x_445_ = 24ULL;
v___x_446_ = vastitas_storage_fill(v_a_396_, v___x_387_, v___x_445_, v___x_422_, v___x_435_, v___x_419_, v___x_393_, v___x_412_, v___x_438_, v___x_415_);
if (lean_obj_tag(v___x_446_) == 0)
{
lean_object* v___x_447_; 
lean_dec_ref_known(v___x_446_, 1);
v___x_447_ = vastitas_storage_store(v_a_396_, v___x_387_, v___x_445_, v___x_422_, v___x_435_, v___x_419_, v___x_393_, v___x_433_, v___x_415_, v___x_412_, v___x_436_, v___x_415_);
if (lean_obj_tag(v___x_447_) == 0)
{
uint64_t v___x_448_; lean_object* v___x_449_; 
lean_dec_ref_known(v___x_447_, 1);
v___x_448_ = 4604930618986332160ULL;
v___x_449_ = vastitas_storage_store(v_a_396_, v___x_387_, v___x_445_, v___x_422_, v___x_435_, v___x_419_, v___x_393_, v___x_415_, v___x_434_, v___x_412_, v___x_448_, v___x_415_);
if (lean_obj_tag(v___x_449_) == 0)
{
uint32_t v___x_450_; uint64_t v___x_451_; lean_object* v___x_452_; 
lean_dec_ref_known(v___x_449_, 1);
v___x_450_ = 3;
v___x_451_ = 82ULL;
v___x_452_ = vastitas_storage_allocate(v_a_396_, v___x_450_, v___x_412_, v___x_451_);
if (lean_obj_tag(v___x_452_) == 0)
{
lean_object* v___x_453_; 
lean_dec_ref_known(v___x_452_, 1);
v___x_453_ = vastitas_storage_fill(v_a_396_, v___x_450_, v___x_415_, v___x_451_, v___x_416_, v___x_451_, v___x_393_, v___x_412_, v___x_417_, v___x_415_);
if (lean_obj_tag(v___x_453_) == 0)
{
uint32_t v___x_454_; uint64_t v___x_455_; lean_object* v___x_456_; 
lean_dec_ref_known(v___x_453_, 1);
v___x_454_ = 4;
v___x_455_ = 78ULL;
v___x_456_ = vastitas_storage_allocate(v_a_396_, v___x_454_, v___x_412_, v___x_455_);
if (lean_obj_tag(v___x_456_) == 0)
{
lean_object* v___x_457_; 
lean_dec_ref_known(v___x_456_, 1);
v___x_457_ = vastitas_storage_fill(v_a_396_, v___x_454_, v___x_415_, v___x_455_, v___x_416_, v___x_455_, v___x_393_, v___x_412_, v___x_417_, v___x_415_);
if (lean_obj_tag(v___x_457_) == 0)
{
uint32_t v___x_458_; uint64_t v___x_459_; lean_object* v___x_460_; 
lean_dec_ref_known(v___x_457_, 1);
v___x_458_ = 5;
v___x_459_ = 111ULL;
v___x_460_ = vastitas_storage_allocate(v_a_396_, v___x_458_, v___x_412_, v___x_459_);
if (lean_obj_tag(v___x_460_) == 0)
{
lean_object* v___x_461_; 
lean_dec_ref_known(v___x_460_, 1);
v___x_461_ = vastitas_storage_fill(v_a_396_, v___x_458_, v___x_415_, v___x_459_, v___x_416_, v___x_459_, v___x_393_, v___x_412_, v___x_417_, v___x_415_);
if (lean_obj_tag(v___x_461_) == 0)
{
uint32_t v___x_462_; uint64_t v___x_463_; lean_object* v___x_464_; 
lean_dec_ref_known(v___x_461_, 1);
v___x_462_ = lean_uint32_of_nat(v_scope_374_);
v___x_463_ = lean_uint64_of_nat(v_reps_379_);
v___x_464_ = bench_begin_lean(v___x_462_, v___x_463_, v_verify_383_);
if (lean_obj_tag(v___x_464_) == 0)
{
lean_object* v___x_465_; lean_object* v___x_466_; lean_object* v___x_467_; 
lean_dec_ref_known(v___x_464_, 1);
v___x_465_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_465_, 0, v___x_368_);
lean_ctor_set(v___x_465_, 1, v_reps_379_);
lean_ctor_set(v___x_465_, 2, v___x_370_);
v___x_466_ = lean_box(0);
v___x_467_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_396_, v_scope_374_, v___x_465_, v___x_466_, v___x_368_);
lean_dec_ref_known(v___x_465_, 3);
lean_dec(v_scope_374_);
if (lean_obj_tag(v___x_467_) == 0)
{
lean_object* v___x_468_; 
lean_dec_ref_known(v___x_467_, 1);
v___x_468_ = bench_stop_lean();
if (lean_obj_tag(v___x_468_) == 0)
{
lean_object* v___x_469_; 
lean_dec_ref_known(v___x_468_, 1);
v___x_469_ = bench_verify_lean(v_a_396_, v___x_463_);
if (lean_obj_tag(v___x_469_) == 0)
{
uint64_t v___x_470_; uint64_t v___x_471_; uint64_t v___x_472_; uint64_t v___x_473_; lean_object* v___x_474_; 
lean_dec_ref_known(v___x_469_, 1);
v___x_470_ = 48ULL;
v___x_471_ = 10ULL;
v___x_472_ = 17ULL;
v___x_473_ = 13822532418818539520ULL;
v___x_474_ = vastitas_storage_expect(v_a_396_, v___x_458_, v___x_470_, v___x_471_, v___x_435_, v___x_472_, v___x_393_, v___x_415_, v___x_415_, v___x_412_, v___x_473_, v___x_415_);
if (lean_obj_tag(v___x_474_) == 0)
{
uint64_t v___x_475_; lean_object* v___x_476_; 
lean_dec_ref_known(v___x_474_, 1);
v___x_475_ = 13820984306446630912ULL;
v___x_476_ = vastitas_storage_expect(v_a_396_, v___x_458_, v___x_470_, v___x_471_, v___x_435_, v___x_472_, v___x_393_, v___x_416_, v___x_434_, v___x_412_, v___x_475_, v___x_415_);
if (lean_obj_tag(v___x_476_) == 0)
{
uint64_t v___x_477_; uint64_t v___x_478_; lean_object* v___x_479_; 
lean_dec_ref_known(v___x_476_, 1);
v___x_477_ = 9ULL;
v___x_478_ = 4590293920197378048ULL;
v___x_479_ = vastitas_storage_expect(v_a_396_, v___x_458_, v___x_470_, v___x_471_, v___x_435_, v___x_472_, v___x_393_, v___x_477_, v___x_415_, v___x_412_, v___x_478_, v___x_415_);
if (lean_obj_tag(v___x_479_) == 0)
{
lean_object* v___x_480_; 
lean_dec_ref_known(v___x_479_, 1);
v___x_480_ = vastitas_storage_drop(v_a_396_, v___x_458_);
if (lean_obj_tag(v___x_480_) == 0)
{
lean_object* v___x_481_; 
lean_dec_ref_known(v___x_480_, 1);
v___x_481_ = vastitas_storage_drop(v_a_396_, v___x_454_);
if (lean_obj_tag(v___x_481_) == 0)
{
lean_object* v___x_482_; 
lean_dec_ref_known(v___x_481_, 1);
v___x_482_ = vastitas_storage_drop(v_a_396_, v___x_450_);
if (lean_obj_tag(v___x_482_) == 0)
{
lean_object* v___x_483_; 
lean_dec_ref_known(v___x_482_, 1);
v___x_483_ = vastitas_storage_drop(v_a_396_, v___x_387_);
if (lean_obj_tag(v___x_483_) == 0)
{
lean_object* v___x_484_; 
lean_dec_ref_known(v___x_483_, 1);
v___x_484_ = vastitas_storage_drop(v_a_396_, v___x_384_);
if (lean_obj_tag(v___x_484_) == 0)
{
lean_object* v___x_485_; 
lean_dec_ref_known(v___x_484_, 1);
v___x_485_ = vastitas_storage_drop(v_a_396_, v___x_411_);
v___y_398_ = v___x_485_;
goto v___jp_397_;
}
else
{
v___y_398_ = v___x_484_;
goto v___jp_397_;
}
}
else
{
v___y_398_ = v___x_483_;
goto v___jp_397_;
}
}
else
{
v___y_398_ = v___x_482_;
goto v___jp_397_;
}
}
else
{
v___y_398_ = v___x_481_;
goto v___jp_397_;
}
}
else
{
v___y_398_ = v___x_480_;
goto v___jp_397_;
}
}
else
{
v___y_398_ = v___x_479_;
goto v___jp_397_;
}
}
else
{
v___y_398_ = v___x_476_;
goto v___jp_397_;
}
}
else
{
v___y_398_ = v___x_474_;
goto v___jp_397_;
}
}
else
{
v___y_398_ = v___x_469_;
goto v___jp_397_;
}
}
else
{
v___y_398_ = v___x_468_;
goto v___jp_397_;
}
}
else
{
v___y_398_ = v___x_467_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_464_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_461_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_460_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_457_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_456_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_453_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_452_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_449_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_447_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_446_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_444_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_443_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_441_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_439_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_437_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_431_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_430_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_428_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_426_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_424_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_418_;
goto v___jp_397_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v___y_398_ = v___x_414_;
goto v___jp_397_;
}
v___jp_397_:
{
if (lean_obj_tag(v___y_398_) == 0)
{
lean_object* v___x_399_; 
lean_dec_ref_known(v___y_398_, 1);
v___x_399_ = vastitas_storage_close(v_a_396_);
lean_dec(v_a_396_);
if (lean_obj_tag(v___x_399_) == 0)
{
lean_object* v___x_400_; 
lean_dec_ref_known(v___x_399_, 1);
v___x_400_ = bench_report_lean();
return v___x_400_;
}
else
{
return v___x_399_;
}
}
else
{
lean_object* v_a_401_; lean_object* v___x_402_; 
v_a_401_ = lean_ctor_get(v___y_398_, 0);
lean_inc(v_a_401_);
lean_dec_ref_known(v___y_398_, 1);
v___x_402_ = vastitas_storage_close(v_a_396_);
lean_dec(v_a_396_);
if (lean_obj_tag(v___x_402_) == 0)
{
lean_object* v___x_404_; uint8_t v_isShared_405_; uint8_t v_isSharedCheck_409_; 
v_isSharedCheck_409_ = !lean_is_exclusive(v___x_402_);
if (v_isSharedCheck_409_ == 0)
{
lean_object* v_unused_410_; 
v_unused_410_ = lean_ctor_get(v___x_402_, 0);
lean_dec(v_unused_410_);
v___x_404_ = v___x_402_;
v_isShared_405_ = v_isSharedCheck_409_;
goto v_resetjp_403_;
}
else
{
lean_dec(v___x_402_);
v___x_404_ = lean_box(0);
v_isShared_405_ = v_isSharedCheck_409_;
goto v_resetjp_403_;
}
v_resetjp_403_:
{
lean_object* v___x_407_; 
if (v_isShared_405_ == 0)
{
lean_ctor_set_tag(v___x_404_, 1);
lean_ctor_set(v___x_404_, 0, v_a_401_);
v___x_407_ = v___x_404_;
goto v_reusejp_406_;
}
else
{
lean_object* v_reuseFailAlloc_408_; 
v_reuseFailAlloc_408_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_408_, 0, v_a_401_);
v___x_407_ = v_reuseFailAlloc_408_;
goto v_reusejp_406_;
}
v_reusejp_406_:
{
return v___x_407_;
}
}
}
else
{
lean_dec(v_a_401_);
return v___x_402_;
}
}
}
}
else
{
lean_object* v_a_486_; lean_object* v___x_488_; uint8_t v_isShared_489_; uint8_t v_isSharedCheck_493_; 
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
v_a_486_ = lean_ctor_get(v___x_395_, 0);
v_isSharedCheck_493_ = !lean_is_exclusive(v___x_395_);
if (v_isSharedCheck_493_ == 0)
{
v___x_488_ = v___x_395_;
v_isShared_489_ = v_isSharedCheck_493_;
goto v_resetjp_487_;
}
else
{
lean_inc(v_a_486_);
lean_dec(v___x_395_);
v___x_488_ = lean_box(0);
v_isShared_489_ = v_isSharedCheck_493_;
goto v_resetjp_487_;
}
v_resetjp_487_:
{
lean_object* v___x_491_; 
if (v_isShared_489_ == 0)
{
v___x_491_ = v___x_488_;
goto v_reusejp_490_;
}
else
{
lean_object* v_reuseFailAlloc_492_; 
v_reuseFailAlloc_492_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_492_, 0, v_a_486_);
v___x_491_ = v_reuseFailAlloc_492_;
goto v_reusejp_490_;
}
v_reusejp_490_:
{
return v___x_491_;
}
}
}
}
else
{
uint32_t v___x_494_; uint64_t v___x_495_; lean_object* v___x_496_; 
lean_dec(v_scope_374_);
v___x_494_ = 0;
v___x_495_ = lean_uint64_of_nat(v_reps_379_);
v___x_496_ = bench_begin_lean(v___x_494_, v___x_495_, v_verify_383_);
if (lean_obj_tag(v___x_496_) == 0)
{
lean_object* v___x_497_; lean_object* v___x_498_; lean_object* v___x_499_; 
lean_dec_ref_known(v___x_496_, 1);
v___x_497_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_497_, 0, v___x_368_);
lean_ctor_set(v___x_497_, 1, v_reps_379_);
lean_ctor_set(v___x_497_, 2, v___x_370_);
v___x_498_ = lean_box(0);
v___x_499_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v___x_497_, v___x_498_, v___x_368_);
lean_dec_ref_known(v___x_497_, 3);
if (lean_obj_tag(v___x_499_) == 0)
{
lean_object* v___x_500_; 
lean_dec_ref_known(v___x_499_, 1);
v___x_500_ = bench_stop_lean();
if (lean_obj_tag(v___x_500_) == 0)
{
lean_object* v___x_501_; 
lean_dec_ref_known(v___x_500_, 1);
v___x_501_ = bench_report_lean();
return v___x_501_;
}
else
{
return v___x_500_;
}
}
else
{
return v___x_499_;
}
}
else
{
lean_dec(v_reps_379_);
return v___x_496_;
}
}
}
else
{
uint32_t v___x_502_; uint64_t v___x_503_; lean_object* v___x_504_; 
v___x_502_ = lean_uint32_of_nat(v_scope_374_);
lean_dec(v_scope_374_);
v___x_503_ = lean_uint64_of_nat(v_reps_379_);
lean_dec(v_reps_379_);
v___x_504_ = bench_c_run_lean(v___x_502_, v___x_503_, v_verify_383_);
if (lean_obj_tag(v___x_504_) == 0)
{
lean_object* v___x_505_; 
lean_dec_ref_known(v___x_504_, 1);
v___x_505_ = bench_report_lean();
return v___x_505_;
}
else
{
return v___x_504_;
}
}
}
else
{
uint32_t v___x_506_; uint64_t v___x_507_; lean_object* v___x_508_; 
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
lean_dec(v_impl_369_);
v___x_506_ = 0;
v___x_507_ = 1ULL;
v___x_508_ = bench_begin_lean(v___x_506_, v___x_507_, v___x_390_);
if (lean_obj_tag(v___x_508_) == 0)
{
lean_object* v___x_509_; 
lean_dec_ref_known(v___x_508_, 1);
v___x_509_ = lp_allocation__audit_generatedFailure();
if (lean_obj_tag(v___x_509_) == 0)
{
lean_object* v___x_511_; uint8_t v_isShared_512_; uint8_t v_isSharedCheck_517_; 
v_isSharedCheck_517_ = !lean_is_exclusive(v___x_509_);
if (v_isSharedCheck_517_ == 0)
{
lean_object* v_unused_518_; 
v_unused_518_ = lean_ctor_get(v___x_509_, 0);
lean_dec(v_unused_518_);
v___x_511_ = v___x_509_;
v_isShared_512_ = v_isSharedCheck_517_;
goto v_resetjp_510_;
}
else
{
lean_dec(v___x_509_);
v___x_511_ = lean_box(0);
v_isShared_512_ = v_isSharedCheck_517_;
goto v_resetjp_510_;
}
v_resetjp_510_:
{
lean_object* v___x_513_; lean_object* v___x_515_; 
v___x_513_ = ((lean_object*)(lp_allocation__audit_main___closed__5));
if (v_isShared_512_ == 0)
{
lean_ctor_set_tag(v___x_511_, 1);
lean_ctor_set(v___x_511_, 0, v___x_513_);
v___x_515_ = v___x_511_;
goto v_reusejp_514_;
}
else
{
lean_object* v_reuseFailAlloc_516_; 
v_reuseFailAlloc_516_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_516_, 0, v___x_513_);
v___x_515_ = v_reuseFailAlloc_516_;
goto v_reusejp_514_;
}
v_reusejp_514_:
{
return v___x_515_;
}
}
}
else
{
lean_object* v_a_519_; lean_object* v___x_520_; lean_object* v___x_521_; uint8_t v___x_522_; 
v_a_519_ = lean_ctor_get(v___x_509_, 0);
lean_inc(v_a_519_);
v___x_520_ = lean_io_error_to_string(v_a_519_);
v___x_521_ = ((lean_object*)(lp_allocation__audit_main___closed__6));
v___x_522_ = lean_string_dec_eq(v___x_520_, v___x_521_);
lean_dec_ref(v___x_520_);
if (v___x_522_ == 0)
{
return v___x_509_;
}
else
{
lean_object* v___x_523_; 
lean_dec_ref_known(v___x_509_, 1);
v___x_523_ = bench_stop_lean();
if (lean_obj_tag(v___x_523_) == 0)
{
lean_object* v___x_524_; 
lean_dec_ref_known(v___x_523_, 1);
v___x_524_ = bench_report_lean();
return v___x_524_;
}
else
{
return v___x_523_;
}
}
}
}
else
{
return v___x_508_;
}
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
lean_dec(v_impl_369_);
return v___x_388_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
lean_dec(v_impl_369_);
return v___x_386_;
}
}
else
{
lean_dec(v_reps_379_);
lean_dec(v_scope_374_);
lean_dec(v_impl_369_);
return v___x_385_;
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object* v_args_525_, lean_object* v_a_526_){
_start:
{
lean_object* v_res_527_; 
v_res_527_ = _lean_main(v_args_525_);
return v_res_527_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object* v_a_528_, lean_object* v_scope_529_, lean_object* v_range_530_, lean_object* v_b_531_, lean_object* v_i_532_, lean_object* v_hs_533_, lean_object* v_hl_534_){
_start:
{
lean_object* v___x_536_; 
v___x_536_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_528_, v_scope_529_, v_range_530_, v_b_531_, v_i_532_);
return v___x_536_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object* v_a_537_, lean_object* v_scope_538_, lean_object* v_range_539_, lean_object* v_b_540_, lean_object* v_i_541_, lean_object* v_hs_542_, lean_object* v_hl_543_, lean_object* v___y_544_){
_start:
{
lean_object* v_res_545_; 
v_res_545_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(v_a_537_, v_scope_538_, v_range_539_, v_b_540_, v_i_541_, v_hs_542_, v_hl_543_);
lean_dec_ref(v_range_539_);
lean_dec(v_scope_538_);
lean_dec(v_a_537_);
return v_res_545_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object* v_range_546_, lean_object* v_b_547_, lean_object* v_i_548_, lean_object* v_hs_549_, lean_object* v_hl_550_){
_start:
{
lean_object* v___x_552_; 
v___x_552_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_546_, v_b_547_, v_i_548_);
return v___x_552_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object* v_range_553_, lean_object* v_b_554_, lean_object* v_i_555_, lean_object* v_hs_556_, lean_object* v_hl_557_, lean_object* v___y_558_){
_start:
{
lean_object* v_res_559_; 
v_res_559_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(v_range_553_, v_b_554_, v_i_555_, v_hs_556_, v_hl_557_);
lean_dec_ref(v_range_553_);
return v_res_559_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_vastitas__storage__native_VastitasStorageNative(uint8_t builtin);
lean_object* initialize_vastitas__gemm__native_VastitasGemmNative(uint8_t builtin);
lean_object* initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_allocation__audit_Main(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__storage__native_VastitasStorageNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__gemm__native_VastitasGemmNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_allocation__audit_VastitasGenerated_f__0 = _init_lp_allocation__audit_VastitasGenerated_f__0();
lean_mark_persistent(lp_allocation__audit_VastitasGenerated_f__0);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_allocation__audit_Main(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = 0;
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
