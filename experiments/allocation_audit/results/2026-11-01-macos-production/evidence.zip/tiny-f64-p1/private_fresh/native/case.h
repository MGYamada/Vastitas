/* Fixture data independently constructed from cases.json. */
static const unsigned scalar = 0;
static const uint64_t dim_i=2, dim_k=3, dim_j=4, dim_a=5;
static const VStorageLayout views[7] = {{8,2,12,4,0},{16,3,5,6,0},{24,4,6,8,0},{32,8,3,13,0},{40,8,5,14,0},{48,10,6,17,0},{56,10,4,18,0}};
static const uint64_t elements[6] = {52,35,54,82,78,111};
static const double values[3][2] = {{0x1.0000000000000p-3,0x0.0p+0},{-0x1.0000000000000p-2,0x0.0p+0},{0x1.0000000000000p-1,-0x0.0p+0}};
static const double sentinel[2] = {-0x1.c000000000000p+2,0x0.0p+0};
static const double alpha[2] = {1,0}, beta[2] = {0,0};
typedef struct { uint64_t row, col; double value[2]; } Patch;
static const Patch patches[3][2] = {{{0,0,{0x1.0000000000000p+0,-0x0.0p+0}},{1,1,{-0x1.0000000000000p-1,0x0.0p+0}}},{{0,4,{0x1.0000000000000p-1,0x0.0p+0}},{2,0,{-0x1.8000000000000p-1,-0x0.0p+0}}},{{3,0,{-0x1.0000000000000p-2,0x0.0p+0}},{0,5,{0x1.8000000000000p-1,-0x0.0p+0}}}};
static const Patch expected[3] = {{0,0,{-0x1.3800000000000p-2,0x0.0p+0}},{1,5,{-0x1.e000000000000p-3,0x0.0p+0}},{9,0,{0x1.4000000000000p-4,0x0.0p+0}}};
