#!/opt/homebrew/opt/python@3.15/bin/python3.15
import json, pathlib, sys
pathlib.Path('/private/tmp/vastitas-production-unit-final/tiny-f64-p1/private_fresh/package/wire.json').write_text(sys.stdin.read())
print(json.dumps({"version":8,"ok":False,"diagnostics":[{"code":"E_CAPTURED","message":"capture only"}]}))
sys.exit(1)
