// Lean compiler output
// Module: Main
// Imports: public import Init public meta import Init
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* lean_task_get_own(lean_object*);
lean_object* lean_io_error_to_string(lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
lean_object* l_List_range(lean_object*);
lean_object* l_List_reverse___redArg(lean_object*);
lean_object* lean_io_as_task(lean_object*, lean_object*);
lean_object* allocation_test_unit();
LEAN_EXPORT lean_object* lp_persistent__thread__test_sharedUnit___boxed(lean_object*);
lean_object* allocation_test_gate();
LEAN_EXPORT lean_object* lp_persistent__thread__test_gate___boxed(lean_object*);
lean_object* allocation_test_error();
LEAN_EXPORT lean_object* lp_persistent__thread__test_expectedError___boxed(lean_object*);
lean_object* allocation_test_validate(uint32_t);
LEAN_EXPORT lean_object* lp_persistent__thread__test_validate___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_persistent__thread__test___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_persistent__thread__test___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_ctor_object lp_persistent__thread__test_List_mapM_loop___at___00main_spec__1___lam__0___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*3 + 0, .m_other = 3, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(1000) << 1) | 1)),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* lp_persistent__thread__test_List_mapM_loop___at___00main_spec__1___lam__0___closed__0 = (const lean_object*)&lp_persistent__thread__test_List_mapM_loop___at___00main_spec__1___lam__0___closed__0_value;
LEAN_EXPORT lean_object* lp_persistent__thread__test_List_mapM_loop___at___00main_spec__1___lam__0();
LEAN_EXPORT lean_object* lp_persistent__thread__test_List_mapM_loop___at___00main_spec__1___lam__0___boxed(lean_object*);
static const lean_closure_object lp_persistent__thread__test_List_mapM_loop___at___00main_spec__1___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_persistent__thread__test_List_mapM_loop___at___00main_spec__1___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_persistent__thread__test_List_mapM_loop___at___00main_spec__1___closed__0 = (const lean_object*)&lp_persistent__thread__test_List_mapM_loop___at___00main_spec__1___closed__0_value;
LEAN_EXPORT lean_object* lp_persistent__thread__test_List_mapM_loop___at___00main_spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_persistent__thread__test_List_mapM_loop___at___00main_spec__1___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_persistent__thread__test_List_forIn_x27_loop___at___00main_spec__2___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_persistent__thread__test_List_forIn_x27_loop___at___00main_spec__2___redArg___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_persistent__thread__test_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 37, .m_capacity = 37, .m_length = 36, .m_data = "persistent experiment expected error"};
static const lean_object* lp_persistent__thread__test_main___closed__0 = (const lean_object*)&lp_persistent__thread__test_main___closed__0_value;
static lean_once_cell_t lp_persistent__thread__test_main___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_persistent__thread__test_main___closed__1;
static const lean_string_object lp_persistent__thread__test_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 24, .m_capacity = 24, .m_length = 23, .m_data = "expected error was lost"};
static const lean_object* lp_persistent__thread__test_main___closed__2 = (const lean_object*)&lp_persistent__thread__test_main___closed__2_value;
static const lean_ctor_object lp_persistent__thread__test_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_persistent__thread__test_main___closed__2_value)}};
static const lean_object* lp_persistent__thread__test_main___closed__3 = (const lean_object*)&lp_persistent__thread__test_main___closed__3_value;
LEAN_EXPORT lean_object* _lean_main();
LEAN_EXPORT lean_object* lp_persistent__thread__test_main___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_persistent__thread__test___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_persistent__thread__test___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_persistent__thread__test_List_forIn_x27_loop___at___00main_spec__2(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_persistent__thread__test_List_forIn_x27_loop___at___00main_spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_persistent__thread__test_sharedUnit___boxed(lean_object* v_a_00___x40___internal___hyg_2_){
_start:
{
lean_object* v_res_3_; 
v_res_3_ = allocation_test_unit();
return v_res_3_;
}
}
LEAN_EXPORT lean_object* lp_persistent__thread__test_gate___boxed(lean_object* v_a_00___x40___internal___hyg_5_){
_start:
{
lean_object* v_res_6_; 
v_res_6_ = allocation_test_gate();
return v_res_6_;
}
}
LEAN_EXPORT lean_object* lp_persistent__thread__test_expectedError___boxed(lean_object* v_a_00___x40___internal___hyg_8_){
_start:
{
lean_object* v_res_9_; 
v_res_9_ = allocation_test_error();
return v_res_9_;
}
}
LEAN_EXPORT lean_object* lp_persistent__thread__test_validate___boxed(lean_object* v_expected_12_, lean_object* v_a_00___x40___internal___hyg_13_){
_start:
{
uint32_t v_expected_boxed_14_; lean_object* v_res_15_; 
v_expected_boxed_14_ = lean_unbox_uint32(v_expected_12_);
lean_dec(v_expected_12_);
v_res_15_ = allocation_test_validate(v_expected_boxed_14_);
return v_res_15_;
}
}
LEAN_EXPORT lean_object* lp_persistent__thread__test___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object* v_range_16_, lean_object* v_b_17_, lean_object* v_i_18_){
_start:
{
lean_object* v_stop_20_; lean_object* v_step_21_; uint8_t v___x_22_; 
v_stop_20_ = lean_ctor_get(v_range_16_, 1);
v_step_21_ = lean_ctor_get(v_range_16_, 2);
v___x_22_ = lean_nat_dec_lt(v_i_18_, v_stop_20_);
if (v___x_22_ == 0)
{
lean_object* v___x_23_; 
lean_dec(v_i_18_);
v___x_23_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_23_, 0, v_b_17_);
return v___x_23_;
}
else
{
lean_object* v___x_24_; lean_object* v___x_25_; 
v___x_24_ = lean_box(0);
v___x_25_ = allocation_test_unit();
if (lean_obj_tag(v___x_25_) == 0)
{
lean_object* v___x_26_; 
lean_dec_ref_known(v___x_25_, 1);
v___x_26_ = lean_nat_add(v_i_18_, v_step_21_);
lean_dec(v_i_18_);
v_b_17_ = v___x_24_;
v_i_18_ = v___x_26_;
goto _start;
}
else
{
lean_dec(v_i_18_);
return v___x_25_;
}
}
}
}
LEAN_EXPORT lean_object* lp_persistent__thread__test___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object* v_range_28_, lean_object* v_b_29_, lean_object* v_i_30_, lean_object* v___y_31_){
_start:
{
lean_object* v_res_32_; 
v_res_32_ = lp_persistent__thread__test___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_range_28_, v_b_29_, v_i_30_);
lean_dec_ref(v_range_28_);
return v_res_32_;
}
}
LEAN_EXPORT lean_object* lp_persistent__thread__test_List_mapM_loop___at___00main_spec__1___lam__0(){
_start:
{
lean_object* v_a_39_; lean_object* v___y_42_; lean_object* v___x_52_; 
v___x_52_ = allocation_test_gate();
if (lean_obj_tag(v___x_52_) == 0)
{
lean_object* v___x_53_; lean_object* v___x_54_; lean_object* v___x_55_; lean_object* v___x_56_; 
lean_dec_ref_known(v___x_52_, 1);
v___x_53_ = lean_unsigned_to_nat(0u);
v___x_54_ = ((lean_object*)(lp_persistent__thread__test_List_mapM_loop___at___00main_spec__1___lam__0___closed__0));
v___x_55_ = lean_box(0);
v___x_56_ = lp_persistent__thread__test___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v___x_54_, v___x_55_, v___x_53_);
if (lean_obj_tag(v___x_56_) == 0)
{
lean_dec_ref_known(v___x_56_, 1);
v_a_39_ = v___x_55_;
goto v___jp_38_;
}
else
{
v___y_42_ = v___x_56_;
goto v___jp_41_;
}
}
else
{
v___y_42_ = v___x_52_;
goto v___jp_41_;
}
v___jp_38_:
{
lean_object* v___x_40_; 
v___x_40_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_40_, 0, v_a_39_);
return v___x_40_;
}
v___jp_41_:
{
if (lean_obj_tag(v___y_42_) == 0)
{
lean_object* v_a_43_; 
v_a_43_ = lean_ctor_get(v___y_42_, 0);
lean_inc(v_a_43_);
lean_dec_ref_known(v___y_42_, 1);
v_a_39_ = v_a_43_;
goto v___jp_38_;
}
else
{
lean_object* v_a_44_; lean_object* v___x_46_; uint8_t v_isShared_47_; uint8_t v_isSharedCheck_51_; 
v_a_44_ = lean_ctor_get(v___y_42_, 0);
v_isSharedCheck_51_ = !lean_is_exclusive(v___y_42_);
if (v_isSharedCheck_51_ == 0)
{
v___x_46_ = v___y_42_;
v_isShared_47_ = v_isSharedCheck_51_;
goto v_resetjp_45_;
}
else
{
lean_inc(v_a_44_);
lean_dec(v___y_42_);
v___x_46_ = lean_box(0);
v_isShared_47_ = v_isSharedCheck_51_;
goto v_resetjp_45_;
}
v_resetjp_45_:
{
lean_object* v___x_49_; 
if (v_isShared_47_ == 0)
{
lean_ctor_set_tag(v___x_46_, 0);
v___x_49_ = v___x_46_;
goto v_reusejp_48_;
}
else
{
lean_object* v_reuseFailAlloc_50_; 
v_reuseFailAlloc_50_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_50_, 0, v_a_44_);
v___x_49_ = v_reuseFailAlloc_50_;
goto v_reusejp_48_;
}
v_reusejp_48_:
{
return v___x_49_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_persistent__thread__test_List_mapM_loop___at___00main_spec__1___lam__0___boxed(lean_object* v___y_57_){
_start:
{
lean_object* v_res_58_; 
v_res_58_ = lp_persistent__thread__test_List_mapM_loop___at___00main_spec__1___lam__0();
return v_res_58_;
}
}
LEAN_EXPORT lean_object* lp_persistent__thread__test_List_mapM_loop___at___00main_spec__1(lean_object* v_x_60_, lean_object* v_x_61_){
_start:
{
if (lean_obj_tag(v_x_60_) == 0)
{
lean_object* v___x_63_; lean_object* v___x_64_; 
v___x_63_ = l_List_reverse___redArg(v_x_61_);
v___x_64_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_64_, 0, v___x_63_);
return v___x_64_;
}
else
{
lean_object* v_tail_65_; lean_object* v___x_67_; uint8_t v_isShared_68_; uint8_t v_isSharedCheck_76_; 
v_tail_65_ = lean_ctor_get(v_x_60_, 1);
v_isSharedCheck_76_ = !lean_is_exclusive(v_x_60_);
if (v_isSharedCheck_76_ == 0)
{
lean_object* v_unused_77_; 
v_unused_77_ = lean_ctor_get(v_x_60_, 0);
lean_dec(v_unused_77_);
v___x_67_ = v_x_60_;
v_isShared_68_ = v_isSharedCheck_76_;
goto v_resetjp_66_;
}
else
{
lean_inc(v_tail_65_);
lean_dec(v_x_60_);
v___x_67_ = lean_box(0);
v_isShared_68_ = v_isSharedCheck_76_;
goto v_resetjp_66_;
}
v_resetjp_66_:
{
lean_object* v___f_69_; lean_object* v___x_70_; lean_object* v___x_71_; lean_object* v___x_73_; 
v___f_69_ = ((lean_object*)(lp_persistent__thread__test_List_mapM_loop___at___00main_spec__1___closed__0));
v___x_70_ = lean_unsigned_to_nat(9u);
v___x_71_ = lean_io_as_task(v___f_69_, v___x_70_);
if (v_isShared_68_ == 0)
{
lean_ctor_set(v___x_67_, 1, v_x_61_);
lean_ctor_set(v___x_67_, 0, v___x_71_);
v___x_73_ = v___x_67_;
goto v_reusejp_72_;
}
else
{
lean_object* v_reuseFailAlloc_75_; 
v_reuseFailAlloc_75_ = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(v_reuseFailAlloc_75_, 0, v___x_71_);
lean_ctor_set(v_reuseFailAlloc_75_, 1, v_x_61_);
v___x_73_ = v_reuseFailAlloc_75_;
goto v_reusejp_72_;
}
v_reusejp_72_:
{
v_x_60_ = v_tail_65_;
v_x_61_ = v___x_73_;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_persistent__thread__test_List_mapM_loop___at___00main_spec__1___boxed(lean_object* v_x_78_, lean_object* v_x_79_, lean_object* v___y_80_){
_start:
{
lean_object* v_res_81_; 
v_res_81_ = lp_persistent__thread__test_List_mapM_loop___at___00main_spec__1(v_x_78_, v_x_79_);
return v_res_81_;
}
}
LEAN_EXPORT lean_object* lp_persistent__thread__test_List_forIn_x27_loop___at___00main_spec__2___redArg(lean_object* v_as_x27_82_, lean_object* v_b_83_){
_start:
{
if (lean_obj_tag(v_as_x27_82_) == 0)
{
lean_object* v___x_85_; 
v___x_85_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_85_, 0, v_b_83_);
return v___x_85_;
}
else
{
lean_object* v_head_86_; lean_object* v_tail_87_; lean_object* v___x_88_; 
v_head_86_ = lean_ctor_get(v_as_x27_82_, 0);
v_tail_87_ = lean_ctor_get(v_as_x27_82_, 1);
lean_inc(v_head_86_);
v___x_88_ = lean_task_get_own(v_head_86_);
if (lean_obj_tag(v___x_88_) == 0)
{
lean_object* v_a_89_; lean_object* v___x_91_; uint8_t v_isShared_92_; uint8_t v_isSharedCheck_96_; 
v_a_89_ = lean_ctor_get(v___x_88_, 0);
v_isSharedCheck_96_ = !lean_is_exclusive(v___x_88_);
if (v_isSharedCheck_96_ == 0)
{
v___x_91_ = v___x_88_;
v_isShared_92_ = v_isSharedCheck_96_;
goto v_resetjp_90_;
}
else
{
lean_inc(v_a_89_);
lean_dec(v___x_88_);
v___x_91_ = lean_box(0);
v_isShared_92_ = v_isSharedCheck_96_;
goto v_resetjp_90_;
}
v_resetjp_90_:
{
lean_object* v___x_94_; 
if (v_isShared_92_ == 0)
{
lean_ctor_set_tag(v___x_91_, 1);
v___x_94_ = v___x_91_;
goto v_reusejp_93_;
}
else
{
lean_object* v_reuseFailAlloc_95_; 
v_reuseFailAlloc_95_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_95_, 0, v_a_89_);
v___x_94_ = v_reuseFailAlloc_95_;
goto v_reusejp_93_;
}
v_reusejp_93_:
{
return v___x_94_;
}
}
}
else
{
lean_object* v___x_97_; 
lean_dec_ref_known(v___x_88_, 1);
v___x_97_ = lean_box(0);
v_as_x27_82_ = v_tail_87_;
v_b_83_ = v___x_97_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_persistent__thread__test_List_forIn_x27_loop___at___00main_spec__2___redArg___boxed(lean_object* v_as_x27_99_, lean_object* v_b_100_, lean_object* v___y_101_){
_start:
{
lean_object* v_res_102_; 
v_res_102_ = lp_persistent__thread__test_List_forIn_x27_loop___at___00main_spec__2___redArg(v_as_x27_99_, v_b_100_);
lean_dec(v_as_x27_99_);
return v_res_102_;
}
}
static lean_object* _init_lp_persistent__thread__test_main___closed__1(void){
_start:
{
lean_object* v___x_104_; lean_object* v___x_105_; 
v___x_104_ = lean_unsigned_to_nat(8u);
v___x_105_ = l_List_range(v___x_104_);
return v___x_105_;
}
}
LEAN_EXPORT lean_object* _lean_main(){
_start:
{
lean_object* v_a_111_; lean_object* v___x_118_; lean_object* v___x_119_; lean_object* v___x_120_; lean_object* v_a_121_; lean_object* v___x_122_; lean_object* v___x_123_; 
v___x_118_ = lean_obj_once(&lp_persistent__thread__test_main___closed__1, &lp_persistent__thread__test_main___closed__1_once, _init_lp_persistent__thread__test_main___closed__1);
v___x_119_ = lean_box(0);
v___x_120_ = lp_persistent__thread__test_List_mapM_loop___at___00main_spec__1(v___x_118_, v___x_119_);
v_a_121_ = lean_ctor_get(v___x_120_, 0);
lean_inc(v_a_121_);
lean_dec_ref(v___x_120_);
v___x_122_ = lean_box(0);
v___x_123_ = lp_persistent__thread__test_List_forIn_x27_loop___at___00main_spec__2___redArg(v_a_121_, v___x_122_);
lean_dec(v_a_121_);
if (lean_obj_tag(v___x_123_) == 0)
{
lean_object* v_r_124_; 
lean_dec_ref_known(v___x_123_, 1);
v_r_124_ = allocation_test_error();
if (lean_obj_tag(v_r_124_) == 0)
{
lean_object* v___x_125_; 
lean_dec_ref_known(v_r_124_, 1);
v___x_125_ = allocation_test_unit();
if (lean_obj_tag(v___x_125_) == 0)
{
lean_object* v___x_127_; uint8_t v_isShared_128_; uint8_t v_isSharedCheck_133_; 
v_isSharedCheck_133_ = !lean_is_exclusive(v___x_125_);
if (v_isSharedCheck_133_ == 0)
{
lean_object* v_unused_134_; 
v_unused_134_ = lean_ctor_get(v___x_125_, 0);
lean_dec(v_unused_134_);
v___x_127_ = v___x_125_;
v_isShared_128_ = v_isSharedCheck_133_;
goto v_resetjp_126_;
}
else
{
lean_dec(v___x_125_);
v___x_127_ = lean_box(0);
v_isShared_128_ = v_isSharedCheck_133_;
goto v_resetjp_126_;
}
v_resetjp_126_:
{
lean_object* v___x_129_; lean_object* v___x_131_; 
v___x_129_ = ((lean_object*)(lp_persistent__thread__test_main___closed__3));
if (v_isShared_128_ == 0)
{
lean_ctor_set_tag(v___x_127_, 1);
lean_ctor_set(v___x_127_, 0, v___x_129_);
v___x_131_ = v___x_127_;
goto v_reusejp_130_;
}
else
{
lean_object* v_reuseFailAlloc_132_; 
v_reuseFailAlloc_132_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_132_, 0, v___x_129_);
v___x_131_ = v_reuseFailAlloc_132_;
goto v_reusejp_130_;
}
v_reusejp_130_:
{
return v___x_131_;
}
}
}
else
{
lean_object* v_a_135_; 
v_a_135_ = lean_ctor_get(v___x_125_, 0);
lean_inc(v_a_135_);
lean_dec_ref_known(v___x_125_, 1);
v_a_111_ = v_a_135_;
goto v___jp_110_;
}
}
else
{
lean_object* v_a_136_; lean_object* v___x_137_; 
v_a_136_ = lean_ctor_get(v_r_124_, 0);
lean_inc(v_a_136_);
lean_dec_ref_known(v_r_124_, 1);
v___x_137_ = allocation_test_unit();
if (lean_obj_tag(v___x_137_) == 0)
{
lean_dec_ref_known(v___x_137_, 1);
v_a_111_ = v_a_136_;
goto v___jp_110_;
}
else
{
lean_object* v_a_138_; 
lean_dec(v_a_136_);
v_a_138_ = lean_ctor_get(v___x_137_, 0);
lean_inc(v_a_138_);
lean_dec_ref_known(v___x_137_, 1);
v_a_111_ = v_a_138_;
goto v___jp_110_;
}
}
}
else
{
return v___x_123_;
}
v___jp_110_:
{
lean_object* v___x_112_; lean_object* v___x_113_; uint8_t v___x_114_; 
lean_inc(v_a_111_);
v___x_112_ = lean_io_error_to_string(v_a_111_);
v___x_113_ = ((lean_object*)(lp_persistent__thread__test_main___closed__0));
v___x_114_ = lean_string_dec_eq(v___x_112_, v___x_113_);
lean_dec_ref(v___x_112_);
if (v___x_114_ == 0)
{
lean_object* v___x_115_; 
v___x_115_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_115_, 0, v_a_111_);
return v___x_115_;
}
else
{
uint32_t v___x_116_; lean_object* v___x_117_; 
lean_dec(v_a_111_);
v___x_116_ = 8001;
v___x_117_ = allocation_test_validate(v___x_116_);
return v___x_117_;
}
}
}
}
LEAN_EXPORT lean_object* lp_persistent__thread__test_main___boxed(lean_object* v_a_139_){
_start:
{
lean_object* v_res_140_; 
v_res_140_ = _lean_main();
return v_res_140_;
}
}
LEAN_EXPORT lean_object* lp_persistent__thread__test___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object* v_range_141_, lean_object* v_b_142_, lean_object* v_i_143_, lean_object* v_hs_144_, lean_object* v_hl_145_){
_start:
{
lean_object* v___x_147_; 
v___x_147_ = lp_persistent__thread__test___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_range_141_, v_b_142_, v_i_143_);
return v___x_147_;
}
}
LEAN_EXPORT lean_object* lp_persistent__thread__test___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object* v_range_148_, lean_object* v_b_149_, lean_object* v_i_150_, lean_object* v_hs_151_, lean_object* v_hl_152_, lean_object* v___y_153_){
_start:
{
lean_object* v_res_154_; 
v_res_154_ = lp_persistent__thread__test___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(v_range_148_, v_b_149_, v_i_150_, v_hs_151_, v_hl_152_);
lean_dec_ref(v_range_148_);
return v_res_154_;
}
}
LEAN_EXPORT lean_object* lp_persistent__thread__test_List_forIn_x27_loop___at___00main_spec__2(lean_object* v_as_155_, lean_object* v_as_x27_156_, lean_object* v_b_157_, lean_object* v_a_158_){
_start:
{
lean_object* v___x_160_; 
v___x_160_ = lp_persistent__thread__test_List_forIn_x27_loop___at___00main_spec__2___redArg(v_as_x27_156_, v_b_157_);
return v___x_160_;
}
}
LEAN_EXPORT lean_object* lp_persistent__thread__test_List_forIn_x27_loop___at___00main_spec__2___boxed(lean_object* v_as_161_, lean_object* v_as_x27_162_, lean_object* v_b_163_, lean_object* v_a_164_, lean_object* v___y_165_){
_start:
{
lean_object* v_res_166_; 
v_res_166_ = lp_persistent__thread__test_List_forIn_x27_loop___at___00main_spec__2(v_as_161_, v_as_x27_162_, v_b_163_, v_a_164_);
lean_dec(v_as_x27_162_);
lean_dec(v_as_161_);
return v_res_166_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_persistent__thread__test_Main(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    return _lean_main();
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_persistent__thread__test_Main(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = 0;
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
