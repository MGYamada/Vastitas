@[extern "allocation_test_unit"] opaque sharedUnit : IO Unit
@[extern "allocation_test_gate"] opaque gate : IO Unit
@[extern "allocation_test_error"] opaque expectedError : IO Unit
@[extern "allocation_test_validate"] opaque validate (expected : UInt32) : IO Unit
def main : IO Unit := do
  let tasks ← (List.range 8).mapM fun _ => IO.asTask (do
    gate
    for _ in [:1000] do sharedUnit) Task.Priority.dedicated
  for task in tasks do
    match task.get with
    | .ok _ => pure ()
    | .error error => throw error
  let caught ← try
    try expectedError finally sharedUnit
    pure false
  catch error =>
    if error.toString != "persistent experiment expected error" then throw error
    pure true
  if !caught then throw (IO.userError "expected error was lost")
  validate 8001
