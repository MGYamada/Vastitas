import Lake
open Lake DSL System
package persistent_thread_test where
  moreLinkArgs := #["-fno-lto", "-L", "/Users/masa/.elan/toolchains/leanprover--lean4---v4.35.0/lib"]
input_file persistentSource where path := "persistent.c"
target persistentObject pkg : FilePath := do
  let source ← persistentSource.fetch
  buildLeanO (pkg.buildDir / "persistent.o") source #[] #["-std=c11", "-O3", "-fno-lto", "-Wall", "-Wextra", "-Werror"]
extern_lib persistentNative pkg := do
  buildStaticLib (pkg.staticLibDir / nameToStaticLib "persistent_native") #[← persistentObject.fetch]
lean_exe test where
  root := `Main
