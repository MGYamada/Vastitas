/* Fixture data independently constructed from cases.json. */
static const unsigned scalar = 0;
static const uint64_t dim_i=7, dim_k=17, dim_j=5, dim_a=11;
static const VStorageLayout views[7] = {{8,7,85,9,0},{16,17,11,20,0},{24,5,13,9,0},{32,35,17,40,0},{40,35,11,41,0},{48,77,13,84,0},{56,77,5,85,0}};
static const uint64_t elements[6] = {769,225,123,687,459,1101};
static const double values[3][2] = {{0x1.0000000000000p-3,0x0.0p+0},{-0x1.0000000000000p-2,0x0.0p+0},{0x1.0000000000000p-1,-0x0.0p+0}};
static const double sentinel[2] = {-0x1.c000000000000p+2,0x0.0p+0};
static const double alpha[2] = {1,0}, beta[2] = {0,0};
typedef struct { uint64_t row, col; double value[2]; } Patch;
static const Patch patches[3][2] = {{{0,0,{0x1.0000000000000p+0,-0x0.0p+0}},{6,1,{-0x1.0000000000000p-1,0x0.0p+0}}},{{0,10,{0x1.0000000000000p-1,0x0.0p+0}},{16,0,{-0x1.8000000000000p-1,-0x0.0p+0}}},{{4,0,{-0x1.0000000000000p-2,0x0.0p+0}},{0,12,{0x1.8000000000000p-1,-0x0.0p+0}}}};
static const Patch expected[3] = {{0,0,{-0x1.2600000000000p+0,0x0.0p+0}},{6,12,{-0x1.8400000000000p+0,0x0.0p+0}},{76,0,{-0x1.6000000000000p-1,0x0.0p+0}}};
