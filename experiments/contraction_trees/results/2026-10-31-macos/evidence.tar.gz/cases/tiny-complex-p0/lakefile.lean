import Lake
open Lake DSL
package tree_benchmark where
  moreLinkArgs := #["-fno-lto", "-L", "/Users/masa/.elan/toolchains/leanprover--lean4---v4.35.0/lib"]
require vastitas_kernel from "/private/tmp/vastitas-contraction-trees/lean-kernel"
require vastitas_gemm_native from "./numerical" with
  NameMap.empty.insert `openblas "/private/tmp/vastitas-openblas-verified"
lean_exe bench where
  root := `Main
  moreLeancArgs := #["-O3", "-fno-lto"]
