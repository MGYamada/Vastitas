#!/usr/bin/python3
import json, pathlib, sys
pathlib.Path('/home/runner/work/_temp/contraction-tree-results/cases/bulk-complex-p1/package/wire.json').write_text(sys.stdin.read())
print(json.dumps({"version":8,"ok":False,"diagnostics":[{"code":"E_CAPTURED","message":"capture only"}]}))
sys.exit(1)
