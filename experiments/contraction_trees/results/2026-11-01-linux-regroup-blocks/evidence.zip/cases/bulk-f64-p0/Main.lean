import VastitasStorageNative
import VastitasGemmNative
import VastitasKernel.IndexedRuntime

set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
set_option linter.unusedVariables false

namespace VastitasGenerated

def f_0 : Int :=
  (0 : Int)

end VastitasGenerated

open VastitasStorageNative


@[extern "bench_begin_lean"] opaque benchBegin (scope : UInt32) (reps : UInt64) (verify : Bool) : IO Unit
@[extern "bench_stop_lean"] opaque benchStop : IO Unit
@[extern "bench_report_lean"] opaque benchReport : IO Unit
@[extern "bench_c_run_lean"] opaque benchCRun (scope : UInt32) (reps : UInt64) (verify : Bool) : IO Unit
@[extern "bench_verify_lean"] opaque benchVerify (arena : @& Arena) (reps : UInt64) : IO Unit

@[noinline] def generatedOnce : IO Unit := do
  let arena ← newArena 9223372036854775807
  try
    allocate arena 0 0 30720
    fill arena 0 0 30720 1 30720 false 0 13842939354630062080 0
    fill arena 0 0 24 1280 24 false 0 4593671619917905920 0
    store arena 0 0 24 1280 24 false 0 0 0 4607182418800017408 0
    store arena 0 0 24 1280 24 false 23 1 0 13826050856027422720 0
    allocate arena 1 0 1920
    fill arena 1 0 1920 1 1920 false 0 13842939354630062080 0
    fill arena 1 0 40 48 40 false 0 13821547256400052224 0
    store arena 1 0 40 48 40 false 0 47 0 4602678819172646912 0
    store arena 1 0 40 48 40 false 39 0 0 13828302655841107968 0
    allocate arena 2 0 1792
    fill arena 2 0 1792 1 1792 false 0 13842939354630062080 0
    fill arena 2 0 32 56 32 false 0 4602678819172646912 0
    store arena 2 0 32 56 32 false 31 0 0 13821547256400052224 0
    store arena 2 0 32 56 32 false 0 55 0 4604930618986332160 0
    allocate arena 3 0 36864
    fill arena 3 0 36864 1 36864 false 0 13842939354630062080 0
    allocate arena 4 0 36864
    fill arena 4 0 36864 1 36864 false 0 13842939354630062080 0
    allocate arena 5 0 64512
    fill arena 5 0 64512 1 64512 false 0 13842939354630062080 0
    pack3 arena 0 0 24 1280 24 false 3 0 768 40 768 false 24 40 32
    VastitasGemmNative.gemm arena 3 0 768 40 768 false false 1 0 40 48 40 false false 4 0 768 48 768 false 0
    regroup3 arena 4 0 768 48 768 false 3 0 1152 32 1152 false 24 32 48 48 42
    VastitasGemmNative.gemm arena 3 0 1152 32 1152 false false 2 0 32 56 32 false false 5 0 1152 56 1152 false 0
    expect arena 5 0 1152 56 1152 false 0 0 0 13849729938443206656 0
    expect arena 5 0 1152 56 1152 false 23 55 0 13850035602675728384 0
    expect arena 5 0 1152 56 1152 false 1151 0 0 13849006459792130048 0
    drop arena 5
    drop arena 4
    drop arena 3
    drop arena 2
    drop arena 1
    drop arena 0
    pure ()
  finally
    close arena

def main (args : List String) : IO Unit := do
  let impl := args[0]!
  let scope := args[1]!.toNat!
  let reps := args[2]!.toNat!
  let verify := args[3]! == "1"
  generatedOnce
  if impl == "c" then
    benchCRun scope.toUInt32 reps.toUInt64 verify
  else if scope == 0 then
    benchBegin 0 reps.toUInt64 verify
    for _ in [:reps] do generatedOnce
    benchStop
  else
    let arena ← newArena 9223372036854775807
    try
      allocate arena 0 0 30720
      fill arena 0 0 30720 1 30720 false 0 13842939354630062080 0
      fill arena 0 0 24 1280 24 false 0 4593671619917905920 0
      store arena 0 0 24 1280 24 false 0 0 0 4607182418800017408 0
      store arena 0 0 24 1280 24 false 23 1 0 13826050856027422720 0
      allocate arena 1 0 1920
      fill arena 1 0 1920 1 1920 false 0 13842939354630062080 0
      fill arena 1 0 40 48 40 false 0 13821547256400052224 0
      store arena 1 0 40 48 40 false 0 47 0 4602678819172646912 0
      store arena 1 0 40 48 40 false 39 0 0 13828302655841107968 0
      allocate arena 2 0 1792
      fill arena 2 0 1792 1 1792 false 0 13842939354630062080 0
      fill arena 2 0 32 56 32 false 0 4602678819172646912 0
      store arena 2 0 32 56 32 false 31 0 0 13821547256400052224 0
      store arena 2 0 32 56 32 false 0 55 0 4604930618986332160 0
      allocate arena 3 0 36864
      fill arena 3 0 36864 1 36864 false 0 13842939354630062080 0
      allocate arena 4 0 36864
      fill arena 4 0 36864 1 36864 false 0 13842939354630062080 0
      allocate arena 5 0 64512
      fill arena 5 0 64512 1 64512 false 0 13842939354630062080 0
      benchBegin scope.toUInt32 reps.toUInt64 verify
      for _ in [:reps] do
        pack3 arena 0 0 24 1280 24 false 3 0 768 40 768 false 24 40 32
        VastitasGemmNative.gemm arena 3 0 768 40 768 false false 1 0 40 48 40 false false 4 0 768 48 768 false 0
        regroup3 arena 4 0 768 48 768 false 3 0 1152 32 1152 false 24 32 48 48 42
        VastitasGemmNative.gemm arena 3 0 1152 32 1152 false false 2 0 32 56 32 false false 5 0 1152 56 1152 false 0
      benchStop
      benchVerify arena reps.toUInt64
      expect arena 5 0 1152 56 1152 false 0 0 0 13849729938443206656 0
      expect arena 5 0 1152 56 1152 false 23 55 0 13850035602675728384 0
      expect arena 5 0 1152 56 1152 false 1151 0 0 13849006459792130048 0
      drop arena 5
      drop arena 4
      drop arena 3
      drop arena 2
      drop arena 1
      drop arena 0
    finally
      close arena
  benchReport
