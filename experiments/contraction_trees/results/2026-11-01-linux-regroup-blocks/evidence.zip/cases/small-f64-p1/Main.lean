import VastitasStorageNative
import VastitasGemmNative
import VastitasKernel.IndexedRuntime

set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
set_option linter.unusedVariables false

namespace VastitasGenerated

def f_0 : Int :=
  (0 : Int)

end VastitasGenerated

open VastitasStorageNative


@[extern "bench_begin_lean"] opaque benchBegin (scope : UInt32) (reps : UInt64) (verify : Bool) : IO Unit
@[extern "bench_stop_lean"] opaque benchStop : IO Unit
@[extern "bench_report_lean"] opaque benchReport : IO Unit
@[extern "bench_c_run_lean"] opaque benchCRun (scope : UInt32) (reps : UInt64) (verify : Bool) : IO Unit
@[extern "bench_verify_lean"] opaque benchVerify (arena : @& Arena) (reps : UInt64) : IO Unit

@[noinline] def generatedOnce : IO Unit := do
  let arena ← newArena 9223372036854775807
  try
    allocate arena 0 0 769
    fill arena 0 0 769 1 769 false 0 13842939354630062080 0
    fill arena 0 8 7 85 9 false 0 4593671619917905920 0
    store arena 0 8 7 85 9 false 0 0 0 4607182418800017408 0
    store arena 0 8 7 85 9 false 6 1 0 13826050856027422720 0
    allocate arena 1 0 225
    fill arena 1 0 225 1 225 false 0 13842939354630062080 0
    fill arena 1 16 17 11 20 false 0 13821547256400052224 0
    store arena 1 16 17 11 20 false 0 10 0 4602678819172646912 0
    store arena 1 16 17 11 20 false 16 0 0 13828302655841107968 0
    allocate arena 2 0 123
    fill arena 2 0 123 1 123 false 0 13842939354630062080 0
    fill arena 2 24 5 13 9 false 0 4602678819172646912 0
    store arena 2 24 5 13 9 false 4 0 0 13821547256400052224 0
    store arena 2 24 5 13 9 false 0 12 0 4604930618986332160 0
    allocate arena 3 0 687
    fill arena 3 0 687 1 687 false 0 13842939354630062080 0
    allocate arena 4 0 459
    fill arena 4 0 459 1 459 false 0 13842939354630062080 0
    allocate arena 5 0 1101
    fill arena 5 0 1101 1 1101 false 0 13842939354630062080 0
    pack3 arena 0 8 7 85 9 false 3 32 35 17 40 false 7 17 5
    VastitasGemmNative.gemm arena 3 32 35 17 40 false false 1 16 17 11 20 false false 4 40 35 11 41 false 0
    regroup3 arena 4 40 35 11 41 false 3 56 77 5 85 false 7 5 11 48 42
    VastitasGemmNative.gemm arena 3 56 77 5 85 false false 2 24 5 13 9 false false 5 48 77 13 84 false 0
    expect arena 5 48 77 13 84 false 0 0 0 13831222958724481024 0
    expect arena 5 48 77 13 84 false 6 12 0 13832876624212656128 0
    expect arena 5 48 77 13 84 false 76 0 0 13827739705887686656 0
    drop arena 5
    drop arena 4
    drop arena 3
    drop arena 2
    drop arena 1
    drop arena 0
    pure ()
  finally
    close arena

def main (args : List String) : IO Unit := do
  let impl := args[0]!
  let scope := args[1]!.toNat!
  let reps := args[2]!.toNat!
  let verify := args[3]! == "1"
  generatedOnce
  if impl == "c" then
    benchCRun scope.toUInt32 reps.toUInt64 verify
  else if scope == 0 then
    benchBegin 0 reps.toUInt64 verify
    for _ in [:reps] do generatedOnce
    benchStop
  else
    let arena ← newArena 9223372036854775807
    try
      allocate arena 0 0 769
      fill arena 0 0 769 1 769 false 0 13842939354630062080 0
      fill arena 0 8 7 85 9 false 0 4593671619917905920 0
      store arena 0 8 7 85 9 false 0 0 0 4607182418800017408 0
      store arena 0 8 7 85 9 false 6 1 0 13826050856027422720 0
      allocate arena 1 0 225
      fill arena 1 0 225 1 225 false 0 13842939354630062080 0
      fill arena 1 16 17 11 20 false 0 13821547256400052224 0
      store arena 1 16 17 11 20 false 0 10 0 4602678819172646912 0
      store arena 1 16 17 11 20 false 16 0 0 13828302655841107968 0
      allocate arena 2 0 123
      fill arena 2 0 123 1 123 false 0 13842939354630062080 0
      fill arena 2 24 5 13 9 false 0 4602678819172646912 0
      store arena 2 24 5 13 9 false 4 0 0 13821547256400052224 0
      store arena 2 24 5 13 9 false 0 12 0 4604930618986332160 0
      allocate arena 3 0 687
      fill arena 3 0 687 1 687 false 0 13842939354630062080 0
      allocate arena 4 0 459
      fill arena 4 0 459 1 459 false 0 13842939354630062080 0
      allocate arena 5 0 1101
      fill arena 5 0 1101 1 1101 false 0 13842939354630062080 0
      benchBegin scope.toUInt32 reps.toUInt64 verify
      for _ in [:reps] do
        pack3 arena 0 8 7 85 9 false 3 32 35 17 40 false 7 17 5
        VastitasGemmNative.gemm arena 3 32 35 17 40 false false 1 16 17 11 20 false false 4 40 35 11 41 false 0
        regroup3 arena 4 40 35 11 41 false 3 56 77 5 85 false 7 5 11 48 42
        VastitasGemmNative.gemm arena 3 56 77 5 85 false false 2 24 5 13 9 false false 5 48 77 13 84 false 0
      benchStop
      benchVerify arena reps.toUInt64
      expect arena 5 48 77 13 84 false 0 0 0 13831222958724481024 0
      expect arena 5 48 77 13 84 false 6 12 0 13832876624212656128 0
      expect arena 5 48 77 13 84 false 76 0 0 13827739705887686656 0
      drop arena 5
      drop arena 4
      drop arena 3
      drop arena 2
      drop arena 1
      drop arena 0
    finally
      close arena
  benchReport
