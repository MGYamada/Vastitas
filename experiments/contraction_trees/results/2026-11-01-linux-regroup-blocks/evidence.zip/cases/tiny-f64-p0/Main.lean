import VastitasStorageNative
import VastitasGemmNative
import VastitasKernel.IndexedRuntime

set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
set_option linter.unusedVariables false

namespace VastitasGenerated

def f_0 : Int :=
  (0 : Int)

end VastitasGenerated

open VastitasStorageNative


@[extern "bench_begin_lean"] opaque benchBegin (scope : UInt32) (reps : UInt64) (verify : Bool) : IO Unit
@[extern "bench_stop_lean"] opaque benchStop : IO Unit
@[extern "bench_report_lean"] opaque benchReport : IO Unit
@[extern "bench_c_run_lean"] opaque benchCRun (scope : UInt32) (reps : UInt64) (verify : Bool) : IO Unit
@[extern "bench_verify_lean"] opaque benchVerify (arena : @& Arena) (reps : UInt64) : IO Unit

@[noinline] def generatedOnce : IO Unit := do
  let arena ← newArena 9223372036854775807
  try
    allocate arena 0 0 24
    fill arena 0 0 24 1 24 false 0 13842939354630062080 0
    fill arena 0 0 2 12 2 false 0 4593671619917905920 0
    store arena 0 0 2 12 2 false 0 0 0 4607182418800017408 0
    store arena 0 0 2 12 2 false 1 1 0 13826050856027422720 0
    allocate arena 1 0 15
    fill arena 1 0 15 1 15 false 0 13842939354630062080 0
    fill arena 1 0 3 5 3 false 0 13821547256400052224 0
    store arena 1 0 3 5 3 false 0 4 0 4602678819172646912 0
    store arena 1 0 3 5 3 false 2 0 0 13828302655841107968 0
    allocate arena 2 0 24
    fill arena 2 0 24 1 24 false 0 13842939354630062080 0
    fill arena 2 0 4 6 4 false 0 4602678819172646912 0
    store arena 2 0 4 6 4 false 3 0 0 13821547256400052224 0
    store arena 2 0 4 6 4 false 0 5 0 4604930618986332160 0
    allocate arena 3 0 40
    fill arena 3 0 40 1 40 false 0 13842939354630062080 0
    allocate arena 4 0 40
    fill arena 4 0 40 1 40 false 0 13842939354630062080 0
    allocate arena 5 0 60
    fill arena 5 0 60 1 60 false 0 13842939354630062080 0
    pack3 arena 0 0 2 12 2 false 3 0 8 3 8 false 2 3 4
    VastitasGemmNative.gemm arena 3 0 8 3 8 false false 1 0 3 5 3 false false 4 0 8 5 8 false 0
    regroup3 arena 4 0 8 5 8 false 3 0 10 4 10 false 2 4 5 48 42
    VastitasGemmNative.gemm arena 3 0 10 4 10 false false 2 0 4 6 4 false false 5 0 10 6 10 false 0
    expect arena 5 0 10 6 10 false 0 0 0 13822532418818539520 0
    expect arena 5 0 10 6 10 false 1 5 0 13820984306446630912 0
    expect arena 5 0 10 6 10 false 9 0 0 4590293920197378048 0
    drop arena 5
    drop arena 4
    drop arena 3
    drop arena 2
    drop arena 1
    drop arena 0
    pure ()
  finally
    close arena

def main (args : List String) : IO Unit := do
  let impl := args[0]!
  let scope := args[1]!.toNat!
  let reps := args[2]!.toNat!
  let verify := args[3]! == "1"
  generatedOnce
  if impl == "c" then
    benchCRun scope.toUInt32 reps.toUInt64 verify
  else if scope == 0 then
    benchBegin 0 reps.toUInt64 verify
    for _ in [:reps] do generatedOnce
    benchStop
  else
    let arena ← newArena 9223372036854775807
    try
      allocate arena 0 0 24
      fill arena 0 0 24 1 24 false 0 13842939354630062080 0
      fill arena 0 0 2 12 2 false 0 4593671619917905920 0
      store arena 0 0 2 12 2 false 0 0 0 4607182418800017408 0
      store arena 0 0 2 12 2 false 1 1 0 13826050856027422720 0
      allocate arena 1 0 15
      fill arena 1 0 15 1 15 false 0 13842939354630062080 0
      fill arena 1 0 3 5 3 false 0 13821547256400052224 0
      store arena 1 0 3 5 3 false 0 4 0 4602678819172646912 0
      store arena 1 0 3 5 3 false 2 0 0 13828302655841107968 0
      allocate arena 2 0 24
      fill arena 2 0 24 1 24 false 0 13842939354630062080 0
      fill arena 2 0 4 6 4 false 0 4602678819172646912 0
      store arena 2 0 4 6 4 false 3 0 0 13821547256400052224 0
      store arena 2 0 4 6 4 false 0 5 0 4604930618986332160 0
      allocate arena 3 0 40
      fill arena 3 0 40 1 40 false 0 13842939354630062080 0
      allocate arena 4 0 40
      fill arena 4 0 40 1 40 false 0 13842939354630062080 0
      allocate arena 5 0 60
      fill arena 5 0 60 1 60 false 0 13842939354630062080 0
      benchBegin scope.toUInt32 reps.toUInt64 verify
      for _ in [:reps] do
        pack3 arena 0 0 2 12 2 false 3 0 8 3 8 false 2 3 4
        VastitasGemmNative.gemm arena 3 0 8 3 8 false false 1 0 3 5 3 false false 4 0 8 5 8 false 0
        regroup3 arena 4 0 8 5 8 false 3 0 10 4 10 false 2 4 5 48 42
        VastitasGemmNative.gemm arena 3 0 10 4 10 false false 2 0 4 6 4 false false 5 0 10 6 10 false 0
      benchStop
      benchVerify arena reps.toUInt64
      expect arena 5 0 10 6 10 false 0 0 0 13822532418818539520 0
      expect arena 5 0 10 6 10 false 1 5 0 13820984306446630912 0
      expect arena 5 0 10 6 10 false 9 0 0 4590293920197378048 0
      drop arena 5
      drop arena 4
      drop arena 3
      drop arena 2
      drop arena 1
      drop arena 0
    finally
      close arena
  benchReport
