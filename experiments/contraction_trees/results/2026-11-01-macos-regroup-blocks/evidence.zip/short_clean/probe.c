
#define _POSIX_C_SOURCE 200809L
#include "storage.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <time.h>
VStorageArena *old_vstorage_new(uint64_t);
VStorageStatus old_vstorage_allocate(VStorageArena *,uint32_t,uint8_t,uint64_t);
VStorageStatus old_vstorage_fill(VStorageArena *,uint32_t,VStorageLayout,uint8_t,uint64_t,uint64_t);
VStorageStatus old_vstorage_expect(VStorageArena *,uint32_t,VStorageLayout,uint64_t,uint64_t,uint8_t,uint64_t,uint64_t);
VStorageStatus old_vstorage_regroup3(VStorageArena *,uint32_t,VStorageLayout,uint32_t,VStorageLayout,uint64_t,uint64_t,uint64_t,uint64_t,uint64_t);
VStorageStats old_vstorage_stats(const VStorageArena *);
void old_vstorage_delete(VStorageArena *);
typedef struct {
 VStorageArena *(*new_arena)(uint64_t);
 VStorageStatus (*allocate)(VStorageArena *,uint32_t,uint8_t,uint64_t);
 VStorageStatus (*fill)(VStorageArena *,uint32_t,VStorageLayout,uint8_t,uint64_t,uint64_t);
 VStorageStatus (*expect)(VStorageArena *,uint32_t,VStorageLayout,uint64_t,uint64_t,uint8_t,uint64_t,uint64_t);
 VStorageStatus (*regroup)(VStorageArena *,uint32_t,VStorageLayout,uint32_t,VStorageLayout,uint64_t,uint64_t,uint64_t,uint64_t,uint64_t);
 VStorageStats (*stats)(const VStorageArena *);
 void (*delete_arena)(VStorageArena *);
} Ops;
static const Ops ops[2]={
 {old_vstorage_new,old_vstorage_allocate,old_vstorage_fill,old_vstorage_expect,old_vstorage_regroup3,old_vstorage_stats,old_vstorage_delete},
 {vstorage_new,vstorage_allocate,vstorage_fill,vstorage_expect,vstorage_regroup3,vstorage_stats,vstorage_delete}};
static uint64_t now(void) {struct timespec t;assert(clock_gettime(CLOCK_MONOTONIC,&t)==0);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
static uint64_t batch(unsigned side,VStorageArena *arena,VStorageLayout src,VStorageLayout dst,const uint64_t d[3],uint8_t scalar,uint64_t n) {
 VStorageStats before=ops[side].stats(arena);
 uint64_t start=now();
 for (uint64_t i=0;i<n;++i) assert(ops[side].regroup(arena,0,src,1,dst,d[0],d[1],d[2],48,42)==VS_OK);
 uint64_t elapsed=now()-start;
 VStorageStats after=ops[side].stats(arena);
 uint64_t bytes=n*d[0]*d[1]*d[2]*(scalar?16:8);
 assert(after.copied_bytes-before.copied_bytes==bytes && after.written_bytes-before.written_bytes==bytes);
 assert(before.data_allocations==after.data_allocations && before.live_bytes==after.live_bytes);
 assert(ops[side].expect(arena,1,dst,0,0,scalar,UINT64_C(0x3ff0000000000000),UINT64_C(0x8000000000000000))==VS_OK);
 assert(ops[side].expect(arena,1,dst,dst.rows-1,dst.columns-1,scalar,UINT64_C(0x3ff0000000000000),UINT64_C(0x8000000000000000))==VS_OK);
 return elapsed;
}
int main(void) {
 const uint64_t dims[][3]={{2,4,5},{7,5,11},{24,32,48}};
 const char *sizes[]={"tiny","small","bulk"};
 puts("size,scalar,padding,phase,pair,order,implementation,repetitions,elapsed_ns");
 for(unsigned s=0;s<3;++s)for(uint8_t scalar=0;scalar<=1;++scalar)for(unsigned pad=0;pad<=1;++pad){
  const uint64_t *d=dims[s];uint64_t width=scalar?16:8;
  VStorageLayout src={width,d[0]*d[1],d[2],d[0]*d[1]+2*pad,0},dst={3*width,d[0]*d[2],d[1],d[0]*d[2]+3*pad,0};
  VStorageArena *arena[2];
  for(unsigned side=0;side<2;++side){
   arena[side]=ops[side].new_arena(INT64_MAX);assert(arena[side]);
   assert(ops[side].allocate(arena[side],0,scalar,1+src.leading*src.columns)==VS_OK);
   assert(ops[side].allocate(arena[side],1,scalar,3+dst.leading*dst.columns)==VS_OK);
   assert(ops[side].fill(arena[side],0,src,scalar,UINT64_C(0x3ff0000000000000),UINT64_C(0x8000000000000000))==VS_OK);
   assert(ops[side].fill(arena[side],1,dst,scalar,0,0)==VS_OK);
  }
  uint64_t reps=1;unsigned calibration=0;
  for(;;){
   uint64_t minimum=UINT64_MAX;
   for(unsigned order=0;order<2;++order){unsigned side=(calibration+order)%2;uint64_t t=batch(side,arena[side],src,dst,d,scalar,reps);if(t<minimum)minimum=t;
    printf("%s,%u,%u,calibration,%u,%u,%s,%llu,%llu\n",sizes[s],scalar,pad,calibration,order,side?"new":"old",(unsigned long long)reps,(unsigned long long)t);}
   if(minimum>=8000000 || reps>=1000000)break;
   uint64_t next=reps*2;if(next>1000000)next=1000000;reps=next;++calibration;
  }
  for(unsigned pair=0;pair<11;++pair)for(unsigned order=0;order<2;++order){unsigned side=(pair+order+s+scalar+pad)%2;uint64_t t=batch(side,arena[side],src,dst,d,scalar,reps);
   printf("%s,%u,%u,measurement,%u,%u,%s,%llu,%llu\n",sizes[s],scalar,pad,pair,order,side?"new":"old",(unsigned long long)reps,(unsigned long long)t);}
  for(unsigned side=0;side<2;++side)ops[side].delete_arena(arena[side]);
 }
 return 0;
}
