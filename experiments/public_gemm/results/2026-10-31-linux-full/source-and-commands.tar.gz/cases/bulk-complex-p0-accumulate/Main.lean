import VastitasStorageNative
import VastitasGemmNative
import VastitasKernel.IndexedRuntime

set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
set_option linter.unusedVariables false

namespace VastitasGenerated

def f_0 : Int :=
  (0 : Int)

end VastitasGenerated

open VastitasStorageNative


@[extern "bench_begin_lean"] opaque benchBegin (scope : UInt32) (reps : UInt64) (verify : Bool) : IO Unit
@[extern "bench_stop_lean"] opaque benchStop : IO Unit
@[extern "bench_report_lean"] opaque benchReport : IO Unit
@[extern "bench_c_run_lean"] opaque benchCRun (scope : UInt32) (reps : UInt64) (verify : Bool) : IO Unit
@[extern "bench_verify_lean"] opaque benchVerify (arena : @& Arena) (reps : UInt64) : IO Unit

@[noinline] def generatedOnce : IO Unit := do
  let arena ← newArena 9223372036854775807
  try
    allocate arena 0 1 98304
    fill arena 0 0 98304 1 98304 false 1 13842939354630062080 4613937818241073152
    fill arena 0 0 384 256 384 false 1 4593671619917905920 4598175219545276416
    store arena 0 0 384 256 384 false 0 0 1 4607182418800017408 13826050856027422720
    store arena 0 0 384 256 384 false 383 255 1 13826050856027422720 4604930618986332160
    allocate arena 1 1 81920
    fill arena 1 0 81920 1 81920 false 1 13842939354630062080 4613937818241073152
    fill arena 1 0 256 320 256 false 1 13821547256400052224 4593671619917905920
    store arena 1 0 256 320 256 false 0 319 1 4602678819172646912 4598175219545276416
    store arena 1 0 256 320 256 false 255 0 1 13828302655841107968 13826050856027422720
    allocate arena 2 1 122880
    fill arena 2 0 122880 1 122880 false 1 13842939354630062080 4613937818241073152
    fill arena 2 0 384 320 384 false 1 4604930618986332160 13817043656772681728
    VastitasGemmNative.gemmScaled arena 0 0 384 256 384 false false 1 0 256 320 256 false false 2 0 384 320 384 false 1 1 1 4604930618986332160 13826050856027422720 0 0 1 1 4602678819172646912 4598175219545276416 0 0
    drop arena 2
    drop arena 1
    drop arena 0
    pure ()
  finally
    close arena

def main (args : List String) : IO Unit := do
  let impl := args[0]!
  let scope := args[1]!.toNat!
  let reps := args[2]!.toNat!
  let verify := args[3]! == "1"
  -- Identical untimed backend/Lean warmup in every fresh process, on both sides.
  generatedOnce
  if impl == "c" then
    benchCRun scope.toUInt32 reps.toUInt64 verify
  else if scope == 0 then
    benchBegin 0 reps.toUInt64 verify
    for _ in [:reps] do generatedOnce
    benchStop
  else
    let arena ← newArena 9223372036854775807
    try
      allocate arena 0 1 98304
      fill arena 0 0 98304 1 98304 false 1 13842939354630062080 4613937818241073152
      fill arena 0 0 384 256 384 false 1 4593671619917905920 4598175219545276416
      store arena 0 0 384 256 384 false 0 0 1 4607182418800017408 13826050856027422720
      store arena 0 0 384 256 384 false 383 255 1 13826050856027422720 4604930618986332160
      allocate arena 1 1 81920
      fill arena 1 0 81920 1 81920 false 1 13842939354630062080 4613937818241073152
      fill arena 1 0 256 320 256 false 1 13821547256400052224 4593671619917905920
      store arena 1 0 256 320 256 false 0 319 1 4602678819172646912 4598175219545276416
      store arena 1 0 256 320 256 false 255 0 1 13828302655841107968 13826050856027422720
      allocate arena 2 1 122880
      fill arena 2 0 122880 1 122880 false 1 13842939354630062080 4613937818241073152
      fill arena 2 0 384 320 384 false 1 4604930618986332160 13817043656772681728
      benchBegin scope.toUInt32 reps.toUInt64 verify
      for _ in [:reps] do
        VastitasGemmNative.gemmScaled arena 0 0 384 256 384 false false 1 0 256 320 256 false false 2 0 384 320 384 false 1 1 1 4604930618986332160 13826050856027422720 0 0 1 1 4602678819172646912 4598175219545276416 0 0
      benchStop
      benchVerify arena reps.toUInt64
      drop arena 2
      drop arena 1
      drop arena 0
    finally
      close arena
  benchReport
