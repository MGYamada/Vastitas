import VastitasStorageNative
import VastitasGemmNative
import VastitasKernel.IndexedRuntime

set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
set_option linter.unusedVariables false

namespace VastitasGenerated

def f_0 : Int :=
  (0 : Int)

end VastitasGenerated

open VastitasStorageNative

def main : IO Unit := do
  let arena ← newArena 9223372036854775807
  try
    allocate arena 0 1 98820
    fill arena 0 0 98820 1 98820 false 1 13842939354630062080 4613937818241073152
    fill arena 0 16 384 256 386 false 1 4593671619917905920 4598175219545276416
    store arena 0 16 384 256 386 false 0 0 1 4607182418800017408 13826050856027422720
    store arena 0 16 384 256 386 false 383 255 1 13826050856027422720 4604930618986332160
    allocate arena 1 1 82885
    fill arena 1 0 82885 1 82885 false 1 13842939354630062080 4613937818241073152
    fill arena 1 32 256 320 259 false 1 13821547256400052224 4593671619917905920
    store arena 1 32 256 320 259 false 0 319 1 4602678819172646912 4598175219545276416
    store arena 1 32 256 320 259 false 255 0 1 13828302655841107968 13826050856027422720
    allocate arena 2 1 124166
    fill arena 2 0 124166 1 124166 false 1 13842939354630062080 4613937818241073152
    fill arena 2 48 384 320 388 false 1 4604930618986332160 13817043656772681728
    VastitasGemmNative.gemmScaled arena 0 16 384 256 386 false false 1 32 256 320 259 false false 2 48 384 320 388 false 1 1 1 4604930618986332160 13826050856027422720 0 0 1 1 4602678819172646912 4598175219545276416 0 0
    drop arena 2
    drop arena 1
    drop arena 0
    IO.println (VastitasGenerated.f_0)
  finally
    close arena
