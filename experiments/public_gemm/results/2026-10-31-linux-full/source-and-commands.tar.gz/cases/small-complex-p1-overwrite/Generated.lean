import VastitasStorageNative
import VastitasGemmNative
import VastitasKernel.IndexedRuntime

set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
set_option linter.unusedVariables false

namespace VastitasGenerated

def f_0 : Int :=
  (0 : Int)

end VastitasGenerated

open VastitasStorageNative

def main : IO Unit := do
  let arena ← newArena 9223372036854775807
  try
    allocate arena 0 1 365
    fill arena 0 0 365 1 365 false 1 13842939354630062080 4613937818241073152
    fill arena 0 16 17 19 19 false 1 4593671619917905920 4598175219545276416
    store arena 0 16 17 19 19 false 0 0 1 4607182418800017408 13826050856027422720
    store arena 0 16 17 19 19 false 16 18 1 13826050856027422720 4604930618986332160
    allocate arena 1 1 291
    fill arena 1 0 291 1 291 false 1 13842939354630062080 4613937818241073152
    fill arena 1 32 19 13 22 false 1 13821547256400052224 4593671619917905920
    store arena 1 32 19 13 22 false 0 12 1 4602678819172646912 4598175219545276416
    store arena 1 32 19 13 22 false 18 0 1 13828302655841107968 13826050856027422720
    allocate arena 2 1 279
    fill arena 2 0 279 1 279 false 1 13842939354630062080 4613937818241073152
    VastitasGemmNative.gemmScaled arena 0 16 17 19 19 false false 1 32 19 13 22 false false 2 48 17 13 21 false 0 1 1 4604930618986332160 13826050856027422720 0 0 0 0 0 0 0 0
    drop arena 2
    drop arena 1
    drop arena 0
    IO.println (VastitasGenerated.f_0)
  finally
    close arena
