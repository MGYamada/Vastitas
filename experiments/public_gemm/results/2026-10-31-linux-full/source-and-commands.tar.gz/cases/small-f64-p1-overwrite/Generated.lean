import VastitasStorageNative
import VastitasGemmNative
import VastitasKernel.IndexedRuntime

set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
set_option linter.unusedVariables false

namespace VastitasGenerated

def f_0 : Int :=
  (0 : Int)

end VastitasGenerated

open VastitasStorageNative

def main : IO Unit := do
  let arena ← newArena 9223372036854775807
  try
    allocate arena 0 0 365
    fill arena 0 0 365 1 365 false 0 13842939354630062080 0
    fill arena 0 8 17 19 19 false 0 4593671619917905920 0
    store arena 0 8 17 19 19 false 0 0 0 4607182418800017408 0
    store arena 0 8 17 19 19 false 16 18 0 13826050856027422720 0
    allocate arena 1 0 291
    fill arena 1 0 291 1 291 false 0 13842939354630062080 0
    fill arena 1 16 19 13 22 false 0 13821547256400052224 0
    store arena 1 16 19 13 22 false 0 12 0 4602678819172646912 0
    store arena 1 16 19 13 22 false 18 0 0 13828302655841107968 0
    allocate arena 2 0 279
    fill arena 2 0 279 1 279 false 0 13842939354630062080 0
    VastitasGemmNative.gemmScaled arena 0 8 17 19 19 false false 1 16 19 13 22 false false 2 24 17 13 21 false 0 1 0 4609434218613702656 0 0 0 0 0 0 0 0 0
    drop arena 2
    drop arena 1
    drop arena 0
    IO.println (VastitasGenerated.f_0)
  finally
    close arena
