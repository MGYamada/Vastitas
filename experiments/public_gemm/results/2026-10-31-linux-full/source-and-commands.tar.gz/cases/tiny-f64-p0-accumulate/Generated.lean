import VastitasStorageNative
import VastitasGemmNative
import VastitasKernel.IndexedRuntime

set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
set_option linter.unusedVariables false

namespace VastitasGenerated

def f_0 : Int :=
  (0 : Int)

end VastitasGenerated

open VastitasStorageNative

def main : IO Unit := do
  let arena ← newArena 9223372036854775807
  try
    allocate arena 0 0 8
    fill arena 0 0 8 1 8 false 0 13842939354630062080 0
    fill arena 0 0 2 4 2 false 0 4593671619917905920 0
    store arena 0 0 2 4 2 false 0 0 0 4607182418800017408 0
    store arena 0 0 2 4 2 false 1 3 0 13826050856027422720 0
    allocate arena 1 0 12
    fill arena 1 0 12 1 12 false 0 13842939354630062080 0
    fill arena 1 0 4 3 4 false 0 13821547256400052224 0
    store arena 1 0 4 3 4 false 0 2 0 4602678819172646912 0
    store arena 1 0 4 3 4 false 3 0 0 13828302655841107968 0
    allocate arena 2 0 6
    fill arena 2 0 6 1 6 false 0 13842939354630062080 0
    fill arena 2 0 2 3 2 false 0 4604930618986332160 0
    VastitasGemmNative.gemmScaled arena 0 0 2 4 2 false false 1 0 4 3 4 false false 2 0 2 3 2 false 1 1 0 4609434218613702656 0 0 0 1 0 4602678819172646912 0 0 0
    drop arena 2
    drop arena 1
    drop arena 0
    IO.println (VastitasGenerated.f_0)
  finally
    close arena
