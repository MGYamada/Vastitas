import VastitasStorageNative
import VastitasGemmNative
import VastitasKernel.IndexedRuntime

set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
set_option linter.unusedVariables false

namespace VastitasGenerated

def f_1 (v_4 : Nat) (v_5 : Nat) (v_6 : Nat) (v_7 : Nat) : Nat :=
  (v_4 + v_7)

def f_2 (v_8 : Nat) (v_9 : Nat) (v_10 : Nat) (v_11 : Nat) (v_12 : Nat) : Nat :=
  (v_9 + v_11)

def f_3 (v_13 : Nat) (v_14 : Nat) (v_15 : Nat) (v_16 : Nat) (v_17 : Nat) (v_18 : Nat) : Nat :=
  (v_13 + v_16)

def f_4 (v_19 : Nat) (v_20 : Nat) (v_21 : Nat) (v_22 : Nat) (v_23 : Nat) (v_24 : Nat) (v_25 : Nat) : Nat :=
  (v_23 * v_20)

def f_5 (v_26 : Nat) (v_27 : Nat) (v_28 : Nat) (v_29 : Nat) (v_30 : Nat) (v_31 : Nat) (v_32 : Nat) (v_33 : Nat) : Nat :=
  (v_31 * v_28)

def f_6 (v_34 : Nat) (v_35 : Nat) (v_36 : Nat) (v_37 : Nat) (v_38 : Nat) (v_39 : Nat) (v_40 : Nat) (v_41 : Nat) (v_42 : Nat) : Nat :=
  (v_40 * v_36)

def f_8 : Nat :=
  (2 : Nat)

def f_9 (v_53 : Nat) : Nat :=
  (3 : Nat)

def f_10 (v_54 : Nat) (v_55 : Nat) : Nat :=
  (4 : Nat)

def f_11 (v_56 : Nat) (v_57 : Nat) (v_58 : Nat) : Nat :=
  (0 : Nat)

def f_12 (v_59 : Nat) (v_60 : Nat) (v_61 : Nat) (v_62 : Nat) : Int :=
  (0 : Int)

end VastitasGenerated

open VastitasStorageNative


@[extern "shape_begin"] opaque benchBegin (scope : UInt32) (reps : UInt64) (verify : Bool) : IO Unit
@[extern "shape_stop"] opaque benchStop : IO Unit
@[extern "shape_report"] opaque benchReport : IO Unit
@[extern "shape_config"] opaque benchConfig (m k n pad : UInt64) : IO Unit
@[extern "shape_guard"] opaque benchGuard : IO Unit
@[extern "shape_narrow"] opaque benchNarrow : IO Unit
@[extern "shape_verify"] opaque benchVerify (arena : @& Arena) : IO Unit
@[extern "shape_c_run"] opaque benchC (scope : UInt32) (reps : UInt64) (verify : Bool) : IO Unit

@[noinline] def generatedOnce (m k n pad : Nat) : IO Unit := do
  let shapeArena ← newArena 9223372036854775807
  try
    let resourceValue_0 := m
    let resourceValue_1 := k
    let resourceValue_2 := n
    let resourceValue_3 := pad
    let resourceValue_8 := VastitasGenerated.f_1 resourceValue_0 resourceValue_1 resourceValue_2 resourceValue_3
    let resourceValue_9 := VastitasGenerated.f_2 resourceValue_0 resourceValue_1 resourceValue_2 resourceValue_3 resourceValue_8
    let resourceValue_10 := VastitasGenerated.f_3 resourceValue_0 resourceValue_1 resourceValue_2 resourceValue_3 resourceValue_8 resourceValue_9
    let resourceValue_11 := VastitasGenerated.f_4 resourceValue_0 resourceValue_1 resourceValue_2 resourceValue_3 resourceValue_8 resourceValue_9 resourceValue_10
    let resourceValue_12 := VastitasGenerated.f_5 resourceValue_0 resourceValue_1 resourceValue_2 resourceValue_3 resourceValue_8 resourceValue_9 resourceValue_10 resourceValue_11
    let resourceValue_13 := VastitasGenerated.f_6 resourceValue_0 resourceValue_1 resourceValue_2 resourceValue_3 resourceValue_8 resourceValue_9 resourceValue_10 resourceValue_11 resourceValue_12
    benchNarrow
    let runtimeExtent_0 ← runtimeExtentNat resourceValue_0
    benchGuard
    unless (runtimeExtent_0 : UInt64) ≤ 2147483647 do
      throw (IO.userError "E_RUNTIME_GUARD: extent, layout or shape preflight failed")
    benchNarrow
    let runtimeExtent_1 ← runtimeExtentNat resourceValue_1
    benchGuard
    unless (runtimeExtent_1 : UInt64) ≤ 2147483647 do
      throw (IO.userError "E_RUNTIME_GUARD: extent, layout or shape preflight failed")
    benchNarrow
    let runtimeExtent_2 ← runtimeExtentNat resourceValue_2
    benchGuard
    unless (runtimeExtent_2 : UInt64) ≤ 2147483647 do
      throw (IO.userError "E_RUNTIME_GUARD: extent, layout or shape preflight failed")
    benchNarrow
    let runtimeExtent_11 ← runtimeExtentNat resourceValue_11
    benchNarrow
    let runtimeExtent_8 ← runtimeExtentNat resourceValue_8
    benchGuard
    unless runtimeLayoutValid 1 runtimeExtent_11 runtimeExtent_0 runtimeExtent_1 runtimeExtent_8 do
      throw (IO.userError "E_RUNTIME_GUARD: extent, layout or shape preflight failed")
    allocate shapeArena 0 1 runtimeExtent_11
    benchNarrow
    let runtimeExtent_12 ← runtimeExtentNat resourceValue_12
    benchNarrow
    let runtimeExtent_9 ← runtimeExtentNat resourceValue_9
    benchGuard
    unless runtimeLayoutValid 1 runtimeExtent_12 runtimeExtent_1 runtimeExtent_2 runtimeExtent_9 do
      throw (IO.userError "E_RUNTIME_GUARD: extent, layout or shape preflight failed")
    allocate shapeArena 1 1 runtimeExtent_12
    benchNarrow
    let runtimeExtent_13 ← runtimeExtentNat resourceValue_13
    benchNarrow
    let runtimeExtent_10 ← runtimeExtentNat resourceValue_10
    benchGuard
    unless runtimeLayoutValid 1 runtimeExtent_13 runtimeExtent_0 runtimeExtent_2 runtimeExtent_10 do
      throw (IO.userError "E_RUNTIME_GUARD: extent, layout or shape preflight failed")
    allocate shapeArena 2 1 runtimeExtent_13
    fill shapeArena 0 0 runtimeExtent_0 runtimeExtent_1 runtimeExtent_8 false 1 4607182418800017408 4607182418800017408
    fill shapeArena 1 0 runtimeExtent_1 runtimeExtent_2 runtimeExtent_9 false 1 4611686018427387904 13830554455654793216
    VastitasGemmNative.gemm shapeArena 0 0 runtimeExtent_0 runtimeExtent_1 runtimeExtent_8 false false 1 0 runtimeExtent_1 runtimeExtent_2 runtimeExtent_9 false false 2 0 runtimeExtent_0 runtimeExtent_2 runtimeExtent_10 false 0
    VastitasGemmNative.gemm shapeArena 0 0 runtimeExtent_0 runtimeExtent_1 runtimeExtent_8 false false 1 0 runtimeExtent_1 runtimeExtent_2 runtimeExtent_9 false false 2 0 runtimeExtent_0 runtimeExtent_2 runtimeExtent_10 false 0
    benchVerify shapeArena
    drop shapeArena 0
    drop shapeArena 1
    drop shapeArena 2
  finally
    close shapeArena

@[noinline] def generatedReuse (m k n pad reps : Nat) (verify : Bool) : IO Unit := do
  let shapeArena ← newArena 9223372036854775807
  try
    let resourceValue_0 := m
    let resourceValue_1 := k
    let resourceValue_2 := n
    let resourceValue_3 := pad
    let resourceValue_8 := VastitasGenerated.f_1 resourceValue_0 resourceValue_1 resourceValue_2 resourceValue_3
    let resourceValue_9 := VastitasGenerated.f_2 resourceValue_0 resourceValue_1 resourceValue_2 resourceValue_3 resourceValue_8
    let resourceValue_10 := VastitasGenerated.f_3 resourceValue_0 resourceValue_1 resourceValue_2 resourceValue_3 resourceValue_8 resourceValue_9
    let resourceValue_11 := VastitasGenerated.f_4 resourceValue_0 resourceValue_1 resourceValue_2 resourceValue_3 resourceValue_8 resourceValue_9 resourceValue_10
    let resourceValue_12 := VastitasGenerated.f_5 resourceValue_0 resourceValue_1 resourceValue_2 resourceValue_3 resourceValue_8 resourceValue_9 resourceValue_10 resourceValue_11
    let resourceValue_13 := VastitasGenerated.f_6 resourceValue_0 resourceValue_1 resourceValue_2 resourceValue_3 resourceValue_8 resourceValue_9 resourceValue_10 resourceValue_11 resourceValue_12
    benchNarrow
    let runtimeExtent_0 ← runtimeExtentNat resourceValue_0
    benchGuard
    unless (runtimeExtent_0 : UInt64) ≤ 2147483647 do
      throw (IO.userError "E_RUNTIME_GUARD: extent, layout or shape preflight failed")
    benchNarrow
    let runtimeExtent_1 ← runtimeExtentNat resourceValue_1
    benchGuard
    unless (runtimeExtent_1 : UInt64) ≤ 2147483647 do
      throw (IO.userError "E_RUNTIME_GUARD: extent, layout or shape preflight failed")
    benchNarrow
    let runtimeExtent_2 ← runtimeExtentNat resourceValue_2
    benchGuard
    unless (runtimeExtent_2 : UInt64) ≤ 2147483647 do
      throw (IO.userError "E_RUNTIME_GUARD: extent, layout or shape preflight failed")
    benchNarrow
    let runtimeExtent_11 ← runtimeExtentNat resourceValue_11
    benchNarrow
    let runtimeExtent_8 ← runtimeExtentNat resourceValue_8
    benchGuard
    unless runtimeLayoutValid 1 runtimeExtent_11 runtimeExtent_0 runtimeExtent_1 runtimeExtent_8 do
      throw (IO.userError "E_RUNTIME_GUARD: extent, layout or shape preflight failed")
    allocate shapeArena 0 1 runtimeExtent_11
    benchNarrow
    let runtimeExtent_12 ← runtimeExtentNat resourceValue_12
    benchNarrow
    let runtimeExtent_9 ← runtimeExtentNat resourceValue_9
    benchGuard
    unless runtimeLayoutValid 1 runtimeExtent_12 runtimeExtent_1 runtimeExtent_2 runtimeExtent_9 do
      throw (IO.userError "E_RUNTIME_GUARD: extent, layout or shape preflight failed")
    allocate shapeArena 1 1 runtimeExtent_12
    benchNarrow
    let runtimeExtent_13 ← runtimeExtentNat resourceValue_13
    benchNarrow
    let runtimeExtent_10 ← runtimeExtentNat resourceValue_10
    benchGuard
    unless runtimeLayoutValid 1 runtimeExtent_13 runtimeExtent_0 runtimeExtent_2 runtimeExtent_10 do
      throw (IO.userError "E_RUNTIME_GUARD: extent, layout or shape preflight failed")
    allocate shapeArena 2 1 runtimeExtent_13
    fill shapeArena 0 0 runtimeExtent_0 runtimeExtent_1 runtimeExtent_8 false 1 4607182418800017408 4607182418800017408
    fill shapeArena 1 0 runtimeExtent_1 runtimeExtent_2 runtimeExtent_9 false 1 4611686018427387904 13830554455654793216
    benchBegin 1 reps.toUInt64 verify
    for _ in [:reps] do
      VastitasGemmNative.gemm shapeArena 0 0 runtimeExtent_0 runtimeExtent_1 runtimeExtent_8 false false 1 0 runtimeExtent_1 runtimeExtent_2 runtimeExtent_9 false false 2 0 runtimeExtent_0 runtimeExtent_2 runtimeExtent_10 false 0
      VastitasGemmNative.gemm shapeArena 0 0 runtimeExtent_0 runtimeExtent_1 runtimeExtent_8 false false 1 0 runtimeExtent_1 runtimeExtent_2 runtimeExtent_9 false false 2 0 runtimeExtent_0 runtimeExtent_2 runtimeExtent_10 false 0
    benchStop
    benchVerify shapeArena
    drop shapeArena 0
    drop shapeArena 1
    drop shapeArena 2
  finally
    close shapeArena

def main (args : List String) : IO Unit := do
  let implementation := args[0]!
  let scope := args[1]!.toNat!
  let reps := args[2]!.toNat!
  let verify := args[3]! == "1"
  let mut rest := args.drop 4
  while !rest.isEmpty do
    let m := rest[0]!.toNat!; let k := rest[1]!.toNat!
    let n := rest[2]!.toNat!; let pad := rest[3]!.toNat!
    rest := rest.drop 4
    benchConfig m.toUInt64 k.toUInt64 n.toUInt64 pad.toUInt64
    if implementation == "c" then
      benchC scope.toUInt32 reps.toUInt64 verify
    else if scope == 0 then
      benchBegin 0 reps.toUInt64 verify
      for _ in [:reps] do generatedOnce m k n pad
      benchStop
    else
      generatedReuse m k n pad reps verify
    benchReport
