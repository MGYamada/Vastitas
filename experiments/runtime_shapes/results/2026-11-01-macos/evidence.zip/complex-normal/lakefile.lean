import Lake
open Lake DSL
package runtime_shape_audit where
  moreLinkArgs := #["-fno-lto", "-L", "/Users/masa/.elan/toolchains/leanprover--lean4---v4.35.0/lib"]
require vastitas_kernel from "/private/tmp/vastitas-runtime-shapes/lean-kernel"
require vastitas_gemm_native from "./numerical" with
  NameMap.empty.insert `openblas "/private/tmp/vastitas-openblas-verified"
lean_exe audit where
  root := `Main
  moreLeancArgs := #["-O3", "-fno-lto"]
