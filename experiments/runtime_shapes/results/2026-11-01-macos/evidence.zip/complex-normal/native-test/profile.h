#define SCALAR 1
#define TRANSPOSE 0
