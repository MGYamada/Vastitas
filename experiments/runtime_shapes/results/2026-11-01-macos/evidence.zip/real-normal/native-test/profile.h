#define SCALAR 0
#define TRANSPOSE 0
