import VastitasStorageNative
import VastitasGemmNative
import VastitasKernel.IndexedRuntime

set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
set_option linter.unusedVariables false

namespace VastitasGenerated

def f_1 (v_4 : Nat) (v_5 : Nat) (v_6 : Nat) (v_7 : Nat) : Nat :=
  (v_5 + v_7)

def f_2 (v_8 : Nat) (v_9 : Nat) (v_10 : Nat) (v_11 : Nat) (v_12 : Nat) : Nat :=
  (v_9 + v_11)

def f_3 (v_13 : Nat) (v_14 : Nat) (v_15 : Nat) (v_16 : Nat) (v_17 : Nat) (v_18 : Nat) : Nat :=
  (v_13 + v_16)

def f_4 (v_19 : Nat) (v_20 : Nat) (v_21 : Nat) (v_22 : Nat) (v_23 : Nat) (v_24 : Nat) (v_25 : Nat) : Nat :=
  (v_23 * v_19)

def f_5 (v_26 : Nat) (v_27 : Nat) (v_28 : Nat) (v_29 : Nat) (v_30 : Nat) (v_31 : Nat) (v_32 : Nat) (v_33 : Nat) : Nat :=
  (v_31 * v_28)

def f_6 (v_34 : Nat) (v_35 : Nat) (v_36 : Nat) (v_37 : Nat) (v_38 : Nat) (v_39 : Nat) (v_40 : Nat) (v_41 : Nat) (v_42 : Nat) : Nat :=
  (v_40 * v_36)

def f_8 : Nat :=
  (2 : Nat)

def f_9 (v_53 : Nat) : Nat :=
  (3 : Nat)

def f_10 (v_54 : Nat) (v_55 : Nat) : Nat :=
  (4 : Nat)

def f_11 (v_56 : Nat) (v_57 : Nat) (v_58 : Nat) : Nat :=
  (0 : Nat)

def f_12 (v_59 : Nat) (v_60 : Nat) (v_61 : Nat) (v_62 : Nat) : Int :=
  (0 : Int)

end VastitasGenerated

open VastitasStorageNative

def main : IO Unit := do
  let shapeArena ← newArena 9223372036854775807
  try
    let resourceValue_0 := VastitasGenerated.f_8
    let resourceValue_1 := VastitasGenerated.f_9 resourceValue_0
    let resourceValue_2 := VastitasGenerated.f_10 resourceValue_0 resourceValue_1
    let resourceValue_3 := VastitasGenerated.f_11 resourceValue_0 resourceValue_1 resourceValue_2
    let resourceValue_8 := VastitasGenerated.f_1 resourceValue_0 resourceValue_1 resourceValue_2 resourceValue_3
    let resourceValue_9 := VastitasGenerated.f_2 resourceValue_0 resourceValue_1 resourceValue_2 resourceValue_3 resourceValue_8
    let resourceValue_10 := VastitasGenerated.f_3 resourceValue_0 resourceValue_1 resourceValue_2 resourceValue_3 resourceValue_8 resourceValue_9
    let resourceValue_11 := VastitasGenerated.f_4 resourceValue_0 resourceValue_1 resourceValue_2 resourceValue_3 resourceValue_8 resourceValue_9 resourceValue_10
    let resourceValue_12 := VastitasGenerated.f_5 resourceValue_0 resourceValue_1 resourceValue_2 resourceValue_3 resourceValue_8 resourceValue_9 resourceValue_10 resourceValue_11
    let resourceValue_13 := VastitasGenerated.f_6 resourceValue_0 resourceValue_1 resourceValue_2 resourceValue_3 resourceValue_8 resourceValue_9 resourceValue_10 resourceValue_11 resourceValue_12
    let runtimeExtent_0 ← runtimeExtentNat resourceValue_0
    unless (runtimeExtent_0 : UInt64) ≤ 2147483647 do
      throw (IO.userError "E_RUNTIME_GUARD: extent, layout or shape preflight failed")
    let runtimeExtent_1 ← runtimeExtentNat resourceValue_1
    unless (runtimeExtent_1 : UInt64) ≤ 2147483647 do
      throw (IO.userError "E_RUNTIME_GUARD: extent, layout or shape preflight failed")
    let runtimeExtent_2 ← runtimeExtentNat resourceValue_2
    unless (runtimeExtent_2 : UInt64) ≤ 2147483647 do
      throw (IO.userError "E_RUNTIME_GUARD: extent, layout or shape preflight failed")
    let runtimeExtent_11 ← runtimeExtentNat resourceValue_11
    let runtimeExtent_8 ← runtimeExtentNat resourceValue_8
    unless runtimeLayoutValid 0 runtimeExtent_11 runtimeExtent_1 runtimeExtent_0 runtimeExtent_8 do
      throw (IO.userError "E_RUNTIME_GUARD: extent, layout or shape preflight failed")
    allocate shapeArena 0 0 runtimeExtent_11
    let runtimeExtent_12 ← runtimeExtentNat resourceValue_12
    let runtimeExtent_9 ← runtimeExtentNat resourceValue_9
    unless runtimeLayoutValid 0 runtimeExtent_12 runtimeExtent_1 runtimeExtent_2 runtimeExtent_9 do
      throw (IO.userError "E_RUNTIME_GUARD: extent, layout or shape preflight failed")
    allocate shapeArena 1 0 runtimeExtent_12
    let runtimeExtent_13 ← runtimeExtentNat resourceValue_13
    let runtimeExtent_10 ← runtimeExtentNat resourceValue_10
    unless runtimeLayoutValid 0 runtimeExtent_13 runtimeExtent_0 runtimeExtent_2 runtimeExtent_10 do
      throw (IO.userError "E_RUNTIME_GUARD: extent, layout or shape preflight failed")
    allocate shapeArena 2 0 runtimeExtent_13
    fill shapeArena 0 0 runtimeExtent_1 runtimeExtent_0 runtimeExtent_8 true 0 4607182418800017408 0
    fill shapeArena 1 0 runtimeExtent_1 runtimeExtent_2 runtimeExtent_9 false 0 4611686018427387904 0
    VastitasGemmNative.gemm shapeArena 0 0 runtimeExtent_1 runtimeExtent_0 runtimeExtent_8 true false 1 0 runtimeExtent_1 runtimeExtent_2 runtimeExtent_9 false false 2 0 runtimeExtent_0 runtimeExtent_2 runtimeExtent_10 false 0
    VastitasGemmNative.gemm shapeArena 0 0 runtimeExtent_1 runtimeExtent_0 runtimeExtent_8 true false 1 0 runtimeExtent_1 runtimeExtent_2 runtimeExtent_9 false false 2 0 runtimeExtent_0 runtimeExtent_2 runtimeExtent_10 false 0
    drop shapeArena 0
    drop shapeArena 1
    drop shapeArena 2
    IO.println (VastitasGenerated.f_12 resourceValue_0 resourceValue_1 resourceValue_2 resourceValue_3)
  finally
    close shapeArena
