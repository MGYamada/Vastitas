// Lean compiler output
// Module: Main
// Imports: public import Init public meta import Init public import VastitasStorageNative public import VastitasGemmNative public import VastitasKernel.IndexedRuntime
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* vastitas_storage_new(uint64_t);
lean_object* vastitas_storage_close(lean_object*);
lean_object* vastitas_storage_allocate(lean_object*, uint32_t, uint8_t, uint64_t);
lean_object* vastitas_storage_fill(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_store(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_pack3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_gemm_execute(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t);
lean_object* vastitas_storage_regroup3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_storage_expect(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_drop(lean_object*, uint32_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_List_get_x21Internal___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_String_Slice_toNat_x21(lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
uint32_t lean_uint32_of_nat(lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
lean_object* lean_io_error_to_string(lean_object*);
static lean_once_cell_t lp_allocation__audit_VastitasGenerated_f__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_allocation__audit_VastitasGenerated_f__0___closed__0;
LEAN_EXPORT lean_object* lp_allocation__audit_VastitasGenerated_f__0;
lean_object* bench_begin_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_stop_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object*);
lean_object* bench_report_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object*);
lean_object* bench_c_run_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_verify_lean(lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object*);
lean_object* audit_mark_lean(uint32_t);
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_allocation__audit_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 1, .m_capacity = 1, .m_length = 0, .m_data = ""};
static const lean_object* lp_allocation__audit_main___closed__0 = (const lean_object*)&lp_allocation__audit_main___closed__0_value;
static const lean_string_object lp_allocation__audit_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "1"};
static const lean_object* lp_allocation__audit_main___closed__1 = (const lean_object*)&lp_allocation__audit_main___closed__1_value;
static const lean_string_object lp_allocation__audit_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "failure"};
static const lean_object* lp_allocation__audit_main___closed__2 = (const lean_object*)&lp_allocation__audit_main___closed__2_value;
static const lean_string_object lp_allocation__audit_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "c"};
static const lean_object* lp_allocation__audit_main___closed__3 = (const lean_object*)&lp_allocation__audit_main___closed__3_value;
static const lean_string_object lp_allocation__audit_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "expected injected native failure"};
static const lean_object* lp_allocation__audit_main___closed__4 = (const lean_object*)&lp_allocation__audit_main___closed__4_value;
static const lean_ctor_object lp_allocation__audit_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_allocation__audit_main___closed__4_value)}};
static const lean_object* lp_allocation__audit_main___closed__5 = (const lean_object*)&lp_allocation__audit_main___closed__5_value;
static const lean_string_object lp_allocation__audit_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 44, .m_capacity = 44, .m_length = 43, .m_data = "E_NATIVE_EXPECT: stored bit pattern differs"};
static const lean_object* lp_allocation__audit_main___closed__6 = (const lean_object*)&lp_allocation__audit_main___closed__6_value;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(0u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0(void){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_obj_once(&lp_allocation__audit_VastitasGenerated_f__0___closed__0, &lp_allocation__audit_VastitasGenerated_f__0___closed__0_once, _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object* v_scope_8_, lean_object* v_reps_9_, lean_object* v_verify_10_, lean_object* v_a_00___x40___internal___hyg_11_){
_start:
{
uint32_t v_scope_boxed_12_; uint64_t v_reps_boxed_13_; uint8_t v_verify_boxed_14_; lean_object* v_res_15_; 
v_scope_boxed_12_ = lean_unbox_uint32(v_scope_8_);
lean_dec(v_scope_8_);
v_reps_boxed_13_ = lean_unbox_uint64(v_reps_9_);
lean_dec_ref(v_reps_9_);
v_verify_boxed_14_ = lean_unbox(v_verify_10_);
v_res_15_ = bench_begin_lean(v_scope_boxed_12_, v_reps_boxed_13_, v_verify_boxed_14_);
return v_res_15_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object* v_a_00___x40___internal___hyg_17_){
_start:
{
lean_object* v_res_18_; 
v_res_18_ = bench_stop_lean();
return v_res_18_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object* v_a_00___x40___internal___hyg_20_){
_start:
{
lean_object* v_res_21_; 
v_res_21_ = bench_report_lean();
return v_res_21_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object* v_scope_26_, lean_object* v_reps_27_, lean_object* v_verify_28_, lean_object* v_a_00___x40___internal___hyg_29_){
_start:
{
uint32_t v_scope_boxed_30_; uint64_t v_reps_boxed_31_; uint8_t v_verify_boxed_32_; lean_object* v_res_33_; 
v_scope_boxed_30_ = lean_unbox_uint32(v_scope_26_);
lean_dec(v_scope_26_);
v_reps_boxed_31_ = lean_unbox_uint64(v_reps_27_);
lean_dec_ref(v_reps_27_);
v_verify_boxed_32_ = lean_unbox(v_verify_28_);
v_res_33_ = bench_c_run_lean(v_scope_boxed_30_, v_reps_boxed_31_, v_verify_boxed_32_);
return v_res_33_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object* v_arena_37_, lean_object* v_reps_38_, lean_object* v_a_00___x40___internal___hyg_39_){
_start:
{
uint64_t v_reps_boxed_40_; lean_object* v_res_41_; 
v_reps_boxed_40_ = lean_unbox_uint64(v_reps_38_);
lean_dec_ref(v_reps_38_);
v_res_41_ = bench_verify_lean(v_arena_37_, v_reps_boxed_40_);
lean_dec(v_arena_37_);
return v_res_41_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce(){
_start:
{
uint64_t v___x_43_; lean_object* v___x_44_; 
v___x_43_ = 9223372036854775807ULL;
v___x_44_ = vastitas_storage_new(v___x_43_);
if (lean_obj_tag(v___x_44_) == 0)
{
lean_object* v_a_45_; lean_object* v___y_47_; uint32_t v___x_60_; uint8_t v___x_61_; uint64_t v___x_62_; lean_object* v___x_63_; 
v_a_45_ = lean_ctor_get(v___x_44_, 0);
lean_inc(v_a_45_);
lean_dec_ref_known(v___x_44_, 1);
v___x_60_ = 0;
v___x_61_ = 1;
v___x_62_ = 2048ULL;
v___x_63_ = vastitas_storage_allocate(v_a_45_, v___x_60_, v___x_61_, v___x_62_);
if (lean_obj_tag(v___x_63_) == 0)
{
uint64_t v___x_64_; uint64_t v___x_65_; uint8_t v___x_66_; uint64_t v___x_67_; uint64_t v___x_68_; lean_object* v___x_69_; 
lean_dec_ref_known(v___x_63_, 1);
v___x_64_ = 0ULL;
v___x_65_ = 1ULL;
v___x_66_ = 0;
v___x_67_ = 13842939354630062080ULL;
v___x_68_ = 4613937818241073152ULL;
v___x_69_ = vastitas_storage_fill(v_a_45_, v___x_60_, v___x_64_, v___x_62_, v___x_65_, v___x_62_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_69_) == 0)
{
uint64_t v___x_70_; uint64_t v___x_71_; uint64_t v___x_72_; uint64_t v___x_73_; lean_object* v___x_74_; 
lean_dec_ref_known(v___x_69_, 1);
v___x_70_ = 512ULL;
v___x_71_ = 4ULL;
v___x_72_ = 4593671619917905920ULL;
v___x_73_ = 4598175219545276416ULL;
v___x_74_ = vastitas_storage_fill(v_a_45_, v___x_60_, v___x_64_, v___x_70_, v___x_71_, v___x_70_, v___x_66_, v___x_61_, v___x_72_, v___x_73_);
if (lean_obj_tag(v___x_74_) == 0)
{
uint64_t v___x_75_; uint64_t v___x_76_; lean_object* v___x_77_; 
lean_dec_ref_known(v___x_74_, 1);
v___x_75_ = 4607182418800017408ULL;
v___x_76_ = 13826050856027422720ULL;
v___x_77_ = vastitas_storage_store(v_a_45_, v___x_60_, v___x_64_, v___x_70_, v___x_71_, v___x_70_, v___x_66_, v___x_64_, v___x_64_, v___x_61_, v___x_75_, v___x_76_);
if (lean_obj_tag(v___x_77_) == 0)
{
uint64_t v___x_78_; uint64_t v___x_79_; lean_object* v___x_80_; 
lean_dec_ref_known(v___x_77_, 1);
v___x_78_ = 511ULL;
v___x_79_ = 4604930618986332160ULL;
v___x_80_ = vastitas_storage_store(v_a_45_, v___x_60_, v___x_64_, v___x_70_, v___x_71_, v___x_70_, v___x_66_, v___x_78_, v___x_65_, v___x_61_, v___x_76_, v___x_79_);
if (lean_obj_tag(v___x_80_) == 0)
{
uint32_t v___x_81_; uint64_t v___x_82_; lean_object* v___x_83_; 
lean_dec_ref_known(v___x_80_, 1);
v___x_81_ = 1;
v___x_82_ = 128ULL;
v___x_83_ = vastitas_storage_allocate(v_a_45_, v___x_81_, v___x_61_, v___x_82_);
if (lean_obj_tag(v___x_83_) == 0)
{
lean_object* v___x_84_; 
lean_dec_ref_known(v___x_83_, 1);
v___x_84_ = vastitas_storage_fill(v_a_45_, v___x_81_, v___x_64_, v___x_82_, v___x_65_, v___x_82_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_84_) == 0)
{
uint64_t v___x_85_; uint64_t v___x_86_; uint64_t v___x_87_; lean_object* v___x_88_; 
lean_dec_ref_known(v___x_84_, 1);
v___x_85_ = 2ULL;
v___x_86_ = 64ULL;
v___x_87_ = 13821547256400052224ULL;
v___x_88_ = vastitas_storage_fill(v_a_45_, v___x_81_, v___x_64_, v___x_85_, v___x_86_, v___x_85_, v___x_66_, v___x_61_, v___x_87_, v___x_72_);
if (lean_obj_tag(v___x_88_) == 0)
{
uint64_t v___x_89_; uint64_t v___x_90_; lean_object* v___x_91_; 
lean_dec_ref_known(v___x_88_, 1);
v___x_89_ = 63ULL;
v___x_90_ = 4602678819172646912ULL;
v___x_91_ = vastitas_storage_store(v_a_45_, v___x_81_, v___x_64_, v___x_85_, v___x_86_, v___x_85_, v___x_66_, v___x_64_, v___x_89_, v___x_61_, v___x_90_, v___x_73_);
if (lean_obj_tag(v___x_91_) == 0)
{
uint64_t v___x_92_; lean_object* v___x_93_; 
lean_dec_ref_known(v___x_91_, 1);
v___x_92_ = 13828302655841107968ULL;
v___x_93_ = vastitas_storage_store(v_a_45_, v___x_81_, v___x_64_, v___x_85_, v___x_86_, v___x_85_, v___x_66_, v___x_65_, v___x_64_, v___x_61_, v___x_92_, v___x_76_);
if (lean_obj_tag(v___x_93_) == 0)
{
uint32_t v___x_94_; uint64_t v___x_95_; lean_object* v___x_96_; 
lean_dec_ref_known(v___x_93_, 1);
v___x_94_ = 2;
v___x_95_ = 1024ULL;
v___x_96_ = vastitas_storage_allocate(v_a_45_, v___x_94_, v___x_61_, v___x_95_);
if (lean_obj_tag(v___x_96_) == 0)
{
lean_object* v___x_97_; 
lean_dec_ref_known(v___x_96_, 1);
v___x_97_ = vastitas_storage_fill(v_a_45_, v___x_94_, v___x_64_, v___x_95_, v___x_65_, v___x_95_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_97_) == 0)
{
lean_object* v___x_98_; 
lean_dec_ref_known(v___x_97_, 1);
v___x_98_ = vastitas_storage_fill(v_a_45_, v___x_94_, v___x_64_, v___x_85_, v___x_70_, v___x_85_, v___x_66_, v___x_61_, v___x_90_, v___x_87_);
if (lean_obj_tag(v___x_98_) == 0)
{
lean_object* v___x_99_; 
lean_dec_ref_known(v___x_98_, 1);
v___x_99_ = vastitas_storage_store(v_a_45_, v___x_94_, v___x_64_, v___x_85_, v___x_70_, v___x_85_, v___x_66_, v___x_65_, v___x_64_, v___x_61_, v___x_87_, v___x_90_);
if (lean_obj_tag(v___x_99_) == 0)
{
lean_object* v___x_100_; 
lean_dec_ref_known(v___x_99_, 1);
v___x_100_ = vastitas_storage_store(v_a_45_, v___x_94_, v___x_64_, v___x_85_, v___x_70_, v___x_85_, v___x_66_, v___x_64_, v___x_78_, v___x_61_, v___x_79_, v___x_92_);
if (lean_obj_tag(v___x_100_) == 0)
{
uint32_t v___x_101_; uint64_t v___x_102_; lean_object* v___x_103_; 
lean_dec_ref_known(v___x_100_, 1);
v___x_101_ = 3;
v___x_102_ = 65536ULL;
v___x_103_ = vastitas_storage_allocate(v_a_45_, v___x_101_, v___x_61_, v___x_102_);
if (lean_obj_tag(v___x_103_) == 0)
{
lean_object* v___x_104_; 
lean_dec_ref_known(v___x_103_, 1);
v___x_104_ = vastitas_storage_fill(v_a_45_, v___x_101_, v___x_64_, v___x_102_, v___x_65_, v___x_102_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_104_) == 0)
{
uint32_t v___x_105_; lean_object* v___x_106_; 
lean_dec_ref_known(v___x_104_, 1);
v___x_105_ = 4;
v___x_106_ = vastitas_storage_allocate(v_a_45_, v___x_105_, v___x_61_, v___x_102_);
if (lean_obj_tag(v___x_106_) == 0)
{
lean_object* v___x_107_; 
lean_dec_ref_known(v___x_106_, 1);
v___x_107_ = vastitas_storage_fill(v_a_45_, v___x_105_, v___x_64_, v___x_102_, v___x_65_, v___x_102_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_107_) == 0)
{
uint32_t v___x_108_; uint64_t v___x_109_; lean_object* v___x_110_; 
lean_dec_ref_known(v___x_107_, 1);
v___x_108_ = 5;
v___x_109_ = 16777216ULL;
v___x_110_ = vastitas_storage_allocate(v_a_45_, v___x_108_, v___x_61_, v___x_109_);
if (lean_obj_tag(v___x_110_) == 0)
{
lean_object* v___x_111_; 
lean_dec_ref_known(v___x_110_, 1);
v___x_111_ = vastitas_storage_fill(v_a_45_, v___x_108_, v___x_64_, v___x_109_, v___x_65_, v___x_109_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_111_) == 0)
{
lean_object* v___x_112_; 
lean_dec_ref_known(v___x_111_, 1);
v___x_112_ = vastitas_storage_pack3(v_a_45_, v___x_60_, v___x_64_, v___x_70_, v___x_71_, v___x_70_, v___x_66_, v___x_101_, v___x_64_, v___x_95_, v___x_85_, v___x_95_, v___x_66_, v___x_70_, v___x_85_, v___x_85_);
if (lean_obj_tag(v___x_112_) == 0)
{
uint8_t v___x_113_; lean_object* v___x_114_; 
lean_dec_ref_known(v___x_112_, 1);
v___x_113_ = 0;
v___x_114_ = vastitas_gemm_execute(v_a_45_, v___x_101_, v___x_64_, v___x_95_, v___x_85_, v___x_95_, v___x_66_, v___x_66_, v___x_81_, v___x_64_, v___x_85_, v___x_86_, v___x_85_, v___x_66_, v___x_66_, v___x_105_, v___x_64_, v___x_95_, v___x_86_, v___x_95_, v___x_66_, v___x_113_);
if (lean_obj_tag(v___x_114_) == 0)
{
uint64_t v___x_115_; uint64_t v___x_116_; uint64_t v___x_117_; lean_object* v___x_118_; 
lean_dec_ref_known(v___x_114_, 1);
v___x_115_ = 32768ULL;
v___x_116_ = 48ULL;
v___x_117_ = 42ULL;
v___x_118_ = vastitas_storage_regroup3(v_a_45_, v___x_105_, v___x_64_, v___x_95_, v___x_86_, v___x_95_, v___x_66_, v___x_101_, v___x_64_, v___x_115_, v___x_85_, v___x_115_, v___x_66_, v___x_70_, v___x_85_, v___x_86_, v___x_116_, v___x_117_);
if (lean_obj_tag(v___x_118_) == 0)
{
lean_object* v___x_119_; 
lean_dec_ref_known(v___x_118_, 1);
v___x_119_ = vastitas_gemm_execute(v_a_45_, v___x_101_, v___x_64_, v___x_115_, v___x_85_, v___x_115_, v___x_66_, v___x_66_, v___x_94_, v___x_64_, v___x_85_, v___x_70_, v___x_85_, v___x_66_, v___x_66_, v___x_108_, v___x_64_, v___x_115_, v___x_70_, v___x_115_, v___x_66_, v___x_113_);
if (lean_obj_tag(v___x_119_) == 0)
{
uint64_t v___x_120_; uint64_t v___x_121_; lean_object* v___x_122_; 
lean_dec_ref_known(v___x_119_, 1);
v___x_120_ = 4590293920197378048ULL;
v___x_121_ = 4591701295080931328ULL;
v___x_122_ = vastitas_storage_expect(v_a_45_, v___x_108_, v___x_64_, v___x_115_, v___x_70_, v___x_115_, v___x_66_, v___x_64_, v___x_64_, v___x_61_, v___x_120_, v___x_121_);
if (lean_obj_tag(v___x_122_) == 0)
{
uint64_t v___x_123_; uint64_t v___x_124_; lean_object* v___x_125_; 
lean_dec_ref_known(v___x_122_, 1);
v___x_123_ = 4594797519824748544ULL;
v___x_124_ = 13829885952585105408ULL;
v___x_125_ = vastitas_storage_expect(v_a_45_, v___x_108_, v___x_64_, v___x_115_, v___x_70_, v___x_115_, v___x_66_, v___x_78_, v___x_78_, v___x_61_, v___x_123_, v___x_124_);
if (lean_obj_tag(v___x_125_) == 0)
{
uint64_t v___x_126_; uint64_t v___x_127_; uint64_t v___x_128_; lean_object* v___x_129_; 
lean_dec_ref_known(v___x_125_, 1);
v___x_126_ = 32767ULL;
v___x_127_ = 13810288257331625984ULL;
v___x_128_ = 13816199231842549760ULL;
v___x_129_ = vastitas_storage_expect(v_a_45_, v___x_108_, v___x_64_, v___x_115_, v___x_70_, v___x_115_, v___x_66_, v___x_126_, v___x_64_, v___x_61_, v___x_127_, v___x_128_);
if (lean_obj_tag(v___x_129_) == 0)
{
lean_object* v___x_130_; 
lean_dec_ref_known(v___x_129_, 1);
v___x_130_ = vastitas_storage_drop(v_a_45_, v___x_108_);
if (lean_obj_tag(v___x_130_) == 0)
{
lean_object* v___x_131_; 
lean_dec_ref_known(v___x_130_, 1);
v___x_131_ = vastitas_storage_drop(v_a_45_, v___x_105_);
if (lean_obj_tag(v___x_131_) == 0)
{
lean_object* v___x_132_; 
lean_dec_ref_known(v___x_131_, 1);
v___x_132_ = vastitas_storage_drop(v_a_45_, v___x_101_);
if (lean_obj_tag(v___x_132_) == 0)
{
lean_object* v___x_133_; 
lean_dec_ref_known(v___x_132_, 1);
v___x_133_ = vastitas_storage_drop(v_a_45_, v___x_94_);
if (lean_obj_tag(v___x_133_) == 0)
{
lean_object* v___x_134_; 
lean_dec_ref_known(v___x_133_, 1);
v___x_134_ = vastitas_storage_drop(v_a_45_, v___x_81_);
if (lean_obj_tag(v___x_134_) == 0)
{
lean_object* v___x_135_; 
lean_dec_ref_known(v___x_134_, 1);
v___x_135_ = vastitas_storage_drop(v_a_45_, v___x_60_);
if (lean_obj_tag(v___x_135_) == 0)
{
lean_object* v___x_136_; 
lean_dec_ref_known(v___x_135_, 1);
v___x_136_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
return v___x_136_;
}
else
{
v___y_47_ = v___x_135_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_134_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_133_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_132_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_131_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_130_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_129_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_125_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_122_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_119_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_118_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_114_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_112_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_111_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_110_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_107_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_106_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_104_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_103_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_100_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_99_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_98_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_97_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_96_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_93_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_91_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_88_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_84_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_83_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_80_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_77_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_74_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_69_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_63_;
goto v___jp_46_;
}
v___jp_46_:
{
if (lean_obj_tag(v___y_47_) == 0)
{
lean_object* v___x_48_; 
lean_dec_ref_known(v___y_47_, 1);
v___x_48_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
return v___x_48_;
}
else
{
lean_object* v_a_49_; lean_object* v___x_50_; 
v_a_49_ = lean_ctor_get(v___y_47_, 0);
lean_inc(v_a_49_);
lean_dec_ref_known(v___y_47_, 1);
v___x_50_ = vastitas_storage_close(v_a_45_);
if (lean_obj_tag(v___x_50_) == 0)
{
lean_object* v___x_52_; uint8_t v_isShared_53_; uint8_t v_isSharedCheck_57_; 
lean_dec(v_a_45_);
v_isSharedCheck_57_ = !lean_is_exclusive(v___x_50_);
if (v_isSharedCheck_57_ == 0)
{
lean_object* v_unused_58_; 
v_unused_58_ = lean_ctor_get(v___x_50_, 0);
lean_dec(v_unused_58_);
v___x_52_ = v___x_50_;
v_isShared_53_ = v_isSharedCheck_57_;
goto v_resetjp_51_;
}
else
{
lean_dec(v___x_50_);
v___x_52_ = lean_box(0);
v_isShared_53_ = v_isSharedCheck_57_;
goto v_resetjp_51_;
}
v_resetjp_51_:
{
lean_object* v___x_55_; 
if (v_isShared_53_ == 0)
{
lean_ctor_set_tag(v___x_52_, 1);
lean_ctor_set(v___x_52_, 0, v_a_49_);
v___x_55_ = v___x_52_;
goto v_reusejp_54_;
}
else
{
lean_object* v_reuseFailAlloc_56_; 
v_reuseFailAlloc_56_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_56_, 0, v_a_49_);
v___x_55_ = v_reuseFailAlloc_56_;
goto v_reusejp_54_;
}
v_reusejp_54_:
{
return v___x_55_;
}
}
}
else
{
lean_dec(v_a_49_);
if (lean_obj_tag(v___x_50_) == 0)
{
lean_object* v___x_59_; 
lean_dec_ref_known(v___x_50_, 1);
v___x_59_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
return v___x_59_;
}
else
{
lean_dec(v_a_45_);
return v___x_50_;
}
}
}
}
}
else
{
lean_object* v_a_137_; lean_object* v___x_139_; uint8_t v_isShared_140_; uint8_t v_isSharedCheck_144_; 
v_a_137_ = lean_ctor_get(v___x_44_, 0);
v_isSharedCheck_144_ = !lean_is_exclusive(v___x_44_);
if (v_isSharedCheck_144_ == 0)
{
v___x_139_ = v___x_44_;
v_isShared_140_ = v_isSharedCheck_144_;
goto v_resetjp_138_;
}
else
{
lean_inc(v_a_137_);
lean_dec(v___x_44_);
v___x_139_ = lean_box(0);
v_isShared_140_ = v_isSharedCheck_144_;
goto v_resetjp_138_;
}
v_resetjp_138_:
{
lean_object* v___x_142_; 
if (v_isShared_140_ == 0)
{
v___x_142_ = v___x_139_;
goto v_reusejp_141_;
}
else
{
lean_object* v_reuseFailAlloc_143_; 
v_reuseFailAlloc_143_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_143_, 0, v_a_137_);
v___x_142_ = v_reuseFailAlloc_143_;
goto v_reusejp_141_;
}
v_reusejp_141_:
{
return v___x_142_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object* v_a_145_){
_start:
{
lean_object* v_res_146_; 
v_res_146_ = lp_allocation__audit_generatedOnce();
return v_res_146_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure(){
_start:
{
uint64_t v___x_148_; lean_object* v___x_149_; 
v___x_148_ = 9223372036854775807ULL;
v___x_149_ = vastitas_storage_new(v___x_148_);
if (lean_obj_tag(v___x_149_) == 0)
{
lean_object* v_a_150_; lean_object* v___y_152_; uint32_t v___x_165_; uint8_t v___x_166_; uint64_t v___x_167_; lean_object* v___x_168_; 
v_a_150_ = lean_ctor_get(v___x_149_, 0);
lean_inc(v_a_150_);
lean_dec_ref_known(v___x_149_, 1);
v___x_165_ = 0;
v___x_166_ = 1;
v___x_167_ = 2048ULL;
v___x_168_ = vastitas_storage_allocate(v_a_150_, v___x_165_, v___x_166_, v___x_167_);
if (lean_obj_tag(v___x_168_) == 0)
{
uint64_t v___x_169_; uint64_t v___x_170_; uint8_t v___x_171_; uint64_t v___x_172_; uint64_t v___x_173_; lean_object* v___x_174_; 
lean_dec_ref_known(v___x_168_, 1);
v___x_169_ = 0ULL;
v___x_170_ = 1ULL;
v___x_171_ = 0;
v___x_172_ = 13842939354630062080ULL;
v___x_173_ = 4613937818241073152ULL;
v___x_174_ = vastitas_storage_fill(v_a_150_, v___x_165_, v___x_169_, v___x_167_, v___x_170_, v___x_167_, v___x_171_, v___x_166_, v___x_172_, v___x_173_);
if (lean_obj_tag(v___x_174_) == 0)
{
uint64_t v___x_175_; uint64_t v___x_176_; uint64_t v___x_177_; uint64_t v___x_178_; lean_object* v___x_179_; 
lean_dec_ref_known(v___x_174_, 1);
v___x_175_ = 512ULL;
v___x_176_ = 4ULL;
v___x_177_ = 4593671619917905920ULL;
v___x_178_ = 4598175219545276416ULL;
v___x_179_ = vastitas_storage_fill(v_a_150_, v___x_165_, v___x_169_, v___x_175_, v___x_176_, v___x_175_, v___x_171_, v___x_166_, v___x_177_, v___x_178_);
if (lean_obj_tag(v___x_179_) == 0)
{
uint64_t v___x_180_; uint64_t v___x_181_; lean_object* v___x_182_; 
lean_dec_ref_known(v___x_179_, 1);
v___x_180_ = 4607182418800017408ULL;
v___x_181_ = 13826050856027422720ULL;
v___x_182_ = vastitas_storage_store(v_a_150_, v___x_165_, v___x_169_, v___x_175_, v___x_176_, v___x_175_, v___x_171_, v___x_169_, v___x_169_, v___x_166_, v___x_180_, v___x_181_);
if (lean_obj_tag(v___x_182_) == 0)
{
uint64_t v___x_183_; uint64_t v___x_184_; lean_object* v___x_185_; 
lean_dec_ref_known(v___x_182_, 1);
v___x_183_ = 511ULL;
v___x_184_ = 4604930618986332160ULL;
v___x_185_ = vastitas_storage_store(v_a_150_, v___x_165_, v___x_169_, v___x_175_, v___x_176_, v___x_175_, v___x_171_, v___x_183_, v___x_170_, v___x_166_, v___x_181_, v___x_184_);
if (lean_obj_tag(v___x_185_) == 0)
{
uint32_t v___x_186_; uint64_t v___x_187_; lean_object* v___x_188_; 
lean_dec_ref_known(v___x_185_, 1);
v___x_186_ = 1;
v___x_187_ = 128ULL;
v___x_188_ = vastitas_storage_allocate(v_a_150_, v___x_186_, v___x_166_, v___x_187_);
if (lean_obj_tag(v___x_188_) == 0)
{
lean_object* v___x_189_; 
lean_dec_ref_known(v___x_188_, 1);
v___x_189_ = vastitas_storage_fill(v_a_150_, v___x_186_, v___x_169_, v___x_187_, v___x_170_, v___x_187_, v___x_171_, v___x_166_, v___x_172_, v___x_173_);
if (lean_obj_tag(v___x_189_) == 0)
{
uint64_t v___x_190_; uint64_t v___x_191_; uint64_t v___x_192_; lean_object* v___x_193_; 
lean_dec_ref_known(v___x_189_, 1);
v___x_190_ = 2ULL;
v___x_191_ = 64ULL;
v___x_192_ = 13821547256400052224ULL;
v___x_193_ = vastitas_storage_fill(v_a_150_, v___x_186_, v___x_169_, v___x_190_, v___x_191_, v___x_190_, v___x_171_, v___x_166_, v___x_192_, v___x_177_);
if (lean_obj_tag(v___x_193_) == 0)
{
uint64_t v___x_194_; uint64_t v___x_195_; lean_object* v___x_196_; 
lean_dec_ref_known(v___x_193_, 1);
v___x_194_ = 63ULL;
v___x_195_ = 4602678819172646912ULL;
v___x_196_ = vastitas_storage_store(v_a_150_, v___x_186_, v___x_169_, v___x_190_, v___x_191_, v___x_190_, v___x_171_, v___x_169_, v___x_194_, v___x_166_, v___x_195_, v___x_178_);
if (lean_obj_tag(v___x_196_) == 0)
{
uint64_t v___x_197_; lean_object* v___x_198_; 
lean_dec_ref_known(v___x_196_, 1);
v___x_197_ = 13828302655841107968ULL;
v___x_198_ = vastitas_storage_store(v_a_150_, v___x_186_, v___x_169_, v___x_190_, v___x_191_, v___x_190_, v___x_171_, v___x_170_, v___x_169_, v___x_166_, v___x_197_, v___x_181_);
if (lean_obj_tag(v___x_198_) == 0)
{
uint32_t v___x_199_; uint64_t v___x_200_; lean_object* v___x_201_; 
lean_dec_ref_known(v___x_198_, 1);
v___x_199_ = 2;
v___x_200_ = 1024ULL;
v___x_201_ = vastitas_storage_allocate(v_a_150_, v___x_199_, v___x_166_, v___x_200_);
if (lean_obj_tag(v___x_201_) == 0)
{
lean_object* v___x_202_; 
lean_dec_ref_known(v___x_201_, 1);
v___x_202_ = vastitas_storage_fill(v_a_150_, v___x_199_, v___x_169_, v___x_200_, v___x_170_, v___x_200_, v___x_171_, v___x_166_, v___x_172_, v___x_173_);
if (lean_obj_tag(v___x_202_) == 0)
{
lean_object* v___x_203_; 
lean_dec_ref_known(v___x_202_, 1);
v___x_203_ = vastitas_storage_fill(v_a_150_, v___x_199_, v___x_169_, v___x_190_, v___x_175_, v___x_190_, v___x_171_, v___x_166_, v___x_195_, v___x_192_);
if (lean_obj_tag(v___x_203_) == 0)
{
lean_object* v___x_204_; 
lean_dec_ref_known(v___x_203_, 1);
v___x_204_ = vastitas_storage_store(v_a_150_, v___x_199_, v___x_169_, v___x_190_, v___x_175_, v___x_190_, v___x_171_, v___x_170_, v___x_169_, v___x_166_, v___x_192_, v___x_195_);
if (lean_obj_tag(v___x_204_) == 0)
{
lean_object* v___x_205_; 
lean_dec_ref_known(v___x_204_, 1);
v___x_205_ = vastitas_storage_store(v_a_150_, v___x_199_, v___x_169_, v___x_190_, v___x_175_, v___x_190_, v___x_171_, v___x_169_, v___x_183_, v___x_166_, v___x_184_, v___x_197_);
if (lean_obj_tag(v___x_205_) == 0)
{
uint32_t v___x_206_; uint64_t v___x_207_; lean_object* v___x_208_; 
lean_dec_ref_known(v___x_205_, 1);
v___x_206_ = 3;
v___x_207_ = 65536ULL;
v___x_208_ = vastitas_storage_allocate(v_a_150_, v___x_206_, v___x_166_, v___x_207_);
if (lean_obj_tag(v___x_208_) == 0)
{
lean_object* v___x_209_; 
lean_dec_ref_known(v___x_208_, 1);
v___x_209_ = vastitas_storage_fill(v_a_150_, v___x_206_, v___x_169_, v___x_207_, v___x_170_, v___x_207_, v___x_171_, v___x_166_, v___x_172_, v___x_173_);
if (lean_obj_tag(v___x_209_) == 0)
{
uint32_t v___x_210_; lean_object* v___x_211_; 
lean_dec_ref_known(v___x_209_, 1);
v___x_210_ = 4;
v___x_211_ = vastitas_storage_allocate(v_a_150_, v___x_210_, v___x_166_, v___x_207_);
if (lean_obj_tag(v___x_211_) == 0)
{
lean_object* v___x_212_; 
lean_dec_ref_known(v___x_211_, 1);
v___x_212_ = vastitas_storage_fill(v_a_150_, v___x_210_, v___x_169_, v___x_207_, v___x_170_, v___x_207_, v___x_171_, v___x_166_, v___x_172_, v___x_173_);
if (lean_obj_tag(v___x_212_) == 0)
{
uint32_t v___x_213_; uint64_t v___x_214_; lean_object* v___x_215_; 
lean_dec_ref_known(v___x_212_, 1);
v___x_213_ = 5;
v___x_214_ = 16777216ULL;
v___x_215_ = vastitas_storage_allocate(v_a_150_, v___x_213_, v___x_166_, v___x_214_);
if (lean_obj_tag(v___x_215_) == 0)
{
lean_object* v___x_216_; 
lean_dec_ref_known(v___x_215_, 1);
v___x_216_ = vastitas_storage_fill(v_a_150_, v___x_213_, v___x_169_, v___x_214_, v___x_170_, v___x_214_, v___x_171_, v___x_166_, v___x_172_, v___x_173_);
if (lean_obj_tag(v___x_216_) == 0)
{
lean_object* v___x_217_; 
lean_dec_ref_known(v___x_216_, 1);
v___x_217_ = vastitas_storage_pack3(v_a_150_, v___x_165_, v___x_169_, v___x_175_, v___x_176_, v___x_175_, v___x_171_, v___x_206_, v___x_169_, v___x_200_, v___x_190_, v___x_200_, v___x_171_, v___x_175_, v___x_190_, v___x_190_);
if (lean_obj_tag(v___x_217_) == 0)
{
uint8_t v___x_218_; lean_object* v___x_219_; 
lean_dec_ref_known(v___x_217_, 1);
v___x_218_ = 0;
v___x_219_ = vastitas_gemm_execute(v_a_150_, v___x_206_, v___x_169_, v___x_200_, v___x_190_, v___x_200_, v___x_171_, v___x_171_, v___x_186_, v___x_169_, v___x_190_, v___x_191_, v___x_190_, v___x_171_, v___x_171_, v___x_210_, v___x_169_, v___x_200_, v___x_191_, v___x_200_, v___x_171_, v___x_218_);
if (lean_obj_tag(v___x_219_) == 0)
{
uint64_t v___x_220_; uint64_t v___x_221_; uint64_t v___x_222_; lean_object* v___x_223_; 
lean_dec_ref_known(v___x_219_, 1);
v___x_220_ = 32768ULL;
v___x_221_ = 48ULL;
v___x_222_ = 42ULL;
v___x_223_ = vastitas_storage_regroup3(v_a_150_, v___x_210_, v___x_169_, v___x_200_, v___x_191_, v___x_200_, v___x_171_, v___x_206_, v___x_169_, v___x_220_, v___x_190_, v___x_220_, v___x_171_, v___x_175_, v___x_190_, v___x_191_, v___x_221_, v___x_222_);
if (lean_obj_tag(v___x_223_) == 0)
{
lean_object* v___x_224_; 
lean_dec_ref_known(v___x_223_, 1);
v___x_224_ = vastitas_gemm_execute(v_a_150_, v___x_206_, v___x_169_, v___x_220_, v___x_190_, v___x_220_, v___x_171_, v___x_171_, v___x_199_, v___x_169_, v___x_190_, v___x_175_, v___x_190_, v___x_171_, v___x_171_, v___x_213_, v___x_169_, v___x_220_, v___x_175_, v___x_220_, v___x_171_, v___x_218_);
if (lean_obj_tag(v___x_224_) == 0)
{
uint64_t v___x_225_; uint64_t v___x_226_; lean_object* v___x_227_; 
lean_dec_ref_known(v___x_224_, 1);
v___x_225_ = 4590293920197378049ULL;
v___x_226_ = 4591701295080931328ULL;
v___x_227_ = vastitas_storage_expect(v_a_150_, v___x_213_, v___x_169_, v___x_220_, v___x_175_, v___x_220_, v___x_171_, v___x_169_, v___x_169_, v___x_166_, v___x_225_, v___x_226_);
if (lean_obj_tag(v___x_227_) == 0)
{
uint64_t v___x_228_; uint64_t v___x_229_; lean_object* v___x_230_; 
lean_dec_ref_known(v___x_227_, 1);
v___x_228_ = 4594797519824748544ULL;
v___x_229_ = 13829885952585105408ULL;
v___x_230_ = vastitas_storage_expect(v_a_150_, v___x_213_, v___x_169_, v___x_220_, v___x_175_, v___x_220_, v___x_171_, v___x_183_, v___x_183_, v___x_166_, v___x_228_, v___x_229_);
if (lean_obj_tag(v___x_230_) == 0)
{
uint64_t v___x_231_; uint64_t v___x_232_; uint64_t v___x_233_; lean_object* v___x_234_; 
lean_dec_ref_known(v___x_230_, 1);
v___x_231_ = 32767ULL;
v___x_232_ = 13810288257331625984ULL;
v___x_233_ = 13816199231842549760ULL;
v___x_234_ = vastitas_storage_expect(v_a_150_, v___x_213_, v___x_169_, v___x_220_, v___x_175_, v___x_220_, v___x_171_, v___x_231_, v___x_169_, v___x_166_, v___x_232_, v___x_233_);
if (lean_obj_tag(v___x_234_) == 0)
{
lean_object* v___x_235_; 
lean_dec_ref_known(v___x_234_, 1);
v___x_235_ = vastitas_storage_drop(v_a_150_, v___x_213_);
if (lean_obj_tag(v___x_235_) == 0)
{
lean_object* v___x_236_; 
lean_dec_ref_known(v___x_235_, 1);
v___x_236_ = vastitas_storage_drop(v_a_150_, v___x_210_);
if (lean_obj_tag(v___x_236_) == 0)
{
lean_object* v___x_237_; 
lean_dec_ref_known(v___x_236_, 1);
v___x_237_ = vastitas_storage_drop(v_a_150_, v___x_206_);
if (lean_obj_tag(v___x_237_) == 0)
{
lean_object* v___x_238_; 
lean_dec_ref_known(v___x_237_, 1);
v___x_238_ = vastitas_storage_drop(v_a_150_, v___x_199_);
if (lean_obj_tag(v___x_238_) == 0)
{
lean_object* v___x_239_; 
lean_dec_ref_known(v___x_238_, 1);
v___x_239_ = vastitas_storage_drop(v_a_150_, v___x_186_);
if (lean_obj_tag(v___x_239_) == 0)
{
lean_object* v___x_240_; 
lean_dec_ref_known(v___x_239_, 1);
v___x_240_ = vastitas_storage_drop(v_a_150_, v___x_165_);
if (lean_obj_tag(v___x_240_) == 0)
{
lean_object* v___x_241_; 
lean_dec_ref_known(v___x_240_, 1);
v___x_241_ = vastitas_storage_close(v_a_150_);
lean_dec(v_a_150_);
return v___x_241_;
}
else
{
v___y_152_ = v___x_240_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_239_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_238_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_237_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_236_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_235_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_234_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_230_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_227_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_224_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_223_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_219_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_217_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_216_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_215_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_212_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_211_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_209_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_208_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_205_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_204_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_203_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_202_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_201_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_198_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_196_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_193_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_189_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_188_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_185_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_182_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_179_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_174_;
goto v___jp_151_;
}
}
else
{
v___y_152_ = v___x_168_;
goto v___jp_151_;
}
v___jp_151_:
{
if (lean_obj_tag(v___y_152_) == 0)
{
lean_object* v___x_153_; 
lean_dec_ref_known(v___y_152_, 1);
v___x_153_ = vastitas_storage_close(v_a_150_);
lean_dec(v_a_150_);
return v___x_153_;
}
else
{
lean_object* v_a_154_; lean_object* v___x_155_; 
v_a_154_ = lean_ctor_get(v___y_152_, 0);
lean_inc(v_a_154_);
lean_dec_ref_known(v___y_152_, 1);
v___x_155_ = vastitas_storage_close(v_a_150_);
if (lean_obj_tag(v___x_155_) == 0)
{
lean_object* v___x_157_; uint8_t v_isShared_158_; uint8_t v_isSharedCheck_162_; 
lean_dec(v_a_150_);
v_isSharedCheck_162_ = !lean_is_exclusive(v___x_155_);
if (v_isSharedCheck_162_ == 0)
{
lean_object* v_unused_163_; 
v_unused_163_ = lean_ctor_get(v___x_155_, 0);
lean_dec(v_unused_163_);
v___x_157_ = v___x_155_;
v_isShared_158_ = v_isSharedCheck_162_;
goto v_resetjp_156_;
}
else
{
lean_dec(v___x_155_);
v___x_157_ = lean_box(0);
v_isShared_158_ = v_isSharedCheck_162_;
goto v_resetjp_156_;
}
v_resetjp_156_:
{
lean_object* v___x_160_; 
if (v_isShared_158_ == 0)
{
lean_ctor_set_tag(v___x_157_, 1);
lean_ctor_set(v___x_157_, 0, v_a_154_);
v___x_160_ = v___x_157_;
goto v_reusejp_159_;
}
else
{
lean_object* v_reuseFailAlloc_161_; 
v_reuseFailAlloc_161_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_161_, 0, v_a_154_);
v___x_160_ = v_reuseFailAlloc_161_;
goto v_reusejp_159_;
}
v_reusejp_159_:
{
return v___x_160_;
}
}
}
else
{
lean_dec(v_a_154_);
if (lean_obj_tag(v___x_155_) == 0)
{
lean_object* v___x_164_; 
lean_dec_ref_known(v___x_155_, 1);
v___x_164_ = vastitas_storage_close(v_a_150_);
lean_dec(v_a_150_);
return v___x_164_;
}
else
{
lean_dec(v_a_150_);
return v___x_155_;
}
}
}
}
}
else
{
lean_object* v_a_242_; lean_object* v___x_244_; uint8_t v_isShared_245_; uint8_t v_isSharedCheck_249_; 
v_a_242_ = lean_ctor_get(v___x_149_, 0);
v_isSharedCheck_249_ = !lean_is_exclusive(v___x_149_);
if (v_isSharedCheck_249_ == 0)
{
v___x_244_ = v___x_149_;
v_isShared_245_ = v_isSharedCheck_249_;
goto v_resetjp_243_;
}
else
{
lean_inc(v_a_242_);
lean_dec(v___x_149_);
v___x_244_ = lean_box(0);
v_isShared_245_ = v_isSharedCheck_249_;
goto v_resetjp_243_;
}
v_resetjp_243_:
{
lean_object* v___x_247_; 
if (v_isShared_245_ == 0)
{
v___x_247_ = v___x_244_;
goto v_reusejp_246_;
}
else
{
lean_object* v_reuseFailAlloc_248_; 
v_reuseFailAlloc_248_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_248_, 0, v_a_242_);
v___x_247_ = v_reuseFailAlloc_248_;
goto v_reusejp_246_;
}
v_reusejp_246_:
{
return v___x_247_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object* v_a_250_){
_start:
{
lean_object* v_res_251_; 
v_res_251_ = lp_allocation__audit_generatedFailure();
return v_res_251_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object* v_phase_254_, lean_object* v_a_00___x40___internal___hyg_255_){
_start:
{
uint32_t v_phase_boxed_256_; lean_object* v_res_257_; 
v_phase_boxed_256_ = lean_unbox_uint32(v_phase_254_);
lean_dec(v_phase_254_);
v_res_257_ = audit_mark_lean(v_phase_boxed_256_);
return v_res_257_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object* v_a_258_, lean_object* v_scope_259_, lean_object* v_range_260_, lean_object* v_b_261_, lean_object* v_i_262_){
_start:
{
lean_object* v_stop_264_; lean_object* v_step_265_; uint8_t v___x_266_; 
v_stop_264_ = lean_ctor_get(v_range_260_, 1);
v_step_265_ = lean_ctor_get(v_range_260_, 2);
v___x_266_ = lean_nat_dec_lt(v_i_262_, v_stop_264_);
if (v___x_266_ == 0)
{
lean_object* v___x_267_; 
lean_dec(v_i_262_);
v___x_267_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_267_, 0, v_b_261_);
return v___x_267_;
}
else
{
uint32_t v___x_268_; uint64_t v___x_269_; uint64_t v___x_270_; uint64_t v___x_271_; lean_object* v___x_272_; uint8_t v___x_273_; uint32_t v___x_274_; uint64_t v___x_275_; uint64_t v___x_276_; uint32_t v___x_277_; uint64_t v___x_278_; uint32_t v___x_279_; uint32_t v___x_280_; uint32_t v___x_281_; lean_object* v___x_282_; lean_object* v___x_283_; 
v___x_268_ = 0;
v___x_269_ = 0ULL;
v___x_270_ = 512ULL;
v___x_271_ = 4ULL;
v___x_272_ = lean_unsigned_to_nat(0u);
v___x_273_ = lean_nat_dec_eq(v_scope_259_, v___x_272_);
v___x_274_ = 3;
v___x_275_ = 1024ULL;
v___x_276_ = 2ULL;
v___x_277_ = 1;
v___x_278_ = 64ULL;
v___x_279_ = 4;
v___x_280_ = 2;
v___x_281_ = 5;
v___x_282_ = lean_box(0);
v___x_283_ = vastitas_storage_pack3(v_a_258_, v___x_268_, v___x_269_, v___x_270_, v___x_271_, v___x_270_, v___x_273_, v___x_274_, v___x_269_, v___x_275_, v___x_276_, v___x_275_, v___x_273_, v___x_270_, v___x_276_, v___x_276_);
if (lean_obj_tag(v___x_283_) == 0)
{
uint8_t v___x_284_; lean_object* v___x_285_; 
lean_dec_ref_known(v___x_283_, 1);
v___x_284_ = 0;
v___x_285_ = vastitas_gemm_execute(v_a_258_, v___x_274_, v___x_269_, v___x_275_, v___x_276_, v___x_275_, v___x_273_, v___x_273_, v___x_277_, v___x_269_, v___x_276_, v___x_278_, v___x_276_, v___x_273_, v___x_273_, v___x_279_, v___x_269_, v___x_275_, v___x_278_, v___x_275_, v___x_273_, v___x_284_);
if (lean_obj_tag(v___x_285_) == 0)
{
uint64_t v___x_286_; uint64_t v___x_287_; uint64_t v___x_288_; lean_object* v___x_289_; 
lean_dec_ref_known(v___x_285_, 1);
v___x_286_ = 32768ULL;
v___x_287_ = 48ULL;
v___x_288_ = 42ULL;
v___x_289_ = vastitas_storage_regroup3(v_a_258_, v___x_279_, v___x_269_, v___x_275_, v___x_278_, v___x_275_, v___x_273_, v___x_274_, v___x_269_, v___x_286_, v___x_276_, v___x_286_, v___x_273_, v___x_270_, v___x_276_, v___x_278_, v___x_287_, v___x_288_);
if (lean_obj_tag(v___x_289_) == 0)
{
lean_object* v___x_290_; 
lean_dec_ref_known(v___x_289_, 1);
v___x_290_ = vastitas_gemm_execute(v_a_258_, v___x_274_, v___x_269_, v___x_286_, v___x_276_, v___x_286_, v___x_273_, v___x_273_, v___x_280_, v___x_269_, v___x_276_, v___x_270_, v___x_276_, v___x_273_, v___x_273_, v___x_281_, v___x_269_, v___x_286_, v___x_270_, v___x_286_, v___x_273_, v___x_284_);
if (lean_obj_tag(v___x_290_) == 0)
{
lean_object* v___x_291_; 
lean_dec_ref_known(v___x_290_, 1);
v___x_291_ = lean_nat_add(v_i_262_, v_step_265_);
lean_dec(v_i_262_);
v_b_261_ = v___x_282_;
v_i_262_ = v___x_291_;
goto _start;
}
else
{
lean_dec(v_i_262_);
return v___x_290_;
}
}
else
{
lean_dec(v_i_262_);
return v___x_289_;
}
}
else
{
lean_dec(v_i_262_);
return v___x_285_;
}
}
else
{
lean_dec(v_i_262_);
return v___x_283_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object* v_a_293_, lean_object* v_scope_294_, lean_object* v_range_295_, lean_object* v_b_296_, lean_object* v_i_297_, lean_object* v___y_298_){
_start:
{
lean_object* v_res_299_; 
v_res_299_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_293_, v_scope_294_, v_range_295_, v_b_296_, v_i_297_);
lean_dec_ref(v_range_295_);
lean_dec(v_scope_294_);
lean_dec(v_a_293_);
return v_res_299_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object* v_range_300_, lean_object* v_b_301_, lean_object* v_i_302_){
_start:
{
lean_object* v_stop_304_; lean_object* v_step_305_; uint8_t v___x_306_; 
v_stop_304_ = lean_ctor_get(v_range_300_, 1);
v_step_305_ = lean_ctor_get(v_range_300_, 2);
v___x_306_ = lean_nat_dec_lt(v_i_302_, v_stop_304_);
if (v___x_306_ == 0)
{
lean_object* v___x_307_; 
lean_dec(v_i_302_);
v___x_307_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_307_, 0, v_b_301_);
return v___x_307_;
}
else
{
lean_object* v___x_308_; lean_object* v___x_309_; 
v___x_308_ = lean_box(0);
v___x_309_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_309_) == 0)
{
lean_object* v___x_310_; 
lean_dec_ref_known(v___x_309_, 1);
v___x_310_ = lean_nat_add(v_i_302_, v_step_305_);
lean_dec(v_i_302_);
v_b_301_ = v___x_308_;
v_i_302_ = v___x_310_;
goto _start;
}
else
{
lean_dec(v_i_302_);
return v___x_309_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object* v_range_312_, lean_object* v_b_313_, lean_object* v_i_314_, lean_object* v___y_315_){
_start:
{
lean_object* v_res_316_; 
v_res_316_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_312_, v_b_313_, v_i_314_);
lean_dec_ref(v_range_312_);
return v_res_316_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_325_){
_start:
{
lean_object* v___x_327_; lean_object* v___x_328_; lean_object* v_impl_329_; lean_object* v___x_330_; lean_object* v___x_331_; lean_object* v___x_332_; lean_object* v___x_333_; lean_object* v_scope_334_; lean_object* v___x_335_; lean_object* v___x_336_; lean_object* v___x_337_; lean_object* v___x_338_; lean_object* v_reps_339_; lean_object* v___x_340_; lean_object* v___x_341_; lean_object* v___x_342_; uint8_t v_verify_343_; uint32_t v___x_344_; lean_object* v___x_345_; 
v___x_327_ = ((lean_object*)(lp_allocation__audit_main___closed__0));
v___x_328_ = lean_unsigned_to_nat(0u);
v_impl_329_ = l_List_get_x21Internal___redArg(v___x_327_, v_args_325_, v___x_328_);
v___x_330_ = lean_unsigned_to_nat(1u);
v___x_331_ = l_List_get_x21Internal___redArg(v___x_327_, v_args_325_, v___x_330_);
v___x_332_ = lean_string_utf8_byte_size(v___x_331_);
v___x_333_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_333_, 0, v___x_331_);
lean_ctor_set(v___x_333_, 1, v___x_328_);
lean_ctor_set(v___x_333_, 2, v___x_332_);
v_scope_334_ = l_String_Slice_toNat_x21(v___x_333_);
lean_dec_ref_known(v___x_333_, 3);
v___x_335_ = lean_unsigned_to_nat(2u);
v___x_336_ = l_List_get_x21Internal___redArg(v___x_327_, v_args_325_, v___x_335_);
v___x_337_ = lean_string_utf8_byte_size(v___x_336_);
v___x_338_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_338_, 0, v___x_336_);
lean_ctor_set(v___x_338_, 1, v___x_328_);
lean_ctor_set(v___x_338_, 2, v___x_337_);
v_reps_339_ = l_String_Slice_toNat_x21(v___x_338_);
lean_dec_ref_known(v___x_338_, 3);
v___x_340_ = lean_unsigned_to_nat(3u);
v___x_341_ = l_List_get_x21Internal___redArg(v___x_327_, v_args_325_, v___x_340_);
lean_dec(v_args_325_);
v___x_342_ = ((lean_object*)(lp_allocation__audit_main___closed__1));
v_verify_343_ = lean_string_dec_eq(v___x_341_, v___x_342_);
lean_dec(v___x_341_);
v___x_344_ = 1;
v___x_345_ = audit_mark_lean(v___x_344_);
if (lean_obj_tag(v___x_345_) == 0)
{
lean_object* v___x_346_; 
lean_dec_ref_known(v___x_345_, 1);
v___x_346_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_346_) == 0)
{
uint32_t v___x_347_; lean_object* v___x_348_; 
lean_dec_ref_known(v___x_346_, 1);
v___x_347_ = 2;
v___x_348_ = audit_mark_lean(v___x_347_);
if (lean_obj_tag(v___x_348_) == 0)
{
lean_object* v___x_349_; uint8_t v___x_350_; 
lean_dec_ref_known(v___x_348_, 1);
v___x_349_ = ((lean_object*)(lp_allocation__audit_main___closed__2));
v___x_350_ = lean_string_dec_eq(v_impl_329_, v___x_349_);
if (v___x_350_ == 0)
{
lean_object* v___x_351_; uint8_t v___x_352_; 
v___x_351_ = ((lean_object*)(lp_allocation__audit_main___closed__3));
v___x_352_ = lean_string_dec_eq(v_impl_329_, v___x_351_);
lean_dec(v_impl_329_);
if (v___x_352_ == 0)
{
uint8_t v___x_353_; 
v___x_353_ = lean_nat_dec_eq(v_scope_334_, v___x_328_);
if (v___x_353_ == 0)
{
uint64_t v___x_354_; lean_object* v___x_355_; 
v___x_354_ = 9223372036854775807ULL;
v___x_355_ = vastitas_storage_new(v___x_354_);
if (lean_obj_tag(v___x_355_) == 0)
{
lean_object* v_a_356_; lean_object* v___y_361_; uint32_t v___x_372_; uint8_t v___x_373_; uint64_t v___x_374_; lean_object* v___x_375_; 
v_a_356_ = lean_ctor_get(v___x_355_, 0);
lean_inc(v_a_356_);
lean_dec_ref_known(v___x_355_, 1);
v___x_372_ = 0;
v___x_373_ = 1;
v___x_374_ = 2048ULL;
v___x_375_ = vastitas_storage_allocate(v_a_356_, v___x_372_, v___x_373_, v___x_374_);
if (lean_obj_tag(v___x_375_) == 0)
{
uint64_t v___x_376_; uint64_t v___x_377_; uint64_t v___x_378_; uint64_t v___x_379_; lean_object* v___x_380_; 
lean_dec_ref_known(v___x_375_, 1);
v___x_376_ = 0ULL;
v___x_377_ = 1ULL;
v___x_378_ = 13842939354630062080ULL;
v___x_379_ = 4613937818241073152ULL;
v___x_380_ = vastitas_storage_fill(v_a_356_, v___x_372_, v___x_376_, v___x_374_, v___x_377_, v___x_374_, v___x_353_, v___x_373_, v___x_378_, v___x_379_);
if (lean_obj_tag(v___x_380_) == 0)
{
uint64_t v___x_381_; uint64_t v___x_382_; uint64_t v___x_383_; uint64_t v___x_384_; lean_object* v___x_385_; 
lean_dec_ref_known(v___x_380_, 1);
v___x_381_ = 512ULL;
v___x_382_ = 4ULL;
v___x_383_ = 4593671619917905920ULL;
v___x_384_ = 4598175219545276416ULL;
v___x_385_ = vastitas_storage_fill(v_a_356_, v___x_372_, v___x_376_, v___x_381_, v___x_382_, v___x_381_, v___x_353_, v___x_373_, v___x_383_, v___x_384_);
if (lean_obj_tag(v___x_385_) == 0)
{
uint64_t v___x_386_; uint64_t v___x_387_; lean_object* v___x_388_; 
lean_dec_ref_known(v___x_385_, 1);
v___x_386_ = 4607182418800017408ULL;
v___x_387_ = 13826050856027422720ULL;
v___x_388_ = vastitas_storage_store(v_a_356_, v___x_372_, v___x_376_, v___x_381_, v___x_382_, v___x_381_, v___x_353_, v___x_376_, v___x_376_, v___x_373_, v___x_386_, v___x_387_);
if (lean_obj_tag(v___x_388_) == 0)
{
uint64_t v___x_389_; uint64_t v___x_390_; lean_object* v___x_391_; 
lean_dec_ref_known(v___x_388_, 1);
v___x_389_ = 511ULL;
v___x_390_ = 4604930618986332160ULL;
v___x_391_ = vastitas_storage_store(v_a_356_, v___x_372_, v___x_376_, v___x_381_, v___x_382_, v___x_381_, v___x_353_, v___x_389_, v___x_377_, v___x_373_, v___x_387_, v___x_390_);
if (lean_obj_tag(v___x_391_) == 0)
{
uint64_t v___x_392_; lean_object* v___x_393_; 
lean_dec_ref_known(v___x_391_, 1);
v___x_392_ = 128ULL;
v___x_393_ = vastitas_storage_allocate(v_a_356_, v___x_344_, v___x_373_, v___x_392_);
if (lean_obj_tag(v___x_393_) == 0)
{
lean_object* v___x_394_; 
lean_dec_ref_known(v___x_393_, 1);
v___x_394_ = vastitas_storage_fill(v_a_356_, v___x_344_, v___x_376_, v___x_392_, v___x_377_, v___x_392_, v___x_353_, v___x_373_, v___x_378_, v___x_379_);
if (lean_obj_tag(v___x_394_) == 0)
{
uint64_t v___x_395_; uint64_t v___x_396_; uint64_t v___x_397_; lean_object* v___x_398_; 
lean_dec_ref_known(v___x_394_, 1);
v___x_395_ = 2ULL;
v___x_396_ = 64ULL;
v___x_397_ = 13821547256400052224ULL;
v___x_398_ = vastitas_storage_fill(v_a_356_, v___x_344_, v___x_376_, v___x_395_, v___x_396_, v___x_395_, v___x_353_, v___x_373_, v___x_397_, v___x_383_);
if (lean_obj_tag(v___x_398_) == 0)
{
uint64_t v___x_399_; uint64_t v___x_400_; lean_object* v___x_401_; 
lean_dec_ref_known(v___x_398_, 1);
v___x_399_ = 63ULL;
v___x_400_ = 4602678819172646912ULL;
v___x_401_ = vastitas_storage_store(v_a_356_, v___x_344_, v___x_376_, v___x_395_, v___x_396_, v___x_395_, v___x_353_, v___x_376_, v___x_399_, v___x_373_, v___x_400_, v___x_384_);
if (lean_obj_tag(v___x_401_) == 0)
{
uint64_t v___x_402_; lean_object* v___x_403_; 
lean_dec_ref_known(v___x_401_, 1);
v___x_402_ = 13828302655841107968ULL;
v___x_403_ = vastitas_storage_store(v_a_356_, v___x_344_, v___x_376_, v___x_395_, v___x_396_, v___x_395_, v___x_353_, v___x_377_, v___x_376_, v___x_373_, v___x_402_, v___x_387_);
if (lean_obj_tag(v___x_403_) == 0)
{
uint64_t v___x_404_; lean_object* v___x_405_; 
lean_dec_ref_known(v___x_403_, 1);
v___x_404_ = 1024ULL;
v___x_405_ = vastitas_storage_allocate(v_a_356_, v___x_347_, v___x_373_, v___x_404_);
if (lean_obj_tag(v___x_405_) == 0)
{
lean_object* v___x_406_; 
lean_dec_ref_known(v___x_405_, 1);
v___x_406_ = vastitas_storage_fill(v_a_356_, v___x_347_, v___x_376_, v___x_404_, v___x_377_, v___x_404_, v___x_353_, v___x_373_, v___x_378_, v___x_379_);
if (lean_obj_tag(v___x_406_) == 0)
{
lean_object* v___x_407_; 
lean_dec_ref_known(v___x_406_, 1);
v___x_407_ = vastitas_storage_fill(v_a_356_, v___x_347_, v___x_376_, v___x_395_, v___x_381_, v___x_395_, v___x_353_, v___x_373_, v___x_400_, v___x_397_);
if (lean_obj_tag(v___x_407_) == 0)
{
lean_object* v___x_408_; 
lean_dec_ref_known(v___x_407_, 1);
v___x_408_ = vastitas_storage_store(v_a_356_, v___x_347_, v___x_376_, v___x_395_, v___x_381_, v___x_395_, v___x_353_, v___x_377_, v___x_376_, v___x_373_, v___x_397_, v___x_400_);
if (lean_obj_tag(v___x_408_) == 0)
{
lean_object* v___x_409_; 
lean_dec_ref_known(v___x_408_, 1);
v___x_409_ = vastitas_storage_store(v_a_356_, v___x_347_, v___x_376_, v___x_395_, v___x_381_, v___x_395_, v___x_353_, v___x_376_, v___x_389_, v___x_373_, v___x_390_, v___x_402_);
if (lean_obj_tag(v___x_409_) == 0)
{
uint32_t v___x_410_; uint64_t v___x_411_; lean_object* v___x_412_; 
lean_dec_ref_known(v___x_409_, 1);
v___x_410_ = 3;
v___x_411_ = 65536ULL;
v___x_412_ = vastitas_storage_allocate(v_a_356_, v___x_410_, v___x_373_, v___x_411_);
if (lean_obj_tag(v___x_412_) == 0)
{
lean_object* v___x_413_; 
lean_dec_ref_known(v___x_412_, 1);
v___x_413_ = vastitas_storage_fill(v_a_356_, v___x_410_, v___x_376_, v___x_411_, v___x_377_, v___x_411_, v___x_353_, v___x_373_, v___x_378_, v___x_379_);
if (lean_obj_tag(v___x_413_) == 0)
{
uint32_t v___x_414_; lean_object* v___x_415_; 
lean_dec_ref_known(v___x_413_, 1);
v___x_414_ = 4;
v___x_415_ = vastitas_storage_allocate(v_a_356_, v___x_414_, v___x_373_, v___x_411_);
if (lean_obj_tag(v___x_415_) == 0)
{
lean_object* v___x_416_; 
lean_dec_ref_known(v___x_415_, 1);
v___x_416_ = vastitas_storage_fill(v_a_356_, v___x_414_, v___x_376_, v___x_411_, v___x_377_, v___x_411_, v___x_353_, v___x_373_, v___x_378_, v___x_379_);
if (lean_obj_tag(v___x_416_) == 0)
{
uint32_t v___x_417_; uint64_t v___x_418_; lean_object* v___x_419_; 
lean_dec_ref_known(v___x_416_, 1);
v___x_417_ = 5;
v___x_418_ = 16777216ULL;
v___x_419_ = vastitas_storage_allocate(v_a_356_, v___x_417_, v___x_373_, v___x_418_);
if (lean_obj_tag(v___x_419_) == 0)
{
lean_object* v___x_420_; 
lean_dec_ref_known(v___x_419_, 1);
v___x_420_ = vastitas_storage_fill(v_a_356_, v___x_417_, v___x_376_, v___x_418_, v___x_377_, v___x_418_, v___x_353_, v___x_373_, v___x_378_, v___x_379_);
if (lean_obj_tag(v___x_420_) == 0)
{
uint32_t v___x_421_; uint64_t v___x_422_; lean_object* v___x_423_; 
lean_dec_ref_known(v___x_420_, 1);
v___x_421_ = lean_uint32_of_nat(v_scope_334_);
v___x_422_ = lean_uint64_of_nat(v_reps_339_);
v___x_423_ = bench_begin_lean(v___x_421_, v___x_422_, v_verify_343_);
if (lean_obj_tag(v___x_423_) == 0)
{
lean_object* v___x_424_; lean_object* v___x_425_; lean_object* v___x_426_; 
lean_dec_ref_known(v___x_423_, 1);
v___x_424_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_424_, 0, v___x_328_);
lean_ctor_set(v___x_424_, 1, v_reps_339_);
lean_ctor_set(v___x_424_, 2, v___x_330_);
v___x_425_ = lean_box(0);
v___x_426_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_356_, v_scope_334_, v___x_424_, v___x_425_, v___x_328_);
lean_dec_ref_known(v___x_424_, 3);
lean_dec(v_scope_334_);
if (lean_obj_tag(v___x_426_) == 0)
{
lean_object* v___x_427_; 
lean_dec_ref_known(v___x_426_, 1);
v___x_427_ = bench_stop_lean();
if (lean_obj_tag(v___x_427_) == 0)
{
lean_object* v___x_428_; 
lean_dec_ref_known(v___x_427_, 1);
v___x_428_ = bench_verify_lean(v_a_356_, v___x_422_);
if (lean_obj_tag(v___x_428_) == 0)
{
uint64_t v___x_429_; uint64_t v___x_430_; uint64_t v___x_431_; lean_object* v___x_432_; 
lean_dec_ref_known(v___x_428_, 1);
v___x_429_ = 32768ULL;
v___x_430_ = 4590293920197378048ULL;
v___x_431_ = 4591701295080931328ULL;
v___x_432_ = vastitas_storage_expect(v_a_356_, v___x_417_, v___x_376_, v___x_429_, v___x_381_, v___x_429_, v___x_353_, v___x_376_, v___x_376_, v___x_373_, v___x_430_, v___x_431_);
if (lean_obj_tag(v___x_432_) == 0)
{
uint64_t v___x_433_; uint64_t v___x_434_; lean_object* v___x_435_; 
lean_dec_ref_known(v___x_432_, 1);
v___x_433_ = 4594797519824748544ULL;
v___x_434_ = 13829885952585105408ULL;
v___x_435_ = vastitas_storage_expect(v_a_356_, v___x_417_, v___x_376_, v___x_429_, v___x_381_, v___x_429_, v___x_353_, v___x_389_, v___x_389_, v___x_373_, v___x_433_, v___x_434_);
if (lean_obj_tag(v___x_435_) == 0)
{
uint64_t v___x_436_; uint64_t v___x_437_; uint64_t v___x_438_; lean_object* v___x_439_; 
lean_dec_ref_known(v___x_435_, 1);
v___x_436_ = 32767ULL;
v___x_437_ = 13810288257331625984ULL;
v___x_438_ = 13816199231842549760ULL;
v___x_439_ = vastitas_storage_expect(v_a_356_, v___x_417_, v___x_376_, v___x_429_, v___x_381_, v___x_429_, v___x_353_, v___x_436_, v___x_376_, v___x_373_, v___x_437_, v___x_438_);
if (lean_obj_tag(v___x_439_) == 0)
{
lean_object* v___x_440_; 
lean_dec_ref_known(v___x_439_, 1);
v___x_440_ = vastitas_storage_drop(v_a_356_, v___x_417_);
if (lean_obj_tag(v___x_440_) == 0)
{
lean_object* v___x_441_; 
lean_dec_ref_known(v___x_440_, 1);
v___x_441_ = vastitas_storage_drop(v_a_356_, v___x_414_);
if (lean_obj_tag(v___x_441_) == 0)
{
lean_object* v___x_442_; 
lean_dec_ref_known(v___x_441_, 1);
v___x_442_ = vastitas_storage_drop(v_a_356_, v___x_410_);
if (lean_obj_tag(v___x_442_) == 0)
{
lean_object* v___x_443_; 
lean_dec_ref_known(v___x_442_, 1);
v___x_443_ = vastitas_storage_drop(v_a_356_, v___x_347_);
if (lean_obj_tag(v___x_443_) == 0)
{
lean_object* v___x_444_; 
lean_dec_ref_known(v___x_443_, 1);
v___x_444_ = vastitas_storage_drop(v_a_356_, v___x_344_);
if (lean_obj_tag(v___x_444_) == 0)
{
lean_object* v___x_445_; 
lean_dec_ref_known(v___x_444_, 1);
v___x_445_ = vastitas_storage_drop(v_a_356_, v___x_372_);
v___y_361_ = v___x_445_;
goto v___jp_360_;
}
else
{
v___y_361_ = v___x_444_;
goto v___jp_360_;
}
}
else
{
v___y_361_ = v___x_443_;
goto v___jp_360_;
}
}
else
{
v___y_361_ = v___x_442_;
goto v___jp_360_;
}
}
else
{
v___y_361_ = v___x_441_;
goto v___jp_360_;
}
}
else
{
v___y_361_ = v___x_440_;
goto v___jp_360_;
}
}
else
{
v___y_361_ = v___x_439_;
goto v___jp_360_;
}
}
else
{
v___y_361_ = v___x_435_;
goto v___jp_360_;
}
}
else
{
v___y_361_ = v___x_432_;
goto v___jp_360_;
}
}
else
{
v___y_361_ = v___x_428_;
goto v___jp_360_;
}
}
else
{
v___y_361_ = v___x_427_;
goto v___jp_360_;
}
}
else
{
v___y_361_ = v___x_426_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_423_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_420_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_419_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_416_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_415_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_413_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_412_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_409_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_408_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_407_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_406_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_405_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_403_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_401_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_398_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_394_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_393_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_391_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_388_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_385_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_380_;
goto v___jp_360_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v___y_361_ = v___x_375_;
goto v___jp_360_;
}
v___jp_357_:
{
lean_object* v___x_358_; 
v___x_358_ = vastitas_storage_close(v_a_356_);
lean_dec(v_a_356_);
if (lean_obj_tag(v___x_358_) == 0)
{
lean_object* v___x_359_; 
lean_dec_ref_known(v___x_358_, 1);
v___x_359_ = bench_report_lean();
return v___x_359_;
}
else
{
return v___x_358_;
}
}
v___jp_360_:
{
if (lean_obj_tag(v___y_361_) == 0)
{
lean_dec_ref_known(v___y_361_, 1);
goto v___jp_357_;
}
else
{
lean_object* v_a_362_; lean_object* v___x_363_; 
v_a_362_ = lean_ctor_get(v___y_361_, 0);
lean_inc(v_a_362_);
lean_dec_ref_known(v___y_361_, 1);
v___x_363_ = vastitas_storage_close(v_a_356_);
if (lean_obj_tag(v___x_363_) == 0)
{
lean_object* v___x_365_; uint8_t v_isShared_366_; uint8_t v_isSharedCheck_370_; 
lean_dec(v_a_356_);
v_isSharedCheck_370_ = !lean_is_exclusive(v___x_363_);
if (v_isSharedCheck_370_ == 0)
{
lean_object* v_unused_371_; 
v_unused_371_ = lean_ctor_get(v___x_363_, 0);
lean_dec(v_unused_371_);
v___x_365_ = v___x_363_;
v_isShared_366_ = v_isSharedCheck_370_;
goto v_resetjp_364_;
}
else
{
lean_dec(v___x_363_);
v___x_365_ = lean_box(0);
v_isShared_366_ = v_isSharedCheck_370_;
goto v_resetjp_364_;
}
v_resetjp_364_:
{
lean_object* v___x_368_; 
if (v_isShared_366_ == 0)
{
lean_ctor_set_tag(v___x_365_, 1);
lean_ctor_set(v___x_365_, 0, v_a_362_);
v___x_368_ = v___x_365_;
goto v_reusejp_367_;
}
else
{
lean_object* v_reuseFailAlloc_369_; 
v_reuseFailAlloc_369_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_369_, 0, v_a_362_);
v___x_368_ = v_reuseFailAlloc_369_;
goto v_reusejp_367_;
}
v_reusejp_367_:
{
return v___x_368_;
}
}
}
else
{
lean_dec(v_a_362_);
if (lean_obj_tag(v___x_363_) == 0)
{
lean_dec_ref_known(v___x_363_, 1);
goto v___jp_357_;
}
else
{
lean_dec(v_a_356_);
return v___x_363_;
}
}
}
}
}
else
{
lean_object* v_a_446_; lean_object* v___x_448_; uint8_t v_isShared_449_; uint8_t v_isSharedCheck_453_; 
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
v_a_446_ = lean_ctor_get(v___x_355_, 0);
v_isSharedCheck_453_ = !lean_is_exclusive(v___x_355_);
if (v_isSharedCheck_453_ == 0)
{
v___x_448_ = v___x_355_;
v_isShared_449_ = v_isSharedCheck_453_;
goto v_resetjp_447_;
}
else
{
lean_inc(v_a_446_);
lean_dec(v___x_355_);
v___x_448_ = lean_box(0);
v_isShared_449_ = v_isSharedCheck_453_;
goto v_resetjp_447_;
}
v_resetjp_447_:
{
lean_object* v___x_451_; 
if (v_isShared_449_ == 0)
{
v___x_451_ = v___x_448_;
goto v_reusejp_450_;
}
else
{
lean_object* v_reuseFailAlloc_452_; 
v_reuseFailAlloc_452_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_452_, 0, v_a_446_);
v___x_451_ = v_reuseFailAlloc_452_;
goto v_reusejp_450_;
}
v_reusejp_450_:
{
return v___x_451_;
}
}
}
}
else
{
uint32_t v___x_454_; uint64_t v___x_455_; lean_object* v___x_456_; 
lean_dec(v_scope_334_);
v___x_454_ = 0;
v___x_455_ = lean_uint64_of_nat(v_reps_339_);
v___x_456_ = bench_begin_lean(v___x_454_, v___x_455_, v_verify_343_);
if (lean_obj_tag(v___x_456_) == 0)
{
lean_object* v___x_457_; lean_object* v___x_458_; lean_object* v___x_459_; 
lean_dec_ref_known(v___x_456_, 1);
v___x_457_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_457_, 0, v___x_328_);
lean_ctor_set(v___x_457_, 1, v_reps_339_);
lean_ctor_set(v___x_457_, 2, v___x_330_);
v___x_458_ = lean_box(0);
v___x_459_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v___x_457_, v___x_458_, v___x_328_);
lean_dec_ref_known(v___x_457_, 3);
if (lean_obj_tag(v___x_459_) == 0)
{
lean_object* v___x_460_; 
lean_dec_ref_known(v___x_459_, 1);
v___x_460_ = bench_stop_lean();
if (lean_obj_tag(v___x_460_) == 0)
{
lean_object* v___x_461_; 
lean_dec_ref_known(v___x_460_, 1);
v___x_461_ = bench_report_lean();
return v___x_461_;
}
else
{
return v___x_460_;
}
}
else
{
return v___x_459_;
}
}
else
{
lean_dec(v_reps_339_);
return v___x_456_;
}
}
}
else
{
uint32_t v___x_462_; uint64_t v___x_463_; lean_object* v___x_464_; 
v___x_462_ = lean_uint32_of_nat(v_scope_334_);
lean_dec(v_scope_334_);
v___x_463_ = lean_uint64_of_nat(v_reps_339_);
lean_dec(v_reps_339_);
v___x_464_ = bench_c_run_lean(v___x_462_, v___x_463_, v_verify_343_);
if (lean_obj_tag(v___x_464_) == 0)
{
lean_object* v___x_465_; 
lean_dec_ref_known(v___x_464_, 1);
v___x_465_ = bench_report_lean();
return v___x_465_;
}
else
{
return v___x_464_;
}
}
}
else
{
uint32_t v___x_466_; uint64_t v___x_467_; lean_object* v___x_468_; 
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
lean_dec(v_impl_329_);
v___x_466_ = 0;
v___x_467_ = 1ULL;
v___x_468_ = bench_begin_lean(v___x_466_, v___x_467_, v___x_350_);
if (lean_obj_tag(v___x_468_) == 0)
{
lean_object* v___x_469_; 
lean_dec_ref_known(v___x_468_, 1);
v___x_469_ = lp_allocation__audit_generatedFailure();
if (lean_obj_tag(v___x_469_) == 0)
{
lean_object* v___x_471_; uint8_t v_isShared_472_; uint8_t v_isSharedCheck_477_; 
v_isSharedCheck_477_ = !lean_is_exclusive(v___x_469_);
if (v_isSharedCheck_477_ == 0)
{
lean_object* v_unused_478_; 
v_unused_478_ = lean_ctor_get(v___x_469_, 0);
lean_dec(v_unused_478_);
v___x_471_ = v___x_469_;
v_isShared_472_ = v_isSharedCheck_477_;
goto v_resetjp_470_;
}
else
{
lean_dec(v___x_469_);
v___x_471_ = lean_box(0);
v_isShared_472_ = v_isSharedCheck_477_;
goto v_resetjp_470_;
}
v_resetjp_470_:
{
lean_object* v___x_473_; lean_object* v___x_475_; 
v___x_473_ = ((lean_object*)(lp_allocation__audit_main___closed__5));
if (v_isShared_472_ == 0)
{
lean_ctor_set_tag(v___x_471_, 1);
lean_ctor_set(v___x_471_, 0, v___x_473_);
v___x_475_ = v___x_471_;
goto v_reusejp_474_;
}
else
{
lean_object* v_reuseFailAlloc_476_; 
v_reuseFailAlloc_476_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_476_, 0, v___x_473_);
v___x_475_ = v_reuseFailAlloc_476_;
goto v_reusejp_474_;
}
v_reusejp_474_:
{
return v___x_475_;
}
}
}
else
{
lean_object* v_a_479_; lean_object* v___x_480_; lean_object* v___x_481_; uint8_t v___x_482_; 
v_a_479_ = lean_ctor_get(v___x_469_, 0);
lean_inc(v_a_479_);
v___x_480_ = lean_io_error_to_string(v_a_479_);
v___x_481_ = ((lean_object*)(lp_allocation__audit_main___closed__6));
v___x_482_ = lean_string_dec_eq(v___x_480_, v___x_481_);
lean_dec_ref(v___x_480_);
if (v___x_482_ == 0)
{
return v___x_469_;
}
else
{
lean_object* v___x_483_; 
lean_dec_ref_known(v___x_469_, 1);
v___x_483_ = bench_stop_lean();
if (lean_obj_tag(v___x_483_) == 0)
{
lean_object* v___x_484_; 
lean_dec_ref_known(v___x_483_, 1);
v___x_484_ = bench_report_lean();
return v___x_484_;
}
else
{
return v___x_483_;
}
}
}
}
else
{
return v___x_468_;
}
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
lean_dec(v_impl_329_);
return v___x_348_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
lean_dec(v_impl_329_);
return v___x_346_;
}
}
else
{
lean_dec(v_reps_339_);
lean_dec(v_scope_334_);
lean_dec(v_impl_329_);
return v___x_345_;
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object* v_args_485_, lean_object* v_a_486_){
_start:
{
lean_object* v_res_487_; 
v_res_487_ = _lean_main(v_args_485_);
return v_res_487_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object* v_a_488_, lean_object* v_scope_489_, lean_object* v_range_490_, lean_object* v_b_491_, lean_object* v_i_492_, lean_object* v_hs_493_, lean_object* v_hl_494_){
_start:
{
lean_object* v___x_496_; 
v___x_496_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_488_, v_scope_489_, v_range_490_, v_b_491_, v_i_492_);
return v___x_496_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object* v_a_497_, lean_object* v_scope_498_, lean_object* v_range_499_, lean_object* v_b_500_, lean_object* v_i_501_, lean_object* v_hs_502_, lean_object* v_hl_503_, lean_object* v___y_504_){
_start:
{
lean_object* v_res_505_; 
v_res_505_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(v_a_497_, v_scope_498_, v_range_499_, v_b_500_, v_i_501_, v_hs_502_, v_hl_503_);
lean_dec_ref(v_range_499_);
lean_dec(v_scope_498_);
lean_dec(v_a_497_);
return v_res_505_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object* v_range_506_, lean_object* v_b_507_, lean_object* v_i_508_, lean_object* v_hs_509_, lean_object* v_hl_510_){
_start:
{
lean_object* v___x_512_; 
v___x_512_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_506_, v_b_507_, v_i_508_);
return v___x_512_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object* v_range_513_, lean_object* v_b_514_, lean_object* v_i_515_, lean_object* v_hs_516_, lean_object* v_hl_517_, lean_object* v___y_518_){
_start:
{
lean_object* v_res_519_; 
v_res_519_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(v_range_513_, v_b_514_, v_i_515_, v_hs_516_, v_hl_517_);
lean_dec_ref(v_range_513_);
return v_res_519_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_vastitas__storage__native_VastitasStorageNative(uint8_t builtin);
lean_object* initialize_vastitas__gemm__native_VastitasGemmNative(uint8_t builtin);
lean_object* initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_allocation__audit_Main(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__storage__native_VastitasStorageNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__gemm__native_VastitasGemmNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_allocation__audit_VastitasGenerated_f__0 = _init_lp_allocation__audit_VastitasGenerated_f__0();
lean_mark_persistent(lp_allocation__audit_VastitasGenerated_f__0);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_allocation__audit_Main(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = 0;
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
