/* Fixture data independently constructed from cases.json. */
static const unsigned scalar = 1;
static const uint64_t dim_i=512, dim_k=2, dim_j=2, dim_a=64;
static const VStorageLayout views[7] = {{0,512,4,512,0},{0,2,64,2,0},{0,2,512,2,0},{0,1024,2,1024,0},{0,1024,64,1024,0},{0,32768,512,32768,0},{0,32768,2,32768,0}};
static const uint64_t elements[6] = {2048,128,1024,65536,65536,16777216};
static const double values[3][2] = {{0x1.0000000000000p-3,0x1.0000000000000p-2},{-0x1.0000000000000p-2,0x1.0000000000000p-3},{0x1.0000000000000p-1,-0x1.0000000000000p-2}};
static const double sentinel[2] = {-0x1.c000000000000p+2,0x1.8000000000000p+1};
static const double alpha[2] = {1,0}, beta[2] = {0,0};
typedef struct { uint64_t row, col; double value[2]; } Patch;
static const Patch patches[3][2] = {{{0,0,{0x1.0000000000000p+0,-0x1.0000000000000p-1}},{511,1,{-0x1.0000000000000p-1,0x1.8000000000000p-1}}},{{0,63,{0x1.0000000000000p-1,0x1.0000000000000p-2}},{1,0,{-0x1.8000000000000p-1,-0x1.0000000000000p-1}}},{{1,0,{-0x1.0000000000000p-2,0x1.0000000000000p-1}},{0,511,{0x1.8000000000000p-1,-0x1.8000000000000p-1}}}};
static const Patch expected[3] = {{0,0,{0x1.4000000000000p-4,0x1.9000000000000p-4}},{511,511,{0x1.4000000000000p-3,-0x1.da00000000000p-1}},{32767,0,{-0x1.8000000000000p-5,-0x1.d000000000000p-4}}};
