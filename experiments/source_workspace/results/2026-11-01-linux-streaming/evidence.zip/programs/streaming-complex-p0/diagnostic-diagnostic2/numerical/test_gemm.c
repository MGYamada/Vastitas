#include "gemm.h"
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

static uint64_t bits(double value) {
    uint64_t result;
    memcpy(&result, &value, sizeof(result));
    return result;
}
static VStorageLayout layout(uint64_t rows, uint64_t columns, int transpose, int padded) {
    uint64_t stored_rows = transpose ? columns : rows;
    return (VStorageLayout){padded ? 16 : 0, stored_rows,
        transpose ? rows : columns, (stored_rows ? stored_rows : 1) + (padded ? 2 : 0), (uint8_t)transpose};
}
static void allocate(VStorageArena *arena, uint32_t id, uint8_t scalar, VStorageLayout view) {
    assert(vstorage_allocate(arena, id, scalar, view.offset / (scalar ? 16 : 8) +
        view.leading * view.columns) == VS_OK);
}
static void put(VStorageArena *arena, uint32_t id, VStorageLayout view,
                uint64_t row, uint64_t column, uint8_t scalar, double real, double imaginary) {
    assert(vstorage_store(arena,id,view,row,column,scalar,bits(real),bits(imaginary)) == VS_OK);
}
static void expect(VStorageArena *arena, uint32_t id, VStorageLayout view,
                   uint64_t row, uint64_t column, double real, double imaginary) {
    VStorageDense actual;
    assert(vstorage_prepare_dense(arena,id,view,&actual) == VS_OK);
    uint64_t index = actual.transposed ? column + row * actual.leading : row + column * actual.leading;
    index *= actual.scalar ? 2 : 1;
    assert(actual.data[index] == real);
    if (actual.scalar) assert(actual.data[index+1] == imaginary);
}
static void cleanup(VStorageArena *arena) {
    vstorage_close(arena);
    VStorageStats stats = vstorage_stats(arena);
    assert(stats.live_bytes == 0 && stats.data_allocations == stats.data_frees);
    vstorage_delete(arena);
}

static void real_orientations(void) {
    const double left[2][3] = {{1,2,3},{4,5,6}};
    const double right[3][2] = {{7,8},{9,10},{11,12}};
    const double product[2][2] = {{58,64},{139,154}};
    for (int ta=0; ta<2; ++ta) for (int tb=0; tb<2; ++tb) for (int pad=0;pad<2;++pad)
    for (int ca=0; ca<2; ++ca) for (int cb=0; cb<2; ++cb) {
        VStorageArena *arena = vstorage_new(4096);
        assert(arena);
        VStorageLayout a=layout(2,3,ta,pad), b=layout(3,2,tb,pad), c=layout(2,2,0,pad);
        allocate(arena,0,0,a); allocate(arena,1,0,b); allocate(arena,2,0,c);
        for (int i=0;i<2;++i) for(int j=0;j<3;++j) put(arena,0,a,i,j,0,left[i][j],0);
        for (int i=0;i<3;++i) for(int j=0;j<2;++j) put(arena,1,b,i,j,0,right[i][j],0);
        VStorageStats before=vstorage_stats(arena);
        VGemmReport report={99,99};
        /* Output is malloc-backed and deliberately uninitialized. */
        assert(vgemm_execute(arena,0,a,ca,1,b,cb,2,c,VGEMM_OVERWRITE,&report)==VS_OK);
        assert(report.kernel_calls==1 && report.written_bytes==32);
        for(int i=0;i<2;++i) for(int j=0;j<2;++j) expect(arena,2,c,i,j,product[i][j],0);
        assert(vgemm_execute(arena,0,a,ca,1,b,cb,2,c,VGEMM_ACCUMULATE,&report)==VS_OK);
        for(int i=0;i<2;++i) for(int j=0;j<2;++j) expect(arena,2,c,i,j,2*product[i][j],0);
        for(int i=0;i<2;++i) for(int j=0;j<3;++j) expect(arena,0,a,i,j,left[i][j],0);
        for(int i=0;i<3;++i) for(int j=0;j<2;++j) expect(arena,1,b,i,j,right[i][j],0);
        VStorageStats after=vstorage_stats(arena);
        assert(after.data_allocations==before.data_allocations && after.copied_bytes==before.copied_bytes);
        assert(after.written_bytes==before.written_bytes+64 && after.peak_bytes==before.peak_bytes);
        cleanup(arena);
    }
}

static void complex_product(void) {
    const double left[2][3][2]={{{1,2},{3,5},{7,11}},{{13,17},{19,23},{29,31}}};
    const double right[3][2][2]={{{37,41},{43,47}},{{53,59},{61,67}},{{71,73},{79,83}}};
    /* N, T, R (conjugation only), C on both operands, independently of padding.
     * All arithmetic is exact for these small integers; the reference loop
     * uses logical entries rather than the adapter's storage/CBLAS mapping. */
    for(int ta=0;ta<2;++ta) for(int tb=0;tb<2;++tb) for(int pad=0;pad<2;++pad)
    for(int ca=0;ca<2;++ca) for(int cb=0;cb<2;++cb) {
        VStorageArena *arena=vstorage_new(4096); assert(arena);
        VStorageLayout a=layout(2,3,ta,pad),b=layout(3,2,tb,pad),c=layout(2,2,0,pad);
        allocate(arena,0,1,a); allocate(arena,1,1,b); allocate(arena,2,1,c);
        for(int i=0;i<2;++i) for(int j=0;j<3;++j) put(arena,0,a,i,j,1,left[i][j][0],left[i][j][1]);
        for(int i=0;i<3;++i) for(int j=0;j<2;++j) put(arena,1,b,i,j,1,right[i][j][0],right[i][j][1]);
        double product[2][2][2]={0};
        for(int i=0;i<2;++i) for(int j=0;j<2;++j) for(int k=0;k<3;++k) {
            double ar=left[i][k][0], ai=(ca?-1:1)*left[i][k][1];
            double br=right[k][j][0], bi=(cb?-1:1)*right[k][j][1];
            product[i][j][0]+=ar*br-ai*bi;
            product[i][j][1]+=ar*bi+ai*br;
        }
        /* Initialize only non-output cells as guards; C itself remains malloc
         * backed and uninitialized for the first overwrite. */
        uint64_t count=c.offset/16+c.leading*c.columns;
        VStorageLayout whole=layout(count,1,0,0);
        for(uint64_t index=0;index<count;++index) {
            int in_output=index>=c.offset/16 && (index-c.offset/16)%c.leading<c.rows;
            if(!in_output) put(arena,2,whole,index,0,1,123,-456);
        }
        VStorageStats before=vstorage_stats(arena);
        VGemmReport report;
        assert(vgemm_execute(arena,0,a,ca,1,b,cb,2,c,VGEMM_OVERWRITE,&report)==VS_OK);
        assert(report.kernel_calls==1 && report.written_bytes==64);
        for(int i=0;i<2;++i) for(int j=0;j<2;++j) expect(arena,2,c,i,j,product[i][j][0],product[i][j][1]);
        assert(vgemm_execute(arena,0,a,ca,1,b,cb,2,c,VGEMM_ACCUMULATE,&report)==VS_OK);
        for(int i=0;i<2;++i) for(int j=0;j<2;++j) expect(arena,2,c,i,j,2*product[i][j][0],2*product[i][j][1]);
        for(uint64_t index=0;index<count;++index) {
            int in_output=index>=c.offset/16 && (index-c.offset/16)%c.leading<c.rows;
            if(!in_output) expect(arena,2,whole,index,0,123,-456);
        }
        for(int i=0;i<2;++i) for(int j=0;j<3;++j) expect(arena,0,a,i,j,left[i][j][0],left[i][j][1]);
        for(int i=0;i<3;++i) for(int j=0;j<2;++j) expect(arena,1,b,i,j,right[i][j][0],right[i][j][1]);
        VStorageStats after=vstorage_stats(arena);
        assert(after.data_allocations==before.data_allocations && after.copied_bytes==before.copied_bytes);
        assert(after.written_bytes==before.written_bytes+128 && after.peak_bytes==before.peak_bytes);
        cleanup(arena);
    }
}

static void conjugation_and_nonfinite(void) {
    VStorageArena *arena=vstorage_new(4096); assert(arena);
    VStorageLayout one=layout(1,1,0,0),t=layout(1,1,1,0);
    for(uint32_t id=0;id<3;++id) allocate(arena,id,1,one);
    put(arena,0,one,0,0,1,0,1); put(arena,1,one,0,0,1,1,0);
    VGemmReport report;
    assert(vgemm_execute(arena,0,t,0,1,one,0,2,one,VGEMM_OVERWRITE,&report)==VS_OK);
    expect(arena,2,one,0,0,0,1);
    assert(vgemm_execute(arena,0,t,1,1,one,0,2,one,VGEMM_OVERWRITE,&report)==VS_OK);
    expect(arena,2,one,0,0,0,-1);
    assert(vgemm_execute(arena,1,one,0,0,t,1,2,one,VGEMM_OVERWRITE,&report)==VS_OK);
    expect(arena,2,one,0,0,0,-1);
    /* Read/read aliases are allowed; ordinary multiplication stays bilinear. */
    assert(vgemm_execute(arena,0,one,0,0,one,0,2,one,VGEMM_OVERWRITE,&report)==VS_OK);
    expect(arena,2,one,0,0,-1,0);
    assert(vgemm_execute(arena,0,one,1,0,one,0,2,one,VGEMM_OVERWRITE,&report)==VS_OK);
    expect(arena,2,one,0,0,1,0);
    assert(vgemm_execute(arena,0,one,1,0,one,1,2,one,VGEMM_OVERWRITE,&report)==VS_OK);
    expect(arena,2,one,0,0,-1,0);
    /* Overwrite is independent of old output NaNs as well as uninitialized bytes. */
    put(arena,2,one,0,0,1,NAN,NAN);
    assert(vgemm_execute(arena,0,one,0,1,one,0,2,one,VGEMM_OVERWRITE,&report)==VS_OK);
    expect(arena,2,one,0,0,0,1);
    cleanup(arena);
}

static void degenerate(void) {
    VStorageArena *arena=vstorage_new(4096); assert(arena);
    VStorageLayout a=layout(2,0,0,0),b=layout(0,3,0,0),c=layout(2,3,0,0);
    for(uint8_t scalar=0;scalar<2;++scalar) {
        uint32_t base=scalar*3;
        allocate(arena,base,scalar,a); allocate(arena,base+1,scalar,b); allocate(arena,base+2,scalar,c);
        VGemmReport report;
        assert(vgemm_execute(arena,base,a,0,base+1,b,0,base+2,c,VGEMM_OVERWRITE,&report)==VS_OK);
        assert(report.kernel_calls==0 && report.written_bytes==6*(scalar?16:8));
        for(int i=0;i<2;++i) for(int j=0;j<3;++j) expect(arena,base+2,c,i,j,0,0);
        put(arena,base+2,c,0,0,scalar,7,scalar?2:0);
        assert(vgemm_execute(arena,base,a,0,base+1,b,0,base+2,c,VGEMM_ACCUMULATE,&report)==VS_OK);
        assert(report.kernel_calls==0 && report.written_bytes==0);
        expect(arena,base+2,c,0,0,7,scalar?2:0);
    }
    cleanup(arena);
    arena=vstorage_new(64); assert(arena);
    a=layout(0,2,0,0); b=layout(2,0,0,0); c=layout(0,0,0,0);
    allocate(arena,0,0,a); allocate(arena,1,0,b); allocate(arena,2,0,c);
    VGemmReport report;
    assert(vgemm_execute(arena,0,a,0,1,b,0,2,c,VGEMM_OVERWRITE,&report)==VS_OK);
    assert(report.kernel_calls==0 && report.written_bytes==0);
    cleanup(arena);
}

static void nonfinite_inputs(void) {
    VStorageArena *arena=vstorage_new(64); assert(arena);
    VStorageLayout one=layout(1,1,0,0);
    for(uint32_t id=0;id<3;++id) allocate(arena,id,0,one);
    put(arena,0,one,0,0,0,INFINITY,0); put(arena,1,one,0,0,0,2,0);
    assert(vgemm_execute(arena,0,one,0,1,one,0,2,one,VGEMM_OVERWRITE,NULL)==VS_OK);
    expect(arena,2,one,0,0,INFINITY,0);
    put(arena,0,one,0,0,0,NAN,0);
    assert(vgemm_execute(arena,0,one,0,1,one,0,2,one,VGEMM_OVERWRITE,NULL)==VS_OK);
    VStorageDense result;
    assert(vstorage_prepare_dense(arena,2,one,&result)==VS_OK && isnan(result.data[0]));
    cleanup(arena);
}

static void failures_preserve_output(void) {
    VStorageArena *arena=vstorage_new(4096); assert(arena);
    VStorageLayout one=layout(1,1,0,0);
    for(uint32_t id=0;id<3;++id) { allocate(arena,id,0,one); put(arena,id,one,0,0,0,3,0); }
    allocate(arena,3,1,one); put(arena,3,one,0,0,1,3,0);
    VGemmReport report={71,72};
    VStorageStats before=vstorage_stats(arena);
    VStorageLayout wrong=one; wrong.rows=2;
    assert(vgemm_execute(arena,0,wrong,0,1,one,0,2,one,VGEMM_OVERWRITE,&report)==VS_LAYOUT);
    wrong=one; wrong.leading=(uint64_t)INT32_MAX+1;
    assert(vgemm_execute(arena,0,wrong,0,1,one,0,2,one,VGEMM_OVERWRITE,&report)==VS_LAYOUT);
    wrong=one; wrong.offset=UINT64_MAX;
    assert(vgemm_execute(arena,0,wrong,0,1,one,0,2,one,VGEMM_OVERWRITE,&report)==VS_LAYOUT);
    wrong=one; wrong.rows=0;
    assert(vgemm_execute(arena,0,wrong,0,1,one,0,2,one,VGEMM_OVERWRITE,&report)==VS_SHAPE);
    assert(vgemm_execute(arena,0,one,0,1,one,0,0,one,VGEMM_OVERWRITE,&report)==VS_ALIAS);
    assert(vgemm_execute(arena,0,one,0,1,one,0,1,one,VGEMM_OVERWRITE,&report)==VS_ALIAS);
    assert(vgemm_execute(arena,0,one,1,1,one,1,0,one,VGEMM_OVERWRITE,&report)==VS_ALIAS);
    assert(vgemm_execute(arena,0,one,2,1,one,0,2,one,VGEMM_OVERWRITE,&report)==VS_OPERATION);
    assert(vgemm_execute(arena,0,one,0,1,one,2,2,one,VGEMM_OVERWRITE,&report)==VS_OPERATION);
    wrong=one; wrong.transposed=1;
    assert(vgemm_execute(arena,0,one,1,1,one,1,2,wrong,VGEMM_OVERWRITE,&report)==VS_OPERATION);
    assert(vgemm_execute(arena,0,one,0,1,one,0,2,one,(VGemmMode)2,&report)==VS_OPERATION);
    assert(vgemm_execute(arena,0,one,0,3,one,0,2,one,VGEMM_OVERWRITE,&report)==VS_SCALAR);
    assert(vgemm_execute(arena,0,one,0,99,one,0,2,one,VGEMM_OVERWRITE,&report)==VS_HANDLE);
    assert(report.kernel_calls==71 && report.written_bytes==72);
    assert(vstorage_stats(arena).written_bytes==before.written_bytes);
    for(uint32_t id=0;id<3;++id) expect(arena,id,one,0,0,3,0);
    cleanup(arena);
    /* Disjoint views in one real allocation retain actual byte provenance. */
    arena=vstorage_new(64); assert(arena);
    assert(vstorage_allocate(arena,0,0,3)==VS_OK);
    VStorageLayout second=one,third=one; second.offset=8; third.offset=16;
    put(arena,0,one,0,0,0,2,0); put(arena,0,second,0,0,0,4,0);
    assert(vgemm_execute(arena,0,one,0,0,second,0,0,third,VGEMM_OVERWRITE,&report)==VS_OK);
    expect(arena,0,third,0,0,8,0);
    cleanup(arena);
}

static VGemmCoefficient literal(uint8_t scalar, double real, double imaginary) {
    return (VGemmCoefficient){VGEMM_LITERAL,scalar,bits(real),bits(imaginary),0,0};
}

static void coefficients(void) {
    VGemmCoefficient defaults = {VGEMM_DEFAULT,0,0,0,0,0};
    for (uint8_t scalar=0; scalar<2; ++scalar) {
        VStorageArena *arena=vstorage_new(4096); assert(arena);
        VStorageLayout one=layout(1,1,0,1);
        for (uint32_t id=0; id<4; ++id) allocate(arena,id,scalar,one);
        put(arena,0,one,0,0,scalar,1,scalar?1:0);
        put(arena,1,one,0,0,scalar,2,0);
        VGemmCoefficient half=literal(scalar,0.5,0);
        VGemmCoefficient alpha=literal(scalar,scalar?0:2,scalar?1:0);
        VGemmReport report;
        /* Nontrivial alpha still overwrites without reading malloc-backed C. */
        assert(vgemm_execute_scaled(arena,0,one,0,1,one,0,2,one,VGEMM_OVERWRITE,alpha,defaults,&report)==VS_OK);
        expect(arena,2,one,0,0,scalar?-2:4,scalar?2:0);
        assert(vgemm_execute_scaled(arena,0,one,0,1,one,0,2,one,VGEMM_ACCUMULATE,defaults,half,&report)==VS_OK);
        expect(arena,2,one,0,0,scalar?1:4,scalar?3:0);
        put(arena,3,one,0,0,scalar,scalar?0:3,scalar?-1:0);
        VGemmCoefficient view={VGEMM_VIEW,0,0,0,3,one.offset};
        VStorageStats before=vstorage_stats(arena);
        assert(vgemm_execute_scaled(arena,0,one,0,1,one,0,2,one,VGEMM_ACCUMULATE,view,half,&report)==VS_OK);
        expect(arena,2,one,0,0,scalar?2.5:8,scalar?-0.5:0);
        assert(vstorage_stats(arena).data_allocations==before.data_allocations);
        assert(vstorage_stats(arena).copied_bytes==before.copied_bytes);
        /* A later write supplies the next call's actual coefficient value. */
        put(arena,3,one,0,0,scalar,2,0);
        assert(vgemm_execute_scaled(arena,0,one,0,1,one,0,2,one,VGEMM_ACCUMULATE,defaults,view,&report)==VS_OK);
        expect(arena,2,one,0,0,scalar?7:18,scalar?1:0);
        before=vstorage_stats(arena); report=(VGemmReport){71,72};
        assert(vgemm_execute_scaled(arena,0,one,0,1,one,0,2,one,VGEMM_OVERWRITE,defaults,half,&report)==VS_OPERATION);
        assert(vgemm_execute_scaled(arena,0,one,0,1,one,0,2,one,VGEMM_ACCUMULATE,literal(!scalar,1,0),defaults,&report)==VS_SCALAR);
        VGemmCoefficient bad=view; bad.allocation=2;
        assert(vgemm_execute_scaled(arena,0,one,0,1,one,0,2,one,VGEMM_ACCUMULATE,bad,defaults,&report)==VS_ALIAS);
        bad=view; bad.offset=UINT64_MAX;
        assert(vgemm_execute_scaled(arena,0,one,0,1,one,0,2,one,VGEMM_ACCUMULATE,bad,defaults,&report)==VS_LAYOUT);
        bad=view; bad.allocation=999;
        assert(vgemm_execute_scaled(arena,0,one,0,1,one,0,2,one,VGEMM_ACCUMULATE,bad,defaults,&report)==VS_HANDLE);
        bad=view; bad.kind=(VGemmCoefficientKind)9;
        assert(vgemm_execute_scaled(arena,0,one,0,1,one,0,2,one,VGEMM_ACCUMULATE,bad,defaults,&report)==VS_OPERATION);
        assert(vstorage_stats(arena).written_bytes==before.written_bytes);
        assert(report.kernel_calls==71 && report.written_bytes==72);
        expect(arena,2,one,0,0,scalar?7:18,scalar?1:0);
        cleanup(arena);

        arena=vstorage_new(4096); assert(arena);
        VStorageLayout a=layout(2,0,0,0), b=layout(0,3,0,0), c=layout(2,3,0,1);
        allocate(arena,0,scalar,a); allocate(arena,1,scalar,b); allocate(arena,2,scalar,c);
        assert(vstorage_fill(arena,2,c,scalar,bits(6),bits(scalar?2:0))==VS_OK);
        assert(vgemm_execute_scaled(arena,0,a,0,1,b,0,2,c,VGEMM_ACCUMULATE,literal(scalar,NAN,NAN),half,&report)==VS_OK);
        assert(report.kernel_calls==0 && report.written_bytes==6*(scalar?16:8));
        for (int i=0;i<2;++i) for(int j=0;j<3;++j) expect(arena,2,c,i,j,3,scalar?1:0);
        if (scalar) {
            assert(vgemm_execute_scaled(arena,0,a,0,1,b,0,2,c,VGEMM_ACCUMULATE,defaults,literal(1,0,1),&report)==VS_OK);
            for (int i=0;i<2;++i) for(int j=0;j<3;++j) expect(arena,2,c,i,j,-1,3);
        }
        assert(vstorage_fill(arena,2,c,scalar,bits(NAN),bits(NAN))==VS_OK);
        assert(vgemm_execute_scaled(arena,0,a,0,1,b,0,2,c,VGEMM_OVERWRITE,alpha,defaults,&report)==VS_OK);
        for (int i=0;i<2;++i) for(int j=0;j<3;++j) expect(arena,2,c,i,j,0,0);
        cleanup(arena);

        arena=vstorage_new(64); assert(arena);
        a=layout(0,1,0,0); b=layout(1,0,0,0); c=layout(0,0,0,0);
        one=layout(1,1,0,0);
        allocate(arena,0,scalar,a); allocate(arena,1,scalar,b); allocate(arena,2,scalar,c);
        allocate(arena,3,scalar,one); put(arena,3,one,0,0,scalar,2,0);
        view=(VGemmCoefficient){VGEMM_VIEW,0,0,0,3,0};
        assert(vgemm_execute_scaled(arena,0,a,0,1,b,0,2,c,VGEMM_OVERWRITE,view,defaults,&report)==VS_OK);
        assert(report.kernel_calls==0 && report.written_bytes==0);
        view.allocation=99; report=(VGemmReport){83,84};
        assert(vgemm_execute_scaled(arena,0,a,0,1,b,0,2,c,VGEMM_OVERWRITE,view,defaults,&report)==VS_HANDLE);
        assert(report.kernel_calls==83 && report.written_bytes==84);
        cleanup(arena);
    }
}

static void diagonal_pairing(void) {
    for (uint8_t scalar=0;scalar<2;++scalar) for (int tx=0;tx<2;++tx) for (int ty=0;ty<2;++ty)
        for(uint8_t cl=0;cl<2;++cl) for(uint8_t cr=0;cr<2;++cr) {
        VStorageArena *arena=vstorage_new(4096); assert(arena);
        VStorageLayout x=layout(2,1,tx,1), y=layout(2,1,ty,1);
        VStorageLayout scratch=layout(2,1,0,1), output=layout(1,1,0,1);
        allocate(arena,0,scalar,x); allocate(arena,1,scalar,y);
        allocate(arena,2,scalar,scratch); allocate(arena,3,scalar,output);
        put(arena,0,x,0,0,scalar,1,1); put(arena,0,x,1,0,scalar,2,-1);
        put(arena,1,y,0,0,scalar,3,-2); put(arena,1,y,1,0,scalar,1,4);
        uint8_t weights[16]; uint64_t values[2]={bits(2),bits(-4)};
        for(unsigned i=0;i<2;++i) for(unsigned j=0;j<8;++j) weights[8*i+j]=(uint8_t)(values[i]>>(8*j));
        VDiagonal diagonal={weights,sizeof(weights),0};
        double expected_real=scalar?(cl==cr?-14:10):-2;
        double expected_imaginary=cr?(cl?26:46):(cl?-46:-26);
        VStorageStats before=vstorage_stats(arena); VGemmReport report;
        for(unsigned repeat=0;repeat<2;++repeat) {
            assert(vgemm_diagonal_pair(arena,0,x,1,y,3,output,2,scratch,diagonal,cl,cr,&report)==VS_OK);
            assert(report.kernel_calls==1 && report.written_bytes==(scalar?16:8));
            expect(arena,3,output,0,0,expected_real,expected_imaginary);
            expect(arena,2,scratch,0,0,6,cr?4:-4); expect(arena,2,scratch,1,0,-4,cr?16:-16);
        }
        VStorageStats after=vstorage_stats(arena);
        assert(after.data_allocations==before.data_allocations && after.copied_bytes==before.copied_bytes);
        assert(after.written_bytes-before.written_bytes==6*(scalar?16:8));
        /* Invalid last coefficient, bounds and aliases leave both caller
         * destinations unchanged, including the earlier scratch elements. */
        memset(weights+8,0,8); before=vstorage_stats(arena); report=(VGemmReport){83,84};
        assert(vgemm_diagonal_pair(arena,0,x,1,y,3,output,2,scratch,diagonal,cl,cr,&report)==VS_OPERATION);
        expect(arena,2,scratch,0,0,6,cr?4:-4); expect(arena,3,output,0,0,expected_real,expected_imaginary);
        assert(report.kernel_calls==83 && report.written_bytes==84);
        assert(vstorage_stats(arena).written_bytes==before.written_bytes);
        for(unsigned j=0;j<8;++j) weights[8+j]=(uint8_t)(values[1]>>(8*j));
        assert(vgemm_diagonal_pair(arena,0,x,1,y,1,output,2,scratch,diagonal,cl,cr,NULL)==VS_ALIAS);
        assert(vgemm_diagonal_pair(arena,0,x,1,y,3,output,0,scratch,diagonal,cl,cr,NULL)==VS_ALIAS);
        VStorageLayout bad=output; bad.offset=4096;
        assert(vgemm_diagonal_pair(arena,0,x,1,y,3,bad,2,scratch,diagonal,cl,cr,NULL)==VS_LAYOUT);
        VStorageLayout other={0,1,1,1,0};
        assert(vstorage_allocate(arena,4,!scalar,1)==VS_OK);
        assert(vgemm_diagonal_pair(arena,0,x,1,y,4,other,2,scratch,diagonal,cl,cr,NULL)==VS_SCALAR);
        assert(vstorage_stats(arena).written_bytes==before.written_bytes);
        cleanup(arena);
    }
}

int main(void) {
    assert(vgemm_backend_check()==VS_OK);
    real_orientations(); complex_product(); conjugation_and_nonfinite();
    degenerate(); nonfinite_inputs(); failures_preserve_output(); coefficients(); diagonal_pairing();
    puts(vgemm_configuration());
    puts("GEMM: real/complex N/T/R/C layouts, reuse, empty dimensions and failure-before-write passed");
}
