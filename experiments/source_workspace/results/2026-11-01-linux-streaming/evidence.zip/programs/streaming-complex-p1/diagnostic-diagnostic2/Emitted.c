// Lean compiler output
// Module: Main
// Imports: public import Init public meta import Init public import VastitasStorageNative public import VastitasGemmNative public import VastitasKernel.IndexedRuntime
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* vastitas_storage_new(uint64_t);
lean_object* vastitas_storage_close(lean_object*);
lean_object* vastitas_storage_allocate(lean_object*, uint32_t, uint8_t, uint64_t);
lean_object* vastitas_storage_fill(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_store(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_pack3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_gemm_execute(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t);
lean_object* vastitas_storage_regroup3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_storage_expect(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_drop(lean_object*, uint32_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_List_get_x21Internal___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_String_Slice_toNat_x21(lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
uint32_t lean_uint32_of_nat(lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
lean_object* lean_io_error_to_string(lean_object*);
static lean_once_cell_t lp_allocation__audit_VastitasGenerated_f__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_allocation__audit_VastitasGenerated_f__0___closed__0;
LEAN_EXPORT lean_object* lp_allocation__audit_VastitasGenerated_f__0;
lean_object* bench_begin_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_stop_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object*);
lean_object* bench_report_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object*);
lean_object* bench_c_run_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_verify_lean(lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object*);
lean_object* audit_mark_lean(uint32_t);
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_allocation__audit_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 1, .m_capacity = 1, .m_length = 0, .m_data = ""};
static const lean_object* lp_allocation__audit_main___closed__0 = (const lean_object*)&lp_allocation__audit_main___closed__0_value;
static const lean_string_object lp_allocation__audit_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "1"};
static const lean_object* lp_allocation__audit_main___closed__1 = (const lean_object*)&lp_allocation__audit_main___closed__1_value;
static const lean_string_object lp_allocation__audit_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "failure"};
static const lean_object* lp_allocation__audit_main___closed__2 = (const lean_object*)&lp_allocation__audit_main___closed__2_value;
static const lean_string_object lp_allocation__audit_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "c"};
static const lean_object* lp_allocation__audit_main___closed__3 = (const lean_object*)&lp_allocation__audit_main___closed__3_value;
static const lean_string_object lp_allocation__audit_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "expected injected native failure"};
static const lean_object* lp_allocation__audit_main___closed__4 = (const lean_object*)&lp_allocation__audit_main___closed__4_value;
static const lean_ctor_object lp_allocation__audit_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_allocation__audit_main___closed__4_value)}};
static const lean_object* lp_allocation__audit_main___closed__5 = (const lean_object*)&lp_allocation__audit_main___closed__5_value;
static const lean_string_object lp_allocation__audit_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 44, .m_capacity = 44, .m_length = 43, .m_data = "E_NATIVE_EXPECT: stored bit pattern differs"};
static const lean_object* lp_allocation__audit_main___closed__6 = (const lean_object*)&lp_allocation__audit_main___closed__6_value;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(0u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0(void){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_obj_once(&lp_allocation__audit_VastitasGenerated_f__0___closed__0, &lp_allocation__audit_VastitasGenerated_f__0___closed__0_once, _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object* v_scope_8_, lean_object* v_reps_9_, lean_object* v_verify_10_, lean_object* v_a_00___x40___internal___hyg_11_){
_start:
{
uint32_t v_scope_boxed_12_; uint64_t v_reps_boxed_13_; uint8_t v_verify_boxed_14_; lean_object* v_res_15_; 
v_scope_boxed_12_ = lean_unbox_uint32(v_scope_8_);
lean_dec(v_scope_8_);
v_reps_boxed_13_ = lean_unbox_uint64(v_reps_9_);
lean_dec_ref(v_reps_9_);
v_verify_boxed_14_ = lean_unbox(v_verify_10_);
v_res_15_ = bench_begin_lean(v_scope_boxed_12_, v_reps_boxed_13_, v_verify_boxed_14_);
return v_res_15_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object* v_a_00___x40___internal___hyg_17_){
_start:
{
lean_object* v_res_18_; 
v_res_18_ = bench_stop_lean();
return v_res_18_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object* v_a_00___x40___internal___hyg_20_){
_start:
{
lean_object* v_res_21_; 
v_res_21_ = bench_report_lean();
return v_res_21_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object* v_scope_26_, lean_object* v_reps_27_, lean_object* v_verify_28_, lean_object* v_a_00___x40___internal___hyg_29_){
_start:
{
uint32_t v_scope_boxed_30_; uint64_t v_reps_boxed_31_; uint8_t v_verify_boxed_32_; lean_object* v_res_33_; 
v_scope_boxed_30_ = lean_unbox_uint32(v_scope_26_);
lean_dec(v_scope_26_);
v_reps_boxed_31_ = lean_unbox_uint64(v_reps_27_);
lean_dec_ref(v_reps_27_);
v_verify_boxed_32_ = lean_unbox(v_verify_28_);
v_res_33_ = bench_c_run_lean(v_scope_boxed_30_, v_reps_boxed_31_, v_verify_boxed_32_);
return v_res_33_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object* v_arena_37_, lean_object* v_reps_38_, lean_object* v_a_00___x40___internal___hyg_39_){
_start:
{
uint64_t v_reps_boxed_40_; lean_object* v_res_41_; 
v_reps_boxed_40_ = lean_unbox_uint64(v_reps_38_);
lean_dec_ref(v_reps_38_);
v_res_41_ = bench_verify_lean(v_arena_37_, v_reps_boxed_40_);
lean_dec(v_arena_37_);
return v_res_41_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce(){
_start:
{
uint64_t v___x_43_; lean_object* v___x_44_; 
v___x_43_ = 9223372036854775807ULL;
v___x_44_ = vastitas_storage_new(v___x_43_);
if (lean_obj_tag(v___x_44_) == 0)
{
lean_object* v_a_45_; lean_object* v___y_47_; uint32_t v___x_60_; uint8_t v___x_61_; uint64_t v___x_62_; lean_object* v___x_63_; 
v_a_45_ = lean_ctor_get(v___x_44_, 0);
lean_inc(v_a_45_);
lean_dec_ref_known(v___x_44_, 1);
v___x_60_ = 0;
v___x_61_ = 1;
v___x_62_ = 2060ULL;
v___x_63_ = vastitas_storage_allocate(v_a_45_, v___x_60_, v___x_61_, v___x_62_);
if (lean_obj_tag(v___x_63_) == 0)
{
uint64_t v___x_64_; uint64_t v___x_65_; uint8_t v___x_66_; uint64_t v___x_67_; uint64_t v___x_68_; lean_object* v___x_69_; 
lean_dec_ref_known(v___x_63_, 1);
v___x_64_ = 0ULL;
v___x_65_ = 1ULL;
v___x_66_ = 0;
v___x_67_ = 13842939354630062080ULL;
v___x_68_ = 4613937818241073152ULL;
v___x_69_ = vastitas_storage_fill(v_a_45_, v___x_60_, v___x_64_, v___x_62_, v___x_65_, v___x_62_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_69_) == 0)
{
uint64_t v___x_70_; uint64_t v___x_71_; uint64_t v___x_72_; uint64_t v___x_73_; uint64_t v___x_74_; uint64_t v___x_75_; lean_object* v___x_76_; 
lean_dec_ref_known(v___x_69_, 1);
v___x_70_ = 16ULL;
v___x_71_ = 512ULL;
v___x_72_ = 4ULL;
v___x_73_ = 514ULL;
v___x_74_ = 4593671619917905920ULL;
v___x_75_ = 4598175219545276416ULL;
v___x_76_ = vastitas_storage_fill(v_a_45_, v___x_60_, v___x_70_, v___x_71_, v___x_72_, v___x_73_, v___x_66_, v___x_61_, v___x_74_, v___x_75_);
if (lean_obj_tag(v___x_76_) == 0)
{
uint64_t v___x_77_; uint64_t v___x_78_; lean_object* v___x_79_; 
lean_dec_ref_known(v___x_76_, 1);
v___x_77_ = 4607182418800017408ULL;
v___x_78_ = 13826050856027422720ULL;
v___x_79_ = vastitas_storage_store(v_a_45_, v___x_60_, v___x_70_, v___x_71_, v___x_72_, v___x_73_, v___x_66_, v___x_64_, v___x_64_, v___x_61_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_79_) == 0)
{
uint64_t v___x_80_; uint64_t v___x_81_; lean_object* v___x_82_; 
lean_dec_ref_known(v___x_79_, 1);
v___x_80_ = 511ULL;
v___x_81_ = 4604930618986332160ULL;
v___x_82_ = vastitas_storage_store(v_a_45_, v___x_60_, v___x_70_, v___x_71_, v___x_72_, v___x_73_, v___x_66_, v___x_80_, v___x_65_, v___x_61_, v___x_78_, v___x_81_);
if (lean_obj_tag(v___x_82_) == 0)
{
uint32_t v___x_83_; uint64_t v___x_84_; lean_object* v___x_85_; 
lean_dec_ref_known(v___x_82_, 1);
v___x_83_ = 1;
v___x_84_ = 325ULL;
v___x_85_ = vastitas_storage_allocate(v_a_45_, v___x_83_, v___x_61_, v___x_84_);
if (lean_obj_tag(v___x_85_) == 0)
{
lean_object* v___x_86_; 
lean_dec_ref_known(v___x_85_, 1);
v___x_86_ = vastitas_storage_fill(v_a_45_, v___x_83_, v___x_64_, v___x_84_, v___x_65_, v___x_84_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_86_) == 0)
{
uint64_t v___x_87_; uint64_t v___x_88_; uint64_t v___x_89_; uint64_t v___x_90_; uint64_t v___x_91_; lean_object* v___x_92_; 
lean_dec_ref_known(v___x_86_, 1);
v___x_87_ = 32ULL;
v___x_88_ = 2ULL;
v___x_89_ = 64ULL;
v___x_90_ = 5ULL;
v___x_91_ = 13821547256400052224ULL;
v___x_92_ = vastitas_storage_fill(v_a_45_, v___x_83_, v___x_87_, v___x_88_, v___x_89_, v___x_90_, v___x_66_, v___x_61_, v___x_91_, v___x_74_);
if (lean_obj_tag(v___x_92_) == 0)
{
uint64_t v___x_93_; uint64_t v___x_94_; lean_object* v___x_95_; 
lean_dec_ref_known(v___x_92_, 1);
v___x_93_ = 63ULL;
v___x_94_ = 4602678819172646912ULL;
v___x_95_ = vastitas_storage_store(v_a_45_, v___x_83_, v___x_87_, v___x_88_, v___x_89_, v___x_90_, v___x_66_, v___x_64_, v___x_93_, v___x_61_, v___x_94_, v___x_75_);
if (lean_obj_tag(v___x_95_) == 0)
{
uint64_t v___x_96_; lean_object* v___x_97_; 
lean_dec_ref_known(v___x_95_, 1);
v___x_96_ = 13828302655841107968ULL;
v___x_97_ = vastitas_storage_store(v_a_45_, v___x_83_, v___x_87_, v___x_88_, v___x_89_, v___x_90_, v___x_66_, v___x_65_, v___x_64_, v___x_61_, v___x_96_, v___x_78_);
if (lean_obj_tag(v___x_97_) == 0)
{
uint32_t v___x_98_; uint64_t v___x_99_; lean_object* v___x_100_; 
lean_dec_ref_known(v___x_97_, 1);
v___x_98_ = 2;
v___x_99_ = 3078ULL;
v___x_100_ = vastitas_storage_allocate(v_a_45_, v___x_98_, v___x_61_, v___x_99_);
if (lean_obj_tag(v___x_100_) == 0)
{
lean_object* v___x_101_; 
lean_dec_ref_known(v___x_100_, 1);
v___x_101_ = vastitas_storage_fill(v_a_45_, v___x_98_, v___x_64_, v___x_99_, v___x_65_, v___x_99_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_101_) == 0)
{
uint64_t v___x_102_; uint64_t v___x_103_; lean_object* v___x_104_; 
lean_dec_ref_known(v___x_101_, 1);
v___x_102_ = 48ULL;
v___x_103_ = 6ULL;
v___x_104_ = vastitas_storage_fill(v_a_45_, v___x_98_, v___x_102_, v___x_88_, v___x_71_, v___x_103_, v___x_66_, v___x_61_, v___x_94_, v___x_91_);
if (lean_obj_tag(v___x_104_) == 0)
{
lean_object* v___x_105_; 
lean_dec_ref_known(v___x_104_, 1);
v___x_105_ = vastitas_storage_store(v_a_45_, v___x_98_, v___x_102_, v___x_88_, v___x_71_, v___x_103_, v___x_66_, v___x_65_, v___x_64_, v___x_61_, v___x_91_, v___x_94_);
if (lean_obj_tag(v___x_105_) == 0)
{
lean_object* v___x_106_; 
lean_dec_ref_known(v___x_105_, 1);
v___x_106_ = vastitas_storage_store(v_a_45_, v___x_98_, v___x_102_, v___x_88_, v___x_71_, v___x_103_, v___x_66_, v___x_64_, v___x_80_, v___x_61_, v___x_81_, v___x_96_);
if (lean_obj_tag(v___x_106_) == 0)
{
uint32_t v___x_107_; uint64_t v___x_108_; lean_object* v___x_109_; 
lean_dec_ref_known(v___x_106_, 1);
v___x_107_ = 3;
v___x_108_ = 65562ULL;
v___x_109_ = vastitas_storage_allocate(v_a_45_, v___x_107_, v___x_61_, v___x_108_);
if (lean_obj_tag(v___x_109_) == 0)
{
lean_object* v___x_110_; 
lean_dec_ref_known(v___x_109_, 1);
v___x_110_ = vastitas_storage_fill(v_a_45_, v___x_107_, v___x_64_, v___x_108_, v___x_65_, v___x_108_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_110_) == 0)
{
uint32_t v___x_111_; uint64_t v___x_112_; lean_object* v___x_113_; 
lean_dec_ref_known(v___x_110_, 1);
v___x_111_ = 4;
v___x_112_ = 65928ULL;
v___x_113_ = vastitas_storage_allocate(v_a_45_, v___x_111_, v___x_61_, v___x_112_);
if (lean_obj_tag(v___x_113_) == 0)
{
lean_object* v___x_114_; 
lean_dec_ref_known(v___x_113_, 1);
v___x_114_ = vastitas_storage_fill(v_a_45_, v___x_111_, v___x_64_, v___x_112_, v___x_65_, v___x_112_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_114_) == 0)
{
uint32_t v___x_115_; uint64_t v___x_116_; lean_object* v___x_117_; 
lean_dec_ref_known(v___x_114_, 1);
v___x_115_ = 5;
v___x_116_ = 16780809ULL;
v___x_117_ = vastitas_storage_allocate(v_a_45_, v___x_115_, v___x_61_, v___x_116_);
if (lean_obj_tag(v___x_117_) == 0)
{
lean_object* v___x_118_; 
lean_dec_ref_known(v___x_117_, 1);
v___x_118_ = vastitas_storage_fill(v_a_45_, v___x_115_, v___x_64_, v___x_116_, v___x_65_, v___x_116_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_118_) == 0)
{
uint64_t v___x_119_; uint64_t v___x_120_; lean_object* v___x_121_; 
lean_dec_ref_known(v___x_118_, 1);
v___x_119_ = 1024ULL;
v___x_120_ = 1029ULL;
v___x_121_ = vastitas_storage_pack3(v_a_45_, v___x_60_, v___x_70_, v___x_71_, v___x_72_, v___x_73_, v___x_66_, v___x_107_, v___x_89_, v___x_119_, v___x_88_, v___x_120_, v___x_66_, v___x_71_, v___x_88_, v___x_88_);
if (lean_obj_tag(v___x_121_) == 0)
{
uint64_t v___x_122_; uint64_t v___x_123_; uint8_t v___x_124_; lean_object* v___x_125_; 
lean_dec_ref_known(v___x_121_, 1);
v___x_122_ = 80ULL;
v___x_123_ = 1030ULL;
v___x_124_ = 0;
v___x_125_ = vastitas_gemm_execute(v_a_45_, v___x_107_, v___x_89_, v___x_119_, v___x_88_, v___x_120_, v___x_66_, v___x_66_, v___x_83_, v___x_87_, v___x_88_, v___x_89_, v___x_90_, v___x_66_, v___x_66_, v___x_111_, v___x_122_, v___x_119_, v___x_89_, v___x_123_, v___x_66_, v___x_124_);
if (lean_obj_tag(v___x_125_) == 0)
{
uint64_t v___x_126_; uint64_t v___x_127_; uint64_t v___x_128_; uint64_t v___x_129_; lean_object* v___x_130_; 
lean_dec_ref_known(v___x_125_, 1);
v___x_126_ = 112ULL;
v___x_127_ = 32768ULL;
v___x_128_ = 32776ULL;
v___x_129_ = 42ULL;
v___x_130_ = vastitas_storage_regroup3(v_a_45_, v___x_111_, v___x_122_, v___x_119_, v___x_89_, v___x_123_, v___x_66_, v___x_107_, v___x_126_, v___x_127_, v___x_88_, v___x_128_, v___x_66_, v___x_71_, v___x_88_, v___x_89_, v___x_102_, v___x_129_);
if (lean_obj_tag(v___x_130_) == 0)
{
uint64_t v___x_131_; uint64_t v___x_132_; lean_object* v___x_133_; 
lean_dec_ref_known(v___x_130_, 1);
v___x_131_ = 96ULL;
v___x_132_ = 32775ULL;
v___x_133_ = vastitas_gemm_execute(v_a_45_, v___x_107_, v___x_126_, v___x_127_, v___x_88_, v___x_128_, v___x_66_, v___x_66_, v___x_98_, v___x_102_, v___x_88_, v___x_71_, v___x_103_, v___x_66_, v___x_66_, v___x_115_, v___x_131_, v___x_127_, v___x_71_, v___x_132_, v___x_66_, v___x_124_);
if (lean_obj_tag(v___x_133_) == 0)
{
uint64_t v___x_134_; uint64_t v___x_135_; lean_object* v___x_136_; 
lean_dec_ref_known(v___x_133_, 1);
v___x_134_ = 4590293920197378048ULL;
v___x_135_ = 4591701295080931328ULL;
v___x_136_ = vastitas_storage_expect(v_a_45_, v___x_115_, v___x_131_, v___x_127_, v___x_71_, v___x_132_, v___x_66_, v___x_64_, v___x_64_, v___x_61_, v___x_134_, v___x_135_);
if (lean_obj_tag(v___x_136_) == 0)
{
uint64_t v___x_137_; uint64_t v___x_138_; lean_object* v___x_139_; 
lean_dec_ref_known(v___x_136_, 1);
v___x_137_ = 4594797519824748544ULL;
v___x_138_ = 13829885952585105408ULL;
v___x_139_ = vastitas_storage_expect(v_a_45_, v___x_115_, v___x_131_, v___x_127_, v___x_71_, v___x_132_, v___x_66_, v___x_80_, v___x_80_, v___x_61_, v___x_137_, v___x_138_);
if (lean_obj_tag(v___x_139_) == 0)
{
uint64_t v___x_140_; uint64_t v___x_141_; uint64_t v___x_142_; lean_object* v___x_143_; 
lean_dec_ref_known(v___x_139_, 1);
v___x_140_ = 32767ULL;
v___x_141_ = 13810288257331625984ULL;
v___x_142_ = 13816199231842549760ULL;
v___x_143_ = vastitas_storage_expect(v_a_45_, v___x_115_, v___x_131_, v___x_127_, v___x_71_, v___x_132_, v___x_66_, v___x_140_, v___x_64_, v___x_61_, v___x_141_, v___x_142_);
if (lean_obj_tag(v___x_143_) == 0)
{
lean_object* v___x_144_; 
lean_dec_ref_known(v___x_143_, 1);
v___x_144_ = vastitas_storage_drop(v_a_45_, v___x_115_);
if (lean_obj_tag(v___x_144_) == 0)
{
lean_object* v___x_145_; 
lean_dec_ref_known(v___x_144_, 1);
v___x_145_ = vastitas_storage_drop(v_a_45_, v___x_111_);
if (lean_obj_tag(v___x_145_) == 0)
{
lean_object* v___x_146_; 
lean_dec_ref_known(v___x_145_, 1);
v___x_146_ = vastitas_storage_drop(v_a_45_, v___x_107_);
if (lean_obj_tag(v___x_146_) == 0)
{
lean_object* v___x_147_; 
lean_dec_ref_known(v___x_146_, 1);
v___x_147_ = vastitas_storage_drop(v_a_45_, v___x_98_);
if (lean_obj_tag(v___x_147_) == 0)
{
lean_object* v___x_148_; 
lean_dec_ref_known(v___x_147_, 1);
v___x_148_ = vastitas_storage_drop(v_a_45_, v___x_83_);
if (lean_obj_tag(v___x_148_) == 0)
{
lean_object* v___x_149_; 
lean_dec_ref_known(v___x_148_, 1);
v___x_149_ = vastitas_storage_drop(v_a_45_, v___x_60_);
if (lean_obj_tag(v___x_149_) == 0)
{
lean_object* v___x_150_; 
lean_dec_ref_known(v___x_149_, 1);
v___x_150_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
return v___x_150_;
}
else
{
v___y_47_ = v___x_149_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_148_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_147_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_146_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_145_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_144_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_143_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_139_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_136_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_133_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_130_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_125_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_121_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_118_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_117_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_114_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_113_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_110_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_109_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_106_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_105_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_104_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_101_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_100_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_97_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_95_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_92_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_86_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_85_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_82_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_79_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_76_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_69_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_63_;
goto v___jp_46_;
}
v___jp_46_:
{
if (lean_obj_tag(v___y_47_) == 0)
{
lean_object* v___x_48_; 
lean_dec_ref_known(v___y_47_, 1);
v___x_48_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
return v___x_48_;
}
else
{
lean_object* v_a_49_; lean_object* v___x_50_; 
v_a_49_ = lean_ctor_get(v___y_47_, 0);
lean_inc(v_a_49_);
lean_dec_ref_known(v___y_47_, 1);
v___x_50_ = vastitas_storage_close(v_a_45_);
if (lean_obj_tag(v___x_50_) == 0)
{
lean_object* v___x_52_; uint8_t v_isShared_53_; uint8_t v_isSharedCheck_57_; 
lean_dec(v_a_45_);
v_isSharedCheck_57_ = !lean_is_exclusive(v___x_50_);
if (v_isSharedCheck_57_ == 0)
{
lean_object* v_unused_58_; 
v_unused_58_ = lean_ctor_get(v___x_50_, 0);
lean_dec(v_unused_58_);
v___x_52_ = v___x_50_;
v_isShared_53_ = v_isSharedCheck_57_;
goto v_resetjp_51_;
}
else
{
lean_dec(v___x_50_);
v___x_52_ = lean_box(0);
v_isShared_53_ = v_isSharedCheck_57_;
goto v_resetjp_51_;
}
v_resetjp_51_:
{
lean_object* v___x_55_; 
if (v_isShared_53_ == 0)
{
lean_ctor_set_tag(v___x_52_, 1);
lean_ctor_set(v___x_52_, 0, v_a_49_);
v___x_55_ = v___x_52_;
goto v_reusejp_54_;
}
else
{
lean_object* v_reuseFailAlloc_56_; 
v_reuseFailAlloc_56_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_56_, 0, v_a_49_);
v___x_55_ = v_reuseFailAlloc_56_;
goto v_reusejp_54_;
}
v_reusejp_54_:
{
return v___x_55_;
}
}
}
else
{
lean_dec(v_a_49_);
if (lean_obj_tag(v___x_50_) == 0)
{
lean_object* v___x_59_; 
lean_dec_ref_known(v___x_50_, 1);
v___x_59_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
return v___x_59_;
}
else
{
lean_dec(v_a_45_);
return v___x_50_;
}
}
}
}
}
else
{
lean_object* v_a_151_; lean_object* v___x_153_; uint8_t v_isShared_154_; uint8_t v_isSharedCheck_158_; 
v_a_151_ = lean_ctor_get(v___x_44_, 0);
v_isSharedCheck_158_ = !lean_is_exclusive(v___x_44_);
if (v_isSharedCheck_158_ == 0)
{
v___x_153_ = v___x_44_;
v_isShared_154_ = v_isSharedCheck_158_;
goto v_resetjp_152_;
}
else
{
lean_inc(v_a_151_);
lean_dec(v___x_44_);
v___x_153_ = lean_box(0);
v_isShared_154_ = v_isSharedCheck_158_;
goto v_resetjp_152_;
}
v_resetjp_152_:
{
lean_object* v___x_156_; 
if (v_isShared_154_ == 0)
{
v___x_156_ = v___x_153_;
goto v_reusejp_155_;
}
else
{
lean_object* v_reuseFailAlloc_157_; 
v_reuseFailAlloc_157_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_157_, 0, v_a_151_);
v___x_156_ = v_reuseFailAlloc_157_;
goto v_reusejp_155_;
}
v_reusejp_155_:
{
return v___x_156_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object* v_a_159_){
_start:
{
lean_object* v_res_160_; 
v_res_160_ = lp_allocation__audit_generatedOnce();
return v_res_160_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure(){
_start:
{
uint64_t v___x_162_; lean_object* v___x_163_; 
v___x_162_ = 9223372036854775807ULL;
v___x_163_ = vastitas_storage_new(v___x_162_);
if (lean_obj_tag(v___x_163_) == 0)
{
lean_object* v_a_164_; lean_object* v___y_166_; uint32_t v___x_179_; uint8_t v___x_180_; uint64_t v___x_181_; lean_object* v___x_182_; 
v_a_164_ = lean_ctor_get(v___x_163_, 0);
lean_inc(v_a_164_);
lean_dec_ref_known(v___x_163_, 1);
v___x_179_ = 0;
v___x_180_ = 1;
v___x_181_ = 2060ULL;
v___x_182_ = vastitas_storage_allocate(v_a_164_, v___x_179_, v___x_180_, v___x_181_);
if (lean_obj_tag(v___x_182_) == 0)
{
uint64_t v___x_183_; uint64_t v___x_184_; uint8_t v___x_185_; uint64_t v___x_186_; uint64_t v___x_187_; lean_object* v___x_188_; 
lean_dec_ref_known(v___x_182_, 1);
v___x_183_ = 0ULL;
v___x_184_ = 1ULL;
v___x_185_ = 0;
v___x_186_ = 13842939354630062080ULL;
v___x_187_ = 4613937818241073152ULL;
v___x_188_ = vastitas_storage_fill(v_a_164_, v___x_179_, v___x_183_, v___x_181_, v___x_184_, v___x_181_, v___x_185_, v___x_180_, v___x_186_, v___x_187_);
if (lean_obj_tag(v___x_188_) == 0)
{
uint64_t v___x_189_; uint64_t v___x_190_; uint64_t v___x_191_; uint64_t v___x_192_; uint64_t v___x_193_; uint64_t v___x_194_; lean_object* v___x_195_; 
lean_dec_ref_known(v___x_188_, 1);
v___x_189_ = 16ULL;
v___x_190_ = 512ULL;
v___x_191_ = 4ULL;
v___x_192_ = 514ULL;
v___x_193_ = 4593671619917905920ULL;
v___x_194_ = 4598175219545276416ULL;
v___x_195_ = vastitas_storage_fill(v_a_164_, v___x_179_, v___x_189_, v___x_190_, v___x_191_, v___x_192_, v___x_185_, v___x_180_, v___x_193_, v___x_194_);
if (lean_obj_tag(v___x_195_) == 0)
{
uint64_t v___x_196_; uint64_t v___x_197_; lean_object* v___x_198_; 
lean_dec_ref_known(v___x_195_, 1);
v___x_196_ = 4607182418800017408ULL;
v___x_197_ = 13826050856027422720ULL;
v___x_198_ = vastitas_storage_store(v_a_164_, v___x_179_, v___x_189_, v___x_190_, v___x_191_, v___x_192_, v___x_185_, v___x_183_, v___x_183_, v___x_180_, v___x_196_, v___x_197_);
if (lean_obj_tag(v___x_198_) == 0)
{
uint64_t v___x_199_; uint64_t v___x_200_; lean_object* v___x_201_; 
lean_dec_ref_known(v___x_198_, 1);
v___x_199_ = 511ULL;
v___x_200_ = 4604930618986332160ULL;
v___x_201_ = vastitas_storage_store(v_a_164_, v___x_179_, v___x_189_, v___x_190_, v___x_191_, v___x_192_, v___x_185_, v___x_199_, v___x_184_, v___x_180_, v___x_197_, v___x_200_);
if (lean_obj_tag(v___x_201_) == 0)
{
uint32_t v___x_202_; uint64_t v___x_203_; lean_object* v___x_204_; 
lean_dec_ref_known(v___x_201_, 1);
v___x_202_ = 1;
v___x_203_ = 325ULL;
v___x_204_ = vastitas_storage_allocate(v_a_164_, v___x_202_, v___x_180_, v___x_203_);
if (lean_obj_tag(v___x_204_) == 0)
{
lean_object* v___x_205_; 
lean_dec_ref_known(v___x_204_, 1);
v___x_205_ = vastitas_storage_fill(v_a_164_, v___x_202_, v___x_183_, v___x_203_, v___x_184_, v___x_203_, v___x_185_, v___x_180_, v___x_186_, v___x_187_);
if (lean_obj_tag(v___x_205_) == 0)
{
uint64_t v___x_206_; uint64_t v___x_207_; uint64_t v___x_208_; uint64_t v___x_209_; uint64_t v___x_210_; lean_object* v___x_211_; 
lean_dec_ref_known(v___x_205_, 1);
v___x_206_ = 32ULL;
v___x_207_ = 2ULL;
v___x_208_ = 64ULL;
v___x_209_ = 5ULL;
v___x_210_ = 13821547256400052224ULL;
v___x_211_ = vastitas_storage_fill(v_a_164_, v___x_202_, v___x_206_, v___x_207_, v___x_208_, v___x_209_, v___x_185_, v___x_180_, v___x_210_, v___x_193_);
if (lean_obj_tag(v___x_211_) == 0)
{
uint64_t v___x_212_; uint64_t v___x_213_; lean_object* v___x_214_; 
lean_dec_ref_known(v___x_211_, 1);
v___x_212_ = 63ULL;
v___x_213_ = 4602678819172646912ULL;
v___x_214_ = vastitas_storage_store(v_a_164_, v___x_202_, v___x_206_, v___x_207_, v___x_208_, v___x_209_, v___x_185_, v___x_183_, v___x_212_, v___x_180_, v___x_213_, v___x_194_);
if (lean_obj_tag(v___x_214_) == 0)
{
uint64_t v___x_215_; lean_object* v___x_216_; 
lean_dec_ref_known(v___x_214_, 1);
v___x_215_ = 13828302655841107968ULL;
v___x_216_ = vastitas_storage_store(v_a_164_, v___x_202_, v___x_206_, v___x_207_, v___x_208_, v___x_209_, v___x_185_, v___x_184_, v___x_183_, v___x_180_, v___x_215_, v___x_197_);
if (lean_obj_tag(v___x_216_) == 0)
{
uint32_t v___x_217_; uint64_t v___x_218_; lean_object* v___x_219_; 
lean_dec_ref_known(v___x_216_, 1);
v___x_217_ = 2;
v___x_218_ = 3078ULL;
v___x_219_ = vastitas_storage_allocate(v_a_164_, v___x_217_, v___x_180_, v___x_218_);
if (lean_obj_tag(v___x_219_) == 0)
{
lean_object* v___x_220_; 
lean_dec_ref_known(v___x_219_, 1);
v___x_220_ = vastitas_storage_fill(v_a_164_, v___x_217_, v___x_183_, v___x_218_, v___x_184_, v___x_218_, v___x_185_, v___x_180_, v___x_186_, v___x_187_);
if (lean_obj_tag(v___x_220_) == 0)
{
uint64_t v___x_221_; uint64_t v___x_222_; lean_object* v___x_223_; 
lean_dec_ref_known(v___x_220_, 1);
v___x_221_ = 48ULL;
v___x_222_ = 6ULL;
v___x_223_ = vastitas_storage_fill(v_a_164_, v___x_217_, v___x_221_, v___x_207_, v___x_190_, v___x_222_, v___x_185_, v___x_180_, v___x_213_, v___x_210_);
if (lean_obj_tag(v___x_223_) == 0)
{
lean_object* v___x_224_; 
lean_dec_ref_known(v___x_223_, 1);
v___x_224_ = vastitas_storage_store(v_a_164_, v___x_217_, v___x_221_, v___x_207_, v___x_190_, v___x_222_, v___x_185_, v___x_184_, v___x_183_, v___x_180_, v___x_210_, v___x_213_);
if (lean_obj_tag(v___x_224_) == 0)
{
lean_object* v___x_225_; 
lean_dec_ref_known(v___x_224_, 1);
v___x_225_ = vastitas_storage_store(v_a_164_, v___x_217_, v___x_221_, v___x_207_, v___x_190_, v___x_222_, v___x_185_, v___x_183_, v___x_199_, v___x_180_, v___x_200_, v___x_215_);
if (lean_obj_tag(v___x_225_) == 0)
{
uint32_t v___x_226_; uint64_t v___x_227_; lean_object* v___x_228_; 
lean_dec_ref_known(v___x_225_, 1);
v___x_226_ = 3;
v___x_227_ = 65562ULL;
v___x_228_ = vastitas_storage_allocate(v_a_164_, v___x_226_, v___x_180_, v___x_227_);
if (lean_obj_tag(v___x_228_) == 0)
{
lean_object* v___x_229_; 
lean_dec_ref_known(v___x_228_, 1);
v___x_229_ = vastitas_storage_fill(v_a_164_, v___x_226_, v___x_183_, v___x_227_, v___x_184_, v___x_227_, v___x_185_, v___x_180_, v___x_186_, v___x_187_);
if (lean_obj_tag(v___x_229_) == 0)
{
uint32_t v___x_230_; uint64_t v___x_231_; lean_object* v___x_232_; 
lean_dec_ref_known(v___x_229_, 1);
v___x_230_ = 4;
v___x_231_ = 65928ULL;
v___x_232_ = vastitas_storage_allocate(v_a_164_, v___x_230_, v___x_180_, v___x_231_);
if (lean_obj_tag(v___x_232_) == 0)
{
lean_object* v___x_233_; 
lean_dec_ref_known(v___x_232_, 1);
v___x_233_ = vastitas_storage_fill(v_a_164_, v___x_230_, v___x_183_, v___x_231_, v___x_184_, v___x_231_, v___x_185_, v___x_180_, v___x_186_, v___x_187_);
if (lean_obj_tag(v___x_233_) == 0)
{
uint32_t v___x_234_; uint64_t v___x_235_; lean_object* v___x_236_; 
lean_dec_ref_known(v___x_233_, 1);
v___x_234_ = 5;
v___x_235_ = 16780809ULL;
v___x_236_ = vastitas_storage_allocate(v_a_164_, v___x_234_, v___x_180_, v___x_235_);
if (lean_obj_tag(v___x_236_) == 0)
{
lean_object* v___x_237_; 
lean_dec_ref_known(v___x_236_, 1);
v___x_237_ = vastitas_storage_fill(v_a_164_, v___x_234_, v___x_183_, v___x_235_, v___x_184_, v___x_235_, v___x_185_, v___x_180_, v___x_186_, v___x_187_);
if (lean_obj_tag(v___x_237_) == 0)
{
uint64_t v___x_238_; uint64_t v___x_239_; lean_object* v___x_240_; 
lean_dec_ref_known(v___x_237_, 1);
v___x_238_ = 1024ULL;
v___x_239_ = 1029ULL;
v___x_240_ = vastitas_storage_pack3(v_a_164_, v___x_179_, v___x_189_, v___x_190_, v___x_191_, v___x_192_, v___x_185_, v___x_226_, v___x_208_, v___x_238_, v___x_207_, v___x_239_, v___x_185_, v___x_190_, v___x_207_, v___x_207_);
if (lean_obj_tag(v___x_240_) == 0)
{
uint64_t v___x_241_; uint64_t v___x_242_; uint8_t v___x_243_; lean_object* v___x_244_; 
lean_dec_ref_known(v___x_240_, 1);
v___x_241_ = 80ULL;
v___x_242_ = 1030ULL;
v___x_243_ = 0;
v___x_244_ = vastitas_gemm_execute(v_a_164_, v___x_226_, v___x_208_, v___x_238_, v___x_207_, v___x_239_, v___x_185_, v___x_185_, v___x_202_, v___x_206_, v___x_207_, v___x_208_, v___x_209_, v___x_185_, v___x_185_, v___x_230_, v___x_241_, v___x_238_, v___x_208_, v___x_242_, v___x_185_, v___x_243_);
if (lean_obj_tag(v___x_244_) == 0)
{
uint64_t v___x_245_; uint64_t v___x_246_; uint64_t v___x_247_; uint64_t v___x_248_; lean_object* v___x_249_; 
lean_dec_ref_known(v___x_244_, 1);
v___x_245_ = 112ULL;
v___x_246_ = 32768ULL;
v___x_247_ = 32776ULL;
v___x_248_ = 42ULL;
v___x_249_ = vastitas_storage_regroup3(v_a_164_, v___x_230_, v___x_241_, v___x_238_, v___x_208_, v___x_242_, v___x_185_, v___x_226_, v___x_245_, v___x_246_, v___x_207_, v___x_247_, v___x_185_, v___x_190_, v___x_207_, v___x_208_, v___x_221_, v___x_248_);
if (lean_obj_tag(v___x_249_) == 0)
{
uint64_t v___x_250_; uint64_t v___x_251_; lean_object* v___x_252_; 
lean_dec_ref_known(v___x_249_, 1);
v___x_250_ = 96ULL;
v___x_251_ = 32775ULL;
v___x_252_ = vastitas_gemm_execute(v_a_164_, v___x_226_, v___x_245_, v___x_246_, v___x_207_, v___x_247_, v___x_185_, v___x_185_, v___x_217_, v___x_221_, v___x_207_, v___x_190_, v___x_222_, v___x_185_, v___x_185_, v___x_234_, v___x_250_, v___x_246_, v___x_190_, v___x_251_, v___x_185_, v___x_243_);
if (lean_obj_tag(v___x_252_) == 0)
{
uint64_t v___x_253_; uint64_t v___x_254_; lean_object* v___x_255_; 
lean_dec_ref_known(v___x_252_, 1);
v___x_253_ = 4590293920197378049ULL;
v___x_254_ = 4591701295080931328ULL;
v___x_255_ = vastitas_storage_expect(v_a_164_, v___x_234_, v___x_250_, v___x_246_, v___x_190_, v___x_251_, v___x_185_, v___x_183_, v___x_183_, v___x_180_, v___x_253_, v___x_254_);
if (lean_obj_tag(v___x_255_) == 0)
{
uint64_t v___x_256_; uint64_t v___x_257_; lean_object* v___x_258_; 
lean_dec_ref_known(v___x_255_, 1);
v___x_256_ = 4594797519824748544ULL;
v___x_257_ = 13829885952585105408ULL;
v___x_258_ = vastitas_storage_expect(v_a_164_, v___x_234_, v___x_250_, v___x_246_, v___x_190_, v___x_251_, v___x_185_, v___x_199_, v___x_199_, v___x_180_, v___x_256_, v___x_257_);
if (lean_obj_tag(v___x_258_) == 0)
{
uint64_t v___x_259_; uint64_t v___x_260_; uint64_t v___x_261_; lean_object* v___x_262_; 
lean_dec_ref_known(v___x_258_, 1);
v___x_259_ = 32767ULL;
v___x_260_ = 13810288257331625984ULL;
v___x_261_ = 13816199231842549760ULL;
v___x_262_ = vastitas_storage_expect(v_a_164_, v___x_234_, v___x_250_, v___x_246_, v___x_190_, v___x_251_, v___x_185_, v___x_259_, v___x_183_, v___x_180_, v___x_260_, v___x_261_);
if (lean_obj_tag(v___x_262_) == 0)
{
lean_object* v___x_263_; 
lean_dec_ref_known(v___x_262_, 1);
v___x_263_ = vastitas_storage_drop(v_a_164_, v___x_234_);
if (lean_obj_tag(v___x_263_) == 0)
{
lean_object* v___x_264_; 
lean_dec_ref_known(v___x_263_, 1);
v___x_264_ = vastitas_storage_drop(v_a_164_, v___x_230_);
if (lean_obj_tag(v___x_264_) == 0)
{
lean_object* v___x_265_; 
lean_dec_ref_known(v___x_264_, 1);
v___x_265_ = vastitas_storage_drop(v_a_164_, v___x_226_);
if (lean_obj_tag(v___x_265_) == 0)
{
lean_object* v___x_266_; 
lean_dec_ref_known(v___x_265_, 1);
v___x_266_ = vastitas_storage_drop(v_a_164_, v___x_217_);
if (lean_obj_tag(v___x_266_) == 0)
{
lean_object* v___x_267_; 
lean_dec_ref_known(v___x_266_, 1);
v___x_267_ = vastitas_storage_drop(v_a_164_, v___x_202_);
if (lean_obj_tag(v___x_267_) == 0)
{
lean_object* v___x_268_; 
lean_dec_ref_known(v___x_267_, 1);
v___x_268_ = vastitas_storage_drop(v_a_164_, v___x_179_);
if (lean_obj_tag(v___x_268_) == 0)
{
lean_object* v___x_269_; 
lean_dec_ref_known(v___x_268_, 1);
v___x_269_ = vastitas_storage_close(v_a_164_);
lean_dec(v_a_164_);
return v___x_269_;
}
else
{
v___y_166_ = v___x_268_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_267_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_266_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_265_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_264_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_263_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_262_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_258_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_255_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_252_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_249_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_244_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_240_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_237_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_236_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_233_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_232_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_229_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_228_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_225_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_224_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_223_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_220_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_219_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_216_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_214_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_211_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_205_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_204_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_201_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_198_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_195_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_188_;
goto v___jp_165_;
}
}
else
{
v___y_166_ = v___x_182_;
goto v___jp_165_;
}
v___jp_165_:
{
if (lean_obj_tag(v___y_166_) == 0)
{
lean_object* v___x_167_; 
lean_dec_ref_known(v___y_166_, 1);
v___x_167_ = vastitas_storage_close(v_a_164_);
lean_dec(v_a_164_);
return v___x_167_;
}
else
{
lean_object* v_a_168_; lean_object* v___x_169_; 
v_a_168_ = lean_ctor_get(v___y_166_, 0);
lean_inc(v_a_168_);
lean_dec_ref_known(v___y_166_, 1);
v___x_169_ = vastitas_storage_close(v_a_164_);
if (lean_obj_tag(v___x_169_) == 0)
{
lean_object* v___x_171_; uint8_t v_isShared_172_; uint8_t v_isSharedCheck_176_; 
lean_dec(v_a_164_);
v_isSharedCheck_176_ = !lean_is_exclusive(v___x_169_);
if (v_isSharedCheck_176_ == 0)
{
lean_object* v_unused_177_; 
v_unused_177_ = lean_ctor_get(v___x_169_, 0);
lean_dec(v_unused_177_);
v___x_171_ = v___x_169_;
v_isShared_172_ = v_isSharedCheck_176_;
goto v_resetjp_170_;
}
else
{
lean_dec(v___x_169_);
v___x_171_ = lean_box(0);
v_isShared_172_ = v_isSharedCheck_176_;
goto v_resetjp_170_;
}
v_resetjp_170_:
{
lean_object* v___x_174_; 
if (v_isShared_172_ == 0)
{
lean_ctor_set_tag(v___x_171_, 1);
lean_ctor_set(v___x_171_, 0, v_a_168_);
v___x_174_ = v___x_171_;
goto v_reusejp_173_;
}
else
{
lean_object* v_reuseFailAlloc_175_; 
v_reuseFailAlloc_175_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_175_, 0, v_a_168_);
v___x_174_ = v_reuseFailAlloc_175_;
goto v_reusejp_173_;
}
v_reusejp_173_:
{
return v___x_174_;
}
}
}
else
{
lean_dec(v_a_168_);
if (lean_obj_tag(v___x_169_) == 0)
{
lean_object* v___x_178_; 
lean_dec_ref_known(v___x_169_, 1);
v___x_178_ = vastitas_storage_close(v_a_164_);
lean_dec(v_a_164_);
return v___x_178_;
}
else
{
lean_dec(v_a_164_);
return v___x_169_;
}
}
}
}
}
else
{
lean_object* v_a_270_; lean_object* v___x_272_; uint8_t v_isShared_273_; uint8_t v_isSharedCheck_277_; 
v_a_270_ = lean_ctor_get(v___x_163_, 0);
v_isSharedCheck_277_ = !lean_is_exclusive(v___x_163_);
if (v_isSharedCheck_277_ == 0)
{
v___x_272_ = v___x_163_;
v_isShared_273_ = v_isSharedCheck_277_;
goto v_resetjp_271_;
}
else
{
lean_inc(v_a_270_);
lean_dec(v___x_163_);
v___x_272_ = lean_box(0);
v_isShared_273_ = v_isSharedCheck_277_;
goto v_resetjp_271_;
}
v_resetjp_271_:
{
lean_object* v___x_275_; 
if (v_isShared_273_ == 0)
{
v___x_275_ = v___x_272_;
goto v_reusejp_274_;
}
else
{
lean_object* v_reuseFailAlloc_276_; 
v_reuseFailAlloc_276_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_276_, 0, v_a_270_);
v___x_275_ = v_reuseFailAlloc_276_;
goto v_reusejp_274_;
}
v_reusejp_274_:
{
return v___x_275_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object* v_a_278_){
_start:
{
lean_object* v_res_279_; 
v_res_279_ = lp_allocation__audit_generatedFailure();
return v_res_279_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object* v_phase_282_, lean_object* v_a_00___x40___internal___hyg_283_){
_start:
{
uint32_t v_phase_boxed_284_; lean_object* v_res_285_; 
v_phase_boxed_284_ = lean_unbox_uint32(v_phase_282_);
lean_dec(v_phase_282_);
v_res_285_ = audit_mark_lean(v_phase_boxed_284_);
return v_res_285_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object* v_a_286_, lean_object* v_scope_287_, lean_object* v_range_288_, lean_object* v_b_289_, lean_object* v_i_290_){
_start:
{
lean_object* v_stop_292_; lean_object* v_step_293_; uint8_t v___x_294_; 
v_stop_292_ = lean_ctor_get(v_range_288_, 1);
v_step_293_ = lean_ctor_get(v_range_288_, 2);
v___x_294_ = lean_nat_dec_lt(v_i_290_, v_stop_292_);
if (v___x_294_ == 0)
{
lean_object* v___x_295_; 
lean_dec(v_i_290_);
v___x_295_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_295_, 0, v_b_289_);
return v___x_295_;
}
else
{
uint32_t v___x_296_; uint64_t v___x_297_; uint64_t v___x_298_; uint64_t v___x_299_; uint64_t v___x_300_; lean_object* v___x_301_; uint8_t v___x_302_; uint32_t v___x_303_; uint64_t v___x_304_; uint64_t v___x_305_; uint32_t v___x_306_; uint64_t v___x_307_; uint64_t v___x_308_; uint32_t v___x_309_; uint64_t v___x_310_; uint32_t v___x_311_; uint64_t v___x_312_; uint32_t v___x_313_; lean_object* v___x_314_; uint64_t v___x_315_; uint64_t v___x_316_; lean_object* v___x_317_; 
v___x_296_ = 0;
v___x_297_ = 16ULL;
v___x_298_ = 512ULL;
v___x_299_ = 4ULL;
v___x_300_ = 514ULL;
v___x_301_ = lean_unsigned_to_nat(0u);
v___x_302_ = lean_nat_dec_eq(v_scope_287_, v___x_301_);
v___x_303_ = 3;
v___x_304_ = 64ULL;
v___x_305_ = 2ULL;
v___x_306_ = 1;
v___x_307_ = 32ULL;
v___x_308_ = 5ULL;
v___x_309_ = 4;
v___x_310_ = 48ULL;
v___x_311_ = 2;
v___x_312_ = 6ULL;
v___x_313_ = 5;
v___x_314_ = lean_box(0);
v___x_315_ = 1024ULL;
v___x_316_ = 1029ULL;
v___x_317_ = vastitas_storage_pack3(v_a_286_, v___x_296_, v___x_297_, v___x_298_, v___x_299_, v___x_300_, v___x_302_, v___x_303_, v___x_304_, v___x_315_, v___x_305_, v___x_316_, v___x_302_, v___x_298_, v___x_305_, v___x_305_);
if (lean_obj_tag(v___x_317_) == 0)
{
uint64_t v___x_318_; uint64_t v___x_319_; uint8_t v___x_320_; lean_object* v___x_321_; 
lean_dec_ref_known(v___x_317_, 1);
v___x_318_ = 80ULL;
v___x_319_ = 1030ULL;
v___x_320_ = 0;
v___x_321_ = vastitas_gemm_execute(v_a_286_, v___x_303_, v___x_304_, v___x_315_, v___x_305_, v___x_316_, v___x_302_, v___x_302_, v___x_306_, v___x_307_, v___x_305_, v___x_304_, v___x_308_, v___x_302_, v___x_302_, v___x_309_, v___x_318_, v___x_315_, v___x_304_, v___x_319_, v___x_302_, v___x_320_);
if (lean_obj_tag(v___x_321_) == 0)
{
uint64_t v___x_322_; uint64_t v___x_323_; uint64_t v___x_324_; uint64_t v___x_325_; lean_object* v___x_326_; 
lean_dec_ref_known(v___x_321_, 1);
v___x_322_ = 112ULL;
v___x_323_ = 32768ULL;
v___x_324_ = 32776ULL;
v___x_325_ = 42ULL;
v___x_326_ = vastitas_storage_regroup3(v_a_286_, v___x_309_, v___x_318_, v___x_315_, v___x_304_, v___x_319_, v___x_302_, v___x_303_, v___x_322_, v___x_323_, v___x_305_, v___x_324_, v___x_302_, v___x_298_, v___x_305_, v___x_304_, v___x_310_, v___x_325_);
if (lean_obj_tag(v___x_326_) == 0)
{
uint64_t v___x_327_; uint64_t v___x_328_; lean_object* v___x_329_; 
lean_dec_ref_known(v___x_326_, 1);
v___x_327_ = 96ULL;
v___x_328_ = 32775ULL;
v___x_329_ = vastitas_gemm_execute(v_a_286_, v___x_303_, v___x_322_, v___x_323_, v___x_305_, v___x_324_, v___x_302_, v___x_302_, v___x_311_, v___x_310_, v___x_305_, v___x_298_, v___x_312_, v___x_302_, v___x_302_, v___x_313_, v___x_327_, v___x_323_, v___x_298_, v___x_328_, v___x_302_, v___x_320_);
if (lean_obj_tag(v___x_329_) == 0)
{
lean_object* v___x_330_; 
lean_dec_ref_known(v___x_329_, 1);
v___x_330_ = lean_nat_add(v_i_290_, v_step_293_);
lean_dec(v_i_290_);
v_b_289_ = v___x_314_;
v_i_290_ = v___x_330_;
goto _start;
}
else
{
lean_dec(v_i_290_);
return v___x_329_;
}
}
else
{
lean_dec(v_i_290_);
return v___x_326_;
}
}
else
{
lean_dec(v_i_290_);
return v___x_321_;
}
}
else
{
lean_dec(v_i_290_);
return v___x_317_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object* v_a_332_, lean_object* v_scope_333_, lean_object* v_range_334_, lean_object* v_b_335_, lean_object* v_i_336_, lean_object* v___y_337_){
_start:
{
lean_object* v_res_338_; 
v_res_338_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_332_, v_scope_333_, v_range_334_, v_b_335_, v_i_336_);
lean_dec_ref(v_range_334_);
lean_dec(v_scope_333_);
lean_dec(v_a_332_);
return v_res_338_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object* v_range_339_, lean_object* v_b_340_, lean_object* v_i_341_){
_start:
{
lean_object* v_stop_343_; lean_object* v_step_344_; uint8_t v___x_345_; 
v_stop_343_ = lean_ctor_get(v_range_339_, 1);
v_step_344_ = lean_ctor_get(v_range_339_, 2);
v___x_345_ = lean_nat_dec_lt(v_i_341_, v_stop_343_);
if (v___x_345_ == 0)
{
lean_object* v___x_346_; 
lean_dec(v_i_341_);
v___x_346_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_346_, 0, v_b_340_);
return v___x_346_;
}
else
{
lean_object* v___x_347_; lean_object* v___x_348_; 
v___x_347_ = lean_box(0);
v___x_348_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_348_) == 0)
{
lean_object* v___x_349_; 
lean_dec_ref_known(v___x_348_, 1);
v___x_349_ = lean_nat_add(v_i_341_, v_step_344_);
lean_dec(v_i_341_);
v_b_340_ = v___x_347_;
v_i_341_ = v___x_349_;
goto _start;
}
else
{
lean_dec(v_i_341_);
return v___x_348_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object* v_range_351_, lean_object* v_b_352_, lean_object* v_i_353_, lean_object* v___y_354_){
_start:
{
lean_object* v_res_355_; 
v_res_355_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_351_, v_b_352_, v_i_353_);
lean_dec_ref(v_range_351_);
return v_res_355_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_364_){
_start:
{
lean_object* v___x_366_; lean_object* v___x_367_; lean_object* v_impl_368_; lean_object* v___x_369_; lean_object* v___x_370_; lean_object* v___x_371_; lean_object* v___x_372_; lean_object* v_scope_373_; lean_object* v___x_374_; lean_object* v___x_375_; lean_object* v___x_376_; lean_object* v___x_377_; lean_object* v_reps_378_; lean_object* v___x_379_; lean_object* v___x_380_; lean_object* v___x_381_; uint8_t v_verify_382_; uint32_t v___x_383_; lean_object* v___x_384_; 
v___x_366_ = ((lean_object*)(lp_allocation__audit_main___closed__0));
v___x_367_ = lean_unsigned_to_nat(0u);
v_impl_368_ = l_List_get_x21Internal___redArg(v___x_366_, v_args_364_, v___x_367_);
v___x_369_ = lean_unsigned_to_nat(1u);
v___x_370_ = l_List_get_x21Internal___redArg(v___x_366_, v_args_364_, v___x_369_);
v___x_371_ = lean_string_utf8_byte_size(v___x_370_);
v___x_372_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_372_, 0, v___x_370_);
lean_ctor_set(v___x_372_, 1, v___x_367_);
lean_ctor_set(v___x_372_, 2, v___x_371_);
v_scope_373_ = l_String_Slice_toNat_x21(v___x_372_);
lean_dec_ref_known(v___x_372_, 3);
v___x_374_ = lean_unsigned_to_nat(2u);
v___x_375_ = l_List_get_x21Internal___redArg(v___x_366_, v_args_364_, v___x_374_);
v___x_376_ = lean_string_utf8_byte_size(v___x_375_);
v___x_377_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_377_, 0, v___x_375_);
lean_ctor_set(v___x_377_, 1, v___x_367_);
lean_ctor_set(v___x_377_, 2, v___x_376_);
v_reps_378_ = l_String_Slice_toNat_x21(v___x_377_);
lean_dec_ref_known(v___x_377_, 3);
v___x_379_ = lean_unsigned_to_nat(3u);
v___x_380_ = l_List_get_x21Internal___redArg(v___x_366_, v_args_364_, v___x_379_);
lean_dec(v_args_364_);
v___x_381_ = ((lean_object*)(lp_allocation__audit_main___closed__1));
v_verify_382_ = lean_string_dec_eq(v___x_380_, v___x_381_);
lean_dec(v___x_380_);
v___x_383_ = 1;
v___x_384_ = audit_mark_lean(v___x_383_);
if (lean_obj_tag(v___x_384_) == 0)
{
lean_object* v___x_385_; 
lean_dec_ref_known(v___x_384_, 1);
v___x_385_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_385_) == 0)
{
uint32_t v___x_386_; lean_object* v___x_387_; 
lean_dec_ref_known(v___x_385_, 1);
v___x_386_ = 2;
v___x_387_ = audit_mark_lean(v___x_386_);
if (lean_obj_tag(v___x_387_) == 0)
{
lean_object* v___x_388_; uint8_t v___x_389_; 
lean_dec_ref_known(v___x_387_, 1);
v___x_388_ = ((lean_object*)(lp_allocation__audit_main___closed__2));
v___x_389_ = lean_string_dec_eq(v_impl_368_, v___x_388_);
if (v___x_389_ == 0)
{
lean_object* v___x_390_; uint8_t v___x_391_; 
v___x_390_ = ((lean_object*)(lp_allocation__audit_main___closed__3));
v___x_391_ = lean_string_dec_eq(v_impl_368_, v___x_390_);
lean_dec(v_impl_368_);
if (v___x_391_ == 0)
{
uint8_t v___x_392_; 
v___x_392_ = lean_nat_dec_eq(v_scope_373_, v___x_367_);
if (v___x_392_ == 0)
{
uint64_t v___x_393_; lean_object* v___x_394_; 
v___x_393_ = 9223372036854775807ULL;
v___x_394_ = vastitas_storage_new(v___x_393_);
if (lean_obj_tag(v___x_394_) == 0)
{
lean_object* v_a_395_; lean_object* v___y_400_; uint32_t v___x_411_; uint8_t v___x_412_; uint64_t v___x_413_; lean_object* v___x_414_; 
v_a_395_ = lean_ctor_get(v___x_394_, 0);
lean_inc(v_a_395_);
lean_dec_ref_known(v___x_394_, 1);
v___x_411_ = 0;
v___x_412_ = 1;
v___x_413_ = 2060ULL;
v___x_414_ = vastitas_storage_allocate(v_a_395_, v___x_411_, v___x_412_, v___x_413_);
if (lean_obj_tag(v___x_414_) == 0)
{
uint64_t v___x_415_; uint64_t v___x_416_; uint64_t v___x_417_; uint64_t v___x_418_; lean_object* v___x_419_; 
lean_dec_ref_known(v___x_414_, 1);
v___x_415_ = 0ULL;
v___x_416_ = 1ULL;
v___x_417_ = 13842939354630062080ULL;
v___x_418_ = 4613937818241073152ULL;
v___x_419_ = vastitas_storage_fill(v_a_395_, v___x_411_, v___x_415_, v___x_413_, v___x_416_, v___x_413_, v___x_392_, v___x_412_, v___x_417_, v___x_418_);
if (lean_obj_tag(v___x_419_) == 0)
{
uint64_t v___x_420_; uint64_t v___x_421_; uint64_t v___x_422_; uint64_t v___x_423_; uint64_t v___x_424_; uint64_t v___x_425_; lean_object* v___x_426_; 
lean_dec_ref_known(v___x_419_, 1);
v___x_420_ = 16ULL;
v___x_421_ = 512ULL;
v___x_422_ = 4ULL;
v___x_423_ = 514ULL;
v___x_424_ = 4593671619917905920ULL;
v___x_425_ = 4598175219545276416ULL;
v___x_426_ = vastitas_storage_fill(v_a_395_, v___x_411_, v___x_420_, v___x_421_, v___x_422_, v___x_423_, v___x_392_, v___x_412_, v___x_424_, v___x_425_);
if (lean_obj_tag(v___x_426_) == 0)
{
uint64_t v___x_427_; uint64_t v___x_428_; lean_object* v___x_429_; 
lean_dec_ref_known(v___x_426_, 1);
v___x_427_ = 4607182418800017408ULL;
v___x_428_ = 13826050856027422720ULL;
v___x_429_ = vastitas_storage_store(v_a_395_, v___x_411_, v___x_420_, v___x_421_, v___x_422_, v___x_423_, v___x_392_, v___x_415_, v___x_415_, v___x_412_, v___x_427_, v___x_428_);
if (lean_obj_tag(v___x_429_) == 0)
{
uint64_t v___x_430_; uint64_t v___x_431_; lean_object* v___x_432_; 
lean_dec_ref_known(v___x_429_, 1);
v___x_430_ = 511ULL;
v___x_431_ = 4604930618986332160ULL;
v___x_432_ = vastitas_storage_store(v_a_395_, v___x_411_, v___x_420_, v___x_421_, v___x_422_, v___x_423_, v___x_392_, v___x_430_, v___x_416_, v___x_412_, v___x_428_, v___x_431_);
if (lean_obj_tag(v___x_432_) == 0)
{
uint64_t v___x_433_; lean_object* v___x_434_; 
lean_dec_ref_known(v___x_432_, 1);
v___x_433_ = 325ULL;
v___x_434_ = vastitas_storage_allocate(v_a_395_, v___x_383_, v___x_412_, v___x_433_);
if (lean_obj_tag(v___x_434_) == 0)
{
lean_object* v___x_435_; 
lean_dec_ref_known(v___x_434_, 1);
v___x_435_ = vastitas_storage_fill(v_a_395_, v___x_383_, v___x_415_, v___x_433_, v___x_416_, v___x_433_, v___x_392_, v___x_412_, v___x_417_, v___x_418_);
if (lean_obj_tag(v___x_435_) == 0)
{
uint64_t v___x_436_; uint64_t v___x_437_; uint64_t v___x_438_; uint64_t v___x_439_; uint64_t v___x_440_; lean_object* v___x_441_; 
lean_dec_ref_known(v___x_435_, 1);
v___x_436_ = 32ULL;
v___x_437_ = 2ULL;
v___x_438_ = 64ULL;
v___x_439_ = 5ULL;
v___x_440_ = 13821547256400052224ULL;
v___x_441_ = vastitas_storage_fill(v_a_395_, v___x_383_, v___x_436_, v___x_437_, v___x_438_, v___x_439_, v___x_392_, v___x_412_, v___x_440_, v___x_424_);
if (lean_obj_tag(v___x_441_) == 0)
{
uint64_t v___x_442_; uint64_t v___x_443_; lean_object* v___x_444_; 
lean_dec_ref_known(v___x_441_, 1);
v___x_442_ = 63ULL;
v___x_443_ = 4602678819172646912ULL;
v___x_444_ = vastitas_storage_store(v_a_395_, v___x_383_, v___x_436_, v___x_437_, v___x_438_, v___x_439_, v___x_392_, v___x_415_, v___x_442_, v___x_412_, v___x_443_, v___x_425_);
if (lean_obj_tag(v___x_444_) == 0)
{
uint64_t v___x_445_; lean_object* v___x_446_; 
lean_dec_ref_known(v___x_444_, 1);
v___x_445_ = 13828302655841107968ULL;
v___x_446_ = vastitas_storage_store(v_a_395_, v___x_383_, v___x_436_, v___x_437_, v___x_438_, v___x_439_, v___x_392_, v___x_416_, v___x_415_, v___x_412_, v___x_445_, v___x_428_);
if (lean_obj_tag(v___x_446_) == 0)
{
uint64_t v___x_447_; lean_object* v___x_448_; 
lean_dec_ref_known(v___x_446_, 1);
v___x_447_ = 3078ULL;
v___x_448_ = vastitas_storage_allocate(v_a_395_, v___x_386_, v___x_412_, v___x_447_);
if (lean_obj_tag(v___x_448_) == 0)
{
lean_object* v___x_449_; 
lean_dec_ref_known(v___x_448_, 1);
v___x_449_ = vastitas_storage_fill(v_a_395_, v___x_386_, v___x_415_, v___x_447_, v___x_416_, v___x_447_, v___x_392_, v___x_412_, v___x_417_, v___x_418_);
if (lean_obj_tag(v___x_449_) == 0)
{
uint64_t v___x_450_; uint64_t v___x_451_; lean_object* v___x_452_; 
lean_dec_ref_known(v___x_449_, 1);
v___x_450_ = 48ULL;
v___x_451_ = 6ULL;
v___x_452_ = vastitas_storage_fill(v_a_395_, v___x_386_, v___x_450_, v___x_437_, v___x_421_, v___x_451_, v___x_392_, v___x_412_, v___x_443_, v___x_440_);
if (lean_obj_tag(v___x_452_) == 0)
{
lean_object* v___x_453_; 
lean_dec_ref_known(v___x_452_, 1);
v___x_453_ = vastitas_storage_store(v_a_395_, v___x_386_, v___x_450_, v___x_437_, v___x_421_, v___x_451_, v___x_392_, v___x_416_, v___x_415_, v___x_412_, v___x_440_, v___x_443_);
if (lean_obj_tag(v___x_453_) == 0)
{
lean_object* v___x_454_; 
lean_dec_ref_known(v___x_453_, 1);
v___x_454_ = vastitas_storage_store(v_a_395_, v___x_386_, v___x_450_, v___x_437_, v___x_421_, v___x_451_, v___x_392_, v___x_415_, v___x_430_, v___x_412_, v___x_431_, v___x_445_);
if (lean_obj_tag(v___x_454_) == 0)
{
uint32_t v___x_455_; uint64_t v___x_456_; lean_object* v___x_457_; 
lean_dec_ref_known(v___x_454_, 1);
v___x_455_ = 3;
v___x_456_ = 65562ULL;
v___x_457_ = vastitas_storage_allocate(v_a_395_, v___x_455_, v___x_412_, v___x_456_);
if (lean_obj_tag(v___x_457_) == 0)
{
lean_object* v___x_458_; 
lean_dec_ref_known(v___x_457_, 1);
v___x_458_ = vastitas_storage_fill(v_a_395_, v___x_455_, v___x_415_, v___x_456_, v___x_416_, v___x_456_, v___x_392_, v___x_412_, v___x_417_, v___x_418_);
if (lean_obj_tag(v___x_458_) == 0)
{
uint32_t v___x_459_; uint64_t v___x_460_; lean_object* v___x_461_; 
lean_dec_ref_known(v___x_458_, 1);
v___x_459_ = 4;
v___x_460_ = 65928ULL;
v___x_461_ = vastitas_storage_allocate(v_a_395_, v___x_459_, v___x_412_, v___x_460_);
if (lean_obj_tag(v___x_461_) == 0)
{
lean_object* v___x_462_; 
lean_dec_ref_known(v___x_461_, 1);
v___x_462_ = vastitas_storage_fill(v_a_395_, v___x_459_, v___x_415_, v___x_460_, v___x_416_, v___x_460_, v___x_392_, v___x_412_, v___x_417_, v___x_418_);
if (lean_obj_tag(v___x_462_) == 0)
{
uint32_t v___x_463_; uint64_t v___x_464_; lean_object* v___x_465_; 
lean_dec_ref_known(v___x_462_, 1);
v___x_463_ = 5;
v___x_464_ = 16780809ULL;
v___x_465_ = vastitas_storage_allocate(v_a_395_, v___x_463_, v___x_412_, v___x_464_);
if (lean_obj_tag(v___x_465_) == 0)
{
lean_object* v___x_466_; 
lean_dec_ref_known(v___x_465_, 1);
v___x_466_ = vastitas_storage_fill(v_a_395_, v___x_463_, v___x_415_, v___x_464_, v___x_416_, v___x_464_, v___x_392_, v___x_412_, v___x_417_, v___x_418_);
if (lean_obj_tag(v___x_466_) == 0)
{
uint32_t v___x_467_; uint64_t v___x_468_; lean_object* v___x_469_; 
lean_dec_ref_known(v___x_466_, 1);
v___x_467_ = lean_uint32_of_nat(v_scope_373_);
v___x_468_ = lean_uint64_of_nat(v_reps_378_);
v___x_469_ = bench_begin_lean(v___x_467_, v___x_468_, v_verify_382_);
if (lean_obj_tag(v___x_469_) == 0)
{
lean_object* v___x_470_; lean_object* v___x_471_; lean_object* v___x_472_; 
lean_dec_ref_known(v___x_469_, 1);
v___x_470_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_470_, 0, v___x_367_);
lean_ctor_set(v___x_470_, 1, v_reps_378_);
lean_ctor_set(v___x_470_, 2, v___x_369_);
v___x_471_ = lean_box(0);
v___x_472_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_395_, v_scope_373_, v___x_470_, v___x_471_, v___x_367_);
lean_dec_ref_known(v___x_470_, 3);
lean_dec(v_scope_373_);
if (lean_obj_tag(v___x_472_) == 0)
{
lean_object* v___x_473_; 
lean_dec_ref_known(v___x_472_, 1);
v___x_473_ = bench_stop_lean();
if (lean_obj_tag(v___x_473_) == 0)
{
lean_object* v___x_474_; 
lean_dec_ref_known(v___x_473_, 1);
v___x_474_ = bench_verify_lean(v_a_395_, v___x_468_);
if (lean_obj_tag(v___x_474_) == 0)
{
uint64_t v___x_475_; uint64_t v___x_476_; uint64_t v___x_477_; uint64_t v___x_478_; uint64_t v___x_479_; lean_object* v___x_480_; 
lean_dec_ref_known(v___x_474_, 1);
v___x_475_ = 96ULL;
v___x_476_ = 32768ULL;
v___x_477_ = 32775ULL;
v___x_478_ = 4590293920197378048ULL;
v___x_479_ = 4591701295080931328ULL;
v___x_480_ = vastitas_storage_expect(v_a_395_, v___x_463_, v___x_475_, v___x_476_, v___x_421_, v___x_477_, v___x_392_, v___x_415_, v___x_415_, v___x_412_, v___x_478_, v___x_479_);
if (lean_obj_tag(v___x_480_) == 0)
{
uint64_t v___x_481_; uint64_t v___x_482_; lean_object* v___x_483_; 
lean_dec_ref_known(v___x_480_, 1);
v___x_481_ = 4594797519824748544ULL;
v___x_482_ = 13829885952585105408ULL;
v___x_483_ = vastitas_storage_expect(v_a_395_, v___x_463_, v___x_475_, v___x_476_, v___x_421_, v___x_477_, v___x_392_, v___x_430_, v___x_430_, v___x_412_, v___x_481_, v___x_482_);
if (lean_obj_tag(v___x_483_) == 0)
{
uint64_t v___x_484_; uint64_t v___x_485_; uint64_t v___x_486_; lean_object* v___x_487_; 
lean_dec_ref_known(v___x_483_, 1);
v___x_484_ = 32767ULL;
v___x_485_ = 13810288257331625984ULL;
v___x_486_ = 13816199231842549760ULL;
v___x_487_ = vastitas_storage_expect(v_a_395_, v___x_463_, v___x_475_, v___x_476_, v___x_421_, v___x_477_, v___x_392_, v___x_484_, v___x_415_, v___x_412_, v___x_485_, v___x_486_);
if (lean_obj_tag(v___x_487_) == 0)
{
lean_object* v___x_488_; 
lean_dec_ref_known(v___x_487_, 1);
v___x_488_ = vastitas_storage_drop(v_a_395_, v___x_463_);
if (lean_obj_tag(v___x_488_) == 0)
{
lean_object* v___x_489_; 
lean_dec_ref_known(v___x_488_, 1);
v___x_489_ = vastitas_storage_drop(v_a_395_, v___x_459_);
if (lean_obj_tag(v___x_489_) == 0)
{
lean_object* v___x_490_; 
lean_dec_ref_known(v___x_489_, 1);
v___x_490_ = vastitas_storage_drop(v_a_395_, v___x_455_);
if (lean_obj_tag(v___x_490_) == 0)
{
lean_object* v___x_491_; 
lean_dec_ref_known(v___x_490_, 1);
v___x_491_ = vastitas_storage_drop(v_a_395_, v___x_386_);
if (lean_obj_tag(v___x_491_) == 0)
{
lean_object* v___x_492_; 
lean_dec_ref_known(v___x_491_, 1);
v___x_492_ = vastitas_storage_drop(v_a_395_, v___x_383_);
if (lean_obj_tag(v___x_492_) == 0)
{
lean_object* v___x_493_; 
lean_dec_ref_known(v___x_492_, 1);
v___x_493_ = vastitas_storage_drop(v_a_395_, v___x_411_);
v___y_400_ = v___x_493_;
goto v___jp_399_;
}
else
{
v___y_400_ = v___x_492_;
goto v___jp_399_;
}
}
else
{
v___y_400_ = v___x_491_;
goto v___jp_399_;
}
}
else
{
v___y_400_ = v___x_490_;
goto v___jp_399_;
}
}
else
{
v___y_400_ = v___x_489_;
goto v___jp_399_;
}
}
else
{
v___y_400_ = v___x_488_;
goto v___jp_399_;
}
}
else
{
v___y_400_ = v___x_487_;
goto v___jp_399_;
}
}
else
{
v___y_400_ = v___x_483_;
goto v___jp_399_;
}
}
else
{
v___y_400_ = v___x_480_;
goto v___jp_399_;
}
}
else
{
v___y_400_ = v___x_474_;
goto v___jp_399_;
}
}
else
{
v___y_400_ = v___x_473_;
goto v___jp_399_;
}
}
else
{
v___y_400_ = v___x_472_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_469_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_466_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_465_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_462_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_461_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_458_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_457_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_454_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_453_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_452_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_449_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_448_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_446_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_444_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_441_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_435_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_434_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_432_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_429_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_426_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_419_;
goto v___jp_399_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v___y_400_ = v___x_414_;
goto v___jp_399_;
}
v___jp_396_:
{
lean_object* v___x_397_; 
v___x_397_ = vastitas_storage_close(v_a_395_);
lean_dec(v_a_395_);
if (lean_obj_tag(v___x_397_) == 0)
{
lean_object* v___x_398_; 
lean_dec_ref_known(v___x_397_, 1);
v___x_398_ = bench_report_lean();
return v___x_398_;
}
else
{
return v___x_397_;
}
}
v___jp_399_:
{
if (lean_obj_tag(v___y_400_) == 0)
{
lean_dec_ref_known(v___y_400_, 1);
goto v___jp_396_;
}
else
{
lean_object* v_a_401_; lean_object* v___x_402_; 
v_a_401_ = lean_ctor_get(v___y_400_, 0);
lean_inc(v_a_401_);
lean_dec_ref_known(v___y_400_, 1);
v___x_402_ = vastitas_storage_close(v_a_395_);
if (lean_obj_tag(v___x_402_) == 0)
{
lean_object* v___x_404_; uint8_t v_isShared_405_; uint8_t v_isSharedCheck_409_; 
lean_dec(v_a_395_);
v_isSharedCheck_409_ = !lean_is_exclusive(v___x_402_);
if (v_isSharedCheck_409_ == 0)
{
lean_object* v_unused_410_; 
v_unused_410_ = lean_ctor_get(v___x_402_, 0);
lean_dec(v_unused_410_);
v___x_404_ = v___x_402_;
v_isShared_405_ = v_isSharedCheck_409_;
goto v_resetjp_403_;
}
else
{
lean_dec(v___x_402_);
v___x_404_ = lean_box(0);
v_isShared_405_ = v_isSharedCheck_409_;
goto v_resetjp_403_;
}
v_resetjp_403_:
{
lean_object* v___x_407_; 
if (v_isShared_405_ == 0)
{
lean_ctor_set_tag(v___x_404_, 1);
lean_ctor_set(v___x_404_, 0, v_a_401_);
v___x_407_ = v___x_404_;
goto v_reusejp_406_;
}
else
{
lean_object* v_reuseFailAlloc_408_; 
v_reuseFailAlloc_408_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_408_, 0, v_a_401_);
v___x_407_ = v_reuseFailAlloc_408_;
goto v_reusejp_406_;
}
v_reusejp_406_:
{
return v___x_407_;
}
}
}
else
{
lean_dec(v_a_401_);
if (lean_obj_tag(v___x_402_) == 0)
{
lean_dec_ref_known(v___x_402_, 1);
goto v___jp_396_;
}
else
{
lean_dec(v_a_395_);
return v___x_402_;
}
}
}
}
}
else
{
lean_object* v_a_494_; lean_object* v___x_496_; uint8_t v_isShared_497_; uint8_t v_isSharedCheck_501_; 
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
v_a_494_ = lean_ctor_get(v___x_394_, 0);
v_isSharedCheck_501_ = !lean_is_exclusive(v___x_394_);
if (v_isSharedCheck_501_ == 0)
{
v___x_496_ = v___x_394_;
v_isShared_497_ = v_isSharedCheck_501_;
goto v_resetjp_495_;
}
else
{
lean_inc(v_a_494_);
lean_dec(v___x_394_);
v___x_496_ = lean_box(0);
v_isShared_497_ = v_isSharedCheck_501_;
goto v_resetjp_495_;
}
v_resetjp_495_:
{
lean_object* v___x_499_; 
if (v_isShared_497_ == 0)
{
v___x_499_ = v___x_496_;
goto v_reusejp_498_;
}
else
{
lean_object* v_reuseFailAlloc_500_; 
v_reuseFailAlloc_500_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_500_, 0, v_a_494_);
v___x_499_ = v_reuseFailAlloc_500_;
goto v_reusejp_498_;
}
v_reusejp_498_:
{
return v___x_499_;
}
}
}
}
else
{
uint32_t v___x_502_; uint64_t v___x_503_; lean_object* v___x_504_; 
lean_dec(v_scope_373_);
v___x_502_ = 0;
v___x_503_ = lean_uint64_of_nat(v_reps_378_);
v___x_504_ = bench_begin_lean(v___x_502_, v___x_503_, v_verify_382_);
if (lean_obj_tag(v___x_504_) == 0)
{
lean_object* v___x_505_; lean_object* v___x_506_; lean_object* v___x_507_; 
lean_dec_ref_known(v___x_504_, 1);
v___x_505_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_505_, 0, v___x_367_);
lean_ctor_set(v___x_505_, 1, v_reps_378_);
lean_ctor_set(v___x_505_, 2, v___x_369_);
v___x_506_ = lean_box(0);
v___x_507_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v___x_505_, v___x_506_, v___x_367_);
lean_dec_ref_known(v___x_505_, 3);
if (lean_obj_tag(v___x_507_) == 0)
{
lean_object* v___x_508_; 
lean_dec_ref_known(v___x_507_, 1);
v___x_508_ = bench_stop_lean();
if (lean_obj_tag(v___x_508_) == 0)
{
lean_object* v___x_509_; 
lean_dec_ref_known(v___x_508_, 1);
v___x_509_ = bench_report_lean();
return v___x_509_;
}
else
{
return v___x_508_;
}
}
else
{
return v___x_507_;
}
}
else
{
lean_dec(v_reps_378_);
return v___x_504_;
}
}
}
else
{
uint32_t v___x_510_; uint64_t v___x_511_; lean_object* v___x_512_; 
v___x_510_ = lean_uint32_of_nat(v_scope_373_);
lean_dec(v_scope_373_);
v___x_511_ = lean_uint64_of_nat(v_reps_378_);
lean_dec(v_reps_378_);
v___x_512_ = bench_c_run_lean(v___x_510_, v___x_511_, v_verify_382_);
if (lean_obj_tag(v___x_512_) == 0)
{
lean_object* v___x_513_; 
lean_dec_ref_known(v___x_512_, 1);
v___x_513_ = bench_report_lean();
return v___x_513_;
}
else
{
return v___x_512_;
}
}
}
else
{
uint32_t v___x_514_; uint64_t v___x_515_; lean_object* v___x_516_; 
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
lean_dec(v_impl_368_);
v___x_514_ = 0;
v___x_515_ = 1ULL;
v___x_516_ = bench_begin_lean(v___x_514_, v___x_515_, v___x_389_);
if (lean_obj_tag(v___x_516_) == 0)
{
lean_object* v___x_517_; 
lean_dec_ref_known(v___x_516_, 1);
v___x_517_ = lp_allocation__audit_generatedFailure();
if (lean_obj_tag(v___x_517_) == 0)
{
lean_object* v___x_519_; uint8_t v_isShared_520_; uint8_t v_isSharedCheck_525_; 
v_isSharedCheck_525_ = !lean_is_exclusive(v___x_517_);
if (v_isSharedCheck_525_ == 0)
{
lean_object* v_unused_526_; 
v_unused_526_ = lean_ctor_get(v___x_517_, 0);
lean_dec(v_unused_526_);
v___x_519_ = v___x_517_;
v_isShared_520_ = v_isSharedCheck_525_;
goto v_resetjp_518_;
}
else
{
lean_dec(v___x_517_);
v___x_519_ = lean_box(0);
v_isShared_520_ = v_isSharedCheck_525_;
goto v_resetjp_518_;
}
v_resetjp_518_:
{
lean_object* v___x_521_; lean_object* v___x_523_; 
v___x_521_ = ((lean_object*)(lp_allocation__audit_main___closed__5));
if (v_isShared_520_ == 0)
{
lean_ctor_set_tag(v___x_519_, 1);
lean_ctor_set(v___x_519_, 0, v___x_521_);
v___x_523_ = v___x_519_;
goto v_reusejp_522_;
}
else
{
lean_object* v_reuseFailAlloc_524_; 
v_reuseFailAlloc_524_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_524_, 0, v___x_521_);
v___x_523_ = v_reuseFailAlloc_524_;
goto v_reusejp_522_;
}
v_reusejp_522_:
{
return v___x_523_;
}
}
}
else
{
lean_object* v_a_527_; lean_object* v___x_528_; lean_object* v___x_529_; uint8_t v___x_530_; 
v_a_527_ = lean_ctor_get(v___x_517_, 0);
lean_inc(v_a_527_);
v___x_528_ = lean_io_error_to_string(v_a_527_);
v___x_529_ = ((lean_object*)(lp_allocation__audit_main___closed__6));
v___x_530_ = lean_string_dec_eq(v___x_528_, v___x_529_);
lean_dec_ref(v___x_528_);
if (v___x_530_ == 0)
{
return v___x_517_;
}
else
{
lean_object* v___x_531_; 
lean_dec_ref_known(v___x_517_, 1);
v___x_531_ = bench_stop_lean();
if (lean_obj_tag(v___x_531_) == 0)
{
lean_object* v___x_532_; 
lean_dec_ref_known(v___x_531_, 1);
v___x_532_ = bench_report_lean();
return v___x_532_;
}
else
{
return v___x_531_;
}
}
}
}
else
{
return v___x_516_;
}
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
lean_dec(v_impl_368_);
return v___x_387_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
lean_dec(v_impl_368_);
return v___x_385_;
}
}
else
{
lean_dec(v_reps_378_);
lean_dec(v_scope_373_);
lean_dec(v_impl_368_);
return v___x_384_;
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object* v_args_533_, lean_object* v_a_534_){
_start:
{
lean_object* v_res_535_; 
v_res_535_ = _lean_main(v_args_533_);
return v_res_535_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object* v_a_536_, lean_object* v_scope_537_, lean_object* v_range_538_, lean_object* v_b_539_, lean_object* v_i_540_, lean_object* v_hs_541_, lean_object* v_hl_542_){
_start:
{
lean_object* v___x_544_; 
v___x_544_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_536_, v_scope_537_, v_range_538_, v_b_539_, v_i_540_);
return v___x_544_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object* v_a_545_, lean_object* v_scope_546_, lean_object* v_range_547_, lean_object* v_b_548_, lean_object* v_i_549_, lean_object* v_hs_550_, lean_object* v_hl_551_, lean_object* v___y_552_){
_start:
{
lean_object* v_res_553_; 
v_res_553_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(v_a_545_, v_scope_546_, v_range_547_, v_b_548_, v_i_549_, v_hs_550_, v_hl_551_);
lean_dec_ref(v_range_547_);
lean_dec(v_scope_546_);
lean_dec(v_a_545_);
return v_res_553_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object* v_range_554_, lean_object* v_b_555_, lean_object* v_i_556_, lean_object* v_hs_557_, lean_object* v_hl_558_){
_start:
{
lean_object* v___x_560_; 
v___x_560_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_554_, v_b_555_, v_i_556_);
return v___x_560_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object* v_range_561_, lean_object* v_b_562_, lean_object* v_i_563_, lean_object* v_hs_564_, lean_object* v_hl_565_, lean_object* v___y_566_){
_start:
{
lean_object* v_res_567_; 
v_res_567_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(v_range_561_, v_b_562_, v_i_563_, v_hs_564_, v_hl_565_);
lean_dec_ref(v_range_561_);
return v_res_567_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_vastitas__storage__native_VastitasStorageNative(uint8_t builtin);
lean_object* initialize_vastitas__gemm__native_VastitasGemmNative(uint8_t builtin);
lean_object* initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_allocation__audit_Main(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__storage__native_VastitasStorageNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__gemm__native_VastitasGemmNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_allocation__audit_VastitasGenerated_f__0 = _init_lp_allocation__audit_VastitasGenerated_f__0();
lean_mark_persistent(lp_allocation__audit_VastitasGenerated_f__0);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_allocation__audit_Main(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = 0;
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
