/* Fixture data independently constructed from cases.json. */
static const unsigned scalar = 1;
static const uint64_t dim_i=512, dim_k=2, dim_j=2, dim_a=64;
static const VStorageLayout views[7] = {{16,512,4,514,0},{32,2,64,5,0},{48,2,512,6,0},{64,1024,2,1029,0},{80,1024,64,1030,0},{96,32768,512,32775,0},{112,32768,2,32776,0}};
static const uint64_t elements[6] = {2060,325,3078,65562,65928,16780809};
static const double values[3][2] = {{0x1.0000000000000p-3,0x1.0000000000000p-2},{-0x1.0000000000000p-2,0x1.0000000000000p-3},{0x1.0000000000000p-1,-0x1.0000000000000p-2}};
static const double sentinel[2] = {-0x1.c000000000000p+2,0x1.8000000000000p+1};
static const double alpha[2] = {1,0}, beta[2] = {0,0};
typedef struct { uint64_t row, col; double value[2]; } Patch;
static const Patch patches[3][2] = {{{0,0,{0x1.0000000000000p+0,-0x1.0000000000000p-1}},{511,1,{-0x1.0000000000000p-1,0x1.8000000000000p-1}}},{{0,63,{0x1.0000000000000p-1,0x1.0000000000000p-2}},{1,0,{-0x1.8000000000000p-1,-0x1.0000000000000p-1}}},{{1,0,{-0x1.0000000000000p-2,0x1.0000000000000p-1}},{0,511,{0x1.8000000000000p-1,-0x1.8000000000000p-1}}}};
static const Patch expected[3] = {{0,0,{0x1.4000000000000p-4,0x1.9000000000000p-4}},{511,511,{0x1.4000000000000p-3,-0x1.da00000000000p-1}},{32767,0,{-0x1.8000000000000p-5,-0x1.d000000000000p-4}}};
