// Lean compiler output
// Module: Main
// Imports: public import Init public meta import Init public import VastitasStorageNative public import VastitasGemmNative public import VastitasKernel.IndexedRuntime
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* vastitas_storage_new(uint64_t);
lean_object* vastitas_storage_close(lean_object*);
lean_object* vastitas_storage_allocate(lean_object*, uint32_t, uint8_t, uint64_t);
lean_object* vastitas_storage_fill(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_store(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_pack3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_gemm_execute(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t);
lean_object* vastitas_storage_regroup3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_storage_expect(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_drop(lean_object*, uint32_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_List_get_x21Internal___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_String_Slice_toNat_x21(lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
uint32_t lean_uint32_of_nat(lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
lean_object* lean_io_error_to_string(lean_object*);
static lean_once_cell_t lp_allocation__audit_VastitasGenerated_f__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_allocation__audit_VastitasGenerated_f__0___closed__0;
LEAN_EXPORT lean_object* lp_allocation__audit_VastitasGenerated_f__0;
lean_object* bench_begin_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_stop_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object*);
lean_object* bench_report_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object*);
lean_object* bench_c_run_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_verify_lean(lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object*);
lean_object* audit_mark_lean(uint32_t);
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_allocation__audit_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 1, .m_capacity = 1, .m_length = 0, .m_data = ""};
static const lean_object* lp_allocation__audit_main___closed__0 = (const lean_object*)&lp_allocation__audit_main___closed__0_value;
static const lean_string_object lp_allocation__audit_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "1"};
static const lean_object* lp_allocation__audit_main___closed__1 = (const lean_object*)&lp_allocation__audit_main___closed__1_value;
static const lean_string_object lp_allocation__audit_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "failure"};
static const lean_object* lp_allocation__audit_main___closed__2 = (const lean_object*)&lp_allocation__audit_main___closed__2_value;
static const lean_string_object lp_allocation__audit_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "c"};
static const lean_object* lp_allocation__audit_main___closed__3 = (const lean_object*)&lp_allocation__audit_main___closed__3_value;
static const lean_string_object lp_allocation__audit_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "expected injected native failure"};
static const lean_object* lp_allocation__audit_main___closed__4 = (const lean_object*)&lp_allocation__audit_main___closed__4_value;
static const lean_ctor_object lp_allocation__audit_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_allocation__audit_main___closed__4_value)}};
static const lean_object* lp_allocation__audit_main___closed__5 = (const lean_object*)&lp_allocation__audit_main___closed__5_value;
static const lean_string_object lp_allocation__audit_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 44, .m_capacity = 44, .m_length = 43, .m_data = "E_NATIVE_EXPECT: stored bit pattern differs"};
static const lean_object* lp_allocation__audit_main___closed__6 = (const lean_object*)&lp_allocation__audit_main___closed__6_value;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(0u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0(void){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_obj_once(&lp_allocation__audit_VastitasGenerated_f__0___closed__0, &lp_allocation__audit_VastitasGenerated_f__0___closed__0_once, _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object* v_scope_8_, lean_object* v_reps_9_, lean_object* v_verify_10_, lean_object* v_a_00___x40___internal___hyg_11_){
_start:
{
uint32_t v_scope_boxed_12_; uint64_t v_reps_boxed_13_; uint8_t v_verify_boxed_14_; lean_object* v_res_15_; 
v_scope_boxed_12_ = lean_unbox_uint32(v_scope_8_);
lean_dec(v_scope_8_);
v_reps_boxed_13_ = lean_unbox_uint64(v_reps_9_);
lean_dec_ref(v_reps_9_);
v_verify_boxed_14_ = lean_unbox(v_verify_10_);
v_res_15_ = bench_begin_lean(v_scope_boxed_12_, v_reps_boxed_13_, v_verify_boxed_14_);
return v_res_15_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object* v_a_00___x40___internal___hyg_17_){
_start:
{
lean_object* v_res_18_; 
v_res_18_ = bench_stop_lean();
return v_res_18_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object* v_a_00___x40___internal___hyg_20_){
_start:
{
lean_object* v_res_21_; 
v_res_21_ = bench_report_lean();
return v_res_21_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object* v_scope_26_, lean_object* v_reps_27_, lean_object* v_verify_28_, lean_object* v_a_00___x40___internal___hyg_29_){
_start:
{
uint32_t v_scope_boxed_30_; uint64_t v_reps_boxed_31_; uint8_t v_verify_boxed_32_; lean_object* v_res_33_; 
v_scope_boxed_30_ = lean_unbox_uint32(v_scope_26_);
lean_dec(v_scope_26_);
v_reps_boxed_31_ = lean_unbox_uint64(v_reps_27_);
lean_dec_ref(v_reps_27_);
v_verify_boxed_32_ = lean_unbox(v_verify_28_);
v_res_33_ = bench_c_run_lean(v_scope_boxed_30_, v_reps_boxed_31_, v_verify_boxed_32_);
return v_res_33_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object* v_arena_37_, lean_object* v_reps_38_, lean_object* v_a_00___x40___internal___hyg_39_){
_start:
{
uint64_t v_reps_boxed_40_; lean_object* v_res_41_; 
v_reps_boxed_40_ = lean_unbox_uint64(v_reps_38_);
lean_dec_ref(v_reps_38_);
v_res_41_ = bench_verify_lean(v_arena_37_, v_reps_boxed_40_);
lean_dec(v_arena_37_);
return v_res_41_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce(){
_start:
{
uint64_t v___x_43_; lean_object* v___x_44_; 
v___x_43_ = 9223372036854775807ULL;
v___x_44_ = vastitas_storage_new(v___x_43_);
if (lean_obj_tag(v___x_44_) == 0)
{
lean_object* v_a_45_; lean_object* v___y_47_; uint32_t v___x_60_; uint8_t v___x_61_; uint64_t v___x_62_; lean_object* v___x_63_; 
v_a_45_ = lean_ctor_get(v___x_44_, 0);
lean_inc(v_a_45_);
lean_dec_ref_known(v___x_44_, 1);
v___x_60_ = 0;
v___x_61_ = 1;
v___x_62_ = 30720ULL;
v___x_63_ = vastitas_storage_allocate(v_a_45_, v___x_60_, v___x_61_, v___x_62_);
if (lean_obj_tag(v___x_63_) == 0)
{
uint64_t v___x_64_; uint64_t v___x_65_; uint8_t v___x_66_; uint64_t v___x_67_; uint64_t v___x_68_; lean_object* v___x_69_; 
lean_dec_ref_known(v___x_63_, 1);
v___x_64_ = 0ULL;
v___x_65_ = 1ULL;
v___x_66_ = 0;
v___x_67_ = 13842939354630062080ULL;
v___x_68_ = 4613937818241073152ULL;
v___x_69_ = vastitas_storage_fill(v_a_45_, v___x_60_, v___x_64_, v___x_62_, v___x_65_, v___x_62_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_69_) == 0)
{
uint64_t v___x_70_; uint64_t v___x_71_; uint64_t v___x_72_; uint64_t v___x_73_; lean_object* v___x_74_; 
lean_dec_ref_known(v___x_69_, 1);
v___x_70_ = 24ULL;
v___x_71_ = 1280ULL;
v___x_72_ = 4593671619917905920ULL;
v___x_73_ = 4598175219545276416ULL;
v___x_74_ = vastitas_storage_fill(v_a_45_, v___x_60_, v___x_64_, v___x_70_, v___x_71_, v___x_70_, v___x_66_, v___x_61_, v___x_72_, v___x_73_);
if (lean_obj_tag(v___x_74_) == 0)
{
uint64_t v___x_75_; uint64_t v___x_76_; lean_object* v___x_77_; 
lean_dec_ref_known(v___x_74_, 1);
v___x_75_ = 4607182418800017408ULL;
v___x_76_ = 13826050856027422720ULL;
v___x_77_ = vastitas_storage_store(v_a_45_, v___x_60_, v___x_64_, v___x_70_, v___x_71_, v___x_70_, v___x_66_, v___x_64_, v___x_64_, v___x_61_, v___x_75_, v___x_76_);
if (lean_obj_tag(v___x_77_) == 0)
{
uint64_t v___x_78_; uint64_t v___x_79_; lean_object* v___x_80_; 
lean_dec_ref_known(v___x_77_, 1);
v___x_78_ = 23ULL;
v___x_79_ = 4604930618986332160ULL;
v___x_80_ = vastitas_storage_store(v_a_45_, v___x_60_, v___x_64_, v___x_70_, v___x_71_, v___x_70_, v___x_66_, v___x_78_, v___x_65_, v___x_61_, v___x_76_, v___x_79_);
if (lean_obj_tag(v___x_80_) == 0)
{
uint32_t v___x_81_; uint64_t v___x_82_; lean_object* v___x_83_; 
lean_dec_ref_known(v___x_80_, 1);
v___x_81_ = 1;
v___x_82_ = 1920ULL;
v___x_83_ = vastitas_storage_allocate(v_a_45_, v___x_81_, v___x_61_, v___x_82_);
if (lean_obj_tag(v___x_83_) == 0)
{
lean_object* v___x_84_; 
lean_dec_ref_known(v___x_83_, 1);
v___x_84_ = vastitas_storage_fill(v_a_45_, v___x_81_, v___x_64_, v___x_82_, v___x_65_, v___x_82_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_84_) == 0)
{
uint64_t v___x_85_; uint64_t v___x_86_; uint64_t v___x_87_; lean_object* v___x_88_; 
lean_dec_ref_known(v___x_84_, 1);
v___x_85_ = 40ULL;
v___x_86_ = 48ULL;
v___x_87_ = 13821547256400052224ULL;
v___x_88_ = vastitas_storage_fill(v_a_45_, v___x_81_, v___x_64_, v___x_85_, v___x_86_, v___x_85_, v___x_66_, v___x_61_, v___x_87_, v___x_72_);
if (lean_obj_tag(v___x_88_) == 0)
{
uint64_t v___x_89_; uint64_t v___x_90_; lean_object* v___x_91_; 
lean_dec_ref_known(v___x_88_, 1);
v___x_89_ = 47ULL;
v___x_90_ = 4602678819172646912ULL;
v___x_91_ = vastitas_storage_store(v_a_45_, v___x_81_, v___x_64_, v___x_85_, v___x_86_, v___x_85_, v___x_66_, v___x_64_, v___x_89_, v___x_61_, v___x_90_, v___x_73_);
if (lean_obj_tag(v___x_91_) == 0)
{
uint64_t v___x_92_; uint64_t v___x_93_; lean_object* v___x_94_; 
lean_dec_ref_known(v___x_91_, 1);
v___x_92_ = 39ULL;
v___x_93_ = 13828302655841107968ULL;
v___x_94_ = vastitas_storage_store(v_a_45_, v___x_81_, v___x_64_, v___x_85_, v___x_86_, v___x_85_, v___x_66_, v___x_92_, v___x_64_, v___x_61_, v___x_93_, v___x_76_);
if (lean_obj_tag(v___x_94_) == 0)
{
uint32_t v___x_95_; uint64_t v___x_96_; lean_object* v___x_97_; 
lean_dec_ref_known(v___x_94_, 1);
v___x_95_ = 2;
v___x_96_ = 1792ULL;
v___x_97_ = vastitas_storage_allocate(v_a_45_, v___x_95_, v___x_61_, v___x_96_);
if (lean_obj_tag(v___x_97_) == 0)
{
lean_object* v___x_98_; 
lean_dec_ref_known(v___x_97_, 1);
v___x_98_ = vastitas_storage_fill(v_a_45_, v___x_95_, v___x_64_, v___x_96_, v___x_65_, v___x_96_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_98_) == 0)
{
uint64_t v___x_99_; uint64_t v___x_100_; lean_object* v___x_101_; 
lean_dec_ref_known(v___x_98_, 1);
v___x_99_ = 32ULL;
v___x_100_ = 56ULL;
v___x_101_ = vastitas_storage_fill(v_a_45_, v___x_95_, v___x_64_, v___x_99_, v___x_100_, v___x_99_, v___x_66_, v___x_61_, v___x_90_, v___x_87_);
if (lean_obj_tag(v___x_101_) == 0)
{
uint64_t v___x_102_; lean_object* v___x_103_; 
lean_dec_ref_known(v___x_101_, 1);
v___x_102_ = 31ULL;
v___x_103_ = vastitas_storage_store(v_a_45_, v___x_95_, v___x_64_, v___x_99_, v___x_100_, v___x_99_, v___x_66_, v___x_102_, v___x_64_, v___x_61_, v___x_87_, v___x_90_);
if (lean_obj_tag(v___x_103_) == 0)
{
uint64_t v___x_104_; lean_object* v___x_105_; 
lean_dec_ref_known(v___x_103_, 1);
v___x_104_ = 55ULL;
v___x_105_ = vastitas_storage_store(v_a_45_, v___x_95_, v___x_64_, v___x_99_, v___x_100_, v___x_99_, v___x_66_, v___x_64_, v___x_104_, v___x_61_, v___x_79_, v___x_93_);
if (lean_obj_tag(v___x_105_) == 0)
{
uint32_t v___x_106_; uint64_t v___x_107_; lean_object* v___x_108_; 
lean_dec_ref_known(v___x_105_, 1);
v___x_106_ = 3;
v___x_107_ = 36864ULL;
v___x_108_ = vastitas_storage_allocate(v_a_45_, v___x_106_, v___x_61_, v___x_107_);
if (lean_obj_tag(v___x_108_) == 0)
{
lean_object* v___x_109_; 
lean_dec_ref_known(v___x_108_, 1);
v___x_109_ = vastitas_storage_fill(v_a_45_, v___x_106_, v___x_64_, v___x_107_, v___x_65_, v___x_107_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_109_) == 0)
{
uint32_t v___x_110_; lean_object* v___x_111_; 
lean_dec_ref_known(v___x_109_, 1);
v___x_110_ = 4;
v___x_111_ = vastitas_storage_allocate(v_a_45_, v___x_110_, v___x_61_, v___x_107_);
if (lean_obj_tag(v___x_111_) == 0)
{
lean_object* v___x_112_; 
lean_dec_ref_known(v___x_111_, 1);
v___x_112_ = vastitas_storage_fill(v_a_45_, v___x_110_, v___x_64_, v___x_107_, v___x_65_, v___x_107_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_112_) == 0)
{
uint32_t v___x_113_; uint64_t v___x_114_; lean_object* v___x_115_; 
lean_dec_ref_known(v___x_112_, 1);
v___x_113_ = 5;
v___x_114_ = 64512ULL;
v___x_115_ = vastitas_storage_allocate(v_a_45_, v___x_113_, v___x_61_, v___x_114_);
if (lean_obj_tag(v___x_115_) == 0)
{
lean_object* v___x_116_; 
lean_dec_ref_known(v___x_115_, 1);
v___x_116_ = vastitas_storage_fill(v_a_45_, v___x_113_, v___x_64_, v___x_114_, v___x_65_, v___x_114_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_116_) == 0)
{
uint64_t v___x_117_; lean_object* v___x_118_; 
lean_dec_ref_known(v___x_116_, 1);
v___x_117_ = 768ULL;
v___x_118_ = vastitas_storage_pack3(v_a_45_, v___x_60_, v___x_64_, v___x_70_, v___x_71_, v___x_70_, v___x_66_, v___x_106_, v___x_64_, v___x_117_, v___x_85_, v___x_117_, v___x_66_, v___x_70_, v___x_85_, v___x_99_);
if (lean_obj_tag(v___x_118_) == 0)
{
uint8_t v___x_119_; lean_object* v___x_120_; 
lean_dec_ref_known(v___x_118_, 1);
v___x_119_ = 0;
v___x_120_ = vastitas_gemm_execute(v_a_45_, v___x_106_, v___x_64_, v___x_117_, v___x_85_, v___x_117_, v___x_66_, v___x_66_, v___x_81_, v___x_64_, v___x_85_, v___x_86_, v___x_85_, v___x_66_, v___x_66_, v___x_110_, v___x_64_, v___x_117_, v___x_86_, v___x_117_, v___x_66_, v___x_119_);
if (lean_obj_tag(v___x_120_) == 0)
{
uint64_t v___x_121_; uint64_t v___x_122_; lean_object* v___x_123_; 
lean_dec_ref_known(v___x_120_, 1);
v___x_121_ = 1152ULL;
v___x_122_ = 42ULL;
v___x_123_ = vastitas_storage_regroup3(v_a_45_, v___x_110_, v___x_64_, v___x_117_, v___x_86_, v___x_117_, v___x_66_, v___x_106_, v___x_64_, v___x_121_, v___x_99_, v___x_121_, v___x_66_, v___x_70_, v___x_99_, v___x_86_, v___x_86_, v___x_122_);
if (lean_obj_tag(v___x_123_) == 0)
{
lean_object* v___x_124_; 
lean_dec_ref_known(v___x_123_, 1);
v___x_124_ = vastitas_gemm_execute(v_a_45_, v___x_106_, v___x_64_, v___x_121_, v___x_99_, v___x_121_, v___x_66_, v___x_66_, v___x_95_, v___x_64_, v___x_99_, v___x_100_, v___x_99_, v___x_66_, v___x_66_, v___x_113_, v___x_64_, v___x_121_, v___x_100_, v___x_121_, v___x_66_, v___x_119_);
if (lean_obj_tag(v___x_124_) == 0)
{
uint64_t v___x_125_; uint64_t v___x_126_; lean_object* v___x_127_; 
lean_dec_ref_known(v___x_124_, 1);
v___x_125_ = 13855852019186663424ULL;
v___x_126_ = 13847480337652776960ULL;
v___x_127_ = vastitas_storage_expect(v_a_45_, v___x_113_, v___x_64_, v___x_121_, v___x_100_, v___x_121_, v___x_66_, v___x_64_, v___x_64_, v___x_61_, v___x_125_, v___x_126_);
if (lean_obj_tag(v___x_127_) == 0)
{
uint64_t v___x_128_; uint64_t v___x_129_; lean_object* v___x_130_; 
lean_dec_ref_known(v___x_127_, 1);
v___x_128_ = 13856569450523787264ULL;
v___x_129_ = 13847183469513277440ULL;
v___x_130_ = vastitas_storage_expect(v_a_45_, v___x_113_, v___x_64_, v___x_121_, v___x_100_, v___x_121_, v___x_66_, v___x_78_, v___x_104_, v___x_61_, v___x_128_, v___x_129_);
if (lean_obj_tag(v___x_130_) == 0)
{
uint64_t v___x_131_; uint64_t v___x_132_; uint64_t v___x_133_; lean_object* v___x_134_; 
lean_dec_ref_known(v___x_130_, 1);
v___x_131_ = 1151ULL;
v___x_132_ = 13855506772535541760ULL;
v___x_133_ = 13844008079932260352ULL;
v___x_134_ = vastitas_storage_expect(v_a_45_, v___x_113_, v___x_64_, v___x_121_, v___x_100_, v___x_121_, v___x_66_, v___x_131_, v___x_64_, v___x_61_, v___x_132_, v___x_133_);
if (lean_obj_tag(v___x_134_) == 0)
{
lean_object* v___x_135_; 
lean_dec_ref_known(v___x_134_, 1);
v___x_135_ = vastitas_storage_drop(v_a_45_, v___x_113_);
if (lean_obj_tag(v___x_135_) == 0)
{
lean_object* v___x_136_; 
lean_dec_ref_known(v___x_135_, 1);
v___x_136_ = vastitas_storage_drop(v_a_45_, v___x_110_);
if (lean_obj_tag(v___x_136_) == 0)
{
lean_object* v___x_137_; 
lean_dec_ref_known(v___x_136_, 1);
v___x_137_ = vastitas_storage_drop(v_a_45_, v___x_106_);
if (lean_obj_tag(v___x_137_) == 0)
{
lean_object* v___x_138_; 
lean_dec_ref_known(v___x_137_, 1);
v___x_138_ = vastitas_storage_drop(v_a_45_, v___x_95_);
if (lean_obj_tag(v___x_138_) == 0)
{
lean_object* v___x_139_; 
lean_dec_ref_known(v___x_138_, 1);
v___x_139_ = vastitas_storage_drop(v_a_45_, v___x_81_);
if (lean_obj_tag(v___x_139_) == 0)
{
lean_object* v___x_140_; 
lean_dec_ref_known(v___x_139_, 1);
v___x_140_ = vastitas_storage_drop(v_a_45_, v___x_60_);
if (lean_obj_tag(v___x_140_) == 0)
{
lean_object* v___x_141_; 
lean_dec_ref_known(v___x_140_, 1);
v___x_141_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
return v___x_141_;
}
else
{
v___y_47_ = v___x_140_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_139_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_138_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_137_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_136_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_135_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_134_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_130_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_127_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_124_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_123_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_120_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_118_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_116_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_115_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_112_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_111_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_109_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_108_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_105_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_103_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_101_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_98_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_97_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_94_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_91_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_88_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_84_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_83_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_80_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_77_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_74_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_69_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_63_;
goto v___jp_46_;
}
v___jp_46_:
{
if (lean_obj_tag(v___y_47_) == 0)
{
lean_object* v___x_48_; 
lean_dec_ref_known(v___y_47_, 1);
v___x_48_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
return v___x_48_;
}
else
{
lean_object* v_a_49_; lean_object* v___x_50_; 
v_a_49_ = lean_ctor_get(v___y_47_, 0);
lean_inc(v_a_49_);
lean_dec_ref_known(v___y_47_, 1);
v___x_50_ = vastitas_storage_close(v_a_45_);
if (lean_obj_tag(v___x_50_) == 0)
{
lean_object* v___x_52_; uint8_t v_isShared_53_; uint8_t v_isSharedCheck_57_; 
lean_dec(v_a_45_);
v_isSharedCheck_57_ = !lean_is_exclusive(v___x_50_);
if (v_isSharedCheck_57_ == 0)
{
lean_object* v_unused_58_; 
v_unused_58_ = lean_ctor_get(v___x_50_, 0);
lean_dec(v_unused_58_);
v___x_52_ = v___x_50_;
v_isShared_53_ = v_isSharedCheck_57_;
goto v_resetjp_51_;
}
else
{
lean_dec(v___x_50_);
v___x_52_ = lean_box(0);
v_isShared_53_ = v_isSharedCheck_57_;
goto v_resetjp_51_;
}
v_resetjp_51_:
{
lean_object* v___x_55_; 
if (v_isShared_53_ == 0)
{
lean_ctor_set_tag(v___x_52_, 1);
lean_ctor_set(v___x_52_, 0, v_a_49_);
v___x_55_ = v___x_52_;
goto v_reusejp_54_;
}
else
{
lean_object* v_reuseFailAlloc_56_; 
v_reuseFailAlloc_56_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_56_, 0, v_a_49_);
v___x_55_ = v_reuseFailAlloc_56_;
goto v_reusejp_54_;
}
v_reusejp_54_:
{
return v___x_55_;
}
}
}
else
{
lean_dec(v_a_49_);
if (lean_obj_tag(v___x_50_) == 0)
{
lean_object* v___x_59_; 
lean_dec_ref_known(v___x_50_, 1);
v___x_59_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
return v___x_59_;
}
else
{
lean_dec(v_a_45_);
return v___x_50_;
}
}
}
}
}
else
{
lean_object* v_a_142_; lean_object* v___x_144_; uint8_t v_isShared_145_; uint8_t v_isSharedCheck_149_; 
v_a_142_ = lean_ctor_get(v___x_44_, 0);
v_isSharedCheck_149_ = !lean_is_exclusive(v___x_44_);
if (v_isSharedCheck_149_ == 0)
{
v___x_144_ = v___x_44_;
v_isShared_145_ = v_isSharedCheck_149_;
goto v_resetjp_143_;
}
else
{
lean_inc(v_a_142_);
lean_dec(v___x_44_);
v___x_144_ = lean_box(0);
v_isShared_145_ = v_isSharedCheck_149_;
goto v_resetjp_143_;
}
v_resetjp_143_:
{
lean_object* v___x_147_; 
if (v_isShared_145_ == 0)
{
v___x_147_ = v___x_144_;
goto v_reusejp_146_;
}
else
{
lean_object* v_reuseFailAlloc_148_; 
v_reuseFailAlloc_148_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_148_, 0, v_a_142_);
v___x_147_ = v_reuseFailAlloc_148_;
goto v_reusejp_146_;
}
v_reusejp_146_:
{
return v___x_147_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object* v_a_150_){
_start:
{
lean_object* v_res_151_; 
v_res_151_ = lp_allocation__audit_generatedOnce();
return v_res_151_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure(){
_start:
{
uint64_t v___x_153_; lean_object* v___x_154_; 
v___x_153_ = 9223372036854775807ULL;
v___x_154_ = vastitas_storage_new(v___x_153_);
if (lean_obj_tag(v___x_154_) == 0)
{
lean_object* v_a_155_; lean_object* v___y_157_; uint32_t v___x_170_; uint8_t v___x_171_; uint64_t v___x_172_; lean_object* v___x_173_; 
v_a_155_ = lean_ctor_get(v___x_154_, 0);
lean_inc(v_a_155_);
lean_dec_ref_known(v___x_154_, 1);
v___x_170_ = 0;
v___x_171_ = 1;
v___x_172_ = 30720ULL;
v___x_173_ = vastitas_storage_allocate(v_a_155_, v___x_170_, v___x_171_, v___x_172_);
if (lean_obj_tag(v___x_173_) == 0)
{
uint64_t v___x_174_; uint64_t v___x_175_; uint8_t v___x_176_; uint64_t v___x_177_; uint64_t v___x_178_; lean_object* v___x_179_; 
lean_dec_ref_known(v___x_173_, 1);
v___x_174_ = 0ULL;
v___x_175_ = 1ULL;
v___x_176_ = 0;
v___x_177_ = 13842939354630062080ULL;
v___x_178_ = 4613937818241073152ULL;
v___x_179_ = vastitas_storage_fill(v_a_155_, v___x_170_, v___x_174_, v___x_172_, v___x_175_, v___x_172_, v___x_176_, v___x_171_, v___x_177_, v___x_178_);
if (lean_obj_tag(v___x_179_) == 0)
{
uint64_t v___x_180_; uint64_t v___x_181_; uint64_t v___x_182_; uint64_t v___x_183_; lean_object* v___x_184_; 
lean_dec_ref_known(v___x_179_, 1);
v___x_180_ = 24ULL;
v___x_181_ = 1280ULL;
v___x_182_ = 4593671619917905920ULL;
v___x_183_ = 4598175219545276416ULL;
v___x_184_ = vastitas_storage_fill(v_a_155_, v___x_170_, v___x_174_, v___x_180_, v___x_181_, v___x_180_, v___x_176_, v___x_171_, v___x_182_, v___x_183_);
if (lean_obj_tag(v___x_184_) == 0)
{
uint64_t v___x_185_; uint64_t v___x_186_; lean_object* v___x_187_; 
lean_dec_ref_known(v___x_184_, 1);
v___x_185_ = 4607182418800017408ULL;
v___x_186_ = 13826050856027422720ULL;
v___x_187_ = vastitas_storage_store(v_a_155_, v___x_170_, v___x_174_, v___x_180_, v___x_181_, v___x_180_, v___x_176_, v___x_174_, v___x_174_, v___x_171_, v___x_185_, v___x_186_);
if (lean_obj_tag(v___x_187_) == 0)
{
uint64_t v___x_188_; uint64_t v___x_189_; lean_object* v___x_190_; 
lean_dec_ref_known(v___x_187_, 1);
v___x_188_ = 23ULL;
v___x_189_ = 4604930618986332160ULL;
v___x_190_ = vastitas_storage_store(v_a_155_, v___x_170_, v___x_174_, v___x_180_, v___x_181_, v___x_180_, v___x_176_, v___x_188_, v___x_175_, v___x_171_, v___x_186_, v___x_189_);
if (lean_obj_tag(v___x_190_) == 0)
{
uint32_t v___x_191_; uint64_t v___x_192_; lean_object* v___x_193_; 
lean_dec_ref_known(v___x_190_, 1);
v___x_191_ = 1;
v___x_192_ = 1920ULL;
v___x_193_ = vastitas_storage_allocate(v_a_155_, v___x_191_, v___x_171_, v___x_192_);
if (lean_obj_tag(v___x_193_) == 0)
{
lean_object* v___x_194_; 
lean_dec_ref_known(v___x_193_, 1);
v___x_194_ = vastitas_storage_fill(v_a_155_, v___x_191_, v___x_174_, v___x_192_, v___x_175_, v___x_192_, v___x_176_, v___x_171_, v___x_177_, v___x_178_);
if (lean_obj_tag(v___x_194_) == 0)
{
uint64_t v___x_195_; uint64_t v___x_196_; uint64_t v___x_197_; lean_object* v___x_198_; 
lean_dec_ref_known(v___x_194_, 1);
v___x_195_ = 40ULL;
v___x_196_ = 48ULL;
v___x_197_ = 13821547256400052224ULL;
v___x_198_ = vastitas_storage_fill(v_a_155_, v___x_191_, v___x_174_, v___x_195_, v___x_196_, v___x_195_, v___x_176_, v___x_171_, v___x_197_, v___x_182_);
if (lean_obj_tag(v___x_198_) == 0)
{
uint64_t v___x_199_; uint64_t v___x_200_; lean_object* v___x_201_; 
lean_dec_ref_known(v___x_198_, 1);
v___x_199_ = 47ULL;
v___x_200_ = 4602678819172646912ULL;
v___x_201_ = vastitas_storage_store(v_a_155_, v___x_191_, v___x_174_, v___x_195_, v___x_196_, v___x_195_, v___x_176_, v___x_174_, v___x_199_, v___x_171_, v___x_200_, v___x_183_);
if (lean_obj_tag(v___x_201_) == 0)
{
uint64_t v___x_202_; uint64_t v___x_203_; lean_object* v___x_204_; 
lean_dec_ref_known(v___x_201_, 1);
v___x_202_ = 39ULL;
v___x_203_ = 13828302655841107968ULL;
v___x_204_ = vastitas_storage_store(v_a_155_, v___x_191_, v___x_174_, v___x_195_, v___x_196_, v___x_195_, v___x_176_, v___x_202_, v___x_174_, v___x_171_, v___x_203_, v___x_186_);
if (lean_obj_tag(v___x_204_) == 0)
{
uint32_t v___x_205_; uint64_t v___x_206_; lean_object* v___x_207_; 
lean_dec_ref_known(v___x_204_, 1);
v___x_205_ = 2;
v___x_206_ = 1792ULL;
v___x_207_ = vastitas_storage_allocate(v_a_155_, v___x_205_, v___x_171_, v___x_206_);
if (lean_obj_tag(v___x_207_) == 0)
{
lean_object* v___x_208_; 
lean_dec_ref_known(v___x_207_, 1);
v___x_208_ = vastitas_storage_fill(v_a_155_, v___x_205_, v___x_174_, v___x_206_, v___x_175_, v___x_206_, v___x_176_, v___x_171_, v___x_177_, v___x_178_);
if (lean_obj_tag(v___x_208_) == 0)
{
uint64_t v___x_209_; uint64_t v___x_210_; lean_object* v___x_211_; 
lean_dec_ref_known(v___x_208_, 1);
v___x_209_ = 32ULL;
v___x_210_ = 56ULL;
v___x_211_ = vastitas_storage_fill(v_a_155_, v___x_205_, v___x_174_, v___x_209_, v___x_210_, v___x_209_, v___x_176_, v___x_171_, v___x_200_, v___x_197_);
if (lean_obj_tag(v___x_211_) == 0)
{
uint64_t v___x_212_; lean_object* v___x_213_; 
lean_dec_ref_known(v___x_211_, 1);
v___x_212_ = 31ULL;
v___x_213_ = vastitas_storage_store(v_a_155_, v___x_205_, v___x_174_, v___x_209_, v___x_210_, v___x_209_, v___x_176_, v___x_212_, v___x_174_, v___x_171_, v___x_197_, v___x_200_);
if (lean_obj_tag(v___x_213_) == 0)
{
uint64_t v___x_214_; lean_object* v___x_215_; 
lean_dec_ref_known(v___x_213_, 1);
v___x_214_ = 55ULL;
v___x_215_ = vastitas_storage_store(v_a_155_, v___x_205_, v___x_174_, v___x_209_, v___x_210_, v___x_209_, v___x_176_, v___x_174_, v___x_214_, v___x_171_, v___x_189_, v___x_203_);
if (lean_obj_tag(v___x_215_) == 0)
{
uint32_t v___x_216_; uint64_t v___x_217_; lean_object* v___x_218_; 
lean_dec_ref_known(v___x_215_, 1);
v___x_216_ = 3;
v___x_217_ = 36864ULL;
v___x_218_ = vastitas_storage_allocate(v_a_155_, v___x_216_, v___x_171_, v___x_217_);
if (lean_obj_tag(v___x_218_) == 0)
{
lean_object* v___x_219_; 
lean_dec_ref_known(v___x_218_, 1);
v___x_219_ = vastitas_storage_fill(v_a_155_, v___x_216_, v___x_174_, v___x_217_, v___x_175_, v___x_217_, v___x_176_, v___x_171_, v___x_177_, v___x_178_);
if (lean_obj_tag(v___x_219_) == 0)
{
uint32_t v___x_220_; lean_object* v___x_221_; 
lean_dec_ref_known(v___x_219_, 1);
v___x_220_ = 4;
v___x_221_ = vastitas_storage_allocate(v_a_155_, v___x_220_, v___x_171_, v___x_217_);
if (lean_obj_tag(v___x_221_) == 0)
{
lean_object* v___x_222_; 
lean_dec_ref_known(v___x_221_, 1);
v___x_222_ = vastitas_storage_fill(v_a_155_, v___x_220_, v___x_174_, v___x_217_, v___x_175_, v___x_217_, v___x_176_, v___x_171_, v___x_177_, v___x_178_);
if (lean_obj_tag(v___x_222_) == 0)
{
uint32_t v___x_223_; uint64_t v___x_224_; lean_object* v___x_225_; 
lean_dec_ref_known(v___x_222_, 1);
v___x_223_ = 5;
v___x_224_ = 64512ULL;
v___x_225_ = vastitas_storage_allocate(v_a_155_, v___x_223_, v___x_171_, v___x_224_);
if (lean_obj_tag(v___x_225_) == 0)
{
lean_object* v___x_226_; 
lean_dec_ref_known(v___x_225_, 1);
v___x_226_ = vastitas_storage_fill(v_a_155_, v___x_223_, v___x_174_, v___x_224_, v___x_175_, v___x_224_, v___x_176_, v___x_171_, v___x_177_, v___x_178_);
if (lean_obj_tag(v___x_226_) == 0)
{
uint64_t v___x_227_; lean_object* v___x_228_; 
lean_dec_ref_known(v___x_226_, 1);
v___x_227_ = 768ULL;
v___x_228_ = vastitas_storage_pack3(v_a_155_, v___x_170_, v___x_174_, v___x_180_, v___x_181_, v___x_180_, v___x_176_, v___x_216_, v___x_174_, v___x_227_, v___x_195_, v___x_227_, v___x_176_, v___x_180_, v___x_195_, v___x_209_);
if (lean_obj_tag(v___x_228_) == 0)
{
uint8_t v___x_229_; lean_object* v___x_230_; 
lean_dec_ref_known(v___x_228_, 1);
v___x_229_ = 0;
v___x_230_ = vastitas_gemm_execute(v_a_155_, v___x_216_, v___x_174_, v___x_227_, v___x_195_, v___x_227_, v___x_176_, v___x_176_, v___x_191_, v___x_174_, v___x_195_, v___x_196_, v___x_195_, v___x_176_, v___x_176_, v___x_220_, v___x_174_, v___x_227_, v___x_196_, v___x_227_, v___x_176_, v___x_229_);
if (lean_obj_tag(v___x_230_) == 0)
{
uint64_t v___x_231_; uint64_t v___x_232_; lean_object* v___x_233_; 
lean_dec_ref_known(v___x_230_, 1);
v___x_231_ = 1152ULL;
v___x_232_ = 42ULL;
v___x_233_ = vastitas_storage_regroup3(v_a_155_, v___x_220_, v___x_174_, v___x_227_, v___x_196_, v___x_227_, v___x_176_, v___x_216_, v___x_174_, v___x_231_, v___x_209_, v___x_231_, v___x_176_, v___x_180_, v___x_209_, v___x_196_, v___x_196_, v___x_232_);
if (lean_obj_tag(v___x_233_) == 0)
{
lean_object* v___x_234_; 
lean_dec_ref_known(v___x_233_, 1);
v___x_234_ = vastitas_gemm_execute(v_a_155_, v___x_216_, v___x_174_, v___x_231_, v___x_209_, v___x_231_, v___x_176_, v___x_176_, v___x_205_, v___x_174_, v___x_209_, v___x_210_, v___x_209_, v___x_176_, v___x_176_, v___x_223_, v___x_174_, v___x_231_, v___x_210_, v___x_231_, v___x_176_, v___x_229_);
if (lean_obj_tag(v___x_234_) == 0)
{
uint64_t v___x_235_; uint64_t v___x_236_; lean_object* v___x_237_; 
lean_dec_ref_known(v___x_234_, 1);
v___x_235_ = 13855852019186663425ULL;
v___x_236_ = 13847480337652776960ULL;
v___x_237_ = vastitas_storage_expect(v_a_155_, v___x_223_, v___x_174_, v___x_231_, v___x_210_, v___x_231_, v___x_176_, v___x_174_, v___x_174_, v___x_171_, v___x_235_, v___x_236_);
if (lean_obj_tag(v___x_237_) == 0)
{
uint64_t v___x_238_; uint64_t v___x_239_; lean_object* v___x_240_; 
lean_dec_ref_known(v___x_237_, 1);
v___x_238_ = 13856569450523787264ULL;
v___x_239_ = 13847183469513277440ULL;
v___x_240_ = vastitas_storage_expect(v_a_155_, v___x_223_, v___x_174_, v___x_231_, v___x_210_, v___x_231_, v___x_176_, v___x_188_, v___x_214_, v___x_171_, v___x_238_, v___x_239_);
if (lean_obj_tag(v___x_240_) == 0)
{
uint64_t v___x_241_; uint64_t v___x_242_; uint64_t v___x_243_; lean_object* v___x_244_; 
lean_dec_ref_known(v___x_240_, 1);
v___x_241_ = 1151ULL;
v___x_242_ = 13855506772535541760ULL;
v___x_243_ = 13844008079932260352ULL;
v___x_244_ = vastitas_storage_expect(v_a_155_, v___x_223_, v___x_174_, v___x_231_, v___x_210_, v___x_231_, v___x_176_, v___x_241_, v___x_174_, v___x_171_, v___x_242_, v___x_243_);
if (lean_obj_tag(v___x_244_) == 0)
{
lean_object* v___x_245_; 
lean_dec_ref_known(v___x_244_, 1);
v___x_245_ = vastitas_storage_drop(v_a_155_, v___x_223_);
if (lean_obj_tag(v___x_245_) == 0)
{
lean_object* v___x_246_; 
lean_dec_ref_known(v___x_245_, 1);
v___x_246_ = vastitas_storage_drop(v_a_155_, v___x_220_);
if (lean_obj_tag(v___x_246_) == 0)
{
lean_object* v___x_247_; 
lean_dec_ref_known(v___x_246_, 1);
v___x_247_ = vastitas_storage_drop(v_a_155_, v___x_216_);
if (lean_obj_tag(v___x_247_) == 0)
{
lean_object* v___x_248_; 
lean_dec_ref_known(v___x_247_, 1);
v___x_248_ = vastitas_storage_drop(v_a_155_, v___x_205_);
if (lean_obj_tag(v___x_248_) == 0)
{
lean_object* v___x_249_; 
lean_dec_ref_known(v___x_248_, 1);
v___x_249_ = vastitas_storage_drop(v_a_155_, v___x_191_);
if (lean_obj_tag(v___x_249_) == 0)
{
lean_object* v___x_250_; 
lean_dec_ref_known(v___x_249_, 1);
v___x_250_ = vastitas_storage_drop(v_a_155_, v___x_170_);
if (lean_obj_tag(v___x_250_) == 0)
{
lean_object* v___x_251_; 
lean_dec_ref_known(v___x_250_, 1);
v___x_251_ = vastitas_storage_close(v_a_155_);
lean_dec(v_a_155_);
return v___x_251_;
}
else
{
v___y_157_ = v___x_250_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_249_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_248_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_247_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_246_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_245_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_244_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_240_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_237_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_234_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_233_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_230_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_228_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_226_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_225_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_222_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_221_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_219_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_218_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_215_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_213_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_211_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_208_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_207_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_204_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_201_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_198_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_194_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_193_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_190_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_187_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_184_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_179_;
goto v___jp_156_;
}
}
else
{
v___y_157_ = v___x_173_;
goto v___jp_156_;
}
v___jp_156_:
{
if (lean_obj_tag(v___y_157_) == 0)
{
lean_object* v___x_158_; 
lean_dec_ref_known(v___y_157_, 1);
v___x_158_ = vastitas_storage_close(v_a_155_);
lean_dec(v_a_155_);
return v___x_158_;
}
else
{
lean_object* v_a_159_; lean_object* v___x_160_; 
v_a_159_ = lean_ctor_get(v___y_157_, 0);
lean_inc(v_a_159_);
lean_dec_ref_known(v___y_157_, 1);
v___x_160_ = vastitas_storage_close(v_a_155_);
if (lean_obj_tag(v___x_160_) == 0)
{
lean_object* v___x_162_; uint8_t v_isShared_163_; uint8_t v_isSharedCheck_167_; 
lean_dec(v_a_155_);
v_isSharedCheck_167_ = !lean_is_exclusive(v___x_160_);
if (v_isSharedCheck_167_ == 0)
{
lean_object* v_unused_168_; 
v_unused_168_ = lean_ctor_get(v___x_160_, 0);
lean_dec(v_unused_168_);
v___x_162_ = v___x_160_;
v_isShared_163_ = v_isSharedCheck_167_;
goto v_resetjp_161_;
}
else
{
lean_dec(v___x_160_);
v___x_162_ = lean_box(0);
v_isShared_163_ = v_isSharedCheck_167_;
goto v_resetjp_161_;
}
v_resetjp_161_:
{
lean_object* v___x_165_; 
if (v_isShared_163_ == 0)
{
lean_ctor_set_tag(v___x_162_, 1);
lean_ctor_set(v___x_162_, 0, v_a_159_);
v___x_165_ = v___x_162_;
goto v_reusejp_164_;
}
else
{
lean_object* v_reuseFailAlloc_166_; 
v_reuseFailAlloc_166_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_166_, 0, v_a_159_);
v___x_165_ = v_reuseFailAlloc_166_;
goto v_reusejp_164_;
}
v_reusejp_164_:
{
return v___x_165_;
}
}
}
else
{
lean_dec(v_a_159_);
if (lean_obj_tag(v___x_160_) == 0)
{
lean_object* v___x_169_; 
lean_dec_ref_known(v___x_160_, 1);
v___x_169_ = vastitas_storage_close(v_a_155_);
lean_dec(v_a_155_);
return v___x_169_;
}
else
{
lean_dec(v_a_155_);
return v___x_160_;
}
}
}
}
}
else
{
lean_object* v_a_252_; lean_object* v___x_254_; uint8_t v_isShared_255_; uint8_t v_isSharedCheck_259_; 
v_a_252_ = lean_ctor_get(v___x_154_, 0);
v_isSharedCheck_259_ = !lean_is_exclusive(v___x_154_);
if (v_isSharedCheck_259_ == 0)
{
v___x_254_ = v___x_154_;
v_isShared_255_ = v_isSharedCheck_259_;
goto v_resetjp_253_;
}
else
{
lean_inc(v_a_252_);
lean_dec(v___x_154_);
v___x_254_ = lean_box(0);
v_isShared_255_ = v_isSharedCheck_259_;
goto v_resetjp_253_;
}
v_resetjp_253_:
{
lean_object* v___x_257_; 
if (v_isShared_255_ == 0)
{
v___x_257_ = v___x_254_;
goto v_reusejp_256_;
}
else
{
lean_object* v_reuseFailAlloc_258_; 
v_reuseFailAlloc_258_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_258_, 0, v_a_252_);
v___x_257_ = v_reuseFailAlloc_258_;
goto v_reusejp_256_;
}
v_reusejp_256_:
{
return v___x_257_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object* v_a_260_){
_start:
{
lean_object* v_res_261_; 
v_res_261_ = lp_allocation__audit_generatedFailure();
return v_res_261_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object* v_phase_264_, lean_object* v_a_00___x40___internal___hyg_265_){
_start:
{
uint32_t v_phase_boxed_266_; lean_object* v_res_267_; 
v_phase_boxed_266_ = lean_unbox_uint32(v_phase_264_);
lean_dec(v_phase_264_);
v_res_267_ = audit_mark_lean(v_phase_boxed_266_);
return v_res_267_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object* v_a_268_, lean_object* v_scope_269_, lean_object* v_range_270_, lean_object* v_b_271_, lean_object* v_i_272_){
_start:
{
lean_object* v_stop_274_; lean_object* v_step_275_; uint8_t v___x_276_; 
v_stop_274_ = lean_ctor_get(v_range_270_, 1);
v_step_275_ = lean_ctor_get(v_range_270_, 2);
v___x_276_ = lean_nat_dec_lt(v_i_272_, v_stop_274_);
if (v___x_276_ == 0)
{
lean_object* v___x_277_; 
lean_dec(v_i_272_);
v___x_277_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_277_, 0, v_b_271_);
return v___x_277_;
}
else
{
uint32_t v___x_278_; uint64_t v___x_279_; uint64_t v___x_280_; uint64_t v___x_281_; lean_object* v___x_282_; uint8_t v___x_283_; uint32_t v___x_284_; uint64_t v___x_285_; uint64_t v___x_286_; uint32_t v___x_287_; uint64_t v___x_288_; uint32_t v___x_289_; uint32_t v___x_290_; uint64_t v___x_291_; uint32_t v___x_292_; lean_object* v___x_293_; uint64_t v___x_294_; lean_object* v___x_295_; 
v___x_278_ = 0;
v___x_279_ = 0ULL;
v___x_280_ = 24ULL;
v___x_281_ = 1280ULL;
v___x_282_ = lean_unsigned_to_nat(0u);
v___x_283_ = lean_nat_dec_eq(v_scope_269_, v___x_282_);
v___x_284_ = 3;
v___x_285_ = 40ULL;
v___x_286_ = 32ULL;
v___x_287_ = 1;
v___x_288_ = 48ULL;
v___x_289_ = 4;
v___x_290_ = 2;
v___x_291_ = 56ULL;
v___x_292_ = 5;
v___x_293_ = lean_box(0);
v___x_294_ = 768ULL;
v___x_295_ = vastitas_storage_pack3(v_a_268_, v___x_278_, v___x_279_, v___x_280_, v___x_281_, v___x_280_, v___x_283_, v___x_284_, v___x_279_, v___x_294_, v___x_285_, v___x_294_, v___x_283_, v___x_280_, v___x_285_, v___x_286_);
if (lean_obj_tag(v___x_295_) == 0)
{
uint8_t v___x_296_; lean_object* v___x_297_; 
lean_dec_ref_known(v___x_295_, 1);
v___x_296_ = 0;
v___x_297_ = vastitas_gemm_execute(v_a_268_, v___x_284_, v___x_279_, v___x_294_, v___x_285_, v___x_294_, v___x_283_, v___x_283_, v___x_287_, v___x_279_, v___x_285_, v___x_288_, v___x_285_, v___x_283_, v___x_283_, v___x_289_, v___x_279_, v___x_294_, v___x_288_, v___x_294_, v___x_283_, v___x_296_);
if (lean_obj_tag(v___x_297_) == 0)
{
uint64_t v___x_298_; uint64_t v___x_299_; lean_object* v___x_300_; 
lean_dec_ref_known(v___x_297_, 1);
v___x_298_ = 1152ULL;
v___x_299_ = 42ULL;
v___x_300_ = vastitas_storage_regroup3(v_a_268_, v___x_289_, v___x_279_, v___x_294_, v___x_288_, v___x_294_, v___x_283_, v___x_284_, v___x_279_, v___x_298_, v___x_286_, v___x_298_, v___x_283_, v___x_280_, v___x_286_, v___x_288_, v___x_288_, v___x_299_);
if (lean_obj_tag(v___x_300_) == 0)
{
lean_object* v___x_301_; 
lean_dec_ref_known(v___x_300_, 1);
v___x_301_ = vastitas_gemm_execute(v_a_268_, v___x_284_, v___x_279_, v___x_298_, v___x_286_, v___x_298_, v___x_283_, v___x_283_, v___x_290_, v___x_279_, v___x_286_, v___x_291_, v___x_286_, v___x_283_, v___x_283_, v___x_292_, v___x_279_, v___x_298_, v___x_291_, v___x_298_, v___x_283_, v___x_296_);
if (lean_obj_tag(v___x_301_) == 0)
{
lean_object* v___x_302_; 
lean_dec_ref_known(v___x_301_, 1);
v___x_302_ = lean_nat_add(v_i_272_, v_step_275_);
lean_dec(v_i_272_);
v_b_271_ = v___x_293_;
v_i_272_ = v___x_302_;
goto _start;
}
else
{
lean_dec(v_i_272_);
return v___x_301_;
}
}
else
{
lean_dec(v_i_272_);
return v___x_300_;
}
}
else
{
lean_dec(v_i_272_);
return v___x_297_;
}
}
else
{
lean_dec(v_i_272_);
return v___x_295_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object* v_a_304_, lean_object* v_scope_305_, lean_object* v_range_306_, lean_object* v_b_307_, lean_object* v_i_308_, lean_object* v___y_309_){
_start:
{
lean_object* v_res_310_; 
v_res_310_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_304_, v_scope_305_, v_range_306_, v_b_307_, v_i_308_);
lean_dec_ref(v_range_306_);
lean_dec(v_scope_305_);
lean_dec(v_a_304_);
return v_res_310_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object* v_range_311_, lean_object* v_b_312_, lean_object* v_i_313_){
_start:
{
lean_object* v_stop_315_; lean_object* v_step_316_; uint8_t v___x_317_; 
v_stop_315_ = lean_ctor_get(v_range_311_, 1);
v_step_316_ = lean_ctor_get(v_range_311_, 2);
v___x_317_ = lean_nat_dec_lt(v_i_313_, v_stop_315_);
if (v___x_317_ == 0)
{
lean_object* v___x_318_; 
lean_dec(v_i_313_);
v___x_318_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_318_, 0, v_b_312_);
return v___x_318_;
}
else
{
lean_object* v___x_319_; lean_object* v___x_320_; 
v___x_319_ = lean_box(0);
v___x_320_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_320_) == 0)
{
lean_object* v___x_321_; 
lean_dec_ref_known(v___x_320_, 1);
v___x_321_ = lean_nat_add(v_i_313_, v_step_316_);
lean_dec(v_i_313_);
v_b_312_ = v___x_319_;
v_i_313_ = v___x_321_;
goto _start;
}
else
{
lean_dec(v_i_313_);
return v___x_320_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object* v_range_323_, lean_object* v_b_324_, lean_object* v_i_325_, lean_object* v___y_326_){
_start:
{
lean_object* v_res_327_; 
v_res_327_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_323_, v_b_324_, v_i_325_);
lean_dec_ref(v_range_323_);
return v_res_327_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_336_){
_start:
{
lean_object* v___x_338_; lean_object* v___x_339_; lean_object* v_impl_340_; lean_object* v___x_341_; lean_object* v___x_342_; lean_object* v___x_343_; lean_object* v___x_344_; lean_object* v_scope_345_; lean_object* v___x_346_; lean_object* v___x_347_; lean_object* v___x_348_; lean_object* v___x_349_; lean_object* v_reps_350_; lean_object* v___x_351_; lean_object* v___x_352_; lean_object* v___x_353_; uint8_t v_verify_354_; uint32_t v___x_355_; lean_object* v___x_356_; 
v___x_338_ = ((lean_object*)(lp_allocation__audit_main___closed__0));
v___x_339_ = lean_unsigned_to_nat(0u);
v_impl_340_ = l_List_get_x21Internal___redArg(v___x_338_, v_args_336_, v___x_339_);
v___x_341_ = lean_unsigned_to_nat(1u);
v___x_342_ = l_List_get_x21Internal___redArg(v___x_338_, v_args_336_, v___x_341_);
v___x_343_ = lean_string_utf8_byte_size(v___x_342_);
v___x_344_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_344_, 0, v___x_342_);
lean_ctor_set(v___x_344_, 1, v___x_339_);
lean_ctor_set(v___x_344_, 2, v___x_343_);
v_scope_345_ = l_String_Slice_toNat_x21(v___x_344_);
lean_dec_ref_known(v___x_344_, 3);
v___x_346_ = lean_unsigned_to_nat(2u);
v___x_347_ = l_List_get_x21Internal___redArg(v___x_338_, v_args_336_, v___x_346_);
v___x_348_ = lean_string_utf8_byte_size(v___x_347_);
v___x_349_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_349_, 0, v___x_347_);
lean_ctor_set(v___x_349_, 1, v___x_339_);
lean_ctor_set(v___x_349_, 2, v___x_348_);
v_reps_350_ = l_String_Slice_toNat_x21(v___x_349_);
lean_dec_ref_known(v___x_349_, 3);
v___x_351_ = lean_unsigned_to_nat(3u);
v___x_352_ = l_List_get_x21Internal___redArg(v___x_338_, v_args_336_, v___x_351_);
lean_dec(v_args_336_);
v___x_353_ = ((lean_object*)(lp_allocation__audit_main___closed__1));
v_verify_354_ = lean_string_dec_eq(v___x_352_, v___x_353_);
lean_dec(v___x_352_);
v___x_355_ = 1;
v___x_356_ = audit_mark_lean(v___x_355_);
if (lean_obj_tag(v___x_356_) == 0)
{
lean_object* v___x_357_; 
lean_dec_ref_known(v___x_356_, 1);
v___x_357_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_357_) == 0)
{
uint32_t v___x_358_; lean_object* v___x_359_; 
lean_dec_ref_known(v___x_357_, 1);
v___x_358_ = 2;
v___x_359_ = audit_mark_lean(v___x_358_);
if (lean_obj_tag(v___x_359_) == 0)
{
lean_object* v___x_360_; uint8_t v___x_361_; 
lean_dec_ref_known(v___x_359_, 1);
v___x_360_ = ((lean_object*)(lp_allocation__audit_main___closed__2));
v___x_361_ = lean_string_dec_eq(v_impl_340_, v___x_360_);
if (v___x_361_ == 0)
{
lean_object* v___x_362_; uint8_t v___x_363_; 
v___x_362_ = ((lean_object*)(lp_allocation__audit_main___closed__3));
v___x_363_ = lean_string_dec_eq(v_impl_340_, v___x_362_);
lean_dec(v_impl_340_);
if (v___x_363_ == 0)
{
uint8_t v___x_364_; 
v___x_364_ = lean_nat_dec_eq(v_scope_345_, v___x_339_);
if (v___x_364_ == 0)
{
uint64_t v___x_365_; lean_object* v___x_366_; 
v___x_365_ = 9223372036854775807ULL;
v___x_366_ = vastitas_storage_new(v___x_365_);
if (lean_obj_tag(v___x_366_) == 0)
{
lean_object* v_a_367_; lean_object* v___y_372_; uint32_t v___x_383_; uint8_t v___x_384_; uint64_t v___x_385_; lean_object* v___x_386_; 
v_a_367_ = lean_ctor_get(v___x_366_, 0);
lean_inc(v_a_367_);
lean_dec_ref_known(v___x_366_, 1);
v___x_383_ = 0;
v___x_384_ = 1;
v___x_385_ = 30720ULL;
v___x_386_ = vastitas_storage_allocate(v_a_367_, v___x_383_, v___x_384_, v___x_385_);
if (lean_obj_tag(v___x_386_) == 0)
{
uint64_t v___x_387_; uint64_t v___x_388_; uint64_t v___x_389_; uint64_t v___x_390_; lean_object* v___x_391_; 
lean_dec_ref_known(v___x_386_, 1);
v___x_387_ = 0ULL;
v___x_388_ = 1ULL;
v___x_389_ = 13842939354630062080ULL;
v___x_390_ = 4613937818241073152ULL;
v___x_391_ = vastitas_storage_fill(v_a_367_, v___x_383_, v___x_387_, v___x_385_, v___x_388_, v___x_385_, v___x_364_, v___x_384_, v___x_389_, v___x_390_);
if (lean_obj_tag(v___x_391_) == 0)
{
uint64_t v___x_392_; uint64_t v___x_393_; uint64_t v___x_394_; uint64_t v___x_395_; lean_object* v___x_396_; 
lean_dec_ref_known(v___x_391_, 1);
v___x_392_ = 24ULL;
v___x_393_ = 1280ULL;
v___x_394_ = 4593671619917905920ULL;
v___x_395_ = 4598175219545276416ULL;
v___x_396_ = vastitas_storage_fill(v_a_367_, v___x_383_, v___x_387_, v___x_392_, v___x_393_, v___x_392_, v___x_364_, v___x_384_, v___x_394_, v___x_395_);
if (lean_obj_tag(v___x_396_) == 0)
{
uint64_t v___x_397_; uint64_t v___x_398_; lean_object* v___x_399_; 
lean_dec_ref_known(v___x_396_, 1);
v___x_397_ = 4607182418800017408ULL;
v___x_398_ = 13826050856027422720ULL;
v___x_399_ = vastitas_storage_store(v_a_367_, v___x_383_, v___x_387_, v___x_392_, v___x_393_, v___x_392_, v___x_364_, v___x_387_, v___x_387_, v___x_384_, v___x_397_, v___x_398_);
if (lean_obj_tag(v___x_399_) == 0)
{
uint64_t v___x_400_; uint64_t v___x_401_; lean_object* v___x_402_; 
lean_dec_ref_known(v___x_399_, 1);
v___x_400_ = 23ULL;
v___x_401_ = 4604930618986332160ULL;
v___x_402_ = vastitas_storage_store(v_a_367_, v___x_383_, v___x_387_, v___x_392_, v___x_393_, v___x_392_, v___x_364_, v___x_400_, v___x_388_, v___x_384_, v___x_398_, v___x_401_);
if (lean_obj_tag(v___x_402_) == 0)
{
uint64_t v___x_403_; lean_object* v___x_404_; 
lean_dec_ref_known(v___x_402_, 1);
v___x_403_ = 1920ULL;
v___x_404_ = vastitas_storage_allocate(v_a_367_, v___x_355_, v___x_384_, v___x_403_);
if (lean_obj_tag(v___x_404_) == 0)
{
lean_object* v___x_405_; 
lean_dec_ref_known(v___x_404_, 1);
v___x_405_ = vastitas_storage_fill(v_a_367_, v___x_355_, v___x_387_, v___x_403_, v___x_388_, v___x_403_, v___x_364_, v___x_384_, v___x_389_, v___x_390_);
if (lean_obj_tag(v___x_405_) == 0)
{
uint64_t v___x_406_; uint64_t v___x_407_; uint64_t v___x_408_; lean_object* v___x_409_; 
lean_dec_ref_known(v___x_405_, 1);
v___x_406_ = 40ULL;
v___x_407_ = 48ULL;
v___x_408_ = 13821547256400052224ULL;
v___x_409_ = vastitas_storage_fill(v_a_367_, v___x_355_, v___x_387_, v___x_406_, v___x_407_, v___x_406_, v___x_364_, v___x_384_, v___x_408_, v___x_394_);
if (lean_obj_tag(v___x_409_) == 0)
{
uint64_t v___x_410_; uint64_t v___x_411_; lean_object* v___x_412_; 
lean_dec_ref_known(v___x_409_, 1);
v___x_410_ = 47ULL;
v___x_411_ = 4602678819172646912ULL;
v___x_412_ = vastitas_storage_store(v_a_367_, v___x_355_, v___x_387_, v___x_406_, v___x_407_, v___x_406_, v___x_364_, v___x_387_, v___x_410_, v___x_384_, v___x_411_, v___x_395_);
if (lean_obj_tag(v___x_412_) == 0)
{
uint64_t v___x_413_; uint64_t v___x_414_; lean_object* v___x_415_; 
lean_dec_ref_known(v___x_412_, 1);
v___x_413_ = 39ULL;
v___x_414_ = 13828302655841107968ULL;
v___x_415_ = vastitas_storage_store(v_a_367_, v___x_355_, v___x_387_, v___x_406_, v___x_407_, v___x_406_, v___x_364_, v___x_413_, v___x_387_, v___x_384_, v___x_414_, v___x_398_);
if (lean_obj_tag(v___x_415_) == 0)
{
uint64_t v___x_416_; lean_object* v___x_417_; 
lean_dec_ref_known(v___x_415_, 1);
v___x_416_ = 1792ULL;
v___x_417_ = vastitas_storage_allocate(v_a_367_, v___x_358_, v___x_384_, v___x_416_);
if (lean_obj_tag(v___x_417_) == 0)
{
lean_object* v___x_418_; 
lean_dec_ref_known(v___x_417_, 1);
v___x_418_ = vastitas_storage_fill(v_a_367_, v___x_358_, v___x_387_, v___x_416_, v___x_388_, v___x_416_, v___x_364_, v___x_384_, v___x_389_, v___x_390_);
if (lean_obj_tag(v___x_418_) == 0)
{
uint64_t v___x_419_; uint64_t v___x_420_; lean_object* v___x_421_; 
lean_dec_ref_known(v___x_418_, 1);
v___x_419_ = 32ULL;
v___x_420_ = 56ULL;
v___x_421_ = vastitas_storage_fill(v_a_367_, v___x_358_, v___x_387_, v___x_419_, v___x_420_, v___x_419_, v___x_364_, v___x_384_, v___x_411_, v___x_408_);
if (lean_obj_tag(v___x_421_) == 0)
{
uint64_t v___x_422_; lean_object* v___x_423_; 
lean_dec_ref_known(v___x_421_, 1);
v___x_422_ = 31ULL;
v___x_423_ = vastitas_storage_store(v_a_367_, v___x_358_, v___x_387_, v___x_419_, v___x_420_, v___x_419_, v___x_364_, v___x_422_, v___x_387_, v___x_384_, v___x_408_, v___x_411_);
if (lean_obj_tag(v___x_423_) == 0)
{
uint64_t v___x_424_; lean_object* v___x_425_; 
lean_dec_ref_known(v___x_423_, 1);
v___x_424_ = 55ULL;
v___x_425_ = vastitas_storage_store(v_a_367_, v___x_358_, v___x_387_, v___x_419_, v___x_420_, v___x_419_, v___x_364_, v___x_387_, v___x_424_, v___x_384_, v___x_401_, v___x_414_);
if (lean_obj_tag(v___x_425_) == 0)
{
uint32_t v___x_426_; uint64_t v___x_427_; lean_object* v___x_428_; 
lean_dec_ref_known(v___x_425_, 1);
v___x_426_ = 3;
v___x_427_ = 36864ULL;
v___x_428_ = vastitas_storage_allocate(v_a_367_, v___x_426_, v___x_384_, v___x_427_);
if (lean_obj_tag(v___x_428_) == 0)
{
lean_object* v___x_429_; 
lean_dec_ref_known(v___x_428_, 1);
v___x_429_ = vastitas_storage_fill(v_a_367_, v___x_426_, v___x_387_, v___x_427_, v___x_388_, v___x_427_, v___x_364_, v___x_384_, v___x_389_, v___x_390_);
if (lean_obj_tag(v___x_429_) == 0)
{
uint32_t v___x_430_; lean_object* v___x_431_; 
lean_dec_ref_known(v___x_429_, 1);
v___x_430_ = 4;
v___x_431_ = vastitas_storage_allocate(v_a_367_, v___x_430_, v___x_384_, v___x_427_);
if (lean_obj_tag(v___x_431_) == 0)
{
lean_object* v___x_432_; 
lean_dec_ref_known(v___x_431_, 1);
v___x_432_ = vastitas_storage_fill(v_a_367_, v___x_430_, v___x_387_, v___x_427_, v___x_388_, v___x_427_, v___x_364_, v___x_384_, v___x_389_, v___x_390_);
if (lean_obj_tag(v___x_432_) == 0)
{
uint32_t v___x_433_; uint64_t v___x_434_; lean_object* v___x_435_; 
lean_dec_ref_known(v___x_432_, 1);
v___x_433_ = 5;
v___x_434_ = 64512ULL;
v___x_435_ = vastitas_storage_allocate(v_a_367_, v___x_433_, v___x_384_, v___x_434_);
if (lean_obj_tag(v___x_435_) == 0)
{
lean_object* v___x_436_; 
lean_dec_ref_known(v___x_435_, 1);
v___x_436_ = vastitas_storage_fill(v_a_367_, v___x_433_, v___x_387_, v___x_434_, v___x_388_, v___x_434_, v___x_364_, v___x_384_, v___x_389_, v___x_390_);
if (lean_obj_tag(v___x_436_) == 0)
{
uint32_t v___x_437_; uint64_t v___x_438_; lean_object* v___x_439_; 
lean_dec_ref_known(v___x_436_, 1);
v___x_437_ = lean_uint32_of_nat(v_scope_345_);
v___x_438_ = lean_uint64_of_nat(v_reps_350_);
v___x_439_ = bench_begin_lean(v___x_437_, v___x_438_, v_verify_354_);
if (lean_obj_tag(v___x_439_) == 0)
{
lean_object* v___x_440_; lean_object* v___x_441_; lean_object* v___x_442_; 
lean_dec_ref_known(v___x_439_, 1);
v___x_440_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_440_, 0, v___x_339_);
lean_ctor_set(v___x_440_, 1, v_reps_350_);
lean_ctor_set(v___x_440_, 2, v___x_341_);
v___x_441_ = lean_box(0);
v___x_442_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_367_, v_scope_345_, v___x_440_, v___x_441_, v___x_339_);
lean_dec_ref_known(v___x_440_, 3);
lean_dec(v_scope_345_);
if (lean_obj_tag(v___x_442_) == 0)
{
lean_object* v___x_443_; 
lean_dec_ref_known(v___x_442_, 1);
v___x_443_ = bench_stop_lean();
if (lean_obj_tag(v___x_443_) == 0)
{
lean_object* v___x_444_; 
lean_dec_ref_known(v___x_443_, 1);
v___x_444_ = bench_verify_lean(v_a_367_, v___x_438_);
if (lean_obj_tag(v___x_444_) == 0)
{
uint64_t v___x_445_; uint64_t v___x_446_; uint64_t v___x_447_; lean_object* v___x_448_; 
lean_dec_ref_known(v___x_444_, 1);
v___x_445_ = 1152ULL;
v___x_446_ = 13855852019186663424ULL;
v___x_447_ = 13847480337652776960ULL;
v___x_448_ = vastitas_storage_expect(v_a_367_, v___x_433_, v___x_387_, v___x_445_, v___x_420_, v___x_445_, v___x_364_, v___x_387_, v___x_387_, v___x_384_, v___x_446_, v___x_447_);
if (lean_obj_tag(v___x_448_) == 0)
{
uint64_t v___x_449_; uint64_t v___x_450_; lean_object* v___x_451_; 
lean_dec_ref_known(v___x_448_, 1);
v___x_449_ = 13856569450523787264ULL;
v___x_450_ = 13847183469513277440ULL;
v___x_451_ = vastitas_storage_expect(v_a_367_, v___x_433_, v___x_387_, v___x_445_, v___x_420_, v___x_445_, v___x_364_, v___x_400_, v___x_424_, v___x_384_, v___x_449_, v___x_450_);
if (lean_obj_tag(v___x_451_) == 0)
{
uint64_t v___x_452_; uint64_t v___x_453_; uint64_t v___x_454_; lean_object* v___x_455_; 
lean_dec_ref_known(v___x_451_, 1);
v___x_452_ = 1151ULL;
v___x_453_ = 13855506772535541760ULL;
v___x_454_ = 13844008079932260352ULL;
v___x_455_ = vastitas_storage_expect(v_a_367_, v___x_433_, v___x_387_, v___x_445_, v___x_420_, v___x_445_, v___x_364_, v___x_452_, v___x_387_, v___x_384_, v___x_453_, v___x_454_);
if (lean_obj_tag(v___x_455_) == 0)
{
lean_object* v___x_456_; 
lean_dec_ref_known(v___x_455_, 1);
v___x_456_ = vastitas_storage_drop(v_a_367_, v___x_433_);
if (lean_obj_tag(v___x_456_) == 0)
{
lean_object* v___x_457_; 
lean_dec_ref_known(v___x_456_, 1);
v___x_457_ = vastitas_storage_drop(v_a_367_, v___x_430_);
if (lean_obj_tag(v___x_457_) == 0)
{
lean_object* v___x_458_; 
lean_dec_ref_known(v___x_457_, 1);
v___x_458_ = vastitas_storage_drop(v_a_367_, v___x_426_);
if (lean_obj_tag(v___x_458_) == 0)
{
lean_object* v___x_459_; 
lean_dec_ref_known(v___x_458_, 1);
v___x_459_ = vastitas_storage_drop(v_a_367_, v___x_358_);
if (lean_obj_tag(v___x_459_) == 0)
{
lean_object* v___x_460_; 
lean_dec_ref_known(v___x_459_, 1);
v___x_460_ = vastitas_storage_drop(v_a_367_, v___x_355_);
if (lean_obj_tag(v___x_460_) == 0)
{
lean_object* v___x_461_; 
lean_dec_ref_known(v___x_460_, 1);
v___x_461_ = vastitas_storage_drop(v_a_367_, v___x_383_);
v___y_372_ = v___x_461_;
goto v___jp_371_;
}
else
{
v___y_372_ = v___x_460_;
goto v___jp_371_;
}
}
else
{
v___y_372_ = v___x_459_;
goto v___jp_371_;
}
}
else
{
v___y_372_ = v___x_458_;
goto v___jp_371_;
}
}
else
{
v___y_372_ = v___x_457_;
goto v___jp_371_;
}
}
else
{
v___y_372_ = v___x_456_;
goto v___jp_371_;
}
}
else
{
v___y_372_ = v___x_455_;
goto v___jp_371_;
}
}
else
{
v___y_372_ = v___x_451_;
goto v___jp_371_;
}
}
else
{
v___y_372_ = v___x_448_;
goto v___jp_371_;
}
}
else
{
v___y_372_ = v___x_444_;
goto v___jp_371_;
}
}
else
{
v___y_372_ = v___x_443_;
goto v___jp_371_;
}
}
else
{
v___y_372_ = v___x_442_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_439_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_436_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_435_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_432_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_431_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_429_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_428_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_425_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_423_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_421_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_418_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_417_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_415_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_412_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_409_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_405_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_404_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_402_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_399_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_396_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_391_;
goto v___jp_371_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v___y_372_ = v___x_386_;
goto v___jp_371_;
}
v___jp_368_:
{
lean_object* v___x_369_; 
v___x_369_ = vastitas_storage_close(v_a_367_);
lean_dec(v_a_367_);
if (lean_obj_tag(v___x_369_) == 0)
{
lean_object* v___x_370_; 
lean_dec_ref_known(v___x_369_, 1);
v___x_370_ = bench_report_lean();
return v___x_370_;
}
else
{
return v___x_369_;
}
}
v___jp_371_:
{
if (lean_obj_tag(v___y_372_) == 0)
{
lean_dec_ref_known(v___y_372_, 1);
goto v___jp_368_;
}
else
{
lean_object* v_a_373_; lean_object* v___x_374_; 
v_a_373_ = lean_ctor_get(v___y_372_, 0);
lean_inc(v_a_373_);
lean_dec_ref_known(v___y_372_, 1);
v___x_374_ = vastitas_storage_close(v_a_367_);
if (lean_obj_tag(v___x_374_) == 0)
{
lean_object* v___x_376_; uint8_t v_isShared_377_; uint8_t v_isSharedCheck_381_; 
lean_dec(v_a_367_);
v_isSharedCheck_381_ = !lean_is_exclusive(v___x_374_);
if (v_isSharedCheck_381_ == 0)
{
lean_object* v_unused_382_; 
v_unused_382_ = lean_ctor_get(v___x_374_, 0);
lean_dec(v_unused_382_);
v___x_376_ = v___x_374_;
v_isShared_377_ = v_isSharedCheck_381_;
goto v_resetjp_375_;
}
else
{
lean_dec(v___x_374_);
v___x_376_ = lean_box(0);
v_isShared_377_ = v_isSharedCheck_381_;
goto v_resetjp_375_;
}
v_resetjp_375_:
{
lean_object* v___x_379_; 
if (v_isShared_377_ == 0)
{
lean_ctor_set_tag(v___x_376_, 1);
lean_ctor_set(v___x_376_, 0, v_a_373_);
v___x_379_ = v___x_376_;
goto v_reusejp_378_;
}
else
{
lean_object* v_reuseFailAlloc_380_; 
v_reuseFailAlloc_380_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_380_, 0, v_a_373_);
v___x_379_ = v_reuseFailAlloc_380_;
goto v_reusejp_378_;
}
v_reusejp_378_:
{
return v___x_379_;
}
}
}
else
{
lean_dec(v_a_373_);
if (lean_obj_tag(v___x_374_) == 0)
{
lean_dec_ref_known(v___x_374_, 1);
goto v___jp_368_;
}
else
{
lean_dec(v_a_367_);
return v___x_374_;
}
}
}
}
}
else
{
lean_object* v_a_462_; lean_object* v___x_464_; uint8_t v_isShared_465_; uint8_t v_isSharedCheck_469_; 
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
v_a_462_ = lean_ctor_get(v___x_366_, 0);
v_isSharedCheck_469_ = !lean_is_exclusive(v___x_366_);
if (v_isSharedCheck_469_ == 0)
{
v___x_464_ = v___x_366_;
v_isShared_465_ = v_isSharedCheck_469_;
goto v_resetjp_463_;
}
else
{
lean_inc(v_a_462_);
lean_dec(v___x_366_);
v___x_464_ = lean_box(0);
v_isShared_465_ = v_isSharedCheck_469_;
goto v_resetjp_463_;
}
v_resetjp_463_:
{
lean_object* v___x_467_; 
if (v_isShared_465_ == 0)
{
v___x_467_ = v___x_464_;
goto v_reusejp_466_;
}
else
{
lean_object* v_reuseFailAlloc_468_; 
v_reuseFailAlloc_468_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_468_, 0, v_a_462_);
v___x_467_ = v_reuseFailAlloc_468_;
goto v_reusejp_466_;
}
v_reusejp_466_:
{
return v___x_467_;
}
}
}
}
else
{
uint32_t v___x_470_; uint64_t v___x_471_; lean_object* v___x_472_; 
lean_dec(v_scope_345_);
v___x_470_ = 0;
v___x_471_ = lean_uint64_of_nat(v_reps_350_);
v___x_472_ = bench_begin_lean(v___x_470_, v___x_471_, v_verify_354_);
if (lean_obj_tag(v___x_472_) == 0)
{
lean_object* v___x_473_; lean_object* v___x_474_; lean_object* v___x_475_; 
lean_dec_ref_known(v___x_472_, 1);
v___x_473_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_473_, 0, v___x_339_);
lean_ctor_set(v___x_473_, 1, v_reps_350_);
lean_ctor_set(v___x_473_, 2, v___x_341_);
v___x_474_ = lean_box(0);
v___x_475_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v___x_473_, v___x_474_, v___x_339_);
lean_dec_ref_known(v___x_473_, 3);
if (lean_obj_tag(v___x_475_) == 0)
{
lean_object* v___x_476_; 
lean_dec_ref_known(v___x_475_, 1);
v___x_476_ = bench_stop_lean();
if (lean_obj_tag(v___x_476_) == 0)
{
lean_object* v___x_477_; 
lean_dec_ref_known(v___x_476_, 1);
v___x_477_ = bench_report_lean();
return v___x_477_;
}
else
{
return v___x_476_;
}
}
else
{
return v___x_475_;
}
}
else
{
lean_dec(v_reps_350_);
return v___x_472_;
}
}
}
else
{
uint32_t v___x_478_; uint64_t v___x_479_; lean_object* v___x_480_; 
v___x_478_ = lean_uint32_of_nat(v_scope_345_);
lean_dec(v_scope_345_);
v___x_479_ = lean_uint64_of_nat(v_reps_350_);
lean_dec(v_reps_350_);
v___x_480_ = bench_c_run_lean(v___x_478_, v___x_479_, v_verify_354_);
if (lean_obj_tag(v___x_480_) == 0)
{
lean_object* v___x_481_; 
lean_dec_ref_known(v___x_480_, 1);
v___x_481_ = bench_report_lean();
return v___x_481_;
}
else
{
return v___x_480_;
}
}
}
else
{
uint32_t v___x_482_; uint64_t v___x_483_; lean_object* v___x_484_; 
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
lean_dec(v_impl_340_);
v___x_482_ = 0;
v___x_483_ = 1ULL;
v___x_484_ = bench_begin_lean(v___x_482_, v___x_483_, v___x_361_);
if (lean_obj_tag(v___x_484_) == 0)
{
lean_object* v___x_485_; 
lean_dec_ref_known(v___x_484_, 1);
v___x_485_ = lp_allocation__audit_generatedFailure();
if (lean_obj_tag(v___x_485_) == 0)
{
lean_object* v___x_487_; uint8_t v_isShared_488_; uint8_t v_isSharedCheck_493_; 
v_isSharedCheck_493_ = !lean_is_exclusive(v___x_485_);
if (v_isSharedCheck_493_ == 0)
{
lean_object* v_unused_494_; 
v_unused_494_ = lean_ctor_get(v___x_485_, 0);
lean_dec(v_unused_494_);
v___x_487_ = v___x_485_;
v_isShared_488_ = v_isSharedCheck_493_;
goto v_resetjp_486_;
}
else
{
lean_dec(v___x_485_);
v___x_487_ = lean_box(0);
v_isShared_488_ = v_isSharedCheck_493_;
goto v_resetjp_486_;
}
v_resetjp_486_:
{
lean_object* v___x_489_; lean_object* v___x_491_; 
v___x_489_ = ((lean_object*)(lp_allocation__audit_main___closed__5));
if (v_isShared_488_ == 0)
{
lean_ctor_set_tag(v___x_487_, 1);
lean_ctor_set(v___x_487_, 0, v___x_489_);
v___x_491_ = v___x_487_;
goto v_reusejp_490_;
}
else
{
lean_object* v_reuseFailAlloc_492_; 
v_reuseFailAlloc_492_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_492_, 0, v___x_489_);
v___x_491_ = v_reuseFailAlloc_492_;
goto v_reusejp_490_;
}
v_reusejp_490_:
{
return v___x_491_;
}
}
}
else
{
lean_object* v_a_495_; lean_object* v___x_496_; lean_object* v___x_497_; uint8_t v___x_498_; 
v_a_495_ = lean_ctor_get(v___x_485_, 0);
lean_inc(v_a_495_);
v___x_496_ = lean_io_error_to_string(v_a_495_);
v___x_497_ = ((lean_object*)(lp_allocation__audit_main___closed__6));
v___x_498_ = lean_string_dec_eq(v___x_496_, v___x_497_);
lean_dec_ref(v___x_496_);
if (v___x_498_ == 0)
{
return v___x_485_;
}
else
{
lean_object* v___x_499_; 
lean_dec_ref_known(v___x_485_, 1);
v___x_499_ = bench_stop_lean();
if (lean_obj_tag(v___x_499_) == 0)
{
lean_object* v___x_500_; 
lean_dec_ref_known(v___x_499_, 1);
v___x_500_ = bench_report_lean();
return v___x_500_;
}
else
{
return v___x_499_;
}
}
}
}
else
{
return v___x_484_;
}
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
lean_dec(v_impl_340_);
return v___x_359_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
lean_dec(v_impl_340_);
return v___x_357_;
}
}
else
{
lean_dec(v_reps_350_);
lean_dec(v_scope_345_);
lean_dec(v_impl_340_);
return v___x_356_;
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object* v_args_501_, lean_object* v_a_502_){
_start:
{
lean_object* v_res_503_; 
v_res_503_ = _lean_main(v_args_501_);
return v_res_503_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object* v_a_504_, lean_object* v_scope_505_, lean_object* v_range_506_, lean_object* v_b_507_, lean_object* v_i_508_, lean_object* v_hs_509_, lean_object* v_hl_510_){
_start:
{
lean_object* v___x_512_; 
v___x_512_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_504_, v_scope_505_, v_range_506_, v_b_507_, v_i_508_);
return v___x_512_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object* v_a_513_, lean_object* v_scope_514_, lean_object* v_range_515_, lean_object* v_b_516_, lean_object* v_i_517_, lean_object* v_hs_518_, lean_object* v_hl_519_, lean_object* v___y_520_){
_start:
{
lean_object* v_res_521_; 
v_res_521_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(v_a_513_, v_scope_514_, v_range_515_, v_b_516_, v_i_517_, v_hs_518_, v_hl_519_);
lean_dec_ref(v_range_515_);
lean_dec(v_scope_514_);
lean_dec(v_a_513_);
return v_res_521_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object* v_range_522_, lean_object* v_b_523_, lean_object* v_i_524_, lean_object* v_hs_525_, lean_object* v_hl_526_){
_start:
{
lean_object* v___x_528_; 
v___x_528_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_522_, v_b_523_, v_i_524_);
return v___x_528_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object* v_range_529_, lean_object* v_b_530_, lean_object* v_i_531_, lean_object* v_hs_532_, lean_object* v_hl_533_, lean_object* v___y_534_){
_start:
{
lean_object* v_res_535_; 
v_res_535_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(v_range_529_, v_b_530_, v_i_531_, v_hs_532_, v_hl_533_);
lean_dec_ref(v_range_529_);
return v_res_535_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_vastitas__storage__native_VastitasStorageNative(uint8_t builtin);
lean_object* initialize_vastitas__gemm__native_VastitasGemmNative(uint8_t builtin);
lean_object* initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_allocation__audit_Main(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__storage__native_VastitasStorageNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__gemm__native_VastitasGemmNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_allocation__audit_VastitasGenerated_f__0 = _init_lp_allocation__audit_VastitasGenerated_f__0();
lean_mark_persistent(lp_allocation__audit_VastitasGenerated_f__0);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_allocation__audit_Main(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = 0;
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
