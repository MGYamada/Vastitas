// Lean compiler output
// Module: Main
// Imports: public import Init public meta import Init public import VastitasStorageNative public import VastitasGemmNative public import VastitasKernel.IndexedRuntime
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* vastitas_storage_new(uint64_t);
lean_object* vastitas_storage_close(lean_object*);
lean_object* vastitas_storage_allocate(lean_object*, uint32_t, uint8_t, uint64_t);
lean_object* vastitas_storage_fill(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_store(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_pack3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_gemm_execute(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t);
lean_object* vastitas_storage_regroup3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_storage_expect(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_drop(lean_object*, uint32_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_List_get_x21Internal___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_String_Slice_toNat_x21(lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
uint32_t lean_uint32_of_nat(lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
lean_object* lean_io_error_to_string(lean_object*);
static lean_once_cell_t lp_allocation__audit_VastitasGenerated_f__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_allocation__audit_VastitasGenerated_f__0___closed__0;
LEAN_EXPORT lean_object* lp_allocation__audit_VastitasGenerated_f__0;
lean_object* bench_begin_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_stop_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object*);
lean_object* bench_report_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object*);
lean_object* bench_c_run_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_verify_lean(lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object*);
lean_object* audit_mark_lean(uint32_t);
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_allocation__audit_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 1, .m_capacity = 1, .m_length = 0, .m_data = ""};
static const lean_object* lp_allocation__audit_main___closed__0 = (const lean_object*)&lp_allocation__audit_main___closed__0_value;
static const lean_string_object lp_allocation__audit_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "1"};
static const lean_object* lp_allocation__audit_main___closed__1 = (const lean_object*)&lp_allocation__audit_main___closed__1_value;
static const lean_string_object lp_allocation__audit_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "failure"};
static const lean_object* lp_allocation__audit_main___closed__2 = (const lean_object*)&lp_allocation__audit_main___closed__2_value;
static const lean_string_object lp_allocation__audit_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "c"};
static const lean_object* lp_allocation__audit_main___closed__3 = (const lean_object*)&lp_allocation__audit_main___closed__3_value;
static const lean_string_object lp_allocation__audit_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "expected injected native failure"};
static const lean_object* lp_allocation__audit_main___closed__4 = (const lean_object*)&lp_allocation__audit_main___closed__4_value;
static const lean_ctor_object lp_allocation__audit_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_allocation__audit_main___closed__4_value)}};
static const lean_object* lp_allocation__audit_main___closed__5 = (const lean_object*)&lp_allocation__audit_main___closed__5_value;
static const lean_string_object lp_allocation__audit_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 44, .m_capacity = 44, .m_length = 43, .m_data = "E_NATIVE_EXPECT: stored bit pattern differs"};
static const lean_object* lp_allocation__audit_main___closed__6 = (const lean_object*)&lp_allocation__audit_main___closed__6_value;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(0u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0(void){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_obj_once(&lp_allocation__audit_VastitasGenerated_f__0___closed__0, &lp_allocation__audit_VastitasGenerated_f__0___closed__0_once, _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object* v_scope_8_, lean_object* v_reps_9_, lean_object* v_verify_10_, lean_object* v_a_00___x40___internal___hyg_11_){
_start:
{
uint32_t v_scope_boxed_12_; uint64_t v_reps_boxed_13_; uint8_t v_verify_boxed_14_; lean_object* v_res_15_; 
v_scope_boxed_12_ = lean_unbox_uint32(v_scope_8_);
lean_dec(v_scope_8_);
v_reps_boxed_13_ = lean_unbox_uint64(v_reps_9_);
lean_dec_ref(v_reps_9_);
v_verify_boxed_14_ = lean_unbox(v_verify_10_);
v_res_15_ = bench_begin_lean(v_scope_boxed_12_, v_reps_boxed_13_, v_verify_boxed_14_);
return v_res_15_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object* v_a_00___x40___internal___hyg_17_){
_start:
{
lean_object* v_res_18_; 
v_res_18_ = bench_stop_lean();
return v_res_18_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object* v_a_00___x40___internal___hyg_20_){
_start:
{
lean_object* v_res_21_; 
v_res_21_ = bench_report_lean();
return v_res_21_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object* v_scope_26_, lean_object* v_reps_27_, lean_object* v_verify_28_, lean_object* v_a_00___x40___internal___hyg_29_){
_start:
{
uint32_t v_scope_boxed_30_; uint64_t v_reps_boxed_31_; uint8_t v_verify_boxed_32_; lean_object* v_res_33_; 
v_scope_boxed_30_ = lean_unbox_uint32(v_scope_26_);
lean_dec(v_scope_26_);
v_reps_boxed_31_ = lean_unbox_uint64(v_reps_27_);
lean_dec_ref(v_reps_27_);
v_verify_boxed_32_ = lean_unbox(v_verify_28_);
v_res_33_ = bench_c_run_lean(v_scope_boxed_30_, v_reps_boxed_31_, v_verify_boxed_32_);
return v_res_33_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object* v_arena_37_, lean_object* v_reps_38_, lean_object* v_a_00___x40___internal___hyg_39_){
_start:
{
uint64_t v_reps_boxed_40_; lean_object* v_res_41_; 
v_reps_boxed_40_ = lean_unbox_uint64(v_reps_38_);
lean_dec_ref(v_reps_38_);
v_res_41_ = bench_verify_lean(v_arena_37_, v_reps_boxed_40_);
lean_dec(v_arena_37_);
return v_res_41_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce(){
_start:
{
uint64_t v___x_43_; lean_object* v___x_44_; 
v___x_43_ = 9223372036854775807ULL;
v___x_44_ = vastitas_storage_new(v___x_43_);
if (lean_obj_tag(v___x_44_) == 0)
{
lean_object* v_a_45_; lean_object* v___y_47_; uint32_t v___x_60_; uint8_t v___x_61_; uint64_t v___x_62_; lean_object* v___x_63_; 
v_a_45_ = lean_ctor_get(v___x_44_, 0);
lean_inc(v_a_45_);
lean_dec_ref_known(v___x_44_, 1);
v___x_60_ = 0;
v___x_61_ = 1;
v___x_62_ = 33284ULL;
v___x_63_ = vastitas_storage_allocate(v_a_45_, v___x_60_, v___x_61_, v___x_62_);
if (lean_obj_tag(v___x_63_) == 0)
{
uint64_t v___x_64_; uint64_t v___x_65_; uint8_t v___x_66_; uint64_t v___x_67_; uint64_t v___x_68_; lean_object* v___x_69_; 
lean_dec_ref_known(v___x_63_, 1);
v___x_64_ = 0ULL;
v___x_65_ = 1ULL;
v___x_66_ = 0;
v___x_67_ = 13842939354630062080ULL;
v___x_68_ = 4613937818241073152ULL;
v___x_69_ = vastitas_storage_fill(v_a_45_, v___x_60_, v___x_64_, v___x_62_, v___x_65_, v___x_62_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_69_) == 0)
{
uint64_t v___x_70_; uint64_t v___x_71_; uint64_t v___x_72_; uint64_t v___x_73_; uint64_t v___x_74_; uint64_t v___x_75_; lean_object* v___x_76_; 
lean_dec_ref_known(v___x_69_, 1);
v___x_70_ = 16ULL;
v___x_71_ = 24ULL;
v___x_72_ = 1280ULL;
v___x_73_ = 26ULL;
v___x_74_ = 4593671619917905920ULL;
v___x_75_ = 4598175219545276416ULL;
v___x_76_ = vastitas_storage_fill(v_a_45_, v___x_60_, v___x_70_, v___x_71_, v___x_72_, v___x_73_, v___x_66_, v___x_61_, v___x_74_, v___x_75_);
if (lean_obj_tag(v___x_76_) == 0)
{
uint64_t v___x_77_; uint64_t v___x_78_; lean_object* v___x_79_; 
lean_dec_ref_known(v___x_76_, 1);
v___x_77_ = 4607182418800017408ULL;
v___x_78_ = 13826050856027422720ULL;
v___x_79_ = vastitas_storage_store(v_a_45_, v___x_60_, v___x_70_, v___x_71_, v___x_72_, v___x_73_, v___x_66_, v___x_64_, v___x_64_, v___x_61_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_79_) == 0)
{
uint64_t v___x_80_; uint64_t v___x_81_; lean_object* v___x_82_; 
lean_dec_ref_known(v___x_79_, 1);
v___x_80_ = 23ULL;
v___x_81_ = 4604930618986332160ULL;
v___x_82_ = vastitas_storage_store(v_a_45_, v___x_60_, v___x_70_, v___x_71_, v___x_72_, v___x_73_, v___x_66_, v___x_80_, v___x_65_, v___x_61_, v___x_78_, v___x_81_);
if (lean_obj_tag(v___x_82_) == 0)
{
uint32_t v___x_83_; uint64_t v___x_84_; lean_object* v___x_85_; 
lean_dec_ref_known(v___x_82_, 1);
v___x_83_ = 1;
v___x_84_ = 2069ULL;
v___x_85_ = vastitas_storage_allocate(v_a_45_, v___x_83_, v___x_61_, v___x_84_);
if (lean_obj_tag(v___x_85_) == 0)
{
lean_object* v___x_86_; 
lean_dec_ref_known(v___x_85_, 1);
v___x_86_ = vastitas_storage_fill(v_a_45_, v___x_83_, v___x_64_, v___x_84_, v___x_65_, v___x_84_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_86_) == 0)
{
uint64_t v___x_87_; uint64_t v___x_88_; uint64_t v___x_89_; uint64_t v___x_90_; uint64_t v___x_91_; lean_object* v___x_92_; 
lean_dec_ref_known(v___x_86_, 1);
v___x_87_ = 32ULL;
v___x_88_ = 40ULL;
v___x_89_ = 48ULL;
v___x_90_ = 43ULL;
v___x_91_ = 13821547256400052224ULL;
v___x_92_ = vastitas_storage_fill(v_a_45_, v___x_83_, v___x_87_, v___x_88_, v___x_89_, v___x_90_, v___x_66_, v___x_61_, v___x_91_, v___x_74_);
if (lean_obj_tag(v___x_92_) == 0)
{
uint64_t v___x_93_; uint64_t v___x_94_; lean_object* v___x_95_; 
lean_dec_ref_known(v___x_92_, 1);
v___x_93_ = 47ULL;
v___x_94_ = 4602678819172646912ULL;
v___x_95_ = vastitas_storage_store(v_a_45_, v___x_83_, v___x_87_, v___x_88_, v___x_89_, v___x_90_, v___x_66_, v___x_64_, v___x_93_, v___x_61_, v___x_94_, v___x_75_);
if (lean_obj_tag(v___x_95_) == 0)
{
uint64_t v___x_96_; uint64_t v___x_97_; lean_object* v___x_98_; 
lean_dec_ref_known(v___x_95_, 1);
v___x_96_ = 39ULL;
v___x_97_ = 13828302655841107968ULL;
v___x_98_ = vastitas_storage_store(v_a_45_, v___x_83_, v___x_87_, v___x_88_, v___x_89_, v___x_90_, v___x_66_, v___x_96_, v___x_64_, v___x_61_, v___x_97_, v___x_78_);
if (lean_obj_tag(v___x_98_) == 0)
{
uint32_t v___x_99_; uint64_t v___x_100_; lean_object* v___x_101_; 
lean_dec_ref_known(v___x_98_, 1);
v___x_99_ = 2;
v___x_100_ = 2022ULL;
v___x_101_ = vastitas_storage_allocate(v_a_45_, v___x_99_, v___x_61_, v___x_100_);
if (lean_obj_tag(v___x_101_) == 0)
{
lean_object* v___x_102_; 
lean_dec_ref_known(v___x_101_, 1);
v___x_102_ = vastitas_storage_fill(v_a_45_, v___x_99_, v___x_64_, v___x_100_, v___x_65_, v___x_100_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_102_) == 0)
{
uint64_t v___x_103_; uint64_t v___x_104_; lean_object* v___x_105_; 
lean_dec_ref_known(v___x_102_, 1);
v___x_103_ = 56ULL;
v___x_104_ = 36ULL;
v___x_105_ = vastitas_storage_fill(v_a_45_, v___x_99_, v___x_89_, v___x_87_, v___x_103_, v___x_104_, v___x_66_, v___x_61_, v___x_94_, v___x_91_);
if (lean_obj_tag(v___x_105_) == 0)
{
uint64_t v___x_106_; lean_object* v___x_107_; 
lean_dec_ref_known(v___x_105_, 1);
v___x_106_ = 31ULL;
v___x_107_ = vastitas_storage_store(v_a_45_, v___x_99_, v___x_89_, v___x_87_, v___x_103_, v___x_104_, v___x_66_, v___x_106_, v___x_64_, v___x_61_, v___x_91_, v___x_94_);
if (lean_obj_tag(v___x_107_) == 0)
{
uint64_t v___x_108_; lean_object* v___x_109_; 
lean_dec_ref_known(v___x_107_, 1);
v___x_108_ = 55ULL;
v___x_109_ = vastitas_storage_store(v_a_45_, v___x_99_, v___x_89_, v___x_87_, v___x_103_, v___x_104_, v___x_66_, v___x_64_, v___x_108_, v___x_61_, v___x_81_, v___x_97_);
if (lean_obj_tag(v___x_109_) == 0)
{
uint32_t v___x_110_; uint64_t v___x_111_; lean_object* v___x_112_; 
lean_dec_ref_known(v___x_109_, 1);
v___x_110_ = 3;
v___x_111_ = 37130ULL;
v___x_112_ = vastitas_storage_allocate(v_a_45_, v___x_110_, v___x_61_, v___x_111_);
if (lean_obj_tag(v___x_112_) == 0)
{
lean_object* v___x_113_; 
lean_dec_ref_known(v___x_112_, 1);
v___x_113_ = vastitas_storage_fill(v_a_45_, v___x_110_, v___x_64_, v___x_111_, v___x_65_, v___x_111_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_113_) == 0)
{
uint32_t v___x_114_; uint64_t v___x_115_; lean_object* v___x_116_; 
lean_dec_ref_known(v___x_113_, 1);
v___x_114_ = 4;
v___x_115_ = 37160ULL;
v___x_116_ = vastitas_storage_allocate(v_a_45_, v___x_114_, v___x_61_, v___x_115_);
if (lean_obj_tag(v___x_116_) == 0)
{
lean_object* v___x_117_; 
lean_dec_ref_known(v___x_116_, 1);
v___x_117_ = vastitas_storage_fill(v_a_45_, v___x_114_, v___x_64_, v___x_115_, v___x_65_, v___x_115_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_117_) == 0)
{
uint32_t v___x_118_; uint64_t v___x_119_; lean_object* v___x_120_; 
lean_dec_ref_known(v___x_117_, 1);
v___x_118_ = 5;
v___x_119_ = 64913ULL;
v___x_120_ = vastitas_storage_allocate(v_a_45_, v___x_118_, v___x_61_, v___x_119_);
if (lean_obj_tag(v___x_120_) == 0)
{
lean_object* v___x_121_; 
lean_dec_ref_known(v___x_120_, 1);
v___x_121_ = vastitas_storage_fill(v_a_45_, v___x_118_, v___x_64_, v___x_119_, v___x_65_, v___x_119_, v___x_66_, v___x_61_, v___x_67_, v___x_68_);
if (lean_obj_tag(v___x_121_) == 0)
{
uint64_t v___x_122_; uint64_t v___x_123_; uint64_t v___x_124_; lean_object* v___x_125_; 
lean_dec_ref_known(v___x_121_, 1);
v___x_122_ = 64ULL;
v___x_123_ = 768ULL;
v___x_124_ = 773ULL;
v___x_125_ = vastitas_storage_pack3(v_a_45_, v___x_60_, v___x_70_, v___x_71_, v___x_72_, v___x_73_, v___x_66_, v___x_110_, v___x_122_, v___x_123_, v___x_88_, v___x_124_, v___x_66_, v___x_71_, v___x_88_, v___x_87_);
if (lean_obj_tag(v___x_125_) == 0)
{
uint64_t v___x_126_; uint64_t v___x_127_; uint8_t v___x_128_; lean_object* v___x_129_; 
lean_dec_ref_known(v___x_125_, 1);
v___x_126_ = 80ULL;
v___x_127_ = 774ULL;
v___x_128_ = 0;
v___x_129_ = vastitas_gemm_execute(v_a_45_, v___x_110_, v___x_122_, v___x_123_, v___x_88_, v___x_124_, v___x_66_, v___x_66_, v___x_83_, v___x_87_, v___x_88_, v___x_89_, v___x_90_, v___x_66_, v___x_66_, v___x_114_, v___x_126_, v___x_123_, v___x_89_, v___x_127_, v___x_66_, v___x_128_);
if (lean_obj_tag(v___x_129_) == 0)
{
uint64_t v___x_130_; uint64_t v___x_131_; uint64_t v___x_132_; uint64_t v___x_133_; lean_object* v___x_134_; 
lean_dec_ref_known(v___x_129_, 1);
v___x_130_ = 112ULL;
v___x_131_ = 1152ULL;
v___x_132_ = 1160ULL;
v___x_133_ = 42ULL;
v___x_134_ = vastitas_storage_regroup3(v_a_45_, v___x_114_, v___x_126_, v___x_123_, v___x_89_, v___x_127_, v___x_66_, v___x_110_, v___x_130_, v___x_131_, v___x_87_, v___x_132_, v___x_66_, v___x_71_, v___x_87_, v___x_89_, v___x_89_, v___x_133_);
if (lean_obj_tag(v___x_134_) == 0)
{
uint64_t v___x_135_; uint64_t v___x_136_; lean_object* v___x_137_; 
lean_dec_ref_known(v___x_134_, 1);
v___x_135_ = 96ULL;
v___x_136_ = 1159ULL;
v___x_137_ = vastitas_gemm_execute(v_a_45_, v___x_110_, v___x_130_, v___x_131_, v___x_87_, v___x_132_, v___x_66_, v___x_66_, v___x_99_, v___x_89_, v___x_87_, v___x_103_, v___x_104_, v___x_66_, v___x_66_, v___x_118_, v___x_135_, v___x_131_, v___x_103_, v___x_136_, v___x_66_, v___x_128_);
if (lean_obj_tag(v___x_137_) == 0)
{
uint64_t v___x_138_; uint64_t v___x_139_; lean_object* v___x_140_; 
lean_dec_ref_known(v___x_137_, 1);
v___x_138_ = 13855852019186663424ULL;
v___x_139_ = 13847480337652776960ULL;
v___x_140_ = vastitas_storage_expect(v_a_45_, v___x_118_, v___x_135_, v___x_131_, v___x_103_, v___x_136_, v___x_66_, v___x_64_, v___x_64_, v___x_61_, v___x_138_, v___x_139_);
if (lean_obj_tag(v___x_140_) == 0)
{
uint64_t v___x_141_; uint64_t v___x_142_; lean_object* v___x_143_; 
lean_dec_ref_known(v___x_140_, 1);
v___x_141_ = 13856569450523787264ULL;
v___x_142_ = 13847183469513277440ULL;
v___x_143_ = vastitas_storage_expect(v_a_45_, v___x_118_, v___x_135_, v___x_131_, v___x_103_, v___x_136_, v___x_66_, v___x_80_, v___x_108_, v___x_61_, v___x_141_, v___x_142_);
if (lean_obj_tag(v___x_143_) == 0)
{
uint64_t v___x_144_; uint64_t v___x_145_; uint64_t v___x_146_; lean_object* v___x_147_; 
lean_dec_ref_known(v___x_143_, 1);
v___x_144_ = 1151ULL;
v___x_145_ = 13855506772535541760ULL;
v___x_146_ = 13844008079932260352ULL;
v___x_147_ = vastitas_storage_expect(v_a_45_, v___x_118_, v___x_135_, v___x_131_, v___x_103_, v___x_136_, v___x_66_, v___x_144_, v___x_64_, v___x_61_, v___x_145_, v___x_146_);
if (lean_obj_tag(v___x_147_) == 0)
{
lean_object* v___x_148_; 
lean_dec_ref_known(v___x_147_, 1);
v___x_148_ = vastitas_storage_drop(v_a_45_, v___x_118_);
if (lean_obj_tag(v___x_148_) == 0)
{
lean_object* v___x_149_; 
lean_dec_ref_known(v___x_148_, 1);
v___x_149_ = vastitas_storage_drop(v_a_45_, v___x_114_);
if (lean_obj_tag(v___x_149_) == 0)
{
lean_object* v___x_150_; 
lean_dec_ref_known(v___x_149_, 1);
v___x_150_ = vastitas_storage_drop(v_a_45_, v___x_110_);
if (lean_obj_tag(v___x_150_) == 0)
{
lean_object* v___x_151_; 
lean_dec_ref_known(v___x_150_, 1);
v___x_151_ = vastitas_storage_drop(v_a_45_, v___x_99_);
if (lean_obj_tag(v___x_151_) == 0)
{
lean_object* v___x_152_; 
lean_dec_ref_known(v___x_151_, 1);
v___x_152_ = vastitas_storage_drop(v_a_45_, v___x_83_);
if (lean_obj_tag(v___x_152_) == 0)
{
lean_object* v___x_153_; 
lean_dec_ref_known(v___x_152_, 1);
v___x_153_ = vastitas_storage_drop(v_a_45_, v___x_60_);
if (lean_obj_tag(v___x_153_) == 0)
{
lean_object* v___x_154_; 
lean_dec_ref_known(v___x_153_, 1);
v___x_154_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
return v___x_154_;
}
else
{
v___y_47_ = v___x_153_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_152_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_151_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_150_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_149_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_148_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_147_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_143_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_140_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_137_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_134_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_129_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_125_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_121_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_120_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_117_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_116_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_113_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_112_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_109_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_107_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_105_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_102_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_101_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_98_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_95_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_92_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_86_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_85_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_82_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_79_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_76_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_69_;
goto v___jp_46_;
}
}
else
{
v___y_47_ = v___x_63_;
goto v___jp_46_;
}
v___jp_46_:
{
if (lean_obj_tag(v___y_47_) == 0)
{
lean_object* v___x_48_; 
lean_dec_ref_known(v___y_47_, 1);
v___x_48_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
return v___x_48_;
}
else
{
lean_object* v_a_49_; lean_object* v___x_50_; 
v_a_49_ = lean_ctor_get(v___y_47_, 0);
lean_inc(v_a_49_);
lean_dec_ref_known(v___y_47_, 1);
v___x_50_ = vastitas_storage_close(v_a_45_);
if (lean_obj_tag(v___x_50_) == 0)
{
lean_object* v___x_52_; uint8_t v_isShared_53_; uint8_t v_isSharedCheck_57_; 
lean_dec(v_a_45_);
v_isSharedCheck_57_ = !lean_is_exclusive(v___x_50_);
if (v_isSharedCheck_57_ == 0)
{
lean_object* v_unused_58_; 
v_unused_58_ = lean_ctor_get(v___x_50_, 0);
lean_dec(v_unused_58_);
v___x_52_ = v___x_50_;
v_isShared_53_ = v_isSharedCheck_57_;
goto v_resetjp_51_;
}
else
{
lean_dec(v___x_50_);
v___x_52_ = lean_box(0);
v_isShared_53_ = v_isSharedCheck_57_;
goto v_resetjp_51_;
}
v_resetjp_51_:
{
lean_object* v___x_55_; 
if (v_isShared_53_ == 0)
{
lean_ctor_set_tag(v___x_52_, 1);
lean_ctor_set(v___x_52_, 0, v_a_49_);
v___x_55_ = v___x_52_;
goto v_reusejp_54_;
}
else
{
lean_object* v_reuseFailAlloc_56_; 
v_reuseFailAlloc_56_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_56_, 0, v_a_49_);
v___x_55_ = v_reuseFailAlloc_56_;
goto v_reusejp_54_;
}
v_reusejp_54_:
{
return v___x_55_;
}
}
}
else
{
lean_dec(v_a_49_);
if (lean_obj_tag(v___x_50_) == 0)
{
lean_object* v___x_59_; 
lean_dec_ref_known(v___x_50_, 1);
v___x_59_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
return v___x_59_;
}
else
{
lean_dec(v_a_45_);
return v___x_50_;
}
}
}
}
}
else
{
lean_object* v_a_155_; lean_object* v___x_157_; uint8_t v_isShared_158_; uint8_t v_isSharedCheck_162_; 
v_a_155_ = lean_ctor_get(v___x_44_, 0);
v_isSharedCheck_162_ = !lean_is_exclusive(v___x_44_);
if (v_isSharedCheck_162_ == 0)
{
v___x_157_ = v___x_44_;
v_isShared_158_ = v_isSharedCheck_162_;
goto v_resetjp_156_;
}
else
{
lean_inc(v_a_155_);
lean_dec(v___x_44_);
v___x_157_ = lean_box(0);
v_isShared_158_ = v_isSharedCheck_162_;
goto v_resetjp_156_;
}
v_resetjp_156_:
{
lean_object* v___x_160_; 
if (v_isShared_158_ == 0)
{
v___x_160_ = v___x_157_;
goto v_reusejp_159_;
}
else
{
lean_object* v_reuseFailAlloc_161_; 
v_reuseFailAlloc_161_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_161_, 0, v_a_155_);
v___x_160_ = v_reuseFailAlloc_161_;
goto v_reusejp_159_;
}
v_reusejp_159_:
{
return v___x_160_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object* v_a_163_){
_start:
{
lean_object* v_res_164_; 
v_res_164_ = lp_allocation__audit_generatedOnce();
return v_res_164_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure(){
_start:
{
uint64_t v___x_166_; lean_object* v___x_167_; 
v___x_166_ = 9223372036854775807ULL;
v___x_167_ = vastitas_storage_new(v___x_166_);
if (lean_obj_tag(v___x_167_) == 0)
{
lean_object* v_a_168_; lean_object* v___y_170_; uint32_t v___x_183_; uint8_t v___x_184_; uint64_t v___x_185_; lean_object* v___x_186_; 
v_a_168_ = lean_ctor_get(v___x_167_, 0);
lean_inc(v_a_168_);
lean_dec_ref_known(v___x_167_, 1);
v___x_183_ = 0;
v___x_184_ = 1;
v___x_185_ = 33284ULL;
v___x_186_ = vastitas_storage_allocate(v_a_168_, v___x_183_, v___x_184_, v___x_185_);
if (lean_obj_tag(v___x_186_) == 0)
{
uint64_t v___x_187_; uint64_t v___x_188_; uint8_t v___x_189_; uint64_t v___x_190_; uint64_t v___x_191_; lean_object* v___x_192_; 
lean_dec_ref_known(v___x_186_, 1);
v___x_187_ = 0ULL;
v___x_188_ = 1ULL;
v___x_189_ = 0;
v___x_190_ = 13842939354630062080ULL;
v___x_191_ = 4613937818241073152ULL;
v___x_192_ = vastitas_storage_fill(v_a_168_, v___x_183_, v___x_187_, v___x_185_, v___x_188_, v___x_185_, v___x_189_, v___x_184_, v___x_190_, v___x_191_);
if (lean_obj_tag(v___x_192_) == 0)
{
uint64_t v___x_193_; uint64_t v___x_194_; uint64_t v___x_195_; uint64_t v___x_196_; uint64_t v___x_197_; uint64_t v___x_198_; lean_object* v___x_199_; 
lean_dec_ref_known(v___x_192_, 1);
v___x_193_ = 16ULL;
v___x_194_ = 24ULL;
v___x_195_ = 1280ULL;
v___x_196_ = 26ULL;
v___x_197_ = 4593671619917905920ULL;
v___x_198_ = 4598175219545276416ULL;
v___x_199_ = vastitas_storage_fill(v_a_168_, v___x_183_, v___x_193_, v___x_194_, v___x_195_, v___x_196_, v___x_189_, v___x_184_, v___x_197_, v___x_198_);
if (lean_obj_tag(v___x_199_) == 0)
{
uint64_t v___x_200_; uint64_t v___x_201_; lean_object* v___x_202_; 
lean_dec_ref_known(v___x_199_, 1);
v___x_200_ = 4607182418800017408ULL;
v___x_201_ = 13826050856027422720ULL;
v___x_202_ = vastitas_storage_store(v_a_168_, v___x_183_, v___x_193_, v___x_194_, v___x_195_, v___x_196_, v___x_189_, v___x_187_, v___x_187_, v___x_184_, v___x_200_, v___x_201_);
if (lean_obj_tag(v___x_202_) == 0)
{
uint64_t v___x_203_; uint64_t v___x_204_; lean_object* v___x_205_; 
lean_dec_ref_known(v___x_202_, 1);
v___x_203_ = 23ULL;
v___x_204_ = 4604930618986332160ULL;
v___x_205_ = vastitas_storage_store(v_a_168_, v___x_183_, v___x_193_, v___x_194_, v___x_195_, v___x_196_, v___x_189_, v___x_203_, v___x_188_, v___x_184_, v___x_201_, v___x_204_);
if (lean_obj_tag(v___x_205_) == 0)
{
uint32_t v___x_206_; uint64_t v___x_207_; lean_object* v___x_208_; 
lean_dec_ref_known(v___x_205_, 1);
v___x_206_ = 1;
v___x_207_ = 2069ULL;
v___x_208_ = vastitas_storage_allocate(v_a_168_, v___x_206_, v___x_184_, v___x_207_);
if (lean_obj_tag(v___x_208_) == 0)
{
lean_object* v___x_209_; 
lean_dec_ref_known(v___x_208_, 1);
v___x_209_ = vastitas_storage_fill(v_a_168_, v___x_206_, v___x_187_, v___x_207_, v___x_188_, v___x_207_, v___x_189_, v___x_184_, v___x_190_, v___x_191_);
if (lean_obj_tag(v___x_209_) == 0)
{
uint64_t v___x_210_; uint64_t v___x_211_; uint64_t v___x_212_; uint64_t v___x_213_; uint64_t v___x_214_; lean_object* v___x_215_; 
lean_dec_ref_known(v___x_209_, 1);
v___x_210_ = 32ULL;
v___x_211_ = 40ULL;
v___x_212_ = 48ULL;
v___x_213_ = 43ULL;
v___x_214_ = 13821547256400052224ULL;
v___x_215_ = vastitas_storage_fill(v_a_168_, v___x_206_, v___x_210_, v___x_211_, v___x_212_, v___x_213_, v___x_189_, v___x_184_, v___x_214_, v___x_197_);
if (lean_obj_tag(v___x_215_) == 0)
{
uint64_t v___x_216_; uint64_t v___x_217_; lean_object* v___x_218_; 
lean_dec_ref_known(v___x_215_, 1);
v___x_216_ = 47ULL;
v___x_217_ = 4602678819172646912ULL;
v___x_218_ = vastitas_storage_store(v_a_168_, v___x_206_, v___x_210_, v___x_211_, v___x_212_, v___x_213_, v___x_189_, v___x_187_, v___x_216_, v___x_184_, v___x_217_, v___x_198_);
if (lean_obj_tag(v___x_218_) == 0)
{
uint64_t v___x_219_; uint64_t v___x_220_; lean_object* v___x_221_; 
lean_dec_ref_known(v___x_218_, 1);
v___x_219_ = 39ULL;
v___x_220_ = 13828302655841107968ULL;
v___x_221_ = vastitas_storage_store(v_a_168_, v___x_206_, v___x_210_, v___x_211_, v___x_212_, v___x_213_, v___x_189_, v___x_219_, v___x_187_, v___x_184_, v___x_220_, v___x_201_);
if (lean_obj_tag(v___x_221_) == 0)
{
uint32_t v___x_222_; uint64_t v___x_223_; lean_object* v___x_224_; 
lean_dec_ref_known(v___x_221_, 1);
v___x_222_ = 2;
v___x_223_ = 2022ULL;
v___x_224_ = vastitas_storage_allocate(v_a_168_, v___x_222_, v___x_184_, v___x_223_);
if (lean_obj_tag(v___x_224_) == 0)
{
lean_object* v___x_225_; 
lean_dec_ref_known(v___x_224_, 1);
v___x_225_ = vastitas_storage_fill(v_a_168_, v___x_222_, v___x_187_, v___x_223_, v___x_188_, v___x_223_, v___x_189_, v___x_184_, v___x_190_, v___x_191_);
if (lean_obj_tag(v___x_225_) == 0)
{
uint64_t v___x_226_; uint64_t v___x_227_; lean_object* v___x_228_; 
lean_dec_ref_known(v___x_225_, 1);
v___x_226_ = 56ULL;
v___x_227_ = 36ULL;
v___x_228_ = vastitas_storage_fill(v_a_168_, v___x_222_, v___x_212_, v___x_210_, v___x_226_, v___x_227_, v___x_189_, v___x_184_, v___x_217_, v___x_214_);
if (lean_obj_tag(v___x_228_) == 0)
{
uint64_t v___x_229_; lean_object* v___x_230_; 
lean_dec_ref_known(v___x_228_, 1);
v___x_229_ = 31ULL;
v___x_230_ = vastitas_storage_store(v_a_168_, v___x_222_, v___x_212_, v___x_210_, v___x_226_, v___x_227_, v___x_189_, v___x_229_, v___x_187_, v___x_184_, v___x_214_, v___x_217_);
if (lean_obj_tag(v___x_230_) == 0)
{
uint64_t v___x_231_; lean_object* v___x_232_; 
lean_dec_ref_known(v___x_230_, 1);
v___x_231_ = 55ULL;
v___x_232_ = vastitas_storage_store(v_a_168_, v___x_222_, v___x_212_, v___x_210_, v___x_226_, v___x_227_, v___x_189_, v___x_187_, v___x_231_, v___x_184_, v___x_204_, v___x_220_);
if (lean_obj_tag(v___x_232_) == 0)
{
uint32_t v___x_233_; uint64_t v___x_234_; lean_object* v___x_235_; 
lean_dec_ref_known(v___x_232_, 1);
v___x_233_ = 3;
v___x_234_ = 37130ULL;
v___x_235_ = vastitas_storage_allocate(v_a_168_, v___x_233_, v___x_184_, v___x_234_);
if (lean_obj_tag(v___x_235_) == 0)
{
lean_object* v___x_236_; 
lean_dec_ref_known(v___x_235_, 1);
v___x_236_ = vastitas_storage_fill(v_a_168_, v___x_233_, v___x_187_, v___x_234_, v___x_188_, v___x_234_, v___x_189_, v___x_184_, v___x_190_, v___x_191_);
if (lean_obj_tag(v___x_236_) == 0)
{
uint32_t v___x_237_; uint64_t v___x_238_; lean_object* v___x_239_; 
lean_dec_ref_known(v___x_236_, 1);
v___x_237_ = 4;
v___x_238_ = 37160ULL;
v___x_239_ = vastitas_storage_allocate(v_a_168_, v___x_237_, v___x_184_, v___x_238_);
if (lean_obj_tag(v___x_239_) == 0)
{
lean_object* v___x_240_; 
lean_dec_ref_known(v___x_239_, 1);
v___x_240_ = vastitas_storage_fill(v_a_168_, v___x_237_, v___x_187_, v___x_238_, v___x_188_, v___x_238_, v___x_189_, v___x_184_, v___x_190_, v___x_191_);
if (lean_obj_tag(v___x_240_) == 0)
{
uint32_t v___x_241_; uint64_t v___x_242_; lean_object* v___x_243_; 
lean_dec_ref_known(v___x_240_, 1);
v___x_241_ = 5;
v___x_242_ = 64913ULL;
v___x_243_ = vastitas_storage_allocate(v_a_168_, v___x_241_, v___x_184_, v___x_242_);
if (lean_obj_tag(v___x_243_) == 0)
{
lean_object* v___x_244_; 
lean_dec_ref_known(v___x_243_, 1);
v___x_244_ = vastitas_storage_fill(v_a_168_, v___x_241_, v___x_187_, v___x_242_, v___x_188_, v___x_242_, v___x_189_, v___x_184_, v___x_190_, v___x_191_);
if (lean_obj_tag(v___x_244_) == 0)
{
uint64_t v___x_245_; uint64_t v___x_246_; uint64_t v___x_247_; lean_object* v___x_248_; 
lean_dec_ref_known(v___x_244_, 1);
v___x_245_ = 64ULL;
v___x_246_ = 768ULL;
v___x_247_ = 773ULL;
v___x_248_ = vastitas_storage_pack3(v_a_168_, v___x_183_, v___x_193_, v___x_194_, v___x_195_, v___x_196_, v___x_189_, v___x_233_, v___x_245_, v___x_246_, v___x_211_, v___x_247_, v___x_189_, v___x_194_, v___x_211_, v___x_210_);
if (lean_obj_tag(v___x_248_) == 0)
{
uint64_t v___x_249_; uint64_t v___x_250_; uint8_t v___x_251_; lean_object* v___x_252_; 
lean_dec_ref_known(v___x_248_, 1);
v___x_249_ = 80ULL;
v___x_250_ = 774ULL;
v___x_251_ = 0;
v___x_252_ = vastitas_gemm_execute(v_a_168_, v___x_233_, v___x_245_, v___x_246_, v___x_211_, v___x_247_, v___x_189_, v___x_189_, v___x_206_, v___x_210_, v___x_211_, v___x_212_, v___x_213_, v___x_189_, v___x_189_, v___x_237_, v___x_249_, v___x_246_, v___x_212_, v___x_250_, v___x_189_, v___x_251_);
if (lean_obj_tag(v___x_252_) == 0)
{
uint64_t v___x_253_; uint64_t v___x_254_; uint64_t v___x_255_; uint64_t v___x_256_; lean_object* v___x_257_; 
lean_dec_ref_known(v___x_252_, 1);
v___x_253_ = 112ULL;
v___x_254_ = 1152ULL;
v___x_255_ = 1160ULL;
v___x_256_ = 42ULL;
v___x_257_ = vastitas_storage_regroup3(v_a_168_, v___x_237_, v___x_249_, v___x_246_, v___x_212_, v___x_250_, v___x_189_, v___x_233_, v___x_253_, v___x_254_, v___x_210_, v___x_255_, v___x_189_, v___x_194_, v___x_210_, v___x_212_, v___x_212_, v___x_256_);
if (lean_obj_tag(v___x_257_) == 0)
{
uint64_t v___x_258_; uint64_t v___x_259_; lean_object* v___x_260_; 
lean_dec_ref_known(v___x_257_, 1);
v___x_258_ = 96ULL;
v___x_259_ = 1159ULL;
v___x_260_ = vastitas_gemm_execute(v_a_168_, v___x_233_, v___x_253_, v___x_254_, v___x_210_, v___x_255_, v___x_189_, v___x_189_, v___x_222_, v___x_212_, v___x_210_, v___x_226_, v___x_227_, v___x_189_, v___x_189_, v___x_241_, v___x_258_, v___x_254_, v___x_226_, v___x_259_, v___x_189_, v___x_251_);
if (lean_obj_tag(v___x_260_) == 0)
{
uint64_t v___x_261_; uint64_t v___x_262_; lean_object* v___x_263_; 
lean_dec_ref_known(v___x_260_, 1);
v___x_261_ = 13855852019186663425ULL;
v___x_262_ = 13847480337652776960ULL;
v___x_263_ = vastitas_storage_expect(v_a_168_, v___x_241_, v___x_258_, v___x_254_, v___x_226_, v___x_259_, v___x_189_, v___x_187_, v___x_187_, v___x_184_, v___x_261_, v___x_262_);
if (lean_obj_tag(v___x_263_) == 0)
{
uint64_t v___x_264_; uint64_t v___x_265_; lean_object* v___x_266_; 
lean_dec_ref_known(v___x_263_, 1);
v___x_264_ = 13856569450523787264ULL;
v___x_265_ = 13847183469513277440ULL;
v___x_266_ = vastitas_storage_expect(v_a_168_, v___x_241_, v___x_258_, v___x_254_, v___x_226_, v___x_259_, v___x_189_, v___x_203_, v___x_231_, v___x_184_, v___x_264_, v___x_265_);
if (lean_obj_tag(v___x_266_) == 0)
{
uint64_t v___x_267_; uint64_t v___x_268_; uint64_t v___x_269_; lean_object* v___x_270_; 
lean_dec_ref_known(v___x_266_, 1);
v___x_267_ = 1151ULL;
v___x_268_ = 13855506772535541760ULL;
v___x_269_ = 13844008079932260352ULL;
v___x_270_ = vastitas_storage_expect(v_a_168_, v___x_241_, v___x_258_, v___x_254_, v___x_226_, v___x_259_, v___x_189_, v___x_267_, v___x_187_, v___x_184_, v___x_268_, v___x_269_);
if (lean_obj_tag(v___x_270_) == 0)
{
lean_object* v___x_271_; 
lean_dec_ref_known(v___x_270_, 1);
v___x_271_ = vastitas_storage_drop(v_a_168_, v___x_241_);
if (lean_obj_tag(v___x_271_) == 0)
{
lean_object* v___x_272_; 
lean_dec_ref_known(v___x_271_, 1);
v___x_272_ = vastitas_storage_drop(v_a_168_, v___x_237_);
if (lean_obj_tag(v___x_272_) == 0)
{
lean_object* v___x_273_; 
lean_dec_ref_known(v___x_272_, 1);
v___x_273_ = vastitas_storage_drop(v_a_168_, v___x_233_);
if (lean_obj_tag(v___x_273_) == 0)
{
lean_object* v___x_274_; 
lean_dec_ref_known(v___x_273_, 1);
v___x_274_ = vastitas_storage_drop(v_a_168_, v___x_222_);
if (lean_obj_tag(v___x_274_) == 0)
{
lean_object* v___x_275_; 
lean_dec_ref_known(v___x_274_, 1);
v___x_275_ = vastitas_storage_drop(v_a_168_, v___x_206_);
if (lean_obj_tag(v___x_275_) == 0)
{
lean_object* v___x_276_; 
lean_dec_ref_known(v___x_275_, 1);
v___x_276_ = vastitas_storage_drop(v_a_168_, v___x_183_);
if (lean_obj_tag(v___x_276_) == 0)
{
lean_object* v___x_277_; 
lean_dec_ref_known(v___x_276_, 1);
v___x_277_ = vastitas_storage_close(v_a_168_);
lean_dec(v_a_168_);
return v___x_277_;
}
else
{
v___y_170_ = v___x_276_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_275_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_274_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_273_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_272_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_271_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_270_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_266_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_263_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_260_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_257_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_252_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_248_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_244_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_243_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_240_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_239_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_236_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_235_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_232_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_230_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_228_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_225_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_224_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_221_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_218_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_215_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_209_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_208_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_205_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_202_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_199_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_192_;
goto v___jp_169_;
}
}
else
{
v___y_170_ = v___x_186_;
goto v___jp_169_;
}
v___jp_169_:
{
if (lean_obj_tag(v___y_170_) == 0)
{
lean_object* v___x_171_; 
lean_dec_ref_known(v___y_170_, 1);
v___x_171_ = vastitas_storage_close(v_a_168_);
lean_dec(v_a_168_);
return v___x_171_;
}
else
{
lean_object* v_a_172_; lean_object* v___x_173_; 
v_a_172_ = lean_ctor_get(v___y_170_, 0);
lean_inc(v_a_172_);
lean_dec_ref_known(v___y_170_, 1);
v___x_173_ = vastitas_storage_close(v_a_168_);
if (lean_obj_tag(v___x_173_) == 0)
{
lean_object* v___x_175_; uint8_t v_isShared_176_; uint8_t v_isSharedCheck_180_; 
lean_dec(v_a_168_);
v_isSharedCheck_180_ = !lean_is_exclusive(v___x_173_);
if (v_isSharedCheck_180_ == 0)
{
lean_object* v_unused_181_; 
v_unused_181_ = lean_ctor_get(v___x_173_, 0);
lean_dec(v_unused_181_);
v___x_175_ = v___x_173_;
v_isShared_176_ = v_isSharedCheck_180_;
goto v_resetjp_174_;
}
else
{
lean_dec(v___x_173_);
v___x_175_ = lean_box(0);
v_isShared_176_ = v_isSharedCheck_180_;
goto v_resetjp_174_;
}
v_resetjp_174_:
{
lean_object* v___x_178_; 
if (v_isShared_176_ == 0)
{
lean_ctor_set_tag(v___x_175_, 1);
lean_ctor_set(v___x_175_, 0, v_a_172_);
v___x_178_ = v___x_175_;
goto v_reusejp_177_;
}
else
{
lean_object* v_reuseFailAlloc_179_; 
v_reuseFailAlloc_179_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_179_, 0, v_a_172_);
v___x_178_ = v_reuseFailAlloc_179_;
goto v_reusejp_177_;
}
v_reusejp_177_:
{
return v___x_178_;
}
}
}
else
{
lean_dec(v_a_172_);
if (lean_obj_tag(v___x_173_) == 0)
{
lean_object* v___x_182_; 
lean_dec_ref_known(v___x_173_, 1);
v___x_182_ = vastitas_storage_close(v_a_168_);
lean_dec(v_a_168_);
return v___x_182_;
}
else
{
lean_dec(v_a_168_);
return v___x_173_;
}
}
}
}
}
else
{
lean_object* v_a_278_; lean_object* v___x_280_; uint8_t v_isShared_281_; uint8_t v_isSharedCheck_285_; 
v_a_278_ = lean_ctor_get(v___x_167_, 0);
v_isSharedCheck_285_ = !lean_is_exclusive(v___x_167_);
if (v_isSharedCheck_285_ == 0)
{
v___x_280_ = v___x_167_;
v_isShared_281_ = v_isSharedCheck_285_;
goto v_resetjp_279_;
}
else
{
lean_inc(v_a_278_);
lean_dec(v___x_167_);
v___x_280_ = lean_box(0);
v_isShared_281_ = v_isSharedCheck_285_;
goto v_resetjp_279_;
}
v_resetjp_279_:
{
lean_object* v___x_283_; 
if (v_isShared_281_ == 0)
{
v___x_283_ = v___x_280_;
goto v_reusejp_282_;
}
else
{
lean_object* v_reuseFailAlloc_284_; 
v_reuseFailAlloc_284_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_284_, 0, v_a_278_);
v___x_283_ = v_reuseFailAlloc_284_;
goto v_reusejp_282_;
}
v_reusejp_282_:
{
return v___x_283_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object* v_a_286_){
_start:
{
lean_object* v_res_287_; 
v_res_287_ = lp_allocation__audit_generatedFailure();
return v_res_287_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object* v_phase_290_, lean_object* v_a_00___x40___internal___hyg_291_){
_start:
{
uint32_t v_phase_boxed_292_; lean_object* v_res_293_; 
v_phase_boxed_292_ = lean_unbox_uint32(v_phase_290_);
lean_dec(v_phase_290_);
v_res_293_ = audit_mark_lean(v_phase_boxed_292_);
return v_res_293_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object* v_a_294_, lean_object* v_scope_295_, lean_object* v_range_296_, lean_object* v_b_297_, lean_object* v_i_298_){
_start:
{
lean_object* v_stop_300_; lean_object* v_step_301_; uint8_t v___x_302_; 
v_stop_300_ = lean_ctor_get(v_range_296_, 1);
v_step_301_ = lean_ctor_get(v_range_296_, 2);
v___x_302_ = lean_nat_dec_lt(v_i_298_, v_stop_300_);
if (v___x_302_ == 0)
{
lean_object* v___x_303_; 
lean_dec(v_i_298_);
v___x_303_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_303_, 0, v_b_297_);
return v___x_303_;
}
else
{
uint32_t v___x_304_; uint64_t v___x_305_; uint64_t v___x_306_; uint64_t v___x_307_; uint64_t v___x_308_; lean_object* v___x_309_; uint8_t v___x_310_; uint32_t v___x_311_; uint64_t v___x_312_; uint64_t v___x_313_; uint32_t v___x_314_; uint64_t v___x_315_; uint64_t v___x_316_; uint32_t v___x_317_; uint32_t v___x_318_; uint64_t v___x_319_; uint64_t v___x_320_; uint32_t v___x_321_; lean_object* v___x_322_; uint64_t v___x_323_; uint64_t v___x_324_; uint64_t v___x_325_; lean_object* v___x_326_; 
v___x_304_ = 0;
v___x_305_ = 16ULL;
v___x_306_ = 24ULL;
v___x_307_ = 1280ULL;
v___x_308_ = 26ULL;
v___x_309_ = lean_unsigned_to_nat(0u);
v___x_310_ = lean_nat_dec_eq(v_scope_295_, v___x_309_);
v___x_311_ = 3;
v___x_312_ = 40ULL;
v___x_313_ = 32ULL;
v___x_314_ = 1;
v___x_315_ = 48ULL;
v___x_316_ = 43ULL;
v___x_317_ = 4;
v___x_318_ = 2;
v___x_319_ = 56ULL;
v___x_320_ = 36ULL;
v___x_321_ = 5;
v___x_322_ = lean_box(0);
v___x_323_ = 64ULL;
v___x_324_ = 768ULL;
v___x_325_ = 773ULL;
v___x_326_ = vastitas_storage_pack3(v_a_294_, v___x_304_, v___x_305_, v___x_306_, v___x_307_, v___x_308_, v___x_310_, v___x_311_, v___x_323_, v___x_324_, v___x_312_, v___x_325_, v___x_310_, v___x_306_, v___x_312_, v___x_313_);
if (lean_obj_tag(v___x_326_) == 0)
{
uint64_t v___x_327_; uint64_t v___x_328_; uint8_t v___x_329_; lean_object* v___x_330_; 
lean_dec_ref_known(v___x_326_, 1);
v___x_327_ = 80ULL;
v___x_328_ = 774ULL;
v___x_329_ = 0;
v___x_330_ = vastitas_gemm_execute(v_a_294_, v___x_311_, v___x_323_, v___x_324_, v___x_312_, v___x_325_, v___x_310_, v___x_310_, v___x_314_, v___x_313_, v___x_312_, v___x_315_, v___x_316_, v___x_310_, v___x_310_, v___x_317_, v___x_327_, v___x_324_, v___x_315_, v___x_328_, v___x_310_, v___x_329_);
if (lean_obj_tag(v___x_330_) == 0)
{
uint64_t v___x_331_; uint64_t v___x_332_; uint64_t v___x_333_; uint64_t v___x_334_; lean_object* v___x_335_; 
lean_dec_ref_known(v___x_330_, 1);
v___x_331_ = 112ULL;
v___x_332_ = 1152ULL;
v___x_333_ = 1160ULL;
v___x_334_ = 42ULL;
v___x_335_ = vastitas_storage_regroup3(v_a_294_, v___x_317_, v___x_327_, v___x_324_, v___x_315_, v___x_328_, v___x_310_, v___x_311_, v___x_331_, v___x_332_, v___x_313_, v___x_333_, v___x_310_, v___x_306_, v___x_313_, v___x_315_, v___x_315_, v___x_334_);
if (lean_obj_tag(v___x_335_) == 0)
{
uint64_t v___x_336_; uint64_t v___x_337_; lean_object* v___x_338_; 
lean_dec_ref_known(v___x_335_, 1);
v___x_336_ = 96ULL;
v___x_337_ = 1159ULL;
v___x_338_ = vastitas_gemm_execute(v_a_294_, v___x_311_, v___x_331_, v___x_332_, v___x_313_, v___x_333_, v___x_310_, v___x_310_, v___x_318_, v___x_315_, v___x_313_, v___x_319_, v___x_320_, v___x_310_, v___x_310_, v___x_321_, v___x_336_, v___x_332_, v___x_319_, v___x_337_, v___x_310_, v___x_329_);
if (lean_obj_tag(v___x_338_) == 0)
{
lean_object* v___x_339_; 
lean_dec_ref_known(v___x_338_, 1);
v___x_339_ = lean_nat_add(v_i_298_, v_step_301_);
lean_dec(v_i_298_);
v_b_297_ = v___x_322_;
v_i_298_ = v___x_339_;
goto _start;
}
else
{
lean_dec(v_i_298_);
return v___x_338_;
}
}
else
{
lean_dec(v_i_298_);
return v___x_335_;
}
}
else
{
lean_dec(v_i_298_);
return v___x_330_;
}
}
else
{
lean_dec(v_i_298_);
return v___x_326_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object* v_a_341_, lean_object* v_scope_342_, lean_object* v_range_343_, lean_object* v_b_344_, lean_object* v_i_345_, lean_object* v___y_346_){
_start:
{
lean_object* v_res_347_; 
v_res_347_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_341_, v_scope_342_, v_range_343_, v_b_344_, v_i_345_);
lean_dec_ref(v_range_343_);
lean_dec(v_scope_342_);
lean_dec(v_a_341_);
return v_res_347_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object* v_range_348_, lean_object* v_b_349_, lean_object* v_i_350_){
_start:
{
lean_object* v_stop_352_; lean_object* v_step_353_; uint8_t v___x_354_; 
v_stop_352_ = lean_ctor_get(v_range_348_, 1);
v_step_353_ = lean_ctor_get(v_range_348_, 2);
v___x_354_ = lean_nat_dec_lt(v_i_350_, v_stop_352_);
if (v___x_354_ == 0)
{
lean_object* v___x_355_; 
lean_dec(v_i_350_);
v___x_355_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_355_, 0, v_b_349_);
return v___x_355_;
}
else
{
lean_object* v___x_356_; lean_object* v___x_357_; 
v___x_356_ = lean_box(0);
v___x_357_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_357_) == 0)
{
lean_object* v___x_358_; 
lean_dec_ref_known(v___x_357_, 1);
v___x_358_ = lean_nat_add(v_i_350_, v_step_353_);
lean_dec(v_i_350_);
v_b_349_ = v___x_356_;
v_i_350_ = v___x_358_;
goto _start;
}
else
{
lean_dec(v_i_350_);
return v___x_357_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object* v_range_360_, lean_object* v_b_361_, lean_object* v_i_362_, lean_object* v___y_363_){
_start:
{
lean_object* v_res_364_; 
v_res_364_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_360_, v_b_361_, v_i_362_);
lean_dec_ref(v_range_360_);
return v_res_364_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_373_){
_start:
{
lean_object* v___x_375_; lean_object* v___x_376_; lean_object* v_impl_377_; lean_object* v___x_378_; lean_object* v___x_379_; lean_object* v___x_380_; lean_object* v___x_381_; lean_object* v_scope_382_; lean_object* v___x_383_; lean_object* v___x_384_; lean_object* v___x_385_; lean_object* v___x_386_; lean_object* v_reps_387_; lean_object* v___x_388_; lean_object* v___x_389_; lean_object* v___x_390_; uint8_t v_verify_391_; uint32_t v___x_392_; lean_object* v___x_393_; 
v___x_375_ = ((lean_object*)(lp_allocation__audit_main___closed__0));
v___x_376_ = lean_unsigned_to_nat(0u);
v_impl_377_ = l_List_get_x21Internal___redArg(v___x_375_, v_args_373_, v___x_376_);
v___x_378_ = lean_unsigned_to_nat(1u);
v___x_379_ = l_List_get_x21Internal___redArg(v___x_375_, v_args_373_, v___x_378_);
v___x_380_ = lean_string_utf8_byte_size(v___x_379_);
v___x_381_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_381_, 0, v___x_379_);
lean_ctor_set(v___x_381_, 1, v___x_376_);
lean_ctor_set(v___x_381_, 2, v___x_380_);
v_scope_382_ = l_String_Slice_toNat_x21(v___x_381_);
lean_dec_ref_known(v___x_381_, 3);
v___x_383_ = lean_unsigned_to_nat(2u);
v___x_384_ = l_List_get_x21Internal___redArg(v___x_375_, v_args_373_, v___x_383_);
v___x_385_ = lean_string_utf8_byte_size(v___x_384_);
v___x_386_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_386_, 0, v___x_384_);
lean_ctor_set(v___x_386_, 1, v___x_376_);
lean_ctor_set(v___x_386_, 2, v___x_385_);
v_reps_387_ = l_String_Slice_toNat_x21(v___x_386_);
lean_dec_ref_known(v___x_386_, 3);
v___x_388_ = lean_unsigned_to_nat(3u);
v___x_389_ = l_List_get_x21Internal___redArg(v___x_375_, v_args_373_, v___x_388_);
lean_dec(v_args_373_);
v___x_390_ = ((lean_object*)(lp_allocation__audit_main___closed__1));
v_verify_391_ = lean_string_dec_eq(v___x_389_, v___x_390_);
lean_dec(v___x_389_);
v___x_392_ = 1;
v___x_393_ = audit_mark_lean(v___x_392_);
if (lean_obj_tag(v___x_393_) == 0)
{
lean_object* v___x_394_; 
lean_dec_ref_known(v___x_393_, 1);
v___x_394_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_394_) == 0)
{
uint32_t v___x_395_; lean_object* v___x_396_; 
lean_dec_ref_known(v___x_394_, 1);
v___x_395_ = 2;
v___x_396_ = audit_mark_lean(v___x_395_);
if (lean_obj_tag(v___x_396_) == 0)
{
lean_object* v___x_397_; uint8_t v___x_398_; 
lean_dec_ref_known(v___x_396_, 1);
v___x_397_ = ((lean_object*)(lp_allocation__audit_main___closed__2));
v___x_398_ = lean_string_dec_eq(v_impl_377_, v___x_397_);
if (v___x_398_ == 0)
{
lean_object* v___x_399_; uint8_t v___x_400_; 
v___x_399_ = ((lean_object*)(lp_allocation__audit_main___closed__3));
v___x_400_ = lean_string_dec_eq(v_impl_377_, v___x_399_);
lean_dec(v_impl_377_);
if (v___x_400_ == 0)
{
uint8_t v___x_401_; 
v___x_401_ = lean_nat_dec_eq(v_scope_382_, v___x_376_);
if (v___x_401_ == 0)
{
uint64_t v___x_402_; lean_object* v___x_403_; 
v___x_402_ = 9223372036854775807ULL;
v___x_403_ = vastitas_storage_new(v___x_402_);
if (lean_obj_tag(v___x_403_) == 0)
{
lean_object* v_a_404_; lean_object* v___y_409_; uint32_t v___x_420_; uint8_t v___x_421_; uint64_t v___x_422_; lean_object* v___x_423_; 
v_a_404_ = lean_ctor_get(v___x_403_, 0);
lean_inc(v_a_404_);
lean_dec_ref_known(v___x_403_, 1);
v___x_420_ = 0;
v___x_421_ = 1;
v___x_422_ = 33284ULL;
v___x_423_ = vastitas_storage_allocate(v_a_404_, v___x_420_, v___x_421_, v___x_422_);
if (lean_obj_tag(v___x_423_) == 0)
{
uint64_t v___x_424_; uint64_t v___x_425_; uint64_t v___x_426_; uint64_t v___x_427_; lean_object* v___x_428_; 
lean_dec_ref_known(v___x_423_, 1);
v___x_424_ = 0ULL;
v___x_425_ = 1ULL;
v___x_426_ = 13842939354630062080ULL;
v___x_427_ = 4613937818241073152ULL;
v___x_428_ = vastitas_storage_fill(v_a_404_, v___x_420_, v___x_424_, v___x_422_, v___x_425_, v___x_422_, v___x_401_, v___x_421_, v___x_426_, v___x_427_);
if (lean_obj_tag(v___x_428_) == 0)
{
uint64_t v___x_429_; uint64_t v___x_430_; uint64_t v___x_431_; uint64_t v___x_432_; uint64_t v___x_433_; uint64_t v___x_434_; lean_object* v___x_435_; 
lean_dec_ref_known(v___x_428_, 1);
v___x_429_ = 16ULL;
v___x_430_ = 24ULL;
v___x_431_ = 1280ULL;
v___x_432_ = 26ULL;
v___x_433_ = 4593671619917905920ULL;
v___x_434_ = 4598175219545276416ULL;
v___x_435_ = vastitas_storage_fill(v_a_404_, v___x_420_, v___x_429_, v___x_430_, v___x_431_, v___x_432_, v___x_401_, v___x_421_, v___x_433_, v___x_434_);
if (lean_obj_tag(v___x_435_) == 0)
{
uint64_t v___x_436_; uint64_t v___x_437_; lean_object* v___x_438_; 
lean_dec_ref_known(v___x_435_, 1);
v___x_436_ = 4607182418800017408ULL;
v___x_437_ = 13826050856027422720ULL;
v___x_438_ = vastitas_storage_store(v_a_404_, v___x_420_, v___x_429_, v___x_430_, v___x_431_, v___x_432_, v___x_401_, v___x_424_, v___x_424_, v___x_421_, v___x_436_, v___x_437_);
if (lean_obj_tag(v___x_438_) == 0)
{
uint64_t v___x_439_; uint64_t v___x_440_; lean_object* v___x_441_; 
lean_dec_ref_known(v___x_438_, 1);
v___x_439_ = 23ULL;
v___x_440_ = 4604930618986332160ULL;
v___x_441_ = vastitas_storage_store(v_a_404_, v___x_420_, v___x_429_, v___x_430_, v___x_431_, v___x_432_, v___x_401_, v___x_439_, v___x_425_, v___x_421_, v___x_437_, v___x_440_);
if (lean_obj_tag(v___x_441_) == 0)
{
uint64_t v___x_442_; lean_object* v___x_443_; 
lean_dec_ref_known(v___x_441_, 1);
v___x_442_ = 2069ULL;
v___x_443_ = vastitas_storage_allocate(v_a_404_, v___x_392_, v___x_421_, v___x_442_);
if (lean_obj_tag(v___x_443_) == 0)
{
lean_object* v___x_444_; 
lean_dec_ref_known(v___x_443_, 1);
v___x_444_ = vastitas_storage_fill(v_a_404_, v___x_392_, v___x_424_, v___x_442_, v___x_425_, v___x_442_, v___x_401_, v___x_421_, v___x_426_, v___x_427_);
if (lean_obj_tag(v___x_444_) == 0)
{
uint64_t v___x_445_; uint64_t v___x_446_; uint64_t v___x_447_; uint64_t v___x_448_; uint64_t v___x_449_; lean_object* v___x_450_; 
lean_dec_ref_known(v___x_444_, 1);
v___x_445_ = 32ULL;
v___x_446_ = 40ULL;
v___x_447_ = 48ULL;
v___x_448_ = 43ULL;
v___x_449_ = 13821547256400052224ULL;
v___x_450_ = vastitas_storage_fill(v_a_404_, v___x_392_, v___x_445_, v___x_446_, v___x_447_, v___x_448_, v___x_401_, v___x_421_, v___x_449_, v___x_433_);
if (lean_obj_tag(v___x_450_) == 0)
{
uint64_t v___x_451_; uint64_t v___x_452_; lean_object* v___x_453_; 
lean_dec_ref_known(v___x_450_, 1);
v___x_451_ = 47ULL;
v___x_452_ = 4602678819172646912ULL;
v___x_453_ = vastitas_storage_store(v_a_404_, v___x_392_, v___x_445_, v___x_446_, v___x_447_, v___x_448_, v___x_401_, v___x_424_, v___x_451_, v___x_421_, v___x_452_, v___x_434_);
if (lean_obj_tag(v___x_453_) == 0)
{
uint64_t v___x_454_; uint64_t v___x_455_; lean_object* v___x_456_; 
lean_dec_ref_known(v___x_453_, 1);
v___x_454_ = 39ULL;
v___x_455_ = 13828302655841107968ULL;
v___x_456_ = vastitas_storage_store(v_a_404_, v___x_392_, v___x_445_, v___x_446_, v___x_447_, v___x_448_, v___x_401_, v___x_454_, v___x_424_, v___x_421_, v___x_455_, v___x_437_);
if (lean_obj_tag(v___x_456_) == 0)
{
uint64_t v___x_457_; lean_object* v___x_458_; 
lean_dec_ref_known(v___x_456_, 1);
v___x_457_ = 2022ULL;
v___x_458_ = vastitas_storage_allocate(v_a_404_, v___x_395_, v___x_421_, v___x_457_);
if (lean_obj_tag(v___x_458_) == 0)
{
lean_object* v___x_459_; 
lean_dec_ref_known(v___x_458_, 1);
v___x_459_ = vastitas_storage_fill(v_a_404_, v___x_395_, v___x_424_, v___x_457_, v___x_425_, v___x_457_, v___x_401_, v___x_421_, v___x_426_, v___x_427_);
if (lean_obj_tag(v___x_459_) == 0)
{
uint64_t v___x_460_; uint64_t v___x_461_; lean_object* v___x_462_; 
lean_dec_ref_known(v___x_459_, 1);
v___x_460_ = 56ULL;
v___x_461_ = 36ULL;
v___x_462_ = vastitas_storage_fill(v_a_404_, v___x_395_, v___x_447_, v___x_445_, v___x_460_, v___x_461_, v___x_401_, v___x_421_, v___x_452_, v___x_449_);
if (lean_obj_tag(v___x_462_) == 0)
{
uint64_t v___x_463_; lean_object* v___x_464_; 
lean_dec_ref_known(v___x_462_, 1);
v___x_463_ = 31ULL;
v___x_464_ = vastitas_storage_store(v_a_404_, v___x_395_, v___x_447_, v___x_445_, v___x_460_, v___x_461_, v___x_401_, v___x_463_, v___x_424_, v___x_421_, v___x_449_, v___x_452_);
if (lean_obj_tag(v___x_464_) == 0)
{
uint64_t v___x_465_; lean_object* v___x_466_; 
lean_dec_ref_known(v___x_464_, 1);
v___x_465_ = 55ULL;
v___x_466_ = vastitas_storage_store(v_a_404_, v___x_395_, v___x_447_, v___x_445_, v___x_460_, v___x_461_, v___x_401_, v___x_424_, v___x_465_, v___x_421_, v___x_440_, v___x_455_);
if (lean_obj_tag(v___x_466_) == 0)
{
uint32_t v___x_467_; uint64_t v___x_468_; lean_object* v___x_469_; 
lean_dec_ref_known(v___x_466_, 1);
v___x_467_ = 3;
v___x_468_ = 37130ULL;
v___x_469_ = vastitas_storage_allocate(v_a_404_, v___x_467_, v___x_421_, v___x_468_);
if (lean_obj_tag(v___x_469_) == 0)
{
lean_object* v___x_470_; 
lean_dec_ref_known(v___x_469_, 1);
v___x_470_ = vastitas_storage_fill(v_a_404_, v___x_467_, v___x_424_, v___x_468_, v___x_425_, v___x_468_, v___x_401_, v___x_421_, v___x_426_, v___x_427_);
if (lean_obj_tag(v___x_470_) == 0)
{
uint32_t v___x_471_; uint64_t v___x_472_; lean_object* v___x_473_; 
lean_dec_ref_known(v___x_470_, 1);
v___x_471_ = 4;
v___x_472_ = 37160ULL;
v___x_473_ = vastitas_storage_allocate(v_a_404_, v___x_471_, v___x_421_, v___x_472_);
if (lean_obj_tag(v___x_473_) == 0)
{
lean_object* v___x_474_; 
lean_dec_ref_known(v___x_473_, 1);
v___x_474_ = vastitas_storage_fill(v_a_404_, v___x_471_, v___x_424_, v___x_472_, v___x_425_, v___x_472_, v___x_401_, v___x_421_, v___x_426_, v___x_427_);
if (lean_obj_tag(v___x_474_) == 0)
{
uint32_t v___x_475_; uint64_t v___x_476_; lean_object* v___x_477_; 
lean_dec_ref_known(v___x_474_, 1);
v___x_475_ = 5;
v___x_476_ = 64913ULL;
v___x_477_ = vastitas_storage_allocate(v_a_404_, v___x_475_, v___x_421_, v___x_476_);
if (lean_obj_tag(v___x_477_) == 0)
{
lean_object* v___x_478_; 
lean_dec_ref_known(v___x_477_, 1);
v___x_478_ = vastitas_storage_fill(v_a_404_, v___x_475_, v___x_424_, v___x_476_, v___x_425_, v___x_476_, v___x_401_, v___x_421_, v___x_426_, v___x_427_);
if (lean_obj_tag(v___x_478_) == 0)
{
uint32_t v___x_479_; uint64_t v___x_480_; lean_object* v___x_481_; 
lean_dec_ref_known(v___x_478_, 1);
v___x_479_ = lean_uint32_of_nat(v_scope_382_);
v___x_480_ = lean_uint64_of_nat(v_reps_387_);
v___x_481_ = bench_begin_lean(v___x_479_, v___x_480_, v_verify_391_);
if (lean_obj_tag(v___x_481_) == 0)
{
lean_object* v___x_482_; lean_object* v___x_483_; lean_object* v___x_484_; 
lean_dec_ref_known(v___x_481_, 1);
v___x_482_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_482_, 0, v___x_376_);
lean_ctor_set(v___x_482_, 1, v_reps_387_);
lean_ctor_set(v___x_482_, 2, v___x_378_);
v___x_483_ = lean_box(0);
v___x_484_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_404_, v_scope_382_, v___x_482_, v___x_483_, v___x_376_);
lean_dec_ref_known(v___x_482_, 3);
lean_dec(v_scope_382_);
if (lean_obj_tag(v___x_484_) == 0)
{
lean_object* v___x_485_; 
lean_dec_ref_known(v___x_484_, 1);
v___x_485_ = bench_stop_lean();
if (lean_obj_tag(v___x_485_) == 0)
{
lean_object* v___x_486_; 
lean_dec_ref_known(v___x_485_, 1);
v___x_486_ = bench_verify_lean(v_a_404_, v___x_480_);
if (lean_obj_tag(v___x_486_) == 0)
{
uint64_t v___x_487_; uint64_t v___x_488_; uint64_t v___x_489_; uint64_t v___x_490_; uint64_t v___x_491_; lean_object* v___x_492_; 
lean_dec_ref_known(v___x_486_, 1);
v___x_487_ = 96ULL;
v___x_488_ = 1152ULL;
v___x_489_ = 1159ULL;
v___x_490_ = 13855852019186663424ULL;
v___x_491_ = 13847480337652776960ULL;
v___x_492_ = vastitas_storage_expect(v_a_404_, v___x_475_, v___x_487_, v___x_488_, v___x_460_, v___x_489_, v___x_401_, v___x_424_, v___x_424_, v___x_421_, v___x_490_, v___x_491_);
if (lean_obj_tag(v___x_492_) == 0)
{
uint64_t v___x_493_; uint64_t v___x_494_; lean_object* v___x_495_; 
lean_dec_ref_known(v___x_492_, 1);
v___x_493_ = 13856569450523787264ULL;
v___x_494_ = 13847183469513277440ULL;
v___x_495_ = vastitas_storage_expect(v_a_404_, v___x_475_, v___x_487_, v___x_488_, v___x_460_, v___x_489_, v___x_401_, v___x_439_, v___x_465_, v___x_421_, v___x_493_, v___x_494_);
if (lean_obj_tag(v___x_495_) == 0)
{
uint64_t v___x_496_; uint64_t v___x_497_; uint64_t v___x_498_; lean_object* v___x_499_; 
lean_dec_ref_known(v___x_495_, 1);
v___x_496_ = 1151ULL;
v___x_497_ = 13855506772535541760ULL;
v___x_498_ = 13844008079932260352ULL;
v___x_499_ = vastitas_storage_expect(v_a_404_, v___x_475_, v___x_487_, v___x_488_, v___x_460_, v___x_489_, v___x_401_, v___x_496_, v___x_424_, v___x_421_, v___x_497_, v___x_498_);
if (lean_obj_tag(v___x_499_) == 0)
{
lean_object* v___x_500_; 
lean_dec_ref_known(v___x_499_, 1);
v___x_500_ = vastitas_storage_drop(v_a_404_, v___x_475_);
if (lean_obj_tag(v___x_500_) == 0)
{
lean_object* v___x_501_; 
lean_dec_ref_known(v___x_500_, 1);
v___x_501_ = vastitas_storage_drop(v_a_404_, v___x_471_);
if (lean_obj_tag(v___x_501_) == 0)
{
lean_object* v___x_502_; 
lean_dec_ref_known(v___x_501_, 1);
v___x_502_ = vastitas_storage_drop(v_a_404_, v___x_467_);
if (lean_obj_tag(v___x_502_) == 0)
{
lean_object* v___x_503_; 
lean_dec_ref_known(v___x_502_, 1);
v___x_503_ = vastitas_storage_drop(v_a_404_, v___x_395_);
if (lean_obj_tag(v___x_503_) == 0)
{
lean_object* v___x_504_; 
lean_dec_ref_known(v___x_503_, 1);
v___x_504_ = vastitas_storage_drop(v_a_404_, v___x_392_);
if (lean_obj_tag(v___x_504_) == 0)
{
lean_object* v___x_505_; 
lean_dec_ref_known(v___x_504_, 1);
v___x_505_ = vastitas_storage_drop(v_a_404_, v___x_420_);
v___y_409_ = v___x_505_;
goto v___jp_408_;
}
else
{
v___y_409_ = v___x_504_;
goto v___jp_408_;
}
}
else
{
v___y_409_ = v___x_503_;
goto v___jp_408_;
}
}
else
{
v___y_409_ = v___x_502_;
goto v___jp_408_;
}
}
else
{
v___y_409_ = v___x_501_;
goto v___jp_408_;
}
}
else
{
v___y_409_ = v___x_500_;
goto v___jp_408_;
}
}
else
{
v___y_409_ = v___x_499_;
goto v___jp_408_;
}
}
else
{
v___y_409_ = v___x_495_;
goto v___jp_408_;
}
}
else
{
v___y_409_ = v___x_492_;
goto v___jp_408_;
}
}
else
{
v___y_409_ = v___x_486_;
goto v___jp_408_;
}
}
else
{
v___y_409_ = v___x_485_;
goto v___jp_408_;
}
}
else
{
v___y_409_ = v___x_484_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_481_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_478_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_477_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_474_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_473_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_470_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_469_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_466_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_464_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_462_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_459_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_458_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_456_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_453_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_450_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_444_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_443_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_441_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_438_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_435_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_428_;
goto v___jp_408_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v___y_409_ = v___x_423_;
goto v___jp_408_;
}
v___jp_405_:
{
lean_object* v___x_406_; 
v___x_406_ = vastitas_storage_close(v_a_404_);
lean_dec(v_a_404_);
if (lean_obj_tag(v___x_406_) == 0)
{
lean_object* v___x_407_; 
lean_dec_ref_known(v___x_406_, 1);
v___x_407_ = bench_report_lean();
return v___x_407_;
}
else
{
return v___x_406_;
}
}
v___jp_408_:
{
if (lean_obj_tag(v___y_409_) == 0)
{
lean_dec_ref_known(v___y_409_, 1);
goto v___jp_405_;
}
else
{
lean_object* v_a_410_; lean_object* v___x_411_; 
v_a_410_ = lean_ctor_get(v___y_409_, 0);
lean_inc(v_a_410_);
lean_dec_ref_known(v___y_409_, 1);
v___x_411_ = vastitas_storage_close(v_a_404_);
if (lean_obj_tag(v___x_411_) == 0)
{
lean_object* v___x_413_; uint8_t v_isShared_414_; uint8_t v_isSharedCheck_418_; 
lean_dec(v_a_404_);
v_isSharedCheck_418_ = !lean_is_exclusive(v___x_411_);
if (v_isSharedCheck_418_ == 0)
{
lean_object* v_unused_419_; 
v_unused_419_ = lean_ctor_get(v___x_411_, 0);
lean_dec(v_unused_419_);
v___x_413_ = v___x_411_;
v_isShared_414_ = v_isSharedCheck_418_;
goto v_resetjp_412_;
}
else
{
lean_dec(v___x_411_);
v___x_413_ = lean_box(0);
v_isShared_414_ = v_isSharedCheck_418_;
goto v_resetjp_412_;
}
v_resetjp_412_:
{
lean_object* v___x_416_; 
if (v_isShared_414_ == 0)
{
lean_ctor_set_tag(v___x_413_, 1);
lean_ctor_set(v___x_413_, 0, v_a_410_);
v___x_416_ = v___x_413_;
goto v_reusejp_415_;
}
else
{
lean_object* v_reuseFailAlloc_417_; 
v_reuseFailAlloc_417_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_417_, 0, v_a_410_);
v___x_416_ = v_reuseFailAlloc_417_;
goto v_reusejp_415_;
}
v_reusejp_415_:
{
return v___x_416_;
}
}
}
else
{
lean_dec(v_a_410_);
if (lean_obj_tag(v___x_411_) == 0)
{
lean_dec_ref_known(v___x_411_, 1);
goto v___jp_405_;
}
else
{
lean_dec(v_a_404_);
return v___x_411_;
}
}
}
}
}
else
{
lean_object* v_a_506_; lean_object* v___x_508_; uint8_t v_isShared_509_; uint8_t v_isSharedCheck_513_; 
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
v_a_506_ = lean_ctor_get(v___x_403_, 0);
v_isSharedCheck_513_ = !lean_is_exclusive(v___x_403_);
if (v_isSharedCheck_513_ == 0)
{
v___x_508_ = v___x_403_;
v_isShared_509_ = v_isSharedCheck_513_;
goto v_resetjp_507_;
}
else
{
lean_inc(v_a_506_);
lean_dec(v___x_403_);
v___x_508_ = lean_box(0);
v_isShared_509_ = v_isSharedCheck_513_;
goto v_resetjp_507_;
}
v_resetjp_507_:
{
lean_object* v___x_511_; 
if (v_isShared_509_ == 0)
{
v___x_511_ = v___x_508_;
goto v_reusejp_510_;
}
else
{
lean_object* v_reuseFailAlloc_512_; 
v_reuseFailAlloc_512_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_512_, 0, v_a_506_);
v___x_511_ = v_reuseFailAlloc_512_;
goto v_reusejp_510_;
}
v_reusejp_510_:
{
return v___x_511_;
}
}
}
}
else
{
uint32_t v___x_514_; uint64_t v___x_515_; lean_object* v___x_516_; 
lean_dec(v_scope_382_);
v___x_514_ = 0;
v___x_515_ = lean_uint64_of_nat(v_reps_387_);
v___x_516_ = bench_begin_lean(v___x_514_, v___x_515_, v_verify_391_);
if (lean_obj_tag(v___x_516_) == 0)
{
lean_object* v___x_517_; lean_object* v___x_518_; lean_object* v___x_519_; 
lean_dec_ref_known(v___x_516_, 1);
v___x_517_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_517_, 0, v___x_376_);
lean_ctor_set(v___x_517_, 1, v_reps_387_);
lean_ctor_set(v___x_517_, 2, v___x_378_);
v___x_518_ = lean_box(0);
v___x_519_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v___x_517_, v___x_518_, v___x_376_);
lean_dec_ref_known(v___x_517_, 3);
if (lean_obj_tag(v___x_519_) == 0)
{
lean_object* v___x_520_; 
lean_dec_ref_known(v___x_519_, 1);
v___x_520_ = bench_stop_lean();
if (lean_obj_tag(v___x_520_) == 0)
{
lean_object* v___x_521_; 
lean_dec_ref_known(v___x_520_, 1);
v___x_521_ = bench_report_lean();
return v___x_521_;
}
else
{
return v___x_520_;
}
}
else
{
return v___x_519_;
}
}
else
{
lean_dec(v_reps_387_);
return v___x_516_;
}
}
}
else
{
uint32_t v___x_522_; uint64_t v___x_523_; lean_object* v___x_524_; 
v___x_522_ = lean_uint32_of_nat(v_scope_382_);
lean_dec(v_scope_382_);
v___x_523_ = lean_uint64_of_nat(v_reps_387_);
lean_dec(v_reps_387_);
v___x_524_ = bench_c_run_lean(v___x_522_, v___x_523_, v_verify_391_);
if (lean_obj_tag(v___x_524_) == 0)
{
lean_object* v___x_525_; 
lean_dec_ref_known(v___x_524_, 1);
v___x_525_ = bench_report_lean();
return v___x_525_;
}
else
{
return v___x_524_;
}
}
}
else
{
uint32_t v___x_526_; uint64_t v___x_527_; lean_object* v___x_528_; 
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
lean_dec(v_impl_377_);
v___x_526_ = 0;
v___x_527_ = 1ULL;
v___x_528_ = bench_begin_lean(v___x_526_, v___x_527_, v___x_398_);
if (lean_obj_tag(v___x_528_) == 0)
{
lean_object* v___x_529_; 
lean_dec_ref_known(v___x_528_, 1);
v___x_529_ = lp_allocation__audit_generatedFailure();
if (lean_obj_tag(v___x_529_) == 0)
{
lean_object* v___x_531_; uint8_t v_isShared_532_; uint8_t v_isSharedCheck_537_; 
v_isSharedCheck_537_ = !lean_is_exclusive(v___x_529_);
if (v_isSharedCheck_537_ == 0)
{
lean_object* v_unused_538_; 
v_unused_538_ = lean_ctor_get(v___x_529_, 0);
lean_dec(v_unused_538_);
v___x_531_ = v___x_529_;
v_isShared_532_ = v_isSharedCheck_537_;
goto v_resetjp_530_;
}
else
{
lean_dec(v___x_529_);
v___x_531_ = lean_box(0);
v_isShared_532_ = v_isSharedCheck_537_;
goto v_resetjp_530_;
}
v_resetjp_530_:
{
lean_object* v___x_533_; lean_object* v___x_535_; 
v___x_533_ = ((lean_object*)(lp_allocation__audit_main___closed__5));
if (v_isShared_532_ == 0)
{
lean_ctor_set_tag(v___x_531_, 1);
lean_ctor_set(v___x_531_, 0, v___x_533_);
v___x_535_ = v___x_531_;
goto v_reusejp_534_;
}
else
{
lean_object* v_reuseFailAlloc_536_; 
v_reuseFailAlloc_536_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_536_, 0, v___x_533_);
v___x_535_ = v_reuseFailAlloc_536_;
goto v_reusejp_534_;
}
v_reusejp_534_:
{
return v___x_535_;
}
}
}
else
{
lean_object* v_a_539_; lean_object* v___x_540_; lean_object* v___x_541_; uint8_t v___x_542_; 
v_a_539_ = lean_ctor_get(v___x_529_, 0);
lean_inc(v_a_539_);
v___x_540_ = lean_io_error_to_string(v_a_539_);
v___x_541_ = ((lean_object*)(lp_allocation__audit_main___closed__6));
v___x_542_ = lean_string_dec_eq(v___x_540_, v___x_541_);
lean_dec_ref(v___x_540_);
if (v___x_542_ == 0)
{
return v___x_529_;
}
else
{
lean_object* v___x_543_; 
lean_dec_ref_known(v___x_529_, 1);
v___x_543_ = bench_stop_lean();
if (lean_obj_tag(v___x_543_) == 0)
{
lean_object* v___x_544_; 
lean_dec_ref_known(v___x_543_, 1);
v___x_544_ = bench_report_lean();
return v___x_544_;
}
else
{
return v___x_543_;
}
}
}
}
else
{
return v___x_528_;
}
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
lean_dec(v_impl_377_);
return v___x_396_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
lean_dec(v_impl_377_);
return v___x_394_;
}
}
else
{
lean_dec(v_reps_387_);
lean_dec(v_scope_382_);
lean_dec(v_impl_377_);
return v___x_393_;
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object* v_args_545_, lean_object* v_a_546_){
_start:
{
lean_object* v_res_547_; 
v_res_547_ = _lean_main(v_args_545_);
return v_res_547_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object* v_a_548_, lean_object* v_scope_549_, lean_object* v_range_550_, lean_object* v_b_551_, lean_object* v_i_552_, lean_object* v_hs_553_, lean_object* v_hl_554_){
_start:
{
lean_object* v___x_556_; 
v___x_556_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_548_, v_scope_549_, v_range_550_, v_b_551_, v_i_552_);
return v___x_556_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object* v_a_557_, lean_object* v_scope_558_, lean_object* v_range_559_, lean_object* v_b_560_, lean_object* v_i_561_, lean_object* v_hs_562_, lean_object* v_hl_563_, lean_object* v___y_564_){
_start:
{
lean_object* v_res_565_; 
v_res_565_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(v_a_557_, v_scope_558_, v_range_559_, v_b_560_, v_i_561_, v_hs_562_, v_hl_563_);
lean_dec_ref(v_range_559_);
lean_dec(v_scope_558_);
lean_dec(v_a_557_);
return v_res_565_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object* v_range_566_, lean_object* v_b_567_, lean_object* v_i_568_, lean_object* v_hs_569_, lean_object* v_hl_570_){
_start:
{
lean_object* v___x_572_; 
v___x_572_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_566_, v_b_567_, v_i_568_);
return v___x_572_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object* v_range_573_, lean_object* v_b_574_, lean_object* v_i_575_, lean_object* v_hs_576_, lean_object* v_hl_577_, lean_object* v___y_578_){
_start:
{
lean_object* v_res_579_; 
v_res_579_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(v_range_573_, v_b_574_, v_i_575_, v_hs_576_, v_hl_577_);
lean_dec_ref(v_range_573_);
return v_res_579_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_vastitas__storage__native_VastitasStorageNative(uint8_t builtin);
lean_object* initialize_vastitas__gemm__native_VastitasGemmNative(uint8_t builtin);
lean_object* initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_allocation__audit_Main(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__storage__native_VastitasStorageNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__gemm__native_VastitasGemmNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_allocation__audit_VastitasGenerated_f__0 = _init_lp_allocation__audit_VastitasGenerated_f__0();
lean_mark_persistent(lp_allocation__audit_VastitasGenerated_f__0);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_allocation__audit_Main(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = 0;
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
