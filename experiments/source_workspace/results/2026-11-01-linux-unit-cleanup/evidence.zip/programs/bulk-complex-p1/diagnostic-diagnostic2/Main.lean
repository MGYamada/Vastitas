import VastitasStorageNative
import VastitasGemmNative
import VastitasKernel.IndexedRuntime

set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
set_option linter.unusedVariables false

namespace VastitasGenerated

def f_0 : Int :=
  (0 : Int)

end VastitasGenerated

open VastitasStorageNative


@[extern "bench_begin_lean"] opaque benchBegin (scope : UInt32) (reps : UInt64) (verify : Bool) : IO Unit
@[extern "bench_stop_lean"] opaque benchStop : IO Unit
@[extern "bench_report_lean"] opaque benchReport : IO Unit
@[extern "bench_c_run_lean"] opaque benchCRun (scope : UInt32) (reps : UInt64) (verify : Bool) : IO Unit
@[extern "bench_verify_lean"] opaque benchVerify (arena : @& Arena) (reps : UInt64) : IO Unit

@[noinline] def generatedOnce : IO Unit := do
  let arena ← newArena 9223372036854775807
  try
    allocate arena 0 1 33284
    fill arena 0 0 33284 1 33284 false 1 13842939354630062080 4613937818241073152
    fill arena 0 16 24 1280 26 false 1 4593671619917905920 4598175219545276416
    store arena 0 16 24 1280 26 false 0 0 1 4607182418800017408 13826050856027422720
    store arena 0 16 24 1280 26 false 23 1 1 13826050856027422720 4604930618986332160
    allocate arena 1 1 2069
    fill arena 1 0 2069 1 2069 false 1 13842939354630062080 4613937818241073152
    fill arena 1 32 40 48 43 false 1 13821547256400052224 4593671619917905920
    store arena 1 32 40 48 43 false 0 47 1 4602678819172646912 4598175219545276416
    store arena 1 32 40 48 43 false 39 0 1 13828302655841107968 13826050856027422720
    allocate arena 2 1 2022
    fill arena 2 0 2022 1 2022 false 1 13842939354630062080 4613937818241073152
    fill arena 2 48 32 56 36 false 1 4602678819172646912 13821547256400052224
    store arena 2 48 32 56 36 false 31 0 1 13821547256400052224 4602678819172646912
    store arena 2 48 32 56 36 false 0 55 1 4604930618986332160 13828302655841107968
    allocate arena 3 1 37130
    fill arena 3 0 37130 1 37130 false 1 13842939354630062080 4613937818241073152
    allocate arena 4 1 37160
    fill arena 4 0 37160 1 37160 false 1 13842939354630062080 4613937818241073152
    allocate arena 5 1 64913
    fill arena 5 0 64913 1 64913 false 1 13842939354630062080 4613937818241073152
    pack3 arena 0 16 24 1280 26 false 3 64 768 40 773 false 24 40 32
    VastitasGemmNative.gemm arena 3 64 768 40 773 false false 1 32 40 48 43 false false 4 80 768 48 774 false 0
    regroup3 arena 4 80 768 48 774 false 3 112 1152 32 1160 false 24 32 48 48 42
    VastitasGemmNative.gemm arena 3 112 1152 32 1160 false false 2 48 32 56 36 false false 5 96 1152 56 1159 false 0
    expect arena 5 96 1152 56 1159 false 0 0 1 13855852019186663424 13847480337652776960
    expect arena 5 96 1152 56 1159 false 23 55 1 13856569450523787264 13847183469513277440
    expect arena 5 96 1152 56 1159 false 1151 0 1 13855506772535541760 13844008079932260352
    drop arena 5
    drop arena 4
    drop arena 3
    drop arena 2
    drop arena 1
    drop arena 0
    pure ()
  catch cleanupError =>
    close arena
    throw cleanupError
  close arena

@[noinline] def generatedFailure : IO Unit := do
  let arena ← newArena 9223372036854775807
  try
    allocate arena 0 1 33284
    fill arena 0 0 33284 1 33284 false 1 13842939354630062080 4613937818241073152
    fill arena 0 16 24 1280 26 false 1 4593671619917905920 4598175219545276416
    store arena 0 16 24 1280 26 false 0 0 1 4607182418800017408 13826050856027422720
    store arena 0 16 24 1280 26 false 23 1 1 13826050856027422720 4604930618986332160
    allocate arena 1 1 2069
    fill arena 1 0 2069 1 2069 false 1 13842939354630062080 4613937818241073152
    fill arena 1 32 40 48 43 false 1 13821547256400052224 4593671619917905920
    store arena 1 32 40 48 43 false 0 47 1 4602678819172646912 4598175219545276416
    store arena 1 32 40 48 43 false 39 0 1 13828302655841107968 13826050856027422720
    allocate arena 2 1 2022
    fill arena 2 0 2022 1 2022 false 1 13842939354630062080 4613937818241073152
    fill arena 2 48 32 56 36 false 1 4602678819172646912 13821547256400052224
    store arena 2 48 32 56 36 false 31 0 1 13821547256400052224 4602678819172646912
    store arena 2 48 32 56 36 false 0 55 1 4604930618986332160 13828302655841107968
    allocate arena 3 1 37130
    fill arena 3 0 37130 1 37130 false 1 13842939354630062080 4613937818241073152
    allocate arena 4 1 37160
    fill arena 4 0 37160 1 37160 false 1 13842939354630062080 4613937818241073152
    allocate arena 5 1 64913
    fill arena 5 0 64913 1 64913 false 1 13842939354630062080 4613937818241073152
    pack3 arena 0 16 24 1280 26 false 3 64 768 40 773 false 24 40 32
    VastitasGemmNative.gemm arena 3 64 768 40 773 false false 1 32 40 48 43 false false 4 80 768 48 774 false 0
    regroup3 arena 4 80 768 48 774 false 3 112 1152 32 1160 false 24 32 48 48 42
    VastitasGemmNative.gemm arena 3 112 1152 32 1160 false false 2 48 32 56 36 false false 5 96 1152 56 1159 false 0
    expect arena 5 96 1152 56 1159 false 0 0 1 13855852019186663425 13847480337652776960
    expect arena 5 96 1152 56 1159 false 23 55 1 13856569450523787264 13847183469513277440
    expect arena 5 96 1152 56 1159 false 1151 0 1 13855506772535541760 13844008079932260352
    drop arena 5
    drop arena 4
    drop arena 3
    drop arena 2
    drop arena 1
    drop arena 0
    pure ()
  catch cleanupError =>
    close arena
    throw cleanupError
  close arena

@[extern "audit_mark_lean"] opaque auditMark (phase : UInt32) : IO Unit

def main (args : List String) : IO Unit := do
  let impl := args[0]!
  let scope := args[1]!.toNat!
  let reps := args[2]!.toNat!
  let verify := args[3]! == "1"
  auditMark 1
  generatedOnce
  auditMark 2
  if impl == "failure" then
    benchBegin 0 1 true
    let caught ← try
      generatedFailure
      pure false
    catch error =>
      if error.toString != "E_NATIVE_EXPECT: stored bit pattern differs" then throw error
      pure true
    if !caught then throw (IO.userError "expected injected native failure")
    benchStop
  else if impl == "c" then
    benchCRun scope.toUInt32 reps.toUInt64 verify
  else if scope == 0 then
    benchBegin 0 reps.toUInt64 verify
    for _ in [:reps] do generatedOnce
    benchStop
  else
    let arena ← newArena 9223372036854775807
    try
      allocate arena 0 1 33284
      fill arena 0 0 33284 1 33284 false 1 13842939354630062080 4613937818241073152
      fill arena 0 16 24 1280 26 false 1 4593671619917905920 4598175219545276416
      store arena 0 16 24 1280 26 false 0 0 1 4607182418800017408 13826050856027422720
      store arena 0 16 24 1280 26 false 23 1 1 13826050856027422720 4604930618986332160
      allocate arena 1 1 2069
      fill arena 1 0 2069 1 2069 false 1 13842939354630062080 4613937818241073152
      fill arena 1 32 40 48 43 false 1 13821547256400052224 4593671619917905920
      store arena 1 32 40 48 43 false 0 47 1 4602678819172646912 4598175219545276416
      store arena 1 32 40 48 43 false 39 0 1 13828302655841107968 13826050856027422720
      allocate arena 2 1 2022
      fill arena 2 0 2022 1 2022 false 1 13842939354630062080 4613937818241073152
      fill arena 2 48 32 56 36 false 1 4602678819172646912 13821547256400052224
      store arena 2 48 32 56 36 false 31 0 1 13821547256400052224 4602678819172646912
      store arena 2 48 32 56 36 false 0 55 1 4604930618986332160 13828302655841107968
      allocate arena 3 1 37130
      fill arena 3 0 37130 1 37130 false 1 13842939354630062080 4613937818241073152
      allocate arena 4 1 37160
      fill arena 4 0 37160 1 37160 false 1 13842939354630062080 4613937818241073152
      allocate arena 5 1 64913
      fill arena 5 0 64913 1 64913 false 1 13842939354630062080 4613937818241073152
      benchBegin scope.toUInt32 reps.toUInt64 verify
      for _ in [:reps] do
        pack3 arena 0 16 24 1280 26 false 3 64 768 40 773 false 24 40 32
        VastitasGemmNative.gemm arena 3 64 768 40 773 false false 1 32 40 48 43 false false 4 80 768 48 774 false 0
        regroup3 arena 4 80 768 48 774 false 3 112 1152 32 1160 false 24 32 48 48 42
        VastitasGemmNative.gemm arena 3 112 1152 32 1160 false false 2 48 32 56 36 false false 5 96 1152 56 1159 false 0
      benchStop
      benchVerify arena reps.toUInt64
      expect arena 5 96 1152 56 1159 false 0 0 1 13855852019186663424 13847480337652776960
      expect arena 5 96 1152 56 1159 false 23 55 1 13856569450523787264 13847183469513277440
      expect arena 5 96 1152 56 1159 false 1151 0 1 13855506772535541760 13844008079932260352
      drop arena 5
      drop arena 4
      drop arena 3
      drop arena 2
      drop arena 1
      drop arena 0
    catch cleanupError =>
      close arena
      throw cleanupError
    close arena
  benchReport
