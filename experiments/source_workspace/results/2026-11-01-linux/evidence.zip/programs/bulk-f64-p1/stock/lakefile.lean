import Lake
open Lake DSL
package allocation_audit where
  moreLinkArgs := #["-fno-lto", "-L", "/home/runner/.elan/toolchains/leanprover--lean4---v4.35.0/lib"]
require vastitas_kernel from "/home/runner/work/Vastitas/Vastitas/lean-kernel"
require vastitas_gemm_native from "./numerical" with
  NameMap.empty.insert `openblas "/home/runner/work/_temp/workspace-build/stock"
lean_exe audit where
  root := `Main
  moreLeancArgs := #["-O3", "-fno-lto", "-DAUDIT_GENERATED_MAIN=1", "-include", "/home/runner/work/_temp/source-workspace-record/programs/bulk-f64-p1/stock/native/audit.h"]
