#!/opt/homebrew/opt/python@3.15/bin/python3.15
import json, pathlib, sys
pathlib.Path('/private/tmp/vastitas-source-allocator-f0e0c55/programs/bulk-complex-p0/diagnostic-stock/package/wire.json').write_text(sys.stdin.read())
print(json.dumps({"version":8,"ok":False,"diagnostics":[{"code":"E_CAPTURED","message":"capture only"}]}))
sys.exit(1)
