import Lake
open Lake DSL
package allocation_audit where
  moreLinkArgs := #["-fno-lto", "-L/private/tmp/vastitas-lean-diagnostic-54531c1/build/diagnostic2", "-Wl,-map,/private/tmp/vastitas-source-allocator-f0e0c55/programs/bulk-complex-p1/stock-diagnostic2/link.map", "-L", "/Users/masa/.elan/toolchains/leanprover--lean4---v4.35.0/lib"]
require vastitas_kernel from "/private/tmp/vastitas-runtime-shapes/lean-kernel"
require vastitas_gemm_native from "./numerical" with
  NameMap.empty.insert `openblas "/private/tmp/vastitas-workspace-build-605a5a7/stock"
lean_exe audit where
  root := `Main
  moreLeancArgs := #["-O3", "-fno-lto", "-DAUDIT_GENERATED_MAIN=1", "-include", "/private/tmp/vastitas-source-allocator-f0e0c55/programs/bulk-complex-p1/stock-diagnostic2/native/audit.h"]
