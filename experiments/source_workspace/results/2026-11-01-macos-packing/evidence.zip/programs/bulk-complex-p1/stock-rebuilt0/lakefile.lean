import Lake
open Lake DSL
package allocation_audit where
  moreLinkArgs := #["-fno-lto", "-L/private/tmp/vastitas-lean-diagnostic-54531c1/build/rebuilt0", "-Wl,-map,/private/tmp/vastitas-source-packing-full-20261101a/programs/bulk-complex-p1/stock-rebuilt0/link.map", "-L", "/Users/masa/.elan/toolchains/leanprover--lean4---v4.35.0/lib"]
require vastitas_kernel from "/private/tmp/vastitas-runtime-shapes/lean-kernel"
require vastitas_gemm_native from "./numerical" with
  NameMap.empty.insert `openblas "/private/tmp/vastitas-packing-build-20261101b/stock"
lean_exe audit where
  root := `Main
  moreLeancArgs := #["-O3", "-fno-lto", "-DAUDIT_GENERATED_MAIN=1", "-include", "/private/tmp/vastitas-source-packing-full-20261101a/programs/bulk-complex-p1/stock-rebuilt0/native/audit.h"]
