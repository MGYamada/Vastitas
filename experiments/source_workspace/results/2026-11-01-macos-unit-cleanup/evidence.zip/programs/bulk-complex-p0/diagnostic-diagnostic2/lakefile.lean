import Lake
open Lake DSL
package allocation_audit where
  moreLinkArgs := #["-fno-lto", "-L/Users/runner/work/_temp/lean-allocator-record/build/diagnostic2", "-Wl,-map,/Users/runner/work/_temp/source-workspace-record/programs/bulk-complex-p0/diagnostic-diagnostic2/link.map", "-L", "/Users/runner/.elan/toolchains/leanprover--lean4---v4.35.0/lib"]
require vastitas_kernel from "/Users/runner/work/Vastitas/Vastitas/lean-kernel"
require vastitas_gemm_native from "./numerical" with
  NameMap.empty.insert `openblas "/Users/runner/work/_temp/workspace-build/diagnostic"
lean_exe audit where
  root := `Main
  moreLeancArgs := #["-O3", "-fno-lto", "-DAUDIT_GENERATED_MAIN=1", "-include", "/Users/runner/work/_temp/source-workspace-record/programs/bulk-complex-p0/diagnostic-diagnostic2/native/audit.h"]
