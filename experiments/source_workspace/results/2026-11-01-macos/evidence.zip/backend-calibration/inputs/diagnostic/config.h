#define OS_DARWIN	1
#define ARCH_ARM64	1
#define C_CLANG	1
#define __64BIT__	1
#define FUNDERSCORE	_
#define HAVE_C11	1
#define PTHREAD_CREATE_FUNC	pthread_create
#define BUNDERSCORE	_
#define NEEDBUNDERSCORE	1
#define ARMV8
#define HAVE_NEON
#define HAVE_VFPV4
#define VORTEXM4		      
#define HAVE_SME 1		      
#define L1_CODE_SIZE	     1867590060       
#define L1_CODE_LINESIZE     1867590060       
#define L1_DATA_LINESIZE     1867590060       
#define L1_DATA_SIZE	     1867590060       
#define L2_SIZE	     1867590060       
#define DTB_DEFAULT_ENTRIES  64       
#define DTB_SIZE             4096     
#define NUM_CORES 10
#define NUM_CORES_LP 6
#define NUM_CORES_HP 4
#define CHAR_CORENAME "VORTEXM4"
#define GEMM_MULTITHREAD_THRESHOLD	4
