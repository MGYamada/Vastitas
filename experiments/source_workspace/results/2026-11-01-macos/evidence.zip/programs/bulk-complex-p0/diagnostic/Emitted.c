// Lean compiler output
// Module: Main
// Imports: public import Init public meta import Init public import VastitasStorageNative public import VastitasGemmNative public import VastitasKernel.IndexedRuntime
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* vastitas_storage_new(uint64_t);
lean_object* vastitas_storage_close(lean_object*);
lean_object* vastitas_storage_allocate(lean_object*, uint32_t, uint8_t, uint64_t);
lean_object* vastitas_storage_fill(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_store(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_pack3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_gemm_execute(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t);
lean_object* vastitas_storage_regroup3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_storage_expect(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_drop(lean_object*, uint32_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_List_get_x21Internal___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_String_Slice_toNat_x21(lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
uint32_t lean_uint32_of_nat(lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
lean_object* lean_io_error_to_string(lean_object*);
static lean_once_cell_t lp_allocation__audit_VastitasGenerated_f__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_allocation__audit_VastitasGenerated_f__0___closed__0;
LEAN_EXPORT lean_object* lp_allocation__audit_VastitasGenerated_f__0;
lean_object* bench_begin_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_stop_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object*);
lean_object* bench_report_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object*);
lean_object* bench_c_run_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_verify_lean(lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object*);
lean_object* audit_mark_lean(uint32_t);
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_allocation__audit_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 1, .m_capacity = 1, .m_length = 0, .m_data = ""};
static const lean_object* lp_allocation__audit_main___closed__0 = (const lean_object*)&lp_allocation__audit_main___closed__0_value;
static const lean_string_object lp_allocation__audit_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "1"};
static const lean_object* lp_allocation__audit_main___closed__1 = (const lean_object*)&lp_allocation__audit_main___closed__1_value;
static const lean_string_object lp_allocation__audit_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "failure"};
static const lean_object* lp_allocation__audit_main___closed__2 = (const lean_object*)&lp_allocation__audit_main___closed__2_value;
static const lean_string_object lp_allocation__audit_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "c"};
static const lean_object* lp_allocation__audit_main___closed__3 = (const lean_object*)&lp_allocation__audit_main___closed__3_value;
static const lean_string_object lp_allocation__audit_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "expected injected native failure"};
static const lean_object* lp_allocation__audit_main___closed__4 = (const lean_object*)&lp_allocation__audit_main___closed__4_value;
static const lean_ctor_object lp_allocation__audit_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_allocation__audit_main___closed__4_value)}};
static const lean_object* lp_allocation__audit_main___closed__5 = (const lean_object*)&lp_allocation__audit_main___closed__5_value;
static const lean_string_object lp_allocation__audit_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 44, .m_capacity = 44, .m_length = 43, .m_data = "E_NATIVE_EXPECT: stored bit pattern differs"};
static const lean_object* lp_allocation__audit_main___closed__6 = (const lean_object*)&lp_allocation__audit_main___closed__6_value;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(0u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0(void){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_obj_once(&lp_allocation__audit_VastitasGenerated_f__0___closed__0, &lp_allocation__audit_VastitasGenerated_f__0___closed__0_once, _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object* v_scope_8_, lean_object* v_reps_9_, lean_object* v_verify_10_, lean_object* v_a_00___x40___internal___hyg_11_){
_start:
{
uint32_t v_scope_boxed_12_; uint64_t v_reps_boxed_13_; uint8_t v_verify_boxed_14_; lean_object* v_res_15_; 
v_scope_boxed_12_ = lean_unbox_uint32(v_scope_8_);
lean_dec(v_scope_8_);
v_reps_boxed_13_ = lean_unbox_uint64(v_reps_9_);
lean_dec_ref(v_reps_9_);
v_verify_boxed_14_ = lean_unbox(v_verify_10_);
v_res_15_ = bench_begin_lean(v_scope_boxed_12_, v_reps_boxed_13_, v_verify_boxed_14_);
return v_res_15_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object* v_a_00___x40___internal___hyg_17_){
_start:
{
lean_object* v_res_18_; 
v_res_18_ = bench_stop_lean();
return v_res_18_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object* v_a_00___x40___internal___hyg_20_){
_start:
{
lean_object* v_res_21_; 
v_res_21_ = bench_report_lean();
return v_res_21_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object* v_scope_26_, lean_object* v_reps_27_, lean_object* v_verify_28_, lean_object* v_a_00___x40___internal___hyg_29_){
_start:
{
uint32_t v_scope_boxed_30_; uint64_t v_reps_boxed_31_; uint8_t v_verify_boxed_32_; lean_object* v_res_33_; 
v_scope_boxed_30_ = lean_unbox_uint32(v_scope_26_);
lean_dec(v_scope_26_);
v_reps_boxed_31_ = lean_unbox_uint64(v_reps_27_);
lean_dec_ref(v_reps_27_);
v_verify_boxed_32_ = lean_unbox(v_verify_28_);
v_res_33_ = bench_c_run_lean(v_scope_boxed_30_, v_reps_boxed_31_, v_verify_boxed_32_);
return v_res_33_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object* v_arena_37_, lean_object* v_reps_38_, lean_object* v_a_00___x40___internal___hyg_39_){
_start:
{
uint64_t v_reps_boxed_40_; lean_object* v_res_41_; 
v_reps_boxed_40_ = lean_unbox_uint64(v_reps_38_);
lean_dec_ref(v_reps_38_);
v_res_41_ = bench_verify_lean(v_arena_37_, v_reps_boxed_40_);
lean_dec(v_arena_37_);
return v_res_41_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce(){
_start:
{
uint64_t v___x_43_; lean_object* v___x_44_; 
v___x_43_ = 9223372036854775807ULL;
v___x_44_ = vastitas_storage_new(v___x_43_);
if (lean_obj_tag(v___x_44_) == 0)
{
lean_object* v_a_45_; lean_object* v_a_47_; lean_object* v___y_58_; uint32_t v___x_70_; uint8_t v___x_71_; uint64_t v___x_72_; lean_object* v___x_73_; 
v_a_45_ = lean_ctor_get(v___x_44_, 0);
lean_inc(v_a_45_);
lean_dec_ref_known(v___x_44_, 1);
v___x_70_ = 0;
v___x_71_ = 1;
v___x_72_ = 30720ULL;
v___x_73_ = vastitas_storage_allocate(v_a_45_, v___x_70_, v___x_71_, v___x_72_);
if (lean_obj_tag(v___x_73_) == 0)
{
uint64_t v___x_74_; uint64_t v___x_75_; uint8_t v___x_76_; uint64_t v___x_77_; uint64_t v___x_78_; lean_object* v___x_79_; 
lean_dec_ref_known(v___x_73_, 1);
v___x_74_ = 0ULL;
v___x_75_ = 1ULL;
v___x_76_ = 0;
v___x_77_ = 13842939354630062080ULL;
v___x_78_ = 4613937818241073152ULL;
v___x_79_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_74_, v___x_72_, v___x_75_, v___x_72_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_79_) == 0)
{
uint64_t v___x_80_; uint64_t v___x_81_; uint64_t v___x_82_; uint64_t v___x_83_; lean_object* v___x_84_; 
lean_dec_ref_known(v___x_79_, 1);
v___x_80_ = 24ULL;
v___x_81_ = 1280ULL;
v___x_82_ = 4593671619917905920ULL;
v___x_83_ = 4598175219545276416ULL;
v___x_84_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_74_, v___x_80_, v___x_81_, v___x_80_, v___x_76_, v___x_71_, v___x_82_, v___x_83_);
if (lean_obj_tag(v___x_84_) == 0)
{
uint64_t v___x_85_; uint64_t v___x_86_; lean_object* v___x_87_; 
lean_dec_ref_known(v___x_84_, 1);
v___x_85_ = 4607182418800017408ULL;
v___x_86_ = 13826050856027422720ULL;
v___x_87_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_74_, v___x_80_, v___x_81_, v___x_80_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_85_, v___x_86_);
if (lean_obj_tag(v___x_87_) == 0)
{
uint64_t v___x_88_; uint64_t v___x_89_; lean_object* v___x_90_; 
lean_dec_ref_known(v___x_87_, 1);
v___x_88_ = 23ULL;
v___x_89_ = 4604930618986332160ULL;
v___x_90_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_74_, v___x_80_, v___x_81_, v___x_80_, v___x_76_, v___x_88_, v___x_75_, v___x_71_, v___x_86_, v___x_89_);
if (lean_obj_tag(v___x_90_) == 0)
{
uint32_t v___x_91_; uint64_t v___x_92_; lean_object* v___x_93_; 
lean_dec_ref_known(v___x_90_, 1);
v___x_91_ = 1;
v___x_92_ = 1920ULL;
v___x_93_ = vastitas_storage_allocate(v_a_45_, v___x_91_, v___x_71_, v___x_92_);
if (lean_obj_tag(v___x_93_) == 0)
{
lean_object* v___x_94_; 
lean_dec_ref_known(v___x_93_, 1);
v___x_94_ = vastitas_storage_fill(v_a_45_, v___x_91_, v___x_74_, v___x_92_, v___x_75_, v___x_92_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_94_) == 0)
{
uint64_t v___x_95_; uint64_t v___x_96_; uint64_t v___x_97_; lean_object* v___x_98_; 
lean_dec_ref_known(v___x_94_, 1);
v___x_95_ = 40ULL;
v___x_96_ = 48ULL;
v___x_97_ = 13821547256400052224ULL;
v___x_98_ = vastitas_storage_fill(v_a_45_, v___x_91_, v___x_74_, v___x_95_, v___x_96_, v___x_95_, v___x_76_, v___x_71_, v___x_97_, v___x_82_);
if (lean_obj_tag(v___x_98_) == 0)
{
uint64_t v___x_99_; uint64_t v___x_100_; lean_object* v___x_101_; 
lean_dec_ref_known(v___x_98_, 1);
v___x_99_ = 47ULL;
v___x_100_ = 4602678819172646912ULL;
v___x_101_ = vastitas_storage_store(v_a_45_, v___x_91_, v___x_74_, v___x_95_, v___x_96_, v___x_95_, v___x_76_, v___x_74_, v___x_99_, v___x_71_, v___x_100_, v___x_83_);
if (lean_obj_tag(v___x_101_) == 0)
{
uint64_t v___x_102_; uint64_t v___x_103_; lean_object* v___x_104_; 
lean_dec_ref_known(v___x_101_, 1);
v___x_102_ = 39ULL;
v___x_103_ = 13828302655841107968ULL;
v___x_104_ = vastitas_storage_store(v_a_45_, v___x_91_, v___x_74_, v___x_95_, v___x_96_, v___x_95_, v___x_76_, v___x_102_, v___x_74_, v___x_71_, v___x_103_, v___x_86_);
if (lean_obj_tag(v___x_104_) == 0)
{
uint32_t v___x_105_; uint64_t v___x_106_; lean_object* v___x_107_; 
lean_dec_ref_known(v___x_104_, 1);
v___x_105_ = 2;
v___x_106_ = 1792ULL;
v___x_107_ = vastitas_storage_allocate(v_a_45_, v___x_105_, v___x_71_, v___x_106_);
if (lean_obj_tag(v___x_107_) == 0)
{
lean_object* v___x_108_; 
lean_dec_ref_known(v___x_107_, 1);
v___x_108_ = vastitas_storage_fill(v_a_45_, v___x_105_, v___x_74_, v___x_106_, v___x_75_, v___x_106_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_108_) == 0)
{
uint64_t v___x_109_; uint64_t v___x_110_; lean_object* v___x_111_; 
lean_dec_ref_known(v___x_108_, 1);
v___x_109_ = 32ULL;
v___x_110_ = 56ULL;
v___x_111_ = vastitas_storage_fill(v_a_45_, v___x_105_, v___x_74_, v___x_109_, v___x_110_, v___x_109_, v___x_76_, v___x_71_, v___x_100_, v___x_97_);
if (lean_obj_tag(v___x_111_) == 0)
{
uint64_t v___x_112_; lean_object* v___x_113_; 
lean_dec_ref_known(v___x_111_, 1);
v___x_112_ = 31ULL;
v___x_113_ = vastitas_storage_store(v_a_45_, v___x_105_, v___x_74_, v___x_109_, v___x_110_, v___x_109_, v___x_76_, v___x_112_, v___x_74_, v___x_71_, v___x_97_, v___x_100_);
if (lean_obj_tag(v___x_113_) == 0)
{
uint64_t v___x_114_; lean_object* v___x_115_; 
lean_dec_ref_known(v___x_113_, 1);
v___x_114_ = 55ULL;
v___x_115_ = vastitas_storage_store(v_a_45_, v___x_105_, v___x_74_, v___x_109_, v___x_110_, v___x_109_, v___x_76_, v___x_74_, v___x_114_, v___x_71_, v___x_89_, v___x_103_);
if (lean_obj_tag(v___x_115_) == 0)
{
uint32_t v___x_116_; uint64_t v___x_117_; lean_object* v___x_118_; 
lean_dec_ref_known(v___x_115_, 1);
v___x_116_ = 3;
v___x_117_ = 36864ULL;
v___x_118_ = vastitas_storage_allocate(v_a_45_, v___x_116_, v___x_71_, v___x_117_);
if (lean_obj_tag(v___x_118_) == 0)
{
lean_object* v___x_119_; 
lean_dec_ref_known(v___x_118_, 1);
v___x_119_ = vastitas_storage_fill(v_a_45_, v___x_116_, v___x_74_, v___x_117_, v___x_75_, v___x_117_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_119_) == 0)
{
uint32_t v___x_120_; lean_object* v___x_121_; 
lean_dec_ref_known(v___x_119_, 1);
v___x_120_ = 4;
v___x_121_ = vastitas_storage_allocate(v_a_45_, v___x_120_, v___x_71_, v___x_117_);
if (lean_obj_tag(v___x_121_) == 0)
{
lean_object* v___x_122_; 
lean_dec_ref_known(v___x_121_, 1);
v___x_122_ = vastitas_storage_fill(v_a_45_, v___x_120_, v___x_74_, v___x_117_, v___x_75_, v___x_117_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_122_) == 0)
{
uint32_t v___x_123_; uint64_t v___x_124_; lean_object* v___x_125_; 
lean_dec_ref_known(v___x_122_, 1);
v___x_123_ = 5;
v___x_124_ = 64512ULL;
v___x_125_ = vastitas_storage_allocate(v_a_45_, v___x_123_, v___x_71_, v___x_124_);
if (lean_obj_tag(v___x_125_) == 0)
{
lean_object* v___x_126_; 
lean_dec_ref_known(v___x_125_, 1);
v___x_126_ = vastitas_storage_fill(v_a_45_, v___x_123_, v___x_74_, v___x_124_, v___x_75_, v___x_124_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_126_) == 0)
{
uint64_t v___x_127_; lean_object* v___x_128_; 
lean_dec_ref_known(v___x_126_, 1);
v___x_127_ = 768ULL;
v___x_128_ = vastitas_storage_pack3(v_a_45_, v___x_70_, v___x_74_, v___x_80_, v___x_81_, v___x_80_, v___x_76_, v___x_116_, v___x_74_, v___x_127_, v___x_95_, v___x_127_, v___x_76_, v___x_80_, v___x_95_, v___x_109_);
if (lean_obj_tag(v___x_128_) == 0)
{
uint8_t v___x_129_; lean_object* v___x_130_; 
lean_dec_ref_known(v___x_128_, 1);
v___x_129_ = 0;
v___x_130_ = vastitas_gemm_execute(v_a_45_, v___x_116_, v___x_74_, v___x_127_, v___x_95_, v___x_127_, v___x_76_, v___x_76_, v___x_91_, v___x_74_, v___x_95_, v___x_96_, v___x_95_, v___x_76_, v___x_76_, v___x_120_, v___x_74_, v___x_127_, v___x_96_, v___x_127_, v___x_76_, v___x_129_);
if (lean_obj_tag(v___x_130_) == 0)
{
uint64_t v___x_131_; uint64_t v___x_132_; lean_object* v___x_133_; 
lean_dec_ref_known(v___x_130_, 1);
v___x_131_ = 1152ULL;
v___x_132_ = 42ULL;
v___x_133_ = vastitas_storage_regroup3(v_a_45_, v___x_120_, v___x_74_, v___x_127_, v___x_96_, v___x_127_, v___x_76_, v___x_116_, v___x_74_, v___x_131_, v___x_109_, v___x_131_, v___x_76_, v___x_80_, v___x_109_, v___x_96_, v___x_96_, v___x_132_);
if (lean_obj_tag(v___x_133_) == 0)
{
lean_object* v___x_134_; 
lean_dec_ref_known(v___x_133_, 1);
v___x_134_ = vastitas_gemm_execute(v_a_45_, v___x_116_, v___x_74_, v___x_131_, v___x_109_, v___x_131_, v___x_76_, v___x_76_, v___x_105_, v___x_74_, v___x_109_, v___x_110_, v___x_109_, v___x_76_, v___x_76_, v___x_123_, v___x_74_, v___x_131_, v___x_110_, v___x_131_, v___x_76_, v___x_129_);
if (lean_obj_tag(v___x_134_) == 0)
{
uint64_t v___x_135_; uint64_t v___x_136_; lean_object* v___x_137_; 
lean_dec_ref_known(v___x_134_, 1);
v___x_135_ = 13855852019186663424ULL;
v___x_136_ = 13847480337652776960ULL;
v___x_137_ = vastitas_storage_expect(v_a_45_, v___x_123_, v___x_74_, v___x_131_, v___x_110_, v___x_131_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_135_, v___x_136_);
if (lean_obj_tag(v___x_137_) == 0)
{
uint64_t v___x_138_; uint64_t v___x_139_; lean_object* v___x_140_; 
lean_dec_ref_known(v___x_137_, 1);
v___x_138_ = 13856569450523787264ULL;
v___x_139_ = 13847183469513277440ULL;
v___x_140_ = vastitas_storage_expect(v_a_45_, v___x_123_, v___x_74_, v___x_131_, v___x_110_, v___x_131_, v___x_76_, v___x_88_, v___x_114_, v___x_71_, v___x_138_, v___x_139_);
if (lean_obj_tag(v___x_140_) == 0)
{
uint64_t v___x_141_; uint64_t v___x_142_; uint64_t v___x_143_; lean_object* v___x_144_; 
lean_dec_ref_known(v___x_140_, 1);
v___x_141_ = 1151ULL;
v___x_142_ = 13855506772535541760ULL;
v___x_143_ = 13844008079932260352ULL;
v___x_144_ = vastitas_storage_expect(v_a_45_, v___x_123_, v___x_74_, v___x_131_, v___x_110_, v___x_131_, v___x_76_, v___x_141_, v___x_74_, v___x_71_, v___x_142_, v___x_143_);
if (lean_obj_tag(v___x_144_) == 0)
{
lean_object* v___x_145_; 
lean_dec_ref_known(v___x_144_, 1);
v___x_145_ = vastitas_storage_drop(v_a_45_, v___x_123_);
if (lean_obj_tag(v___x_145_) == 0)
{
lean_object* v___x_146_; 
lean_dec_ref_known(v___x_145_, 1);
v___x_146_ = vastitas_storage_drop(v_a_45_, v___x_120_);
if (lean_obj_tag(v___x_146_) == 0)
{
lean_object* v___x_147_; 
lean_dec_ref_known(v___x_146_, 1);
v___x_147_ = vastitas_storage_drop(v_a_45_, v___x_116_);
if (lean_obj_tag(v___x_147_) == 0)
{
lean_object* v___x_148_; 
lean_dec_ref_known(v___x_147_, 1);
v___x_148_ = vastitas_storage_drop(v_a_45_, v___x_105_);
if (lean_obj_tag(v___x_148_) == 0)
{
lean_object* v___x_149_; 
lean_dec_ref_known(v___x_148_, 1);
v___x_149_ = vastitas_storage_drop(v_a_45_, v___x_91_);
if (lean_obj_tag(v___x_149_) == 0)
{
lean_object* v___x_150_; 
lean_dec_ref_known(v___x_149_, 1);
v___x_150_ = vastitas_storage_drop(v_a_45_, v___x_70_);
if (lean_obj_tag(v___x_150_) == 0)
{
lean_object* v___x_151_; 
lean_dec_ref_known(v___x_150_, 1);
v___x_151_ = lean_box(0);
v_a_47_ = v___x_151_;
goto v___jp_46_;
}
else
{
v___y_58_ = v___x_150_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_149_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_148_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_147_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_146_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_145_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_144_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_140_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_137_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_134_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_133_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_130_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_128_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_126_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_125_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_122_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_121_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_119_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_118_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_115_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_113_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_111_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_108_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_107_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_104_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_101_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_98_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_94_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_93_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_90_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_87_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_84_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_79_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_73_;
goto v___jp_57_;
}
v___jp_46_:
{
lean_object* v___x_48_; 
v___x_48_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_48_) == 0)
{
lean_object* v___x_50_; uint8_t v_isShared_51_; uint8_t v_isSharedCheck_55_; 
v_isSharedCheck_55_ = !lean_is_exclusive(v___x_48_);
if (v_isSharedCheck_55_ == 0)
{
lean_object* v_unused_56_; 
v_unused_56_ = lean_ctor_get(v___x_48_, 0);
lean_dec(v_unused_56_);
v___x_50_ = v___x_48_;
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
else
{
lean_dec(v___x_48_);
v___x_50_ = lean_box(0);
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
v_resetjp_49_:
{
lean_object* v___x_53_; 
if (v_isShared_51_ == 0)
{
lean_ctor_set(v___x_50_, 0, v_a_47_);
v___x_53_ = v___x_50_;
goto v_reusejp_52_;
}
else
{
lean_object* v_reuseFailAlloc_54_; 
v_reuseFailAlloc_54_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_54_, 0, v_a_47_);
v___x_53_ = v_reuseFailAlloc_54_;
goto v_reusejp_52_;
}
v_reusejp_52_:
{
return v___x_53_;
}
}
}
else
{
return v___x_48_;
}
}
v___jp_57_:
{
if (lean_obj_tag(v___y_58_) == 0)
{
lean_object* v_a_59_; 
v_a_59_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_59_);
lean_dec_ref_known(v___y_58_, 1);
v_a_47_ = v_a_59_;
goto v___jp_46_;
}
else
{
lean_object* v_a_60_; lean_object* v___x_61_; 
v_a_60_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_60_);
lean_dec_ref_known(v___y_58_, 1);
v___x_61_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_61_) == 0)
{
lean_object* v___x_63_; uint8_t v_isShared_64_; uint8_t v_isSharedCheck_68_; 
v_isSharedCheck_68_ = !lean_is_exclusive(v___x_61_);
if (v_isSharedCheck_68_ == 0)
{
lean_object* v_unused_69_; 
v_unused_69_ = lean_ctor_get(v___x_61_, 0);
lean_dec(v_unused_69_);
v___x_63_ = v___x_61_;
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
else
{
lean_dec(v___x_61_);
v___x_63_ = lean_box(0);
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
v_resetjp_62_:
{
lean_object* v___x_66_; 
if (v_isShared_64_ == 0)
{
lean_ctor_set_tag(v___x_63_, 1);
lean_ctor_set(v___x_63_, 0, v_a_60_);
v___x_66_ = v___x_63_;
goto v_reusejp_65_;
}
else
{
lean_object* v_reuseFailAlloc_67_; 
v_reuseFailAlloc_67_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_67_, 0, v_a_60_);
v___x_66_ = v_reuseFailAlloc_67_;
goto v_reusejp_65_;
}
v_reusejp_65_:
{
return v___x_66_;
}
}
}
else
{
lean_dec(v_a_60_);
return v___x_61_;
}
}
}
}
else
{
lean_object* v_a_152_; lean_object* v___x_154_; uint8_t v_isShared_155_; uint8_t v_isSharedCheck_159_; 
v_a_152_ = lean_ctor_get(v___x_44_, 0);
v_isSharedCheck_159_ = !lean_is_exclusive(v___x_44_);
if (v_isSharedCheck_159_ == 0)
{
v___x_154_ = v___x_44_;
v_isShared_155_ = v_isSharedCheck_159_;
goto v_resetjp_153_;
}
else
{
lean_inc(v_a_152_);
lean_dec(v___x_44_);
v___x_154_ = lean_box(0);
v_isShared_155_ = v_isSharedCheck_159_;
goto v_resetjp_153_;
}
v_resetjp_153_:
{
lean_object* v___x_157_; 
if (v_isShared_155_ == 0)
{
v___x_157_ = v___x_154_;
goto v_reusejp_156_;
}
else
{
lean_object* v_reuseFailAlloc_158_; 
v_reuseFailAlloc_158_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_158_, 0, v_a_152_);
v___x_157_ = v_reuseFailAlloc_158_;
goto v_reusejp_156_;
}
v_reusejp_156_:
{
return v___x_157_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object* v_a_160_){
_start:
{
lean_object* v_res_161_; 
v_res_161_ = lp_allocation__audit_generatedOnce();
return v_res_161_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure(){
_start:
{
uint64_t v___x_163_; lean_object* v___x_164_; 
v___x_163_ = 9223372036854775807ULL;
v___x_164_ = vastitas_storage_new(v___x_163_);
if (lean_obj_tag(v___x_164_) == 0)
{
lean_object* v_a_165_; lean_object* v_a_167_; lean_object* v___y_178_; uint32_t v___x_190_; uint8_t v___x_191_; uint64_t v___x_192_; lean_object* v___x_193_; 
v_a_165_ = lean_ctor_get(v___x_164_, 0);
lean_inc(v_a_165_);
lean_dec_ref_known(v___x_164_, 1);
v___x_190_ = 0;
v___x_191_ = 1;
v___x_192_ = 30720ULL;
v___x_193_ = vastitas_storage_allocate(v_a_165_, v___x_190_, v___x_191_, v___x_192_);
if (lean_obj_tag(v___x_193_) == 0)
{
uint64_t v___x_194_; uint64_t v___x_195_; uint8_t v___x_196_; uint64_t v___x_197_; uint64_t v___x_198_; lean_object* v___x_199_; 
lean_dec_ref_known(v___x_193_, 1);
v___x_194_ = 0ULL;
v___x_195_ = 1ULL;
v___x_196_ = 0;
v___x_197_ = 13842939354630062080ULL;
v___x_198_ = 4613937818241073152ULL;
v___x_199_ = vastitas_storage_fill(v_a_165_, v___x_190_, v___x_194_, v___x_192_, v___x_195_, v___x_192_, v___x_196_, v___x_191_, v___x_197_, v___x_198_);
if (lean_obj_tag(v___x_199_) == 0)
{
uint64_t v___x_200_; uint64_t v___x_201_; uint64_t v___x_202_; uint64_t v___x_203_; lean_object* v___x_204_; 
lean_dec_ref_known(v___x_199_, 1);
v___x_200_ = 24ULL;
v___x_201_ = 1280ULL;
v___x_202_ = 4593671619917905920ULL;
v___x_203_ = 4598175219545276416ULL;
v___x_204_ = vastitas_storage_fill(v_a_165_, v___x_190_, v___x_194_, v___x_200_, v___x_201_, v___x_200_, v___x_196_, v___x_191_, v___x_202_, v___x_203_);
if (lean_obj_tag(v___x_204_) == 0)
{
uint64_t v___x_205_; uint64_t v___x_206_; lean_object* v___x_207_; 
lean_dec_ref_known(v___x_204_, 1);
v___x_205_ = 4607182418800017408ULL;
v___x_206_ = 13826050856027422720ULL;
v___x_207_ = vastitas_storage_store(v_a_165_, v___x_190_, v___x_194_, v___x_200_, v___x_201_, v___x_200_, v___x_196_, v___x_194_, v___x_194_, v___x_191_, v___x_205_, v___x_206_);
if (lean_obj_tag(v___x_207_) == 0)
{
uint64_t v___x_208_; uint64_t v___x_209_; lean_object* v___x_210_; 
lean_dec_ref_known(v___x_207_, 1);
v___x_208_ = 23ULL;
v___x_209_ = 4604930618986332160ULL;
v___x_210_ = vastitas_storage_store(v_a_165_, v___x_190_, v___x_194_, v___x_200_, v___x_201_, v___x_200_, v___x_196_, v___x_208_, v___x_195_, v___x_191_, v___x_206_, v___x_209_);
if (lean_obj_tag(v___x_210_) == 0)
{
uint32_t v___x_211_; uint64_t v___x_212_; lean_object* v___x_213_; 
lean_dec_ref_known(v___x_210_, 1);
v___x_211_ = 1;
v___x_212_ = 1920ULL;
v___x_213_ = vastitas_storage_allocate(v_a_165_, v___x_211_, v___x_191_, v___x_212_);
if (lean_obj_tag(v___x_213_) == 0)
{
lean_object* v___x_214_; 
lean_dec_ref_known(v___x_213_, 1);
v___x_214_ = vastitas_storage_fill(v_a_165_, v___x_211_, v___x_194_, v___x_212_, v___x_195_, v___x_212_, v___x_196_, v___x_191_, v___x_197_, v___x_198_);
if (lean_obj_tag(v___x_214_) == 0)
{
uint64_t v___x_215_; uint64_t v___x_216_; uint64_t v___x_217_; lean_object* v___x_218_; 
lean_dec_ref_known(v___x_214_, 1);
v___x_215_ = 40ULL;
v___x_216_ = 48ULL;
v___x_217_ = 13821547256400052224ULL;
v___x_218_ = vastitas_storage_fill(v_a_165_, v___x_211_, v___x_194_, v___x_215_, v___x_216_, v___x_215_, v___x_196_, v___x_191_, v___x_217_, v___x_202_);
if (lean_obj_tag(v___x_218_) == 0)
{
uint64_t v___x_219_; uint64_t v___x_220_; lean_object* v___x_221_; 
lean_dec_ref_known(v___x_218_, 1);
v___x_219_ = 47ULL;
v___x_220_ = 4602678819172646912ULL;
v___x_221_ = vastitas_storage_store(v_a_165_, v___x_211_, v___x_194_, v___x_215_, v___x_216_, v___x_215_, v___x_196_, v___x_194_, v___x_219_, v___x_191_, v___x_220_, v___x_203_);
if (lean_obj_tag(v___x_221_) == 0)
{
uint64_t v___x_222_; uint64_t v___x_223_; lean_object* v___x_224_; 
lean_dec_ref_known(v___x_221_, 1);
v___x_222_ = 39ULL;
v___x_223_ = 13828302655841107968ULL;
v___x_224_ = vastitas_storage_store(v_a_165_, v___x_211_, v___x_194_, v___x_215_, v___x_216_, v___x_215_, v___x_196_, v___x_222_, v___x_194_, v___x_191_, v___x_223_, v___x_206_);
if (lean_obj_tag(v___x_224_) == 0)
{
uint32_t v___x_225_; uint64_t v___x_226_; lean_object* v___x_227_; 
lean_dec_ref_known(v___x_224_, 1);
v___x_225_ = 2;
v___x_226_ = 1792ULL;
v___x_227_ = vastitas_storage_allocate(v_a_165_, v___x_225_, v___x_191_, v___x_226_);
if (lean_obj_tag(v___x_227_) == 0)
{
lean_object* v___x_228_; 
lean_dec_ref_known(v___x_227_, 1);
v___x_228_ = vastitas_storage_fill(v_a_165_, v___x_225_, v___x_194_, v___x_226_, v___x_195_, v___x_226_, v___x_196_, v___x_191_, v___x_197_, v___x_198_);
if (lean_obj_tag(v___x_228_) == 0)
{
uint64_t v___x_229_; uint64_t v___x_230_; lean_object* v___x_231_; 
lean_dec_ref_known(v___x_228_, 1);
v___x_229_ = 32ULL;
v___x_230_ = 56ULL;
v___x_231_ = vastitas_storage_fill(v_a_165_, v___x_225_, v___x_194_, v___x_229_, v___x_230_, v___x_229_, v___x_196_, v___x_191_, v___x_220_, v___x_217_);
if (lean_obj_tag(v___x_231_) == 0)
{
uint64_t v___x_232_; lean_object* v___x_233_; 
lean_dec_ref_known(v___x_231_, 1);
v___x_232_ = 31ULL;
v___x_233_ = vastitas_storage_store(v_a_165_, v___x_225_, v___x_194_, v___x_229_, v___x_230_, v___x_229_, v___x_196_, v___x_232_, v___x_194_, v___x_191_, v___x_217_, v___x_220_);
if (lean_obj_tag(v___x_233_) == 0)
{
uint64_t v___x_234_; lean_object* v___x_235_; 
lean_dec_ref_known(v___x_233_, 1);
v___x_234_ = 55ULL;
v___x_235_ = vastitas_storage_store(v_a_165_, v___x_225_, v___x_194_, v___x_229_, v___x_230_, v___x_229_, v___x_196_, v___x_194_, v___x_234_, v___x_191_, v___x_209_, v___x_223_);
if (lean_obj_tag(v___x_235_) == 0)
{
uint32_t v___x_236_; uint64_t v___x_237_; lean_object* v___x_238_; 
lean_dec_ref_known(v___x_235_, 1);
v___x_236_ = 3;
v___x_237_ = 36864ULL;
v___x_238_ = vastitas_storage_allocate(v_a_165_, v___x_236_, v___x_191_, v___x_237_);
if (lean_obj_tag(v___x_238_) == 0)
{
lean_object* v___x_239_; 
lean_dec_ref_known(v___x_238_, 1);
v___x_239_ = vastitas_storage_fill(v_a_165_, v___x_236_, v___x_194_, v___x_237_, v___x_195_, v___x_237_, v___x_196_, v___x_191_, v___x_197_, v___x_198_);
if (lean_obj_tag(v___x_239_) == 0)
{
uint32_t v___x_240_; lean_object* v___x_241_; 
lean_dec_ref_known(v___x_239_, 1);
v___x_240_ = 4;
v___x_241_ = vastitas_storage_allocate(v_a_165_, v___x_240_, v___x_191_, v___x_237_);
if (lean_obj_tag(v___x_241_) == 0)
{
lean_object* v___x_242_; 
lean_dec_ref_known(v___x_241_, 1);
v___x_242_ = vastitas_storage_fill(v_a_165_, v___x_240_, v___x_194_, v___x_237_, v___x_195_, v___x_237_, v___x_196_, v___x_191_, v___x_197_, v___x_198_);
if (lean_obj_tag(v___x_242_) == 0)
{
uint32_t v___x_243_; uint64_t v___x_244_; lean_object* v___x_245_; 
lean_dec_ref_known(v___x_242_, 1);
v___x_243_ = 5;
v___x_244_ = 64512ULL;
v___x_245_ = vastitas_storage_allocate(v_a_165_, v___x_243_, v___x_191_, v___x_244_);
if (lean_obj_tag(v___x_245_) == 0)
{
lean_object* v___x_246_; 
lean_dec_ref_known(v___x_245_, 1);
v___x_246_ = vastitas_storage_fill(v_a_165_, v___x_243_, v___x_194_, v___x_244_, v___x_195_, v___x_244_, v___x_196_, v___x_191_, v___x_197_, v___x_198_);
if (lean_obj_tag(v___x_246_) == 0)
{
uint64_t v___x_247_; lean_object* v___x_248_; 
lean_dec_ref_known(v___x_246_, 1);
v___x_247_ = 768ULL;
v___x_248_ = vastitas_storage_pack3(v_a_165_, v___x_190_, v___x_194_, v___x_200_, v___x_201_, v___x_200_, v___x_196_, v___x_236_, v___x_194_, v___x_247_, v___x_215_, v___x_247_, v___x_196_, v___x_200_, v___x_215_, v___x_229_);
if (lean_obj_tag(v___x_248_) == 0)
{
uint8_t v___x_249_; lean_object* v___x_250_; 
lean_dec_ref_known(v___x_248_, 1);
v___x_249_ = 0;
v___x_250_ = vastitas_gemm_execute(v_a_165_, v___x_236_, v___x_194_, v___x_247_, v___x_215_, v___x_247_, v___x_196_, v___x_196_, v___x_211_, v___x_194_, v___x_215_, v___x_216_, v___x_215_, v___x_196_, v___x_196_, v___x_240_, v___x_194_, v___x_247_, v___x_216_, v___x_247_, v___x_196_, v___x_249_);
if (lean_obj_tag(v___x_250_) == 0)
{
uint64_t v___x_251_; uint64_t v___x_252_; lean_object* v___x_253_; 
lean_dec_ref_known(v___x_250_, 1);
v___x_251_ = 1152ULL;
v___x_252_ = 42ULL;
v___x_253_ = vastitas_storage_regroup3(v_a_165_, v___x_240_, v___x_194_, v___x_247_, v___x_216_, v___x_247_, v___x_196_, v___x_236_, v___x_194_, v___x_251_, v___x_229_, v___x_251_, v___x_196_, v___x_200_, v___x_229_, v___x_216_, v___x_216_, v___x_252_);
if (lean_obj_tag(v___x_253_) == 0)
{
lean_object* v___x_254_; 
lean_dec_ref_known(v___x_253_, 1);
v___x_254_ = vastitas_gemm_execute(v_a_165_, v___x_236_, v___x_194_, v___x_251_, v___x_229_, v___x_251_, v___x_196_, v___x_196_, v___x_225_, v___x_194_, v___x_229_, v___x_230_, v___x_229_, v___x_196_, v___x_196_, v___x_243_, v___x_194_, v___x_251_, v___x_230_, v___x_251_, v___x_196_, v___x_249_);
if (lean_obj_tag(v___x_254_) == 0)
{
uint64_t v___x_255_; uint64_t v___x_256_; lean_object* v___x_257_; 
lean_dec_ref_known(v___x_254_, 1);
v___x_255_ = 13855852019186663425ULL;
v___x_256_ = 13847480337652776960ULL;
v___x_257_ = vastitas_storage_expect(v_a_165_, v___x_243_, v___x_194_, v___x_251_, v___x_230_, v___x_251_, v___x_196_, v___x_194_, v___x_194_, v___x_191_, v___x_255_, v___x_256_);
if (lean_obj_tag(v___x_257_) == 0)
{
uint64_t v___x_258_; uint64_t v___x_259_; lean_object* v___x_260_; 
lean_dec_ref_known(v___x_257_, 1);
v___x_258_ = 13856569450523787264ULL;
v___x_259_ = 13847183469513277440ULL;
v___x_260_ = vastitas_storage_expect(v_a_165_, v___x_243_, v___x_194_, v___x_251_, v___x_230_, v___x_251_, v___x_196_, v___x_208_, v___x_234_, v___x_191_, v___x_258_, v___x_259_);
if (lean_obj_tag(v___x_260_) == 0)
{
uint64_t v___x_261_; uint64_t v___x_262_; uint64_t v___x_263_; lean_object* v___x_264_; 
lean_dec_ref_known(v___x_260_, 1);
v___x_261_ = 1151ULL;
v___x_262_ = 13855506772535541760ULL;
v___x_263_ = 13844008079932260352ULL;
v___x_264_ = vastitas_storage_expect(v_a_165_, v___x_243_, v___x_194_, v___x_251_, v___x_230_, v___x_251_, v___x_196_, v___x_261_, v___x_194_, v___x_191_, v___x_262_, v___x_263_);
if (lean_obj_tag(v___x_264_) == 0)
{
lean_object* v___x_265_; 
lean_dec_ref_known(v___x_264_, 1);
v___x_265_ = vastitas_storage_drop(v_a_165_, v___x_243_);
if (lean_obj_tag(v___x_265_) == 0)
{
lean_object* v___x_266_; 
lean_dec_ref_known(v___x_265_, 1);
v___x_266_ = vastitas_storage_drop(v_a_165_, v___x_240_);
if (lean_obj_tag(v___x_266_) == 0)
{
lean_object* v___x_267_; 
lean_dec_ref_known(v___x_266_, 1);
v___x_267_ = vastitas_storage_drop(v_a_165_, v___x_236_);
if (lean_obj_tag(v___x_267_) == 0)
{
lean_object* v___x_268_; 
lean_dec_ref_known(v___x_267_, 1);
v___x_268_ = vastitas_storage_drop(v_a_165_, v___x_225_);
if (lean_obj_tag(v___x_268_) == 0)
{
lean_object* v___x_269_; 
lean_dec_ref_known(v___x_268_, 1);
v___x_269_ = vastitas_storage_drop(v_a_165_, v___x_211_);
if (lean_obj_tag(v___x_269_) == 0)
{
lean_object* v___x_270_; 
lean_dec_ref_known(v___x_269_, 1);
v___x_270_ = vastitas_storage_drop(v_a_165_, v___x_190_);
if (lean_obj_tag(v___x_270_) == 0)
{
lean_object* v___x_271_; 
lean_dec_ref_known(v___x_270_, 1);
v___x_271_ = lean_box(0);
v_a_167_ = v___x_271_;
goto v___jp_166_;
}
else
{
v___y_178_ = v___x_270_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_269_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_268_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_267_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_266_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_265_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_264_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_260_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_257_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_254_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_253_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_250_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_248_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_246_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_245_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_242_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_241_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_239_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_238_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_235_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_233_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_231_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_228_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_227_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_224_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_221_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_218_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_214_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_213_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_210_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_207_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_204_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_199_;
goto v___jp_177_;
}
}
else
{
v___y_178_ = v___x_193_;
goto v___jp_177_;
}
v___jp_166_:
{
lean_object* v___x_168_; 
v___x_168_ = vastitas_storage_close(v_a_165_);
lean_dec(v_a_165_);
if (lean_obj_tag(v___x_168_) == 0)
{
lean_object* v___x_170_; uint8_t v_isShared_171_; uint8_t v_isSharedCheck_175_; 
v_isSharedCheck_175_ = !lean_is_exclusive(v___x_168_);
if (v_isSharedCheck_175_ == 0)
{
lean_object* v_unused_176_; 
v_unused_176_ = lean_ctor_get(v___x_168_, 0);
lean_dec(v_unused_176_);
v___x_170_ = v___x_168_;
v_isShared_171_ = v_isSharedCheck_175_;
goto v_resetjp_169_;
}
else
{
lean_dec(v___x_168_);
v___x_170_ = lean_box(0);
v_isShared_171_ = v_isSharedCheck_175_;
goto v_resetjp_169_;
}
v_resetjp_169_:
{
lean_object* v___x_173_; 
if (v_isShared_171_ == 0)
{
lean_ctor_set(v___x_170_, 0, v_a_167_);
v___x_173_ = v___x_170_;
goto v_reusejp_172_;
}
else
{
lean_object* v_reuseFailAlloc_174_; 
v_reuseFailAlloc_174_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_174_, 0, v_a_167_);
v___x_173_ = v_reuseFailAlloc_174_;
goto v_reusejp_172_;
}
v_reusejp_172_:
{
return v___x_173_;
}
}
}
else
{
return v___x_168_;
}
}
v___jp_177_:
{
if (lean_obj_tag(v___y_178_) == 0)
{
lean_object* v_a_179_; 
v_a_179_ = lean_ctor_get(v___y_178_, 0);
lean_inc(v_a_179_);
lean_dec_ref_known(v___y_178_, 1);
v_a_167_ = v_a_179_;
goto v___jp_166_;
}
else
{
lean_object* v_a_180_; lean_object* v___x_181_; 
v_a_180_ = lean_ctor_get(v___y_178_, 0);
lean_inc(v_a_180_);
lean_dec_ref_known(v___y_178_, 1);
v___x_181_ = vastitas_storage_close(v_a_165_);
lean_dec(v_a_165_);
if (lean_obj_tag(v___x_181_) == 0)
{
lean_object* v___x_183_; uint8_t v_isShared_184_; uint8_t v_isSharedCheck_188_; 
v_isSharedCheck_188_ = !lean_is_exclusive(v___x_181_);
if (v_isSharedCheck_188_ == 0)
{
lean_object* v_unused_189_; 
v_unused_189_ = lean_ctor_get(v___x_181_, 0);
lean_dec(v_unused_189_);
v___x_183_ = v___x_181_;
v_isShared_184_ = v_isSharedCheck_188_;
goto v_resetjp_182_;
}
else
{
lean_dec(v___x_181_);
v___x_183_ = lean_box(0);
v_isShared_184_ = v_isSharedCheck_188_;
goto v_resetjp_182_;
}
v_resetjp_182_:
{
lean_object* v___x_186_; 
if (v_isShared_184_ == 0)
{
lean_ctor_set_tag(v___x_183_, 1);
lean_ctor_set(v___x_183_, 0, v_a_180_);
v___x_186_ = v___x_183_;
goto v_reusejp_185_;
}
else
{
lean_object* v_reuseFailAlloc_187_; 
v_reuseFailAlloc_187_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_187_, 0, v_a_180_);
v___x_186_ = v_reuseFailAlloc_187_;
goto v_reusejp_185_;
}
v_reusejp_185_:
{
return v___x_186_;
}
}
}
else
{
lean_dec(v_a_180_);
return v___x_181_;
}
}
}
}
else
{
lean_object* v_a_272_; lean_object* v___x_274_; uint8_t v_isShared_275_; uint8_t v_isSharedCheck_279_; 
v_a_272_ = lean_ctor_get(v___x_164_, 0);
v_isSharedCheck_279_ = !lean_is_exclusive(v___x_164_);
if (v_isSharedCheck_279_ == 0)
{
v___x_274_ = v___x_164_;
v_isShared_275_ = v_isSharedCheck_279_;
goto v_resetjp_273_;
}
else
{
lean_inc(v_a_272_);
lean_dec(v___x_164_);
v___x_274_ = lean_box(0);
v_isShared_275_ = v_isSharedCheck_279_;
goto v_resetjp_273_;
}
v_resetjp_273_:
{
lean_object* v___x_277_; 
if (v_isShared_275_ == 0)
{
v___x_277_ = v___x_274_;
goto v_reusejp_276_;
}
else
{
lean_object* v_reuseFailAlloc_278_; 
v_reuseFailAlloc_278_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_278_, 0, v_a_272_);
v___x_277_ = v_reuseFailAlloc_278_;
goto v_reusejp_276_;
}
v_reusejp_276_:
{
return v___x_277_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object* v_a_280_){
_start:
{
lean_object* v_res_281_; 
v_res_281_ = lp_allocation__audit_generatedFailure();
return v_res_281_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object* v_phase_284_, lean_object* v_a_00___x40___internal___hyg_285_){
_start:
{
uint32_t v_phase_boxed_286_; lean_object* v_res_287_; 
v_phase_boxed_286_ = lean_unbox_uint32(v_phase_284_);
lean_dec(v_phase_284_);
v_res_287_ = audit_mark_lean(v_phase_boxed_286_);
return v_res_287_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object* v_a_288_, lean_object* v_scope_289_, lean_object* v_range_290_, lean_object* v_b_291_, lean_object* v_i_292_){
_start:
{
lean_object* v_stop_294_; lean_object* v_step_295_; uint8_t v___x_296_; 
v_stop_294_ = lean_ctor_get(v_range_290_, 1);
v_step_295_ = lean_ctor_get(v_range_290_, 2);
v___x_296_ = lean_nat_dec_lt(v_i_292_, v_stop_294_);
if (v___x_296_ == 0)
{
lean_object* v___x_297_; 
lean_dec(v_i_292_);
v___x_297_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_297_, 0, v_b_291_);
return v___x_297_;
}
else
{
uint32_t v___x_298_; uint64_t v___x_299_; uint64_t v___x_300_; uint64_t v___x_301_; lean_object* v___x_302_; uint8_t v___x_303_; uint32_t v___x_304_; uint64_t v___x_305_; uint64_t v___x_306_; uint32_t v___x_307_; uint64_t v___x_308_; uint32_t v___x_309_; uint32_t v___x_310_; uint64_t v___x_311_; uint32_t v___x_312_; lean_object* v___x_313_; uint64_t v___x_314_; lean_object* v___x_315_; 
v___x_298_ = 0;
v___x_299_ = 0ULL;
v___x_300_ = 24ULL;
v___x_301_ = 1280ULL;
v___x_302_ = lean_unsigned_to_nat(0u);
v___x_303_ = lean_nat_dec_eq(v_scope_289_, v___x_302_);
v___x_304_ = 3;
v___x_305_ = 40ULL;
v___x_306_ = 32ULL;
v___x_307_ = 1;
v___x_308_ = 48ULL;
v___x_309_ = 4;
v___x_310_ = 2;
v___x_311_ = 56ULL;
v___x_312_ = 5;
v___x_313_ = lean_box(0);
v___x_314_ = 768ULL;
v___x_315_ = vastitas_storage_pack3(v_a_288_, v___x_298_, v___x_299_, v___x_300_, v___x_301_, v___x_300_, v___x_303_, v___x_304_, v___x_299_, v___x_314_, v___x_305_, v___x_314_, v___x_303_, v___x_300_, v___x_305_, v___x_306_);
if (lean_obj_tag(v___x_315_) == 0)
{
uint8_t v___x_316_; lean_object* v___x_317_; 
lean_dec_ref_known(v___x_315_, 1);
v___x_316_ = 0;
v___x_317_ = vastitas_gemm_execute(v_a_288_, v___x_304_, v___x_299_, v___x_314_, v___x_305_, v___x_314_, v___x_303_, v___x_303_, v___x_307_, v___x_299_, v___x_305_, v___x_308_, v___x_305_, v___x_303_, v___x_303_, v___x_309_, v___x_299_, v___x_314_, v___x_308_, v___x_314_, v___x_303_, v___x_316_);
if (lean_obj_tag(v___x_317_) == 0)
{
uint64_t v___x_318_; uint64_t v___x_319_; lean_object* v___x_320_; 
lean_dec_ref_known(v___x_317_, 1);
v___x_318_ = 1152ULL;
v___x_319_ = 42ULL;
v___x_320_ = vastitas_storage_regroup3(v_a_288_, v___x_309_, v___x_299_, v___x_314_, v___x_308_, v___x_314_, v___x_303_, v___x_304_, v___x_299_, v___x_318_, v___x_306_, v___x_318_, v___x_303_, v___x_300_, v___x_306_, v___x_308_, v___x_308_, v___x_319_);
if (lean_obj_tag(v___x_320_) == 0)
{
lean_object* v___x_321_; 
lean_dec_ref_known(v___x_320_, 1);
v___x_321_ = vastitas_gemm_execute(v_a_288_, v___x_304_, v___x_299_, v___x_318_, v___x_306_, v___x_318_, v___x_303_, v___x_303_, v___x_310_, v___x_299_, v___x_306_, v___x_311_, v___x_306_, v___x_303_, v___x_303_, v___x_312_, v___x_299_, v___x_318_, v___x_311_, v___x_318_, v___x_303_, v___x_316_);
if (lean_obj_tag(v___x_321_) == 0)
{
lean_object* v___x_322_; 
lean_dec_ref_known(v___x_321_, 1);
v___x_322_ = lean_nat_add(v_i_292_, v_step_295_);
lean_dec(v_i_292_);
v_b_291_ = v___x_313_;
v_i_292_ = v___x_322_;
goto _start;
}
else
{
lean_dec(v_i_292_);
return v___x_321_;
}
}
else
{
lean_dec(v_i_292_);
return v___x_320_;
}
}
else
{
lean_dec(v_i_292_);
return v___x_317_;
}
}
else
{
lean_dec(v_i_292_);
return v___x_315_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object* v_a_324_, lean_object* v_scope_325_, lean_object* v_range_326_, lean_object* v_b_327_, lean_object* v_i_328_, lean_object* v___y_329_){
_start:
{
lean_object* v_res_330_; 
v_res_330_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_324_, v_scope_325_, v_range_326_, v_b_327_, v_i_328_);
lean_dec_ref(v_range_326_);
lean_dec(v_scope_325_);
lean_dec(v_a_324_);
return v_res_330_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object* v_range_331_, lean_object* v_b_332_, lean_object* v_i_333_){
_start:
{
lean_object* v_stop_335_; lean_object* v_step_336_; uint8_t v___x_337_; 
v_stop_335_ = lean_ctor_get(v_range_331_, 1);
v_step_336_ = lean_ctor_get(v_range_331_, 2);
v___x_337_ = lean_nat_dec_lt(v_i_333_, v_stop_335_);
if (v___x_337_ == 0)
{
lean_object* v___x_338_; 
lean_dec(v_i_333_);
v___x_338_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_338_, 0, v_b_332_);
return v___x_338_;
}
else
{
lean_object* v___x_339_; lean_object* v___x_340_; 
v___x_339_ = lean_box(0);
v___x_340_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_340_) == 0)
{
lean_object* v___x_341_; 
lean_dec_ref_known(v___x_340_, 1);
v___x_341_ = lean_nat_add(v_i_333_, v_step_336_);
lean_dec(v_i_333_);
v_b_332_ = v___x_339_;
v_i_333_ = v___x_341_;
goto _start;
}
else
{
lean_dec(v_i_333_);
return v___x_340_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object* v_range_343_, lean_object* v_b_344_, lean_object* v_i_345_, lean_object* v___y_346_){
_start:
{
lean_object* v_res_347_; 
v_res_347_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_343_, v_b_344_, v_i_345_);
lean_dec_ref(v_range_343_);
return v_res_347_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_356_){
_start:
{
lean_object* v___x_358_; lean_object* v___x_359_; lean_object* v_impl_360_; lean_object* v___x_361_; lean_object* v___x_362_; lean_object* v___x_363_; lean_object* v___x_364_; lean_object* v_scope_365_; lean_object* v___x_366_; lean_object* v___x_367_; lean_object* v___x_368_; lean_object* v___x_369_; lean_object* v_reps_370_; lean_object* v___x_371_; lean_object* v___x_372_; lean_object* v___x_373_; uint8_t v_verify_374_; uint32_t v___x_375_; lean_object* v___x_376_; 
v___x_358_ = ((lean_object*)(lp_allocation__audit_main___closed__0));
v___x_359_ = lean_unsigned_to_nat(0u);
v_impl_360_ = l_List_get_x21Internal___redArg(v___x_358_, v_args_356_, v___x_359_);
v___x_361_ = lean_unsigned_to_nat(1u);
v___x_362_ = l_List_get_x21Internal___redArg(v___x_358_, v_args_356_, v___x_361_);
v___x_363_ = lean_string_utf8_byte_size(v___x_362_);
v___x_364_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_364_, 0, v___x_362_);
lean_ctor_set(v___x_364_, 1, v___x_359_);
lean_ctor_set(v___x_364_, 2, v___x_363_);
v_scope_365_ = l_String_Slice_toNat_x21(v___x_364_);
lean_dec_ref_known(v___x_364_, 3);
v___x_366_ = lean_unsigned_to_nat(2u);
v___x_367_ = l_List_get_x21Internal___redArg(v___x_358_, v_args_356_, v___x_366_);
v___x_368_ = lean_string_utf8_byte_size(v___x_367_);
v___x_369_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_369_, 0, v___x_367_);
lean_ctor_set(v___x_369_, 1, v___x_359_);
lean_ctor_set(v___x_369_, 2, v___x_368_);
v_reps_370_ = l_String_Slice_toNat_x21(v___x_369_);
lean_dec_ref_known(v___x_369_, 3);
v___x_371_ = lean_unsigned_to_nat(3u);
v___x_372_ = l_List_get_x21Internal___redArg(v___x_358_, v_args_356_, v___x_371_);
lean_dec(v_args_356_);
v___x_373_ = ((lean_object*)(lp_allocation__audit_main___closed__1));
v_verify_374_ = lean_string_dec_eq(v___x_372_, v___x_373_);
lean_dec(v___x_372_);
v___x_375_ = 1;
v___x_376_ = audit_mark_lean(v___x_375_);
if (lean_obj_tag(v___x_376_) == 0)
{
lean_object* v___x_377_; 
lean_dec_ref_known(v___x_376_, 1);
v___x_377_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_377_) == 0)
{
uint32_t v___x_378_; lean_object* v___x_379_; 
lean_dec_ref_known(v___x_377_, 1);
v___x_378_ = 2;
v___x_379_ = audit_mark_lean(v___x_378_);
if (lean_obj_tag(v___x_379_) == 0)
{
lean_object* v___x_380_; uint8_t v___x_381_; 
lean_dec_ref_known(v___x_379_, 1);
v___x_380_ = ((lean_object*)(lp_allocation__audit_main___closed__2));
v___x_381_ = lean_string_dec_eq(v_impl_360_, v___x_380_);
if (v___x_381_ == 0)
{
lean_object* v___x_382_; uint8_t v___x_383_; 
v___x_382_ = ((lean_object*)(lp_allocation__audit_main___closed__3));
v___x_383_ = lean_string_dec_eq(v_impl_360_, v___x_382_);
lean_dec(v_impl_360_);
if (v___x_383_ == 0)
{
uint8_t v___x_384_; 
v___x_384_ = lean_nat_dec_eq(v_scope_365_, v___x_359_);
if (v___x_384_ == 0)
{
uint64_t v___x_385_; lean_object* v___x_386_; 
v___x_385_ = 9223372036854775807ULL;
v___x_386_ = vastitas_storage_new(v___x_385_);
if (lean_obj_tag(v___x_386_) == 0)
{
lean_object* v_a_387_; lean_object* v___y_389_; uint32_t v___x_402_; uint8_t v___x_403_; uint64_t v___x_404_; lean_object* v___x_405_; 
v_a_387_ = lean_ctor_get(v___x_386_, 0);
lean_inc(v_a_387_);
lean_dec_ref_known(v___x_386_, 1);
v___x_402_ = 0;
v___x_403_ = 1;
v___x_404_ = 30720ULL;
v___x_405_ = vastitas_storage_allocate(v_a_387_, v___x_402_, v___x_403_, v___x_404_);
if (lean_obj_tag(v___x_405_) == 0)
{
uint64_t v___x_406_; uint64_t v___x_407_; uint64_t v___x_408_; uint64_t v___x_409_; lean_object* v___x_410_; 
lean_dec_ref_known(v___x_405_, 1);
v___x_406_ = 0ULL;
v___x_407_ = 1ULL;
v___x_408_ = 13842939354630062080ULL;
v___x_409_ = 4613937818241073152ULL;
v___x_410_ = vastitas_storage_fill(v_a_387_, v___x_402_, v___x_406_, v___x_404_, v___x_407_, v___x_404_, v___x_384_, v___x_403_, v___x_408_, v___x_409_);
if (lean_obj_tag(v___x_410_) == 0)
{
uint64_t v___x_411_; uint64_t v___x_412_; uint64_t v___x_413_; uint64_t v___x_414_; lean_object* v___x_415_; 
lean_dec_ref_known(v___x_410_, 1);
v___x_411_ = 24ULL;
v___x_412_ = 1280ULL;
v___x_413_ = 4593671619917905920ULL;
v___x_414_ = 4598175219545276416ULL;
v___x_415_ = vastitas_storage_fill(v_a_387_, v___x_402_, v___x_406_, v___x_411_, v___x_412_, v___x_411_, v___x_384_, v___x_403_, v___x_413_, v___x_414_);
if (lean_obj_tag(v___x_415_) == 0)
{
uint64_t v___x_416_; uint64_t v___x_417_; lean_object* v___x_418_; 
lean_dec_ref_known(v___x_415_, 1);
v___x_416_ = 4607182418800017408ULL;
v___x_417_ = 13826050856027422720ULL;
v___x_418_ = vastitas_storage_store(v_a_387_, v___x_402_, v___x_406_, v___x_411_, v___x_412_, v___x_411_, v___x_384_, v___x_406_, v___x_406_, v___x_403_, v___x_416_, v___x_417_);
if (lean_obj_tag(v___x_418_) == 0)
{
uint64_t v___x_419_; uint64_t v___x_420_; lean_object* v___x_421_; 
lean_dec_ref_known(v___x_418_, 1);
v___x_419_ = 23ULL;
v___x_420_ = 4604930618986332160ULL;
v___x_421_ = vastitas_storage_store(v_a_387_, v___x_402_, v___x_406_, v___x_411_, v___x_412_, v___x_411_, v___x_384_, v___x_419_, v___x_407_, v___x_403_, v___x_417_, v___x_420_);
if (lean_obj_tag(v___x_421_) == 0)
{
uint64_t v___x_422_; lean_object* v___x_423_; 
lean_dec_ref_known(v___x_421_, 1);
v___x_422_ = 1920ULL;
v___x_423_ = vastitas_storage_allocate(v_a_387_, v___x_375_, v___x_403_, v___x_422_);
if (lean_obj_tag(v___x_423_) == 0)
{
lean_object* v___x_424_; 
lean_dec_ref_known(v___x_423_, 1);
v___x_424_ = vastitas_storage_fill(v_a_387_, v___x_375_, v___x_406_, v___x_422_, v___x_407_, v___x_422_, v___x_384_, v___x_403_, v___x_408_, v___x_409_);
if (lean_obj_tag(v___x_424_) == 0)
{
uint64_t v___x_425_; uint64_t v___x_426_; uint64_t v___x_427_; lean_object* v___x_428_; 
lean_dec_ref_known(v___x_424_, 1);
v___x_425_ = 40ULL;
v___x_426_ = 48ULL;
v___x_427_ = 13821547256400052224ULL;
v___x_428_ = vastitas_storage_fill(v_a_387_, v___x_375_, v___x_406_, v___x_425_, v___x_426_, v___x_425_, v___x_384_, v___x_403_, v___x_427_, v___x_413_);
if (lean_obj_tag(v___x_428_) == 0)
{
uint64_t v___x_429_; uint64_t v___x_430_; lean_object* v___x_431_; 
lean_dec_ref_known(v___x_428_, 1);
v___x_429_ = 47ULL;
v___x_430_ = 4602678819172646912ULL;
v___x_431_ = vastitas_storage_store(v_a_387_, v___x_375_, v___x_406_, v___x_425_, v___x_426_, v___x_425_, v___x_384_, v___x_406_, v___x_429_, v___x_403_, v___x_430_, v___x_414_);
if (lean_obj_tag(v___x_431_) == 0)
{
uint64_t v___x_432_; uint64_t v___x_433_; lean_object* v___x_434_; 
lean_dec_ref_known(v___x_431_, 1);
v___x_432_ = 39ULL;
v___x_433_ = 13828302655841107968ULL;
v___x_434_ = vastitas_storage_store(v_a_387_, v___x_375_, v___x_406_, v___x_425_, v___x_426_, v___x_425_, v___x_384_, v___x_432_, v___x_406_, v___x_403_, v___x_433_, v___x_417_);
if (lean_obj_tag(v___x_434_) == 0)
{
uint64_t v___x_435_; lean_object* v___x_436_; 
lean_dec_ref_known(v___x_434_, 1);
v___x_435_ = 1792ULL;
v___x_436_ = vastitas_storage_allocate(v_a_387_, v___x_378_, v___x_403_, v___x_435_);
if (lean_obj_tag(v___x_436_) == 0)
{
lean_object* v___x_437_; 
lean_dec_ref_known(v___x_436_, 1);
v___x_437_ = vastitas_storage_fill(v_a_387_, v___x_378_, v___x_406_, v___x_435_, v___x_407_, v___x_435_, v___x_384_, v___x_403_, v___x_408_, v___x_409_);
if (lean_obj_tag(v___x_437_) == 0)
{
uint64_t v___x_438_; uint64_t v___x_439_; lean_object* v___x_440_; 
lean_dec_ref_known(v___x_437_, 1);
v___x_438_ = 32ULL;
v___x_439_ = 56ULL;
v___x_440_ = vastitas_storage_fill(v_a_387_, v___x_378_, v___x_406_, v___x_438_, v___x_439_, v___x_438_, v___x_384_, v___x_403_, v___x_430_, v___x_427_);
if (lean_obj_tag(v___x_440_) == 0)
{
uint64_t v___x_441_; lean_object* v___x_442_; 
lean_dec_ref_known(v___x_440_, 1);
v___x_441_ = 31ULL;
v___x_442_ = vastitas_storage_store(v_a_387_, v___x_378_, v___x_406_, v___x_438_, v___x_439_, v___x_438_, v___x_384_, v___x_441_, v___x_406_, v___x_403_, v___x_427_, v___x_430_);
if (lean_obj_tag(v___x_442_) == 0)
{
uint64_t v___x_443_; lean_object* v___x_444_; 
lean_dec_ref_known(v___x_442_, 1);
v___x_443_ = 55ULL;
v___x_444_ = vastitas_storage_store(v_a_387_, v___x_378_, v___x_406_, v___x_438_, v___x_439_, v___x_438_, v___x_384_, v___x_406_, v___x_443_, v___x_403_, v___x_420_, v___x_433_);
if (lean_obj_tag(v___x_444_) == 0)
{
uint32_t v___x_445_; uint64_t v___x_446_; lean_object* v___x_447_; 
lean_dec_ref_known(v___x_444_, 1);
v___x_445_ = 3;
v___x_446_ = 36864ULL;
v___x_447_ = vastitas_storage_allocate(v_a_387_, v___x_445_, v___x_403_, v___x_446_);
if (lean_obj_tag(v___x_447_) == 0)
{
lean_object* v___x_448_; 
lean_dec_ref_known(v___x_447_, 1);
v___x_448_ = vastitas_storage_fill(v_a_387_, v___x_445_, v___x_406_, v___x_446_, v___x_407_, v___x_446_, v___x_384_, v___x_403_, v___x_408_, v___x_409_);
if (lean_obj_tag(v___x_448_) == 0)
{
uint32_t v___x_449_; lean_object* v___x_450_; 
lean_dec_ref_known(v___x_448_, 1);
v___x_449_ = 4;
v___x_450_ = vastitas_storage_allocate(v_a_387_, v___x_449_, v___x_403_, v___x_446_);
if (lean_obj_tag(v___x_450_) == 0)
{
lean_object* v___x_451_; 
lean_dec_ref_known(v___x_450_, 1);
v___x_451_ = vastitas_storage_fill(v_a_387_, v___x_449_, v___x_406_, v___x_446_, v___x_407_, v___x_446_, v___x_384_, v___x_403_, v___x_408_, v___x_409_);
if (lean_obj_tag(v___x_451_) == 0)
{
uint32_t v___x_452_; uint64_t v___x_453_; lean_object* v___x_454_; 
lean_dec_ref_known(v___x_451_, 1);
v___x_452_ = 5;
v___x_453_ = 64512ULL;
v___x_454_ = vastitas_storage_allocate(v_a_387_, v___x_452_, v___x_403_, v___x_453_);
if (lean_obj_tag(v___x_454_) == 0)
{
lean_object* v___x_455_; 
lean_dec_ref_known(v___x_454_, 1);
v___x_455_ = vastitas_storage_fill(v_a_387_, v___x_452_, v___x_406_, v___x_453_, v___x_407_, v___x_453_, v___x_384_, v___x_403_, v___x_408_, v___x_409_);
if (lean_obj_tag(v___x_455_) == 0)
{
uint32_t v___x_456_; uint64_t v___x_457_; lean_object* v___x_458_; 
lean_dec_ref_known(v___x_455_, 1);
v___x_456_ = lean_uint32_of_nat(v_scope_365_);
v___x_457_ = lean_uint64_of_nat(v_reps_370_);
v___x_458_ = bench_begin_lean(v___x_456_, v___x_457_, v_verify_374_);
if (lean_obj_tag(v___x_458_) == 0)
{
lean_object* v___x_459_; lean_object* v___x_460_; lean_object* v___x_461_; 
lean_dec_ref_known(v___x_458_, 1);
v___x_459_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_459_, 0, v___x_359_);
lean_ctor_set(v___x_459_, 1, v_reps_370_);
lean_ctor_set(v___x_459_, 2, v___x_361_);
v___x_460_ = lean_box(0);
v___x_461_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_387_, v_scope_365_, v___x_459_, v___x_460_, v___x_359_);
lean_dec_ref_known(v___x_459_, 3);
lean_dec(v_scope_365_);
if (lean_obj_tag(v___x_461_) == 0)
{
lean_object* v___x_462_; 
lean_dec_ref_known(v___x_461_, 1);
v___x_462_ = bench_stop_lean();
if (lean_obj_tag(v___x_462_) == 0)
{
lean_object* v___x_463_; 
lean_dec_ref_known(v___x_462_, 1);
v___x_463_ = bench_verify_lean(v_a_387_, v___x_457_);
if (lean_obj_tag(v___x_463_) == 0)
{
uint64_t v___x_464_; uint64_t v___x_465_; uint64_t v___x_466_; lean_object* v___x_467_; 
lean_dec_ref_known(v___x_463_, 1);
v___x_464_ = 1152ULL;
v___x_465_ = 13855852019186663424ULL;
v___x_466_ = 13847480337652776960ULL;
v___x_467_ = vastitas_storage_expect(v_a_387_, v___x_452_, v___x_406_, v___x_464_, v___x_439_, v___x_464_, v___x_384_, v___x_406_, v___x_406_, v___x_403_, v___x_465_, v___x_466_);
if (lean_obj_tag(v___x_467_) == 0)
{
uint64_t v___x_468_; uint64_t v___x_469_; lean_object* v___x_470_; 
lean_dec_ref_known(v___x_467_, 1);
v___x_468_ = 13856569450523787264ULL;
v___x_469_ = 13847183469513277440ULL;
v___x_470_ = vastitas_storage_expect(v_a_387_, v___x_452_, v___x_406_, v___x_464_, v___x_439_, v___x_464_, v___x_384_, v___x_419_, v___x_443_, v___x_403_, v___x_468_, v___x_469_);
if (lean_obj_tag(v___x_470_) == 0)
{
uint64_t v___x_471_; uint64_t v___x_472_; uint64_t v___x_473_; lean_object* v___x_474_; 
lean_dec_ref_known(v___x_470_, 1);
v___x_471_ = 1151ULL;
v___x_472_ = 13855506772535541760ULL;
v___x_473_ = 13844008079932260352ULL;
v___x_474_ = vastitas_storage_expect(v_a_387_, v___x_452_, v___x_406_, v___x_464_, v___x_439_, v___x_464_, v___x_384_, v___x_471_, v___x_406_, v___x_403_, v___x_472_, v___x_473_);
if (lean_obj_tag(v___x_474_) == 0)
{
lean_object* v___x_475_; 
lean_dec_ref_known(v___x_474_, 1);
v___x_475_ = vastitas_storage_drop(v_a_387_, v___x_452_);
if (lean_obj_tag(v___x_475_) == 0)
{
lean_object* v___x_476_; 
lean_dec_ref_known(v___x_475_, 1);
v___x_476_ = vastitas_storage_drop(v_a_387_, v___x_449_);
if (lean_obj_tag(v___x_476_) == 0)
{
lean_object* v___x_477_; 
lean_dec_ref_known(v___x_476_, 1);
v___x_477_ = vastitas_storage_drop(v_a_387_, v___x_445_);
if (lean_obj_tag(v___x_477_) == 0)
{
lean_object* v___x_478_; 
lean_dec_ref_known(v___x_477_, 1);
v___x_478_ = vastitas_storage_drop(v_a_387_, v___x_378_);
if (lean_obj_tag(v___x_478_) == 0)
{
lean_object* v___x_479_; 
lean_dec_ref_known(v___x_478_, 1);
v___x_479_ = vastitas_storage_drop(v_a_387_, v___x_375_);
if (lean_obj_tag(v___x_479_) == 0)
{
lean_object* v___x_480_; 
lean_dec_ref_known(v___x_479_, 1);
v___x_480_ = vastitas_storage_drop(v_a_387_, v___x_402_);
v___y_389_ = v___x_480_;
goto v___jp_388_;
}
else
{
v___y_389_ = v___x_479_;
goto v___jp_388_;
}
}
else
{
v___y_389_ = v___x_478_;
goto v___jp_388_;
}
}
else
{
v___y_389_ = v___x_477_;
goto v___jp_388_;
}
}
else
{
v___y_389_ = v___x_476_;
goto v___jp_388_;
}
}
else
{
v___y_389_ = v___x_475_;
goto v___jp_388_;
}
}
else
{
v___y_389_ = v___x_474_;
goto v___jp_388_;
}
}
else
{
v___y_389_ = v___x_470_;
goto v___jp_388_;
}
}
else
{
v___y_389_ = v___x_467_;
goto v___jp_388_;
}
}
else
{
v___y_389_ = v___x_463_;
goto v___jp_388_;
}
}
else
{
v___y_389_ = v___x_462_;
goto v___jp_388_;
}
}
else
{
v___y_389_ = v___x_461_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_458_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_455_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_454_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_451_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_450_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_448_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_447_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_444_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_442_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_440_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_437_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_436_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_434_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_431_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_428_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_424_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_423_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_421_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_418_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_415_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_410_;
goto v___jp_388_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v___y_389_ = v___x_405_;
goto v___jp_388_;
}
v___jp_388_:
{
if (lean_obj_tag(v___y_389_) == 0)
{
lean_object* v___x_390_; 
lean_dec_ref_known(v___y_389_, 1);
v___x_390_ = vastitas_storage_close(v_a_387_);
lean_dec(v_a_387_);
if (lean_obj_tag(v___x_390_) == 0)
{
lean_object* v___x_391_; 
lean_dec_ref_known(v___x_390_, 1);
v___x_391_ = bench_report_lean();
return v___x_391_;
}
else
{
return v___x_390_;
}
}
else
{
lean_object* v_a_392_; lean_object* v___x_393_; 
v_a_392_ = lean_ctor_get(v___y_389_, 0);
lean_inc(v_a_392_);
lean_dec_ref_known(v___y_389_, 1);
v___x_393_ = vastitas_storage_close(v_a_387_);
lean_dec(v_a_387_);
if (lean_obj_tag(v___x_393_) == 0)
{
lean_object* v___x_395_; uint8_t v_isShared_396_; uint8_t v_isSharedCheck_400_; 
v_isSharedCheck_400_ = !lean_is_exclusive(v___x_393_);
if (v_isSharedCheck_400_ == 0)
{
lean_object* v_unused_401_; 
v_unused_401_ = lean_ctor_get(v___x_393_, 0);
lean_dec(v_unused_401_);
v___x_395_ = v___x_393_;
v_isShared_396_ = v_isSharedCheck_400_;
goto v_resetjp_394_;
}
else
{
lean_dec(v___x_393_);
v___x_395_ = lean_box(0);
v_isShared_396_ = v_isSharedCheck_400_;
goto v_resetjp_394_;
}
v_resetjp_394_:
{
lean_object* v___x_398_; 
if (v_isShared_396_ == 0)
{
lean_ctor_set_tag(v___x_395_, 1);
lean_ctor_set(v___x_395_, 0, v_a_392_);
v___x_398_ = v___x_395_;
goto v_reusejp_397_;
}
else
{
lean_object* v_reuseFailAlloc_399_; 
v_reuseFailAlloc_399_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_399_, 0, v_a_392_);
v___x_398_ = v_reuseFailAlloc_399_;
goto v_reusejp_397_;
}
v_reusejp_397_:
{
return v___x_398_;
}
}
}
else
{
lean_dec(v_a_392_);
return v___x_393_;
}
}
}
}
else
{
lean_object* v_a_481_; lean_object* v___x_483_; uint8_t v_isShared_484_; uint8_t v_isSharedCheck_488_; 
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
v_a_481_ = lean_ctor_get(v___x_386_, 0);
v_isSharedCheck_488_ = !lean_is_exclusive(v___x_386_);
if (v_isSharedCheck_488_ == 0)
{
v___x_483_ = v___x_386_;
v_isShared_484_ = v_isSharedCheck_488_;
goto v_resetjp_482_;
}
else
{
lean_inc(v_a_481_);
lean_dec(v___x_386_);
v___x_483_ = lean_box(0);
v_isShared_484_ = v_isSharedCheck_488_;
goto v_resetjp_482_;
}
v_resetjp_482_:
{
lean_object* v___x_486_; 
if (v_isShared_484_ == 0)
{
v___x_486_ = v___x_483_;
goto v_reusejp_485_;
}
else
{
lean_object* v_reuseFailAlloc_487_; 
v_reuseFailAlloc_487_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_487_, 0, v_a_481_);
v___x_486_ = v_reuseFailAlloc_487_;
goto v_reusejp_485_;
}
v_reusejp_485_:
{
return v___x_486_;
}
}
}
}
else
{
uint32_t v___x_489_; uint64_t v___x_490_; lean_object* v___x_491_; 
lean_dec(v_scope_365_);
v___x_489_ = 0;
v___x_490_ = lean_uint64_of_nat(v_reps_370_);
v___x_491_ = bench_begin_lean(v___x_489_, v___x_490_, v_verify_374_);
if (lean_obj_tag(v___x_491_) == 0)
{
lean_object* v___x_492_; lean_object* v___x_493_; lean_object* v___x_494_; 
lean_dec_ref_known(v___x_491_, 1);
v___x_492_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_492_, 0, v___x_359_);
lean_ctor_set(v___x_492_, 1, v_reps_370_);
lean_ctor_set(v___x_492_, 2, v___x_361_);
v___x_493_ = lean_box(0);
v___x_494_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v___x_492_, v___x_493_, v___x_359_);
lean_dec_ref_known(v___x_492_, 3);
if (lean_obj_tag(v___x_494_) == 0)
{
lean_object* v___x_495_; 
lean_dec_ref_known(v___x_494_, 1);
v___x_495_ = bench_stop_lean();
if (lean_obj_tag(v___x_495_) == 0)
{
lean_object* v___x_496_; 
lean_dec_ref_known(v___x_495_, 1);
v___x_496_ = bench_report_lean();
return v___x_496_;
}
else
{
return v___x_495_;
}
}
else
{
return v___x_494_;
}
}
else
{
lean_dec(v_reps_370_);
return v___x_491_;
}
}
}
else
{
uint32_t v___x_497_; uint64_t v___x_498_; lean_object* v___x_499_; 
v___x_497_ = lean_uint32_of_nat(v_scope_365_);
lean_dec(v_scope_365_);
v___x_498_ = lean_uint64_of_nat(v_reps_370_);
lean_dec(v_reps_370_);
v___x_499_ = bench_c_run_lean(v___x_497_, v___x_498_, v_verify_374_);
if (lean_obj_tag(v___x_499_) == 0)
{
lean_object* v___x_500_; 
lean_dec_ref_known(v___x_499_, 1);
v___x_500_ = bench_report_lean();
return v___x_500_;
}
else
{
return v___x_499_;
}
}
}
else
{
uint32_t v___x_501_; uint64_t v___x_502_; lean_object* v___x_503_; 
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
lean_dec(v_impl_360_);
v___x_501_ = 0;
v___x_502_ = 1ULL;
v___x_503_ = bench_begin_lean(v___x_501_, v___x_502_, v___x_381_);
if (lean_obj_tag(v___x_503_) == 0)
{
lean_object* v___x_504_; 
lean_dec_ref_known(v___x_503_, 1);
v___x_504_ = lp_allocation__audit_generatedFailure();
if (lean_obj_tag(v___x_504_) == 0)
{
lean_object* v___x_506_; uint8_t v_isShared_507_; uint8_t v_isSharedCheck_512_; 
v_isSharedCheck_512_ = !lean_is_exclusive(v___x_504_);
if (v_isSharedCheck_512_ == 0)
{
lean_object* v_unused_513_; 
v_unused_513_ = lean_ctor_get(v___x_504_, 0);
lean_dec(v_unused_513_);
v___x_506_ = v___x_504_;
v_isShared_507_ = v_isSharedCheck_512_;
goto v_resetjp_505_;
}
else
{
lean_dec(v___x_504_);
v___x_506_ = lean_box(0);
v_isShared_507_ = v_isSharedCheck_512_;
goto v_resetjp_505_;
}
v_resetjp_505_:
{
lean_object* v___x_508_; lean_object* v___x_510_; 
v___x_508_ = ((lean_object*)(lp_allocation__audit_main___closed__5));
if (v_isShared_507_ == 0)
{
lean_ctor_set_tag(v___x_506_, 1);
lean_ctor_set(v___x_506_, 0, v___x_508_);
v___x_510_ = v___x_506_;
goto v_reusejp_509_;
}
else
{
lean_object* v_reuseFailAlloc_511_; 
v_reuseFailAlloc_511_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_511_, 0, v___x_508_);
v___x_510_ = v_reuseFailAlloc_511_;
goto v_reusejp_509_;
}
v_reusejp_509_:
{
return v___x_510_;
}
}
}
else
{
lean_object* v_a_514_; lean_object* v___x_515_; lean_object* v___x_516_; uint8_t v___x_517_; 
v_a_514_ = lean_ctor_get(v___x_504_, 0);
lean_inc(v_a_514_);
v___x_515_ = lean_io_error_to_string(v_a_514_);
v___x_516_ = ((lean_object*)(lp_allocation__audit_main___closed__6));
v___x_517_ = lean_string_dec_eq(v___x_515_, v___x_516_);
lean_dec_ref(v___x_515_);
if (v___x_517_ == 0)
{
return v___x_504_;
}
else
{
lean_object* v___x_518_; 
lean_dec_ref_known(v___x_504_, 1);
v___x_518_ = bench_stop_lean();
if (lean_obj_tag(v___x_518_) == 0)
{
lean_object* v___x_519_; 
lean_dec_ref_known(v___x_518_, 1);
v___x_519_ = bench_report_lean();
return v___x_519_;
}
else
{
return v___x_518_;
}
}
}
}
else
{
return v___x_503_;
}
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
lean_dec(v_impl_360_);
return v___x_379_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
lean_dec(v_impl_360_);
return v___x_377_;
}
}
else
{
lean_dec(v_reps_370_);
lean_dec(v_scope_365_);
lean_dec(v_impl_360_);
return v___x_376_;
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object* v_args_520_, lean_object* v_a_521_){
_start:
{
lean_object* v_res_522_; 
v_res_522_ = _lean_main(v_args_520_);
return v_res_522_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object* v_a_523_, lean_object* v_scope_524_, lean_object* v_range_525_, lean_object* v_b_526_, lean_object* v_i_527_, lean_object* v_hs_528_, lean_object* v_hl_529_){
_start:
{
lean_object* v___x_531_; 
v___x_531_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_523_, v_scope_524_, v_range_525_, v_b_526_, v_i_527_);
return v___x_531_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object* v_a_532_, lean_object* v_scope_533_, lean_object* v_range_534_, lean_object* v_b_535_, lean_object* v_i_536_, lean_object* v_hs_537_, lean_object* v_hl_538_, lean_object* v___y_539_){
_start:
{
lean_object* v_res_540_; 
v_res_540_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(v_a_532_, v_scope_533_, v_range_534_, v_b_535_, v_i_536_, v_hs_537_, v_hl_538_);
lean_dec_ref(v_range_534_);
lean_dec(v_scope_533_);
lean_dec(v_a_532_);
return v_res_540_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object* v_range_541_, lean_object* v_b_542_, lean_object* v_i_543_, lean_object* v_hs_544_, lean_object* v_hl_545_){
_start:
{
lean_object* v___x_547_; 
v___x_547_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_541_, v_b_542_, v_i_543_);
return v___x_547_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object* v_range_548_, lean_object* v_b_549_, lean_object* v_i_550_, lean_object* v_hs_551_, lean_object* v_hl_552_, lean_object* v___y_553_){
_start:
{
lean_object* v_res_554_; 
v_res_554_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(v_range_548_, v_b_549_, v_i_550_, v_hs_551_, v_hl_552_);
lean_dec_ref(v_range_548_);
return v_res_554_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_vastitas__storage__native_VastitasStorageNative(uint8_t builtin);
lean_object* initialize_vastitas__gemm__native_VastitasGemmNative(uint8_t builtin);
lean_object* initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_allocation__audit_Main(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__storage__native_VastitasStorageNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__gemm__native_VastitasGemmNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_allocation__audit_VastitasGenerated_f__0 = _init_lp_allocation__audit_VastitasGenerated_f__0();
lean_mark_persistent(lp_allocation__audit_VastitasGenerated_f__0);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_allocation__audit_Main(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = 0;
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
