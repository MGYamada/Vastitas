import VastitasStorageNative
import VastitasGemmNative
import VastitasKernel.IndexedRuntime

set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
set_option linter.unusedVariables false

namespace VastitasGenerated

def f_0 : Int :=
  (0 : Int)

end VastitasGenerated

open VastitasStorageNative

def main : IO Unit := do
  let arena ← newArena 9223372036854775807
  try
    allocate arena 0 1 30720
    fill arena 0 0 30720 1 30720 false 1 13842939354630062080 4613937818241073152
    fill arena 0 0 24 1280 24 false 1 4593671619917905920 4598175219545276416
    store arena 0 0 24 1280 24 false 0 0 1 4607182418800017408 13826050856027422720
    store arena 0 0 24 1280 24 false 23 1 1 13826050856027422720 4604930618986332160
    allocate arena 1 1 1920
    fill arena 1 0 1920 1 1920 false 1 13842939354630062080 4613937818241073152
    fill arena 1 0 40 48 40 false 1 13821547256400052224 4593671619917905920
    store arena 1 0 40 48 40 false 0 47 1 4602678819172646912 4598175219545276416
    store arena 1 0 40 48 40 false 39 0 1 13828302655841107968 13826050856027422720
    allocate arena 2 1 1792
    fill arena 2 0 1792 1 1792 false 1 13842939354630062080 4613937818241073152
    fill arena 2 0 32 56 32 false 1 4602678819172646912 13821547256400052224
    store arena 2 0 32 56 32 false 31 0 1 13821547256400052224 4602678819172646912
    store arena 2 0 32 56 32 false 0 55 1 4604930618986332160 13828302655841107968
    allocate arena 3 1 36864
    fill arena 3 0 36864 1 36864 false 1 13842939354630062080 4613937818241073152
    allocate arena 4 1 36864
    fill arena 4 0 36864 1 36864 false 1 13842939354630062080 4613937818241073152
    allocate arena 5 1 64512
    fill arena 5 0 64512 1 64512 false 1 13842939354630062080 4613937818241073152
    pack3 arena 0 0 24 1280 24 false 3 0 768 40 768 false 24 40 32
    VastitasGemmNative.gemm arena 3 0 768 40 768 false false 1 0 40 48 40 false false 4 0 768 48 768 false 0
    regroup3 arena 4 0 768 48 768 false 3 0 1152 32 1152 false 24 32 48 48 42
    VastitasGemmNative.gemm arena 3 0 1152 32 1152 false false 2 0 32 56 32 false false 5 0 1152 56 1152 false 0
    expect arena 5 0 1152 56 1152 false 0 0 1 13855852019186663424 13847480337652776960
    expect arena 5 0 1152 56 1152 false 23 55 1 13856569450523787264 13847183469513277440
    expect arena 5 0 1152 56 1152 false 1151 0 1 13855506772535541760 13844008079932260352
    drop arena 5
    drop arena 4
    drop arena 3
    drop arena 2
    drop arena 1
    drop arena 0
    IO.println (VastitasGenerated.f_0)
  finally
    close arena
