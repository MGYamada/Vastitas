/* Fixture data independently constructed from cases.json. */
static const unsigned scalar = 1;
static const uint64_t dim_i=24, dim_k=40, dim_j=32, dim_a=48;
static const VStorageLayout views[7] = {{0,24,1280,24,0},{0,40,48,40,0},{0,32,56,32,0},{0,768,40,768,0},{0,768,48,768,0},{0,1152,56,1152,0},{0,1152,32,1152,0}};
static const uint64_t elements[6] = {30720,1920,1792,36864,36864,64512};
static const double values[3][2] = {{0x1.0000000000000p-3,0x1.0000000000000p-2},{-0x1.0000000000000p-2,0x1.0000000000000p-3},{0x1.0000000000000p-1,-0x1.0000000000000p-2}};
static const double sentinel[2] = {-0x1.c000000000000p+2,0x1.8000000000000p+1};
static const double alpha[2] = {1,0}, beta[2] = {0,0};
typedef struct { uint64_t row, col; double value[2]; } Patch;
static const Patch patches[3][2] = {{{0,0,{0x1.0000000000000p+0,-0x1.0000000000000p-1}},{23,1,{-0x1.0000000000000p-1,0x1.8000000000000p-1}}},{{0,47,{0x1.0000000000000p-1,0x1.0000000000000p-2}},{39,0,{-0x1.8000000000000p-1,-0x1.0000000000000p-1}}},{{31,0,{-0x1.0000000000000p-2,0x1.0000000000000p-1}},{0,55,{0x1.8000000000000p-1,-0x1.8000000000000p-1}}}};
static const Patch expected[3] = {{0,0,{-0x1.9e00000000000p+5,-0x1.c220000000000p+3}},{23,55,{-0x1.c6c8000000000p+5,-0x1.b140000000000p+3}},{1151,0,{-0x1.8a60000000000p+5,-0x1.fcc0000000000p+2}}};
