#include "bridge.h"
#include <lean/lean.h>
static lean_obj_res untracked_report_result(void) { return lean_io_result_mk_ok(lean_box(0)); }
#include "audit.h"
#include "storage.h"
#include "diagonal.h"
#include "ffi_result.h"
#include <stdatomic.h>

static lean_once_cell_t success_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object *unit_success;
static lean_object *initialize_success(void) {
    lean_object *result = audit_shared_create();
    lean_mark_persistent(result);
    return result;
}

/* Lean's once cell publishes the fully initialized immutable object. The pinned
 * Lean API prevents callers from resetting a persistent constructor in place;
 * generated finally blocks take their ordinary nonexclusive fallback instead.
 * One result remains live for the process lifetime, with no arena/error payload. */
LEAN_EXPORT lean_obj_res vastitas_io_unit_success(void) {
    lean_object *result = lean_obj_once(&unit_success, &success_once, initialize_success);
    lean_inc(result);
    return audit_shared_return(result);
}

static lean_external_class *arena_class;
static atomic_flag class_lock = ATOMIC_FLAG_INIT;
static void finalize(void *data) { audit_finalize(data); vstorage_delete(data); }
static void foreach(void *data, b_lean_obj_arg function) { (void)data; (void)function; }
/* Registration is synchronized only at arena construction, never per operation
 * or element. Individual arenas have the synchronous, single-caller contract. */
static void initialize_class(void) {
    while (atomic_flag_test_and_set_explicit(&class_lock, memory_order_acquire)) {}
    if (!arena_class) arena_class = lean_register_external_class(finalize, foreach);
    atomic_flag_clear_explicit(&class_lock, memory_order_release);
}
static VStorageArena *arena_data(b_lean_obj_arg arena) { return lean_get_external_data(arena); }
static lean_obj_res result(VStorageStatus status) {
    if (status == VS_OK) return vastitas_io_unit_success();
    return lean_io_result_mk_error(lean_mk_io_user_error(lean_mk_string(vstorage_error(status))));
}

/* Lean 4.35 erases the IO world argument. Keep these signatures in agreement
 * with the generated Runtime.c declarations, including borrowed Arena values. */
LEAN_EXPORT lean_obj_res vastitas_storage_new(uint64_t budget) {
    initialize_class();
    VStorageArena *arena = vstorage_new(budget);
    if (!arena) return result(VS_ALLOCATION);
    return lean_io_result_mk_ok(lean_alloc_external(arena_class, arena));
}
LEAN_EXPORT lean_obj_res vastitas_storage_close(b_lean_obj_arg arena) {
    vstorage_close(arena_data(arena));
    return result(VS_OK);
}
LEAN_EXPORT lean_obj_res vastitas_storage_stats(b_lean_obj_arg arena) {
    VStorageStats s = vstorage_stats(arena_data(arena));
    uint64_t values[] = {s.data_allocations, s.data_frees, s.live_bytes, s.peak_bytes,
        s.written_bytes, s.copied_bytes, s.metadata_allocations, s.metadata_bytes};
    lean_object *array = lean_mk_empty_array_with_capacity(lean_box(8));
    for (unsigned i = 0; i < 8; ++i) array = lean_array_push(array, lean_box_uint64(values[i]));
    return lean_io_result_mk_ok(array);
}
LEAN_EXPORT lean_obj_res vastitas_storage_allocate(b_lean_obj_arg arena, uint32_t id, uint8_t scalar, uint64_t elements) {
    return result(vstorage_allocate(arena_data(arena), id, scalar, elements));
}
LEAN_EXPORT lean_obj_res vastitas_storage_drop(b_lean_obj_arg arena, uint32_t id) {
    return result(vstorage_drop(arena_data(arena), id));
}
LEAN_EXPORT lean_obj_res vastitas_storage_fill(b_lean_obj_arg arena, uint32_t id,
        uint64_t offset, uint64_t rows, uint64_t columns, uint64_t leading, uint8_t transposed,
        uint8_t scalar, uint64_t real, uint64_t imaginary) {
    return result(vstorage_fill(arena_data(arena), id, (VStorageLayout){offset,rows,columns,leading,transposed}, scalar, real, imaginary));
}
LEAN_EXPORT lean_obj_res vastitas_storage_store(b_lean_obj_arg arena, uint32_t id,
        uint64_t offset, uint64_t rows, uint64_t columns, uint64_t leading, uint8_t transposed,
        uint64_t row, uint64_t column, uint8_t scalar, uint64_t real, uint64_t imaginary) {
    return result(vstorage_store(arena_data(arena), id, (VStorageLayout){offset,rows,columns,leading,transposed}, row, column, scalar, real, imaginary));
}
LEAN_EXPORT lean_obj_res vastitas_storage_expect(b_lean_obj_arg arena, uint32_t id,
        uint64_t offset, uint64_t rows, uint64_t columns, uint64_t leading, uint8_t transposed,
        uint64_t row, uint64_t column, uint8_t scalar, uint64_t real, uint64_t imaginary) {
    return result(vstorage_expect(arena_data(arena), id, (VStorageLayout){offset,rows,columns,leading,transposed}, row, column, scalar, real, imaginary));
}
LEAN_EXPORT lean_obj_res vastitas_storage_copy(b_lean_obj_arg arena, uint32_t source,
        uint64_t source_offset, uint64_t source_rows, uint64_t source_columns, uint64_t source_leading, uint8_t source_transposed,
        uint32_t target, uint64_t target_offset, uint64_t target_rows, uint64_t target_columns, uint64_t target_leading, uint8_t target_transposed) {
    return result(vstorage_copy(arena_data(arena), source,
        (VStorageLayout){source_offset,source_rows,source_columns,source_leading,source_transposed}, target,
        (VStorageLayout){target_offset,target_rows,target_columns,target_leading,target_transposed}));
}
LEAN_EXPORT lean_obj_res vastitas_storage_pack3(b_lean_obj_arg arena, uint32_t source,
        uint64_t source_offset, uint64_t source_rows, uint64_t source_columns, uint64_t source_leading, uint8_t source_transposed,
        uint32_t target, uint64_t target_offset, uint64_t target_rows, uint64_t target_columns, uint64_t target_leading, uint8_t target_transposed,
        uint64_t i, uint64_t k, uint64_t j) {
    return result(vstorage_pack3(arena_data(arena), source,
        (VStorageLayout){source_offset,source_rows,source_columns,source_leading,source_transposed}, target,
        (VStorageLayout){target_offset,target_rows,target_columns,target_leading,target_transposed}, i, k, j));
}

LEAN_EXPORT lean_obj_res vastitas_diagonal_adjoint(b_lean_obj_arg arena,
        uint32_t input, uint64_t input_offset, uint64_t input_rows, uint64_t input_columns,
        uint64_t input_leading, uint8_t input_transposed,
        uint32_t output, uint64_t output_offset, uint64_t output_rows, uint64_t output_columns,
        uint64_t output_leading, uint8_t output_transposed,
        uint8_t source_uniform, b_lean_obj_arg source, uint8_t target_uniform, b_lean_obj_arg target,
        uint8_t conjugate) {
    return result(vdiagonal_adjoint(arena_data(arena),
        input, (VStorageLayout){input_offset,input_rows,input_columns,input_leading,input_transposed},
        output, (VStorageLayout){output_offset,output_rows,output_columns,output_leading,output_transposed},
        (VDiagonal){lean_sarray_cptr(source),lean_sarray_size(source),source_uniform},
        (VDiagonal){lean_sarray_cptr(target),lean_sarray_size(target),target_uniform}, conjugate));
}
LEAN_EXPORT lean_obj_res vastitas_diagonal_scale(b_lean_obj_arg arena,
        uint32_t input, uint64_t input_offset, uint64_t input_rows, uint64_t input_columns,
        uint64_t input_leading, uint8_t input_transposed,
        uint32_t output, uint64_t output_offset, uint64_t output_rows, uint64_t output_columns,
        uint64_t output_leading, uint8_t output_transposed,
        uint8_t uniform, b_lean_obj_arg diagonal, uint8_t conjugate) {
    return result(vdiagonal_scale(arena_data(arena),
        input, (VStorageLayout){input_offset,input_rows,input_columns,input_leading,input_transposed},
        output, (VStorageLayout){output_offset,output_rows,output_columns,output_leading,output_transposed},
        (VDiagonal){lean_sarray_cptr(diagonal),lean_sarray_size(diagonal),uniform}, conjugate));
}
LEAN_EXPORT lean_obj_res vastitas_storage_regroup3(b_lean_obj_arg arena, uint32_t source,
        uint64_t source_offset, uint64_t source_rows, uint64_t source_columns, uint64_t source_leading, uint8_t source_transposed,
        uint32_t target, uint64_t target_offset, uint64_t target_rows, uint64_t target_columns, uint64_t target_leading, uint8_t target_transposed,
        uint64_t d0, uint64_t d1, uint64_t d2, uint64_t input_grouping, uint64_t output_grouping) {
    return result(vstorage_regroup3(arena_data(arena), source,
        (VStorageLayout){source_offset,source_rows,source_columns,source_leading,source_transposed}, target,
        (VStorageLayout){target_offset,target_rows,target_columns,target_leading,target_transposed},
        d0, d1, d2, input_grouping, output_grouping));
}

#undef lean_io_result_mk_ok
#define lean_io_result_mk_ok audit_control_ok
/* Appended only to the private runtime's ffi.c; Lean 4.35 IO erases the world. */
void bench_begin(uint32_t, uint64_t, uint8_t);
void bench_stop(void);
void bench_report(void);
void bench_c_run(uint32_t, uint64_t, uint8_t);
void bench_verify(VStorageArena *, uint64_t);
LEAN_EXPORT lean_obj_res bench_begin_lean(uint32_t s, uint64_t n, uint8_t v) {
    bench_begin(s,n,v); return lean_io_result_mk_ok(lean_box(0));
}
LEAN_EXPORT lean_obj_res bench_stop_lean(void) { bench_stop(); return lean_io_result_mk_ok(lean_box(0)); }
LEAN_EXPORT lean_obj_res bench_report_lean(void) { bench_report(); audit_report(); source_workspace_report(); return untracked_report_result(); }
LEAN_EXPORT lean_obj_res bench_c_run_lean(uint32_t s, uint64_t n, uint8_t v) {
    bench_c_run(s,n,v); return lean_io_result_mk_ok(lean_box(0));
}
LEAN_EXPORT lean_obj_res bench_verify_lean(b_lean_obj_arg arena, uint64_t n) {
    bench_verify(lean_get_external_data(arena),n); return lean_io_result_mk_ok(lean_box(0));
}
