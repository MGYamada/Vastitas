// Lean compiler output
// Module: Main
// Imports: public import Init public meta import Init public import VastitasStorageNative public import VastitasGemmNative public import VastitasKernel.IndexedRuntime
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* vastitas_storage_new(uint64_t);
lean_object* vastitas_storage_close(lean_object*);
lean_object* vastitas_storage_allocate(lean_object*, uint32_t, uint8_t, uint64_t);
lean_object* vastitas_storage_fill(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_store(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_pack3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_gemm_execute(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t);
lean_object* vastitas_storage_regroup3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_storage_expect(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_drop(lean_object*, uint32_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_List_get_x21Internal___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_String_Slice_toNat_x21(lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
uint32_t lean_uint32_of_nat(lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
lean_object* lean_io_error_to_string(lean_object*);
static lean_once_cell_t lp_allocation__audit_VastitasGenerated_f__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_allocation__audit_VastitasGenerated_f__0___closed__0;
LEAN_EXPORT lean_object* lp_allocation__audit_VastitasGenerated_f__0;
lean_object* bench_begin_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_stop_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object*);
lean_object* bench_report_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object*);
lean_object* bench_c_run_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_verify_lean(lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object*);
lean_object* audit_mark_lean(uint32_t);
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_allocation__audit_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 1, .m_capacity = 1, .m_length = 0, .m_data = ""};
static const lean_object* lp_allocation__audit_main___closed__0 = (const lean_object*)&lp_allocation__audit_main___closed__0_value;
static const lean_string_object lp_allocation__audit_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "1"};
static const lean_object* lp_allocation__audit_main___closed__1 = (const lean_object*)&lp_allocation__audit_main___closed__1_value;
static const lean_string_object lp_allocation__audit_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "failure"};
static const lean_object* lp_allocation__audit_main___closed__2 = (const lean_object*)&lp_allocation__audit_main___closed__2_value;
static const lean_string_object lp_allocation__audit_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "c"};
static const lean_object* lp_allocation__audit_main___closed__3 = (const lean_object*)&lp_allocation__audit_main___closed__3_value;
static const lean_string_object lp_allocation__audit_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "expected injected native failure"};
static const lean_object* lp_allocation__audit_main___closed__4 = (const lean_object*)&lp_allocation__audit_main___closed__4_value;
static const lean_ctor_object lp_allocation__audit_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_allocation__audit_main___closed__4_value)}};
static const lean_object* lp_allocation__audit_main___closed__5 = (const lean_object*)&lp_allocation__audit_main___closed__5_value;
static const lean_string_object lp_allocation__audit_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 44, .m_capacity = 44, .m_length = 43, .m_data = "E_NATIVE_EXPECT: stored bit pattern differs"};
static const lean_object* lp_allocation__audit_main___closed__6 = (const lean_object*)&lp_allocation__audit_main___closed__6_value;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(0u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0(void){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_obj_once(&lp_allocation__audit_VastitasGenerated_f__0___closed__0, &lp_allocation__audit_VastitasGenerated_f__0___closed__0_once, _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object* v_scope_8_, lean_object* v_reps_9_, lean_object* v_verify_10_, lean_object* v_a_00___x40___internal___hyg_11_){
_start:
{
uint32_t v_scope_boxed_12_; uint64_t v_reps_boxed_13_; uint8_t v_verify_boxed_14_; lean_object* v_res_15_; 
v_scope_boxed_12_ = lean_unbox_uint32(v_scope_8_);
lean_dec(v_scope_8_);
v_reps_boxed_13_ = lean_unbox_uint64(v_reps_9_);
lean_dec_ref(v_reps_9_);
v_verify_boxed_14_ = lean_unbox(v_verify_10_);
v_res_15_ = bench_begin_lean(v_scope_boxed_12_, v_reps_boxed_13_, v_verify_boxed_14_);
return v_res_15_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object* v_a_00___x40___internal___hyg_17_){
_start:
{
lean_object* v_res_18_; 
v_res_18_ = bench_stop_lean();
return v_res_18_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object* v_a_00___x40___internal___hyg_20_){
_start:
{
lean_object* v_res_21_; 
v_res_21_ = bench_report_lean();
return v_res_21_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object* v_scope_26_, lean_object* v_reps_27_, lean_object* v_verify_28_, lean_object* v_a_00___x40___internal___hyg_29_){
_start:
{
uint32_t v_scope_boxed_30_; uint64_t v_reps_boxed_31_; uint8_t v_verify_boxed_32_; lean_object* v_res_33_; 
v_scope_boxed_30_ = lean_unbox_uint32(v_scope_26_);
lean_dec(v_scope_26_);
v_reps_boxed_31_ = lean_unbox_uint64(v_reps_27_);
lean_dec_ref(v_reps_27_);
v_verify_boxed_32_ = lean_unbox(v_verify_28_);
v_res_33_ = bench_c_run_lean(v_scope_boxed_30_, v_reps_boxed_31_, v_verify_boxed_32_);
return v_res_33_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object* v_arena_37_, lean_object* v_reps_38_, lean_object* v_a_00___x40___internal___hyg_39_){
_start:
{
uint64_t v_reps_boxed_40_; lean_object* v_res_41_; 
v_reps_boxed_40_ = lean_unbox_uint64(v_reps_38_);
lean_dec_ref(v_reps_38_);
v_res_41_ = bench_verify_lean(v_arena_37_, v_reps_boxed_40_);
lean_dec(v_arena_37_);
return v_res_41_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce(){
_start:
{
uint64_t v___x_43_; lean_object* v___x_44_; 
v___x_43_ = 9223372036854775807ULL;
v___x_44_ = vastitas_storage_new(v___x_43_);
if (lean_obj_tag(v___x_44_) == 0)
{
lean_object* v_a_45_; lean_object* v_a_47_; lean_object* v___y_58_; uint32_t v___x_70_; uint8_t v___x_71_; uint64_t v___x_72_; lean_object* v___x_73_; 
v_a_45_ = lean_ctor_get(v___x_44_, 0);
lean_inc(v_a_45_);
lean_dec_ref_known(v___x_44_, 1);
v___x_70_ = 0;
v___x_71_ = 1;
v___x_72_ = 33284ULL;
v___x_73_ = vastitas_storage_allocate(v_a_45_, v___x_70_, v___x_71_, v___x_72_);
if (lean_obj_tag(v___x_73_) == 0)
{
uint64_t v___x_74_; uint64_t v___x_75_; uint8_t v___x_76_; uint64_t v___x_77_; uint64_t v___x_78_; lean_object* v___x_79_; 
lean_dec_ref_known(v___x_73_, 1);
v___x_74_ = 0ULL;
v___x_75_ = 1ULL;
v___x_76_ = 0;
v___x_77_ = 13842939354630062080ULL;
v___x_78_ = 4613937818241073152ULL;
v___x_79_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_74_, v___x_72_, v___x_75_, v___x_72_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_79_) == 0)
{
uint64_t v___x_80_; uint64_t v___x_81_; uint64_t v___x_82_; uint64_t v___x_83_; uint64_t v___x_84_; uint64_t v___x_85_; lean_object* v___x_86_; 
lean_dec_ref_known(v___x_79_, 1);
v___x_80_ = 16ULL;
v___x_81_ = 24ULL;
v___x_82_ = 1280ULL;
v___x_83_ = 26ULL;
v___x_84_ = 4593671619917905920ULL;
v___x_85_ = 4598175219545276416ULL;
v___x_86_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_80_, v___x_81_, v___x_82_, v___x_83_, v___x_76_, v___x_71_, v___x_84_, v___x_85_);
if (lean_obj_tag(v___x_86_) == 0)
{
uint64_t v___x_87_; uint64_t v___x_88_; lean_object* v___x_89_; 
lean_dec_ref_known(v___x_86_, 1);
v___x_87_ = 4607182418800017408ULL;
v___x_88_ = 13826050856027422720ULL;
v___x_89_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_80_, v___x_81_, v___x_82_, v___x_83_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_87_, v___x_88_);
if (lean_obj_tag(v___x_89_) == 0)
{
uint64_t v___x_90_; uint64_t v___x_91_; lean_object* v___x_92_; 
lean_dec_ref_known(v___x_89_, 1);
v___x_90_ = 23ULL;
v___x_91_ = 4604930618986332160ULL;
v___x_92_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_80_, v___x_81_, v___x_82_, v___x_83_, v___x_76_, v___x_90_, v___x_75_, v___x_71_, v___x_88_, v___x_91_);
if (lean_obj_tag(v___x_92_) == 0)
{
uint32_t v___x_93_; uint64_t v___x_94_; lean_object* v___x_95_; 
lean_dec_ref_known(v___x_92_, 1);
v___x_93_ = 1;
v___x_94_ = 2069ULL;
v___x_95_ = vastitas_storage_allocate(v_a_45_, v___x_93_, v___x_71_, v___x_94_);
if (lean_obj_tag(v___x_95_) == 0)
{
lean_object* v___x_96_; 
lean_dec_ref_known(v___x_95_, 1);
v___x_96_ = vastitas_storage_fill(v_a_45_, v___x_93_, v___x_74_, v___x_94_, v___x_75_, v___x_94_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_96_) == 0)
{
uint64_t v___x_97_; uint64_t v___x_98_; uint64_t v___x_99_; uint64_t v___x_100_; uint64_t v___x_101_; lean_object* v___x_102_; 
lean_dec_ref_known(v___x_96_, 1);
v___x_97_ = 32ULL;
v___x_98_ = 40ULL;
v___x_99_ = 48ULL;
v___x_100_ = 43ULL;
v___x_101_ = 13821547256400052224ULL;
v___x_102_ = vastitas_storage_fill(v_a_45_, v___x_93_, v___x_97_, v___x_98_, v___x_99_, v___x_100_, v___x_76_, v___x_71_, v___x_101_, v___x_84_);
if (lean_obj_tag(v___x_102_) == 0)
{
uint64_t v___x_103_; uint64_t v___x_104_; lean_object* v___x_105_; 
lean_dec_ref_known(v___x_102_, 1);
v___x_103_ = 47ULL;
v___x_104_ = 4602678819172646912ULL;
v___x_105_ = vastitas_storage_store(v_a_45_, v___x_93_, v___x_97_, v___x_98_, v___x_99_, v___x_100_, v___x_76_, v___x_74_, v___x_103_, v___x_71_, v___x_104_, v___x_85_);
if (lean_obj_tag(v___x_105_) == 0)
{
uint64_t v___x_106_; uint64_t v___x_107_; lean_object* v___x_108_; 
lean_dec_ref_known(v___x_105_, 1);
v___x_106_ = 39ULL;
v___x_107_ = 13828302655841107968ULL;
v___x_108_ = vastitas_storage_store(v_a_45_, v___x_93_, v___x_97_, v___x_98_, v___x_99_, v___x_100_, v___x_76_, v___x_106_, v___x_74_, v___x_71_, v___x_107_, v___x_88_);
if (lean_obj_tag(v___x_108_) == 0)
{
uint32_t v___x_109_; uint64_t v___x_110_; lean_object* v___x_111_; 
lean_dec_ref_known(v___x_108_, 1);
v___x_109_ = 2;
v___x_110_ = 2022ULL;
v___x_111_ = vastitas_storage_allocate(v_a_45_, v___x_109_, v___x_71_, v___x_110_);
if (lean_obj_tag(v___x_111_) == 0)
{
lean_object* v___x_112_; 
lean_dec_ref_known(v___x_111_, 1);
v___x_112_ = vastitas_storage_fill(v_a_45_, v___x_109_, v___x_74_, v___x_110_, v___x_75_, v___x_110_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_112_) == 0)
{
uint64_t v___x_113_; uint64_t v___x_114_; lean_object* v___x_115_; 
lean_dec_ref_known(v___x_112_, 1);
v___x_113_ = 56ULL;
v___x_114_ = 36ULL;
v___x_115_ = vastitas_storage_fill(v_a_45_, v___x_109_, v___x_99_, v___x_97_, v___x_113_, v___x_114_, v___x_76_, v___x_71_, v___x_104_, v___x_101_);
if (lean_obj_tag(v___x_115_) == 0)
{
uint64_t v___x_116_; lean_object* v___x_117_; 
lean_dec_ref_known(v___x_115_, 1);
v___x_116_ = 31ULL;
v___x_117_ = vastitas_storage_store(v_a_45_, v___x_109_, v___x_99_, v___x_97_, v___x_113_, v___x_114_, v___x_76_, v___x_116_, v___x_74_, v___x_71_, v___x_101_, v___x_104_);
if (lean_obj_tag(v___x_117_) == 0)
{
uint64_t v___x_118_; lean_object* v___x_119_; 
lean_dec_ref_known(v___x_117_, 1);
v___x_118_ = 55ULL;
v___x_119_ = vastitas_storage_store(v_a_45_, v___x_109_, v___x_99_, v___x_97_, v___x_113_, v___x_114_, v___x_76_, v___x_74_, v___x_118_, v___x_71_, v___x_91_, v___x_107_);
if (lean_obj_tag(v___x_119_) == 0)
{
uint32_t v___x_120_; uint64_t v___x_121_; lean_object* v___x_122_; 
lean_dec_ref_known(v___x_119_, 1);
v___x_120_ = 3;
v___x_121_ = 37130ULL;
v___x_122_ = vastitas_storage_allocate(v_a_45_, v___x_120_, v___x_71_, v___x_121_);
if (lean_obj_tag(v___x_122_) == 0)
{
lean_object* v___x_123_; 
lean_dec_ref_known(v___x_122_, 1);
v___x_123_ = vastitas_storage_fill(v_a_45_, v___x_120_, v___x_74_, v___x_121_, v___x_75_, v___x_121_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_123_) == 0)
{
uint32_t v___x_124_; uint64_t v___x_125_; lean_object* v___x_126_; 
lean_dec_ref_known(v___x_123_, 1);
v___x_124_ = 4;
v___x_125_ = 37160ULL;
v___x_126_ = vastitas_storage_allocate(v_a_45_, v___x_124_, v___x_71_, v___x_125_);
if (lean_obj_tag(v___x_126_) == 0)
{
lean_object* v___x_127_; 
lean_dec_ref_known(v___x_126_, 1);
v___x_127_ = vastitas_storage_fill(v_a_45_, v___x_124_, v___x_74_, v___x_125_, v___x_75_, v___x_125_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_127_) == 0)
{
uint32_t v___x_128_; uint64_t v___x_129_; lean_object* v___x_130_; 
lean_dec_ref_known(v___x_127_, 1);
v___x_128_ = 5;
v___x_129_ = 64913ULL;
v___x_130_ = vastitas_storage_allocate(v_a_45_, v___x_128_, v___x_71_, v___x_129_);
if (lean_obj_tag(v___x_130_) == 0)
{
lean_object* v___x_131_; 
lean_dec_ref_known(v___x_130_, 1);
v___x_131_ = vastitas_storage_fill(v_a_45_, v___x_128_, v___x_74_, v___x_129_, v___x_75_, v___x_129_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_131_) == 0)
{
uint64_t v___x_132_; uint64_t v___x_133_; uint64_t v___x_134_; lean_object* v___x_135_; 
lean_dec_ref_known(v___x_131_, 1);
v___x_132_ = 64ULL;
v___x_133_ = 768ULL;
v___x_134_ = 773ULL;
v___x_135_ = vastitas_storage_pack3(v_a_45_, v___x_70_, v___x_80_, v___x_81_, v___x_82_, v___x_83_, v___x_76_, v___x_120_, v___x_132_, v___x_133_, v___x_98_, v___x_134_, v___x_76_, v___x_81_, v___x_98_, v___x_97_);
if (lean_obj_tag(v___x_135_) == 0)
{
uint64_t v___x_136_; uint64_t v___x_137_; uint8_t v___x_138_; lean_object* v___x_139_; 
lean_dec_ref_known(v___x_135_, 1);
v___x_136_ = 80ULL;
v___x_137_ = 774ULL;
v___x_138_ = 0;
v___x_139_ = vastitas_gemm_execute(v_a_45_, v___x_120_, v___x_132_, v___x_133_, v___x_98_, v___x_134_, v___x_76_, v___x_76_, v___x_93_, v___x_97_, v___x_98_, v___x_99_, v___x_100_, v___x_76_, v___x_76_, v___x_124_, v___x_136_, v___x_133_, v___x_99_, v___x_137_, v___x_76_, v___x_138_);
if (lean_obj_tag(v___x_139_) == 0)
{
uint64_t v___x_140_; uint64_t v___x_141_; uint64_t v___x_142_; uint64_t v___x_143_; lean_object* v___x_144_; 
lean_dec_ref_known(v___x_139_, 1);
v___x_140_ = 112ULL;
v___x_141_ = 1152ULL;
v___x_142_ = 1160ULL;
v___x_143_ = 42ULL;
v___x_144_ = vastitas_storage_regroup3(v_a_45_, v___x_124_, v___x_136_, v___x_133_, v___x_99_, v___x_137_, v___x_76_, v___x_120_, v___x_140_, v___x_141_, v___x_97_, v___x_142_, v___x_76_, v___x_81_, v___x_97_, v___x_99_, v___x_99_, v___x_143_);
if (lean_obj_tag(v___x_144_) == 0)
{
uint64_t v___x_145_; uint64_t v___x_146_; lean_object* v___x_147_; 
lean_dec_ref_known(v___x_144_, 1);
v___x_145_ = 96ULL;
v___x_146_ = 1159ULL;
v___x_147_ = vastitas_gemm_execute(v_a_45_, v___x_120_, v___x_140_, v___x_141_, v___x_97_, v___x_142_, v___x_76_, v___x_76_, v___x_109_, v___x_99_, v___x_97_, v___x_113_, v___x_114_, v___x_76_, v___x_76_, v___x_128_, v___x_145_, v___x_141_, v___x_113_, v___x_146_, v___x_76_, v___x_138_);
if (lean_obj_tag(v___x_147_) == 0)
{
uint64_t v___x_148_; uint64_t v___x_149_; lean_object* v___x_150_; 
lean_dec_ref_known(v___x_147_, 1);
v___x_148_ = 13855852019186663424ULL;
v___x_149_ = 13847480337652776960ULL;
v___x_150_ = vastitas_storage_expect(v_a_45_, v___x_128_, v___x_145_, v___x_141_, v___x_113_, v___x_146_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_148_, v___x_149_);
if (lean_obj_tag(v___x_150_) == 0)
{
uint64_t v___x_151_; uint64_t v___x_152_; lean_object* v___x_153_; 
lean_dec_ref_known(v___x_150_, 1);
v___x_151_ = 13856569450523787264ULL;
v___x_152_ = 13847183469513277440ULL;
v___x_153_ = vastitas_storage_expect(v_a_45_, v___x_128_, v___x_145_, v___x_141_, v___x_113_, v___x_146_, v___x_76_, v___x_90_, v___x_118_, v___x_71_, v___x_151_, v___x_152_);
if (lean_obj_tag(v___x_153_) == 0)
{
uint64_t v___x_154_; uint64_t v___x_155_; uint64_t v___x_156_; lean_object* v___x_157_; 
lean_dec_ref_known(v___x_153_, 1);
v___x_154_ = 1151ULL;
v___x_155_ = 13855506772535541760ULL;
v___x_156_ = 13844008079932260352ULL;
v___x_157_ = vastitas_storage_expect(v_a_45_, v___x_128_, v___x_145_, v___x_141_, v___x_113_, v___x_146_, v___x_76_, v___x_154_, v___x_74_, v___x_71_, v___x_155_, v___x_156_);
if (lean_obj_tag(v___x_157_) == 0)
{
lean_object* v___x_158_; 
lean_dec_ref_known(v___x_157_, 1);
v___x_158_ = vastitas_storage_drop(v_a_45_, v___x_128_);
if (lean_obj_tag(v___x_158_) == 0)
{
lean_object* v___x_159_; 
lean_dec_ref_known(v___x_158_, 1);
v___x_159_ = vastitas_storage_drop(v_a_45_, v___x_124_);
if (lean_obj_tag(v___x_159_) == 0)
{
lean_object* v___x_160_; 
lean_dec_ref_known(v___x_159_, 1);
v___x_160_ = vastitas_storage_drop(v_a_45_, v___x_120_);
if (lean_obj_tag(v___x_160_) == 0)
{
lean_object* v___x_161_; 
lean_dec_ref_known(v___x_160_, 1);
v___x_161_ = vastitas_storage_drop(v_a_45_, v___x_109_);
if (lean_obj_tag(v___x_161_) == 0)
{
lean_object* v___x_162_; 
lean_dec_ref_known(v___x_161_, 1);
v___x_162_ = vastitas_storage_drop(v_a_45_, v___x_93_);
if (lean_obj_tag(v___x_162_) == 0)
{
lean_object* v___x_163_; 
lean_dec_ref_known(v___x_162_, 1);
v___x_163_ = vastitas_storage_drop(v_a_45_, v___x_70_);
if (lean_obj_tag(v___x_163_) == 0)
{
lean_object* v___x_164_; 
lean_dec_ref_known(v___x_163_, 1);
v___x_164_ = lean_box(0);
v_a_47_ = v___x_164_;
goto v___jp_46_;
}
else
{
v___y_58_ = v___x_163_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_162_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_161_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_160_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_159_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_158_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_157_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_153_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_150_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_147_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_144_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_139_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_135_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_131_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_130_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_127_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_126_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_123_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_122_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_119_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_117_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_115_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_112_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_111_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_108_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_105_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_102_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_96_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_95_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_92_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_89_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_86_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_79_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_73_;
goto v___jp_57_;
}
v___jp_46_:
{
lean_object* v___x_48_; 
v___x_48_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_48_) == 0)
{
lean_object* v___x_50_; uint8_t v_isShared_51_; uint8_t v_isSharedCheck_55_; 
v_isSharedCheck_55_ = !lean_is_exclusive(v___x_48_);
if (v_isSharedCheck_55_ == 0)
{
lean_object* v_unused_56_; 
v_unused_56_ = lean_ctor_get(v___x_48_, 0);
lean_dec(v_unused_56_);
v___x_50_ = v___x_48_;
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
else
{
lean_dec(v___x_48_);
v___x_50_ = lean_box(0);
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
v_resetjp_49_:
{
lean_object* v___x_53_; 
if (v_isShared_51_ == 0)
{
lean_ctor_set(v___x_50_, 0, v_a_47_);
v___x_53_ = v___x_50_;
goto v_reusejp_52_;
}
else
{
lean_object* v_reuseFailAlloc_54_; 
v_reuseFailAlloc_54_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_54_, 0, v_a_47_);
v___x_53_ = v_reuseFailAlloc_54_;
goto v_reusejp_52_;
}
v_reusejp_52_:
{
return v___x_53_;
}
}
}
else
{
return v___x_48_;
}
}
v___jp_57_:
{
if (lean_obj_tag(v___y_58_) == 0)
{
lean_object* v_a_59_; 
v_a_59_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_59_);
lean_dec_ref_known(v___y_58_, 1);
v_a_47_ = v_a_59_;
goto v___jp_46_;
}
else
{
lean_object* v_a_60_; lean_object* v___x_61_; 
v_a_60_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_60_);
lean_dec_ref_known(v___y_58_, 1);
v___x_61_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_61_) == 0)
{
lean_object* v___x_63_; uint8_t v_isShared_64_; uint8_t v_isSharedCheck_68_; 
v_isSharedCheck_68_ = !lean_is_exclusive(v___x_61_);
if (v_isSharedCheck_68_ == 0)
{
lean_object* v_unused_69_; 
v_unused_69_ = lean_ctor_get(v___x_61_, 0);
lean_dec(v_unused_69_);
v___x_63_ = v___x_61_;
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
else
{
lean_dec(v___x_61_);
v___x_63_ = lean_box(0);
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
v_resetjp_62_:
{
lean_object* v___x_66_; 
if (v_isShared_64_ == 0)
{
lean_ctor_set_tag(v___x_63_, 1);
lean_ctor_set(v___x_63_, 0, v_a_60_);
v___x_66_ = v___x_63_;
goto v_reusejp_65_;
}
else
{
lean_object* v_reuseFailAlloc_67_; 
v_reuseFailAlloc_67_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_67_, 0, v_a_60_);
v___x_66_ = v_reuseFailAlloc_67_;
goto v_reusejp_65_;
}
v_reusejp_65_:
{
return v___x_66_;
}
}
}
else
{
lean_dec(v_a_60_);
return v___x_61_;
}
}
}
}
else
{
lean_object* v_a_165_; lean_object* v___x_167_; uint8_t v_isShared_168_; uint8_t v_isSharedCheck_172_; 
v_a_165_ = lean_ctor_get(v___x_44_, 0);
v_isSharedCheck_172_ = !lean_is_exclusive(v___x_44_);
if (v_isSharedCheck_172_ == 0)
{
v___x_167_ = v___x_44_;
v_isShared_168_ = v_isSharedCheck_172_;
goto v_resetjp_166_;
}
else
{
lean_inc(v_a_165_);
lean_dec(v___x_44_);
v___x_167_ = lean_box(0);
v_isShared_168_ = v_isSharedCheck_172_;
goto v_resetjp_166_;
}
v_resetjp_166_:
{
lean_object* v___x_170_; 
if (v_isShared_168_ == 0)
{
v___x_170_ = v___x_167_;
goto v_reusejp_169_;
}
else
{
lean_object* v_reuseFailAlloc_171_; 
v_reuseFailAlloc_171_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_171_, 0, v_a_165_);
v___x_170_ = v_reuseFailAlloc_171_;
goto v_reusejp_169_;
}
v_reusejp_169_:
{
return v___x_170_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object* v_a_173_){
_start:
{
lean_object* v_res_174_; 
v_res_174_ = lp_allocation__audit_generatedOnce();
return v_res_174_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure(){
_start:
{
uint64_t v___x_176_; lean_object* v___x_177_; 
v___x_176_ = 9223372036854775807ULL;
v___x_177_ = vastitas_storage_new(v___x_176_);
if (lean_obj_tag(v___x_177_) == 0)
{
lean_object* v_a_178_; lean_object* v_a_180_; lean_object* v___y_191_; uint32_t v___x_203_; uint8_t v___x_204_; uint64_t v___x_205_; lean_object* v___x_206_; 
v_a_178_ = lean_ctor_get(v___x_177_, 0);
lean_inc(v_a_178_);
lean_dec_ref_known(v___x_177_, 1);
v___x_203_ = 0;
v___x_204_ = 1;
v___x_205_ = 33284ULL;
v___x_206_ = vastitas_storage_allocate(v_a_178_, v___x_203_, v___x_204_, v___x_205_);
if (lean_obj_tag(v___x_206_) == 0)
{
uint64_t v___x_207_; uint64_t v___x_208_; uint8_t v___x_209_; uint64_t v___x_210_; uint64_t v___x_211_; lean_object* v___x_212_; 
lean_dec_ref_known(v___x_206_, 1);
v___x_207_ = 0ULL;
v___x_208_ = 1ULL;
v___x_209_ = 0;
v___x_210_ = 13842939354630062080ULL;
v___x_211_ = 4613937818241073152ULL;
v___x_212_ = vastitas_storage_fill(v_a_178_, v___x_203_, v___x_207_, v___x_205_, v___x_208_, v___x_205_, v___x_209_, v___x_204_, v___x_210_, v___x_211_);
if (lean_obj_tag(v___x_212_) == 0)
{
uint64_t v___x_213_; uint64_t v___x_214_; uint64_t v___x_215_; uint64_t v___x_216_; uint64_t v___x_217_; uint64_t v___x_218_; lean_object* v___x_219_; 
lean_dec_ref_known(v___x_212_, 1);
v___x_213_ = 16ULL;
v___x_214_ = 24ULL;
v___x_215_ = 1280ULL;
v___x_216_ = 26ULL;
v___x_217_ = 4593671619917905920ULL;
v___x_218_ = 4598175219545276416ULL;
v___x_219_ = vastitas_storage_fill(v_a_178_, v___x_203_, v___x_213_, v___x_214_, v___x_215_, v___x_216_, v___x_209_, v___x_204_, v___x_217_, v___x_218_);
if (lean_obj_tag(v___x_219_) == 0)
{
uint64_t v___x_220_; uint64_t v___x_221_; lean_object* v___x_222_; 
lean_dec_ref_known(v___x_219_, 1);
v___x_220_ = 4607182418800017408ULL;
v___x_221_ = 13826050856027422720ULL;
v___x_222_ = vastitas_storage_store(v_a_178_, v___x_203_, v___x_213_, v___x_214_, v___x_215_, v___x_216_, v___x_209_, v___x_207_, v___x_207_, v___x_204_, v___x_220_, v___x_221_);
if (lean_obj_tag(v___x_222_) == 0)
{
uint64_t v___x_223_; uint64_t v___x_224_; lean_object* v___x_225_; 
lean_dec_ref_known(v___x_222_, 1);
v___x_223_ = 23ULL;
v___x_224_ = 4604930618986332160ULL;
v___x_225_ = vastitas_storage_store(v_a_178_, v___x_203_, v___x_213_, v___x_214_, v___x_215_, v___x_216_, v___x_209_, v___x_223_, v___x_208_, v___x_204_, v___x_221_, v___x_224_);
if (lean_obj_tag(v___x_225_) == 0)
{
uint32_t v___x_226_; uint64_t v___x_227_; lean_object* v___x_228_; 
lean_dec_ref_known(v___x_225_, 1);
v___x_226_ = 1;
v___x_227_ = 2069ULL;
v___x_228_ = vastitas_storage_allocate(v_a_178_, v___x_226_, v___x_204_, v___x_227_);
if (lean_obj_tag(v___x_228_) == 0)
{
lean_object* v___x_229_; 
lean_dec_ref_known(v___x_228_, 1);
v___x_229_ = vastitas_storage_fill(v_a_178_, v___x_226_, v___x_207_, v___x_227_, v___x_208_, v___x_227_, v___x_209_, v___x_204_, v___x_210_, v___x_211_);
if (lean_obj_tag(v___x_229_) == 0)
{
uint64_t v___x_230_; uint64_t v___x_231_; uint64_t v___x_232_; uint64_t v___x_233_; uint64_t v___x_234_; lean_object* v___x_235_; 
lean_dec_ref_known(v___x_229_, 1);
v___x_230_ = 32ULL;
v___x_231_ = 40ULL;
v___x_232_ = 48ULL;
v___x_233_ = 43ULL;
v___x_234_ = 13821547256400052224ULL;
v___x_235_ = vastitas_storage_fill(v_a_178_, v___x_226_, v___x_230_, v___x_231_, v___x_232_, v___x_233_, v___x_209_, v___x_204_, v___x_234_, v___x_217_);
if (lean_obj_tag(v___x_235_) == 0)
{
uint64_t v___x_236_; uint64_t v___x_237_; lean_object* v___x_238_; 
lean_dec_ref_known(v___x_235_, 1);
v___x_236_ = 47ULL;
v___x_237_ = 4602678819172646912ULL;
v___x_238_ = vastitas_storage_store(v_a_178_, v___x_226_, v___x_230_, v___x_231_, v___x_232_, v___x_233_, v___x_209_, v___x_207_, v___x_236_, v___x_204_, v___x_237_, v___x_218_);
if (lean_obj_tag(v___x_238_) == 0)
{
uint64_t v___x_239_; uint64_t v___x_240_; lean_object* v___x_241_; 
lean_dec_ref_known(v___x_238_, 1);
v___x_239_ = 39ULL;
v___x_240_ = 13828302655841107968ULL;
v___x_241_ = vastitas_storage_store(v_a_178_, v___x_226_, v___x_230_, v___x_231_, v___x_232_, v___x_233_, v___x_209_, v___x_239_, v___x_207_, v___x_204_, v___x_240_, v___x_221_);
if (lean_obj_tag(v___x_241_) == 0)
{
uint32_t v___x_242_; uint64_t v___x_243_; lean_object* v___x_244_; 
lean_dec_ref_known(v___x_241_, 1);
v___x_242_ = 2;
v___x_243_ = 2022ULL;
v___x_244_ = vastitas_storage_allocate(v_a_178_, v___x_242_, v___x_204_, v___x_243_);
if (lean_obj_tag(v___x_244_) == 0)
{
lean_object* v___x_245_; 
lean_dec_ref_known(v___x_244_, 1);
v___x_245_ = vastitas_storage_fill(v_a_178_, v___x_242_, v___x_207_, v___x_243_, v___x_208_, v___x_243_, v___x_209_, v___x_204_, v___x_210_, v___x_211_);
if (lean_obj_tag(v___x_245_) == 0)
{
uint64_t v___x_246_; uint64_t v___x_247_; lean_object* v___x_248_; 
lean_dec_ref_known(v___x_245_, 1);
v___x_246_ = 56ULL;
v___x_247_ = 36ULL;
v___x_248_ = vastitas_storage_fill(v_a_178_, v___x_242_, v___x_232_, v___x_230_, v___x_246_, v___x_247_, v___x_209_, v___x_204_, v___x_237_, v___x_234_);
if (lean_obj_tag(v___x_248_) == 0)
{
uint64_t v___x_249_; lean_object* v___x_250_; 
lean_dec_ref_known(v___x_248_, 1);
v___x_249_ = 31ULL;
v___x_250_ = vastitas_storage_store(v_a_178_, v___x_242_, v___x_232_, v___x_230_, v___x_246_, v___x_247_, v___x_209_, v___x_249_, v___x_207_, v___x_204_, v___x_234_, v___x_237_);
if (lean_obj_tag(v___x_250_) == 0)
{
uint64_t v___x_251_; lean_object* v___x_252_; 
lean_dec_ref_known(v___x_250_, 1);
v___x_251_ = 55ULL;
v___x_252_ = vastitas_storage_store(v_a_178_, v___x_242_, v___x_232_, v___x_230_, v___x_246_, v___x_247_, v___x_209_, v___x_207_, v___x_251_, v___x_204_, v___x_224_, v___x_240_);
if (lean_obj_tag(v___x_252_) == 0)
{
uint32_t v___x_253_; uint64_t v___x_254_; lean_object* v___x_255_; 
lean_dec_ref_known(v___x_252_, 1);
v___x_253_ = 3;
v___x_254_ = 37130ULL;
v___x_255_ = vastitas_storage_allocate(v_a_178_, v___x_253_, v___x_204_, v___x_254_);
if (lean_obj_tag(v___x_255_) == 0)
{
lean_object* v___x_256_; 
lean_dec_ref_known(v___x_255_, 1);
v___x_256_ = vastitas_storage_fill(v_a_178_, v___x_253_, v___x_207_, v___x_254_, v___x_208_, v___x_254_, v___x_209_, v___x_204_, v___x_210_, v___x_211_);
if (lean_obj_tag(v___x_256_) == 0)
{
uint32_t v___x_257_; uint64_t v___x_258_; lean_object* v___x_259_; 
lean_dec_ref_known(v___x_256_, 1);
v___x_257_ = 4;
v___x_258_ = 37160ULL;
v___x_259_ = vastitas_storage_allocate(v_a_178_, v___x_257_, v___x_204_, v___x_258_);
if (lean_obj_tag(v___x_259_) == 0)
{
lean_object* v___x_260_; 
lean_dec_ref_known(v___x_259_, 1);
v___x_260_ = vastitas_storage_fill(v_a_178_, v___x_257_, v___x_207_, v___x_258_, v___x_208_, v___x_258_, v___x_209_, v___x_204_, v___x_210_, v___x_211_);
if (lean_obj_tag(v___x_260_) == 0)
{
uint32_t v___x_261_; uint64_t v___x_262_; lean_object* v___x_263_; 
lean_dec_ref_known(v___x_260_, 1);
v___x_261_ = 5;
v___x_262_ = 64913ULL;
v___x_263_ = vastitas_storage_allocate(v_a_178_, v___x_261_, v___x_204_, v___x_262_);
if (lean_obj_tag(v___x_263_) == 0)
{
lean_object* v___x_264_; 
lean_dec_ref_known(v___x_263_, 1);
v___x_264_ = vastitas_storage_fill(v_a_178_, v___x_261_, v___x_207_, v___x_262_, v___x_208_, v___x_262_, v___x_209_, v___x_204_, v___x_210_, v___x_211_);
if (lean_obj_tag(v___x_264_) == 0)
{
uint64_t v___x_265_; uint64_t v___x_266_; uint64_t v___x_267_; lean_object* v___x_268_; 
lean_dec_ref_known(v___x_264_, 1);
v___x_265_ = 64ULL;
v___x_266_ = 768ULL;
v___x_267_ = 773ULL;
v___x_268_ = vastitas_storage_pack3(v_a_178_, v___x_203_, v___x_213_, v___x_214_, v___x_215_, v___x_216_, v___x_209_, v___x_253_, v___x_265_, v___x_266_, v___x_231_, v___x_267_, v___x_209_, v___x_214_, v___x_231_, v___x_230_);
if (lean_obj_tag(v___x_268_) == 0)
{
uint64_t v___x_269_; uint64_t v___x_270_; uint8_t v___x_271_; lean_object* v___x_272_; 
lean_dec_ref_known(v___x_268_, 1);
v___x_269_ = 80ULL;
v___x_270_ = 774ULL;
v___x_271_ = 0;
v___x_272_ = vastitas_gemm_execute(v_a_178_, v___x_253_, v___x_265_, v___x_266_, v___x_231_, v___x_267_, v___x_209_, v___x_209_, v___x_226_, v___x_230_, v___x_231_, v___x_232_, v___x_233_, v___x_209_, v___x_209_, v___x_257_, v___x_269_, v___x_266_, v___x_232_, v___x_270_, v___x_209_, v___x_271_);
if (lean_obj_tag(v___x_272_) == 0)
{
uint64_t v___x_273_; uint64_t v___x_274_; uint64_t v___x_275_; uint64_t v___x_276_; lean_object* v___x_277_; 
lean_dec_ref_known(v___x_272_, 1);
v___x_273_ = 112ULL;
v___x_274_ = 1152ULL;
v___x_275_ = 1160ULL;
v___x_276_ = 42ULL;
v___x_277_ = vastitas_storage_regroup3(v_a_178_, v___x_257_, v___x_269_, v___x_266_, v___x_232_, v___x_270_, v___x_209_, v___x_253_, v___x_273_, v___x_274_, v___x_230_, v___x_275_, v___x_209_, v___x_214_, v___x_230_, v___x_232_, v___x_232_, v___x_276_);
if (lean_obj_tag(v___x_277_) == 0)
{
uint64_t v___x_278_; uint64_t v___x_279_; lean_object* v___x_280_; 
lean_dec_ref_known(v___x_277_, 1);
v___x_278_ = 96ULL;
v___x_279_ = 1159ULL;
v___x_280_ = vastitas_gemm_execute(v_a_178_, v___x_253_, v___x_273_, v___x_274_, v___x_230_, v___x_275_, v___x_209_, v___x_209_, v___x_242_, v___x_232_, v___x_230_, v___x_246_, v___x_247_, v___x_209_, v___x_209_, v___x_261_, v___x_278_, v___x_274_, v___x_246_, v___x_279_, v___x_209_, v___x_271_);
if (lean_obj_tag(v___x_280_) == 0)
{
uint64_t v___x_281_; uint64_t v___x_282_; lean_object* v___x_283_; 
lean_dec_ref_known(v___x_280_, 1);
v___x_281_ = 13855852019186663425ULL;
v___x_282_ = 13847480337652776960ULL;
v___x_283_ = vastitas_storage_expect(v_a_178_, v___x_261_, v___x_278_, v___x_274_, v___x_246_, v___x_279_, v___x_209_, v___x_207_, v___x_207_, v___x_204_, v___x_281_, v___x_282_);
if (lean_obj_tag(v___x_283_) == 0)
{
uint64_t v___x_284_; uint64_t v___x_285_; lean_object* v___x_286_; 
lean_dec_ref_known(v___x_283_, 1);
v___x_284_ = 13856569450523787264ULL;
v___x_285_ = 13847183469513277440ULL;
v___x_286_ = vastitas_storage_expect(v_a_178_, v___x_261_, v___x_278_, v___x_274_, v___x_246_, v___x_279_, v___x_209_, v___x_223_, v___x_251_, v___x_204_, v___x_284_, v___x_285_);
if (lean_obj_tag(v___x_286_) == 0)
{
uint64_t v___x_287_; uint64_t v___x_288_; uint64_t v___x_289_; lean_object* v___x_290_; 
lean_dec_ref_known(v___x_286_, 1);
v___x_287_ = 1151ULL;
v___x_288_ = 13855506772535541760ULL;
v___x_289_ = 13844008079932260352ULL;
v___x_290_ = vastitas_storage_expect(v_a_178_, v___x_261_, v___x_278_, v___x_274_, v___x_246_, v___x_279_, v___x_209_, v___x_287_, v___x_207_, v___x_204_, v___x_288_, v___x_289_);
if (lean_obj_tag(v___x_290_) == 0)
{
lean_object* v___x_291_; 
lean_dec_ref_known(v___x_290_, 1);
v___x_291_ = vastitas_storage_drop(v_a_178_, v___x_261_);
if (lean_obj_tag(v___x_291_) == 0)
{
lean_object* v___x_292_; 
lean_dec_ref_known(v___x_291_, 1);
v___x_292_ = vastitas_storage_drop(v_a_178_, v___x_257_);
if (lean_obj_tag(v___x_292_) == 0)
{
lean_object* v___x_293_; 
lean_dec_ref_known(v___x_292_, 1);
v___x_293_ = vastitas_storage_drop(v_a_178_, v___x_253_);
if (lean_obj_tag(v___x_293_) == 0)
{
lean_object* v___x_294_; 
lean_dec_ref_known(v___x_293_, 1);
v___x_294_ = vastitas_storage_drop(v_a_178_, v___x_242_);
if (lean_obj_tag(v___x_294_) == 0)
{
lean_object* v___x_295_; 
lean_dec_ref_known(v___x_294_, 1);
v___x_295_ = vastitas_storage_drop(v_a_178_, v___x_226_);
if (lean_obj_tag(v___x_295_) == 0)
{
lean_object* v___x_296_; 
lean_dec_ref_known(v___x_295_, 1);
v___x_296_ = vastitas_storage_drop(v_a_178_, v___x_203_);
if (lean_obj_tag(v___x_296_) == 0)
{
lean_object* v___x_297_; 
lean_dec_ref_known(v___x_296_, 1);
v___x_297_ = lean_box(0);
v_a_180_ = v___x_297_;
goto v___jp_179_;
}
else
{
v___y_191_ = v___x_296_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_295_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_294_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_293_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_292_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_291_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_290_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_286_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_283_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_280_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_277_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_272_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_268_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_264_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_263_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_260_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_259_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_256_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_255_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_252_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_250_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_248_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_245_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_244_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_241_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_238_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_235_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_229_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_228_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_225_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_222_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_219_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_212_;
goto v___jp_190_;
}
}
else
{
v___y_191_ = v___x_206_;
goto v___jp_190_;
}
v___jp_179_:
{
lean_object* v___x_181_; 
v___x_181_ = vastitas_storage_close(v_a_178_);
lean_dec(v_a_178_);
if (lean_obj_tag(v___x_181_) == 0)
{
lean_object* v___x_183_; uint8_t v_isShared_184_; uint8_t v_isSharedCheck_188_; 
v_isSharedCheck_188_ = !lean_is_exclusive(v___x_181_);
if (v_isSharedCheck_188_ == 0)
{
lean_object* v_unused_189_; 
v_unused_189_ = lean_ctor_get(v___x_181_, 0);
lean_dec(v_unused_189_);
v___x_183_ = v___x_181_;
v_isShared_184_ = v_isSharedCheck_188_;
goto v_resetjp_182_;
}
else
{
lean_dec(v___x_181_);
v___x_183_ = lean_box(0);
v_isShared_184_ = v_isSharedCheck_188_;
goto v_resetjp_182_;
}
v_resetjp_182_:
{
lean_object* v___x_186_; 
if (v_isShared_184_ == 0)
{
lean_ctor_set(v___x_183_, 0, v_a_180_);
v___x_186_ = v___x_183_;
goto v_reusejp_185_;
}
else
{
lean_object* v_reuseFailAlloc_187_; 
v_reuseFailAlloc_187_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_187_, 0, v_a_180_);
v___x_186_ = v_reuseFailAlloc_187_;
goto v_reusejp_185_;
}
v_reusejp_185_:
{
return v___x_186_;
}
}
}
else
{
return v___x_181_;
}
}
v___jp_190_:
{
if (lean_obj_tag(v___y_191_) == 0)
{
lean_object* v_a_192_; 
v_a_192_ = lean_ctor_get(v___y_191_, 0);
lean_inc(v_a_192_);
lean_dec_ref_known(v___y_191_, 1);
v_a_180_ = v_a_192_;
goto v___jp_179_;
}
else
{
lean_object* v_a_193_; lean_object* v___x_194_; 
v_a_193_ = lean_ctor_get(v___y_191_, 0);
lean_inc(v_a_193_);
lean_dec_ref_known(v___y_191_, 1);
v___x_194_ = vastitas_storage_close(v_a_178_);
lean_dec(v_a_178_);
if (lean_obj_tag(v___x_194_) == 0)
{
lean_object* v___x_196_; uint8_t v_isShared_197_; uint8_t v_isSharedCheck_201_; 
v_isSharedCheck_201_ = !lean_is_exclusive(v___x_194_);
if (v_isSharedCheck_201_ == 0)
{
lean_object* v_unused_202_; 
v_unused_202_ = lean_ctor_get(v___x_194_, 0);
lean_dec(v_unused_202_);
v___x_196_ = v___x_194_;
v_isShared_197_ = v_isSharedCheck_201_;
goto v_resetjp_195_;
}
else
{
lean_dec(v___x_194_);
v___x_196_ = lean_box(0);
v_isShared_197_ = v_isSharedCheck_201_;
goto v_resetjp_195_;
}
v_resetjp_195_:
{
lean_object* v___x_199_; 
if (v_isShared_197_ == 0)
{
lean_ctor_set_tag(v___x_196_, 1);
lean_ctor_set(v___x_196_, 0, v_a_193_);
v___x_199_ = v___x_196_;
goto v_reusejp_198_;
}
else
{
lean_object* v_reuseFailAlloc_200_; 
v_reuseFailAlloc_200_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_200_, 0, v_a_193_);
v___x_199_ = v_reuseFailAlloc_200_;
goto v_reusejp_198_;
}
v_reusejp_198_:
{
return v___x_199_;
}
}
}
else
{
lean_dec(v_a_193_);
return v___x_194_;
}
}
}
}
else
{
lean_object* v_a_298_; lean_object* v___x_300_; uint8_t v_isShared_301_; uint8_t v_isSharedCheck_305_; 
v_a_298_ = lean_ctor_get(v___x_177_, 0);
v_isSharedCheck_305_ = !lean_is_exclusive(v___x_177_);
if (v_isSharedCheck_305_ == 0)
{
v___x_300_ = v___x_177_;
v_isShared_301_ = v_isSharedCheck_305_;
goto v_resetjp_299_;
}
else
{
lean_inc(v_a_298_);
lean_dec(v___x_177_);
v___x_300_ = lean_box(0);
v_isShared_301_ = v_isSharedCheck_305_;
goto v_resetjp_299_;
}
v_resetjp_299_:
{
lean_object* v___x_303_; 
if (v_isShared_301_ == 0)
{
v___x_303_ = v___x_300_;
goto v_reusejp_302_;
}
else
{
lean_object* v_reuseFailAlloc_304_; 
v_reuseFailAlloc_304_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_304_, 0, v_a_298_);
v___x_303_ = v_reuseFailAlloc_304_;
goto v_reusejp_302_;
}
v_reusejp_302_:
{
return v___x_303_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object* v_a_306_){
_start:
{
lean_object* v_res_307_; 
v_res_307_ = lp_allocation__audit_generatedFailure();
return v_res_307_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object* v_phase_310_, lean_object* v_a_00___x40___internal___hyg_311_){
_start:
{
uint32_t v_phase_boxed_312_; lean_object* v_res_313_; 
v_phase_boxed_312_ = lean_unbox_uint32(v_phase_310_);
lean_dec(v_phase_310_);
v_res_313_ = audit_mark_lean(v_phase_boxed_312_);
return v_res_313_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object* v_a_314_, lean_object* v_scope_315_, lean_object* v_range_316_, lean_object* v_b_317_, lean_object* v_i_318_){
_start:
{
lean_object* v_stop_320_; lean_object* v_step_321_; uint8_t v___x_322_; 
v_stop_320_ = lean_ctor_get(v_range_316_, 1);
v_step_321_ = lean_ctor_get(v_range_316_, 2);
v___x_322_ = lean_nat_dec_lt(v_i_318_, v_stop_320_);
if (v___x_322_ == 0)
{
lean_object* v___x_323_; 
lean_dec(v_i_318_);
v___x_323_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_323_, 0, v_b_317_);
return v___x_323_;
}
else
{
uint32_t v___x_324_; uint64_t v___x_325_; uint64_t v___x_326_; uint64_t v___x_327_; uint64_t v___x_328_; lean_object* v___x_329_; uint8_t v___x_330_; uint32_t v___x_331_; uint64_t v___x_332_; uint64_t v___x_333_; uint32_t v___x_334_; uint64_t v___x_335_; uint64_t v___x_336_; uint32_t v___x_337_; uint32_t v___x_338_; uint64_t v___x_339_; uint64_t v___x_340_; uint32_t v___x_341_; lean_object* v___x_342_; uint64_t v___x_343_; uint64_t v___x_344_; uint64_t v___x_345_; lean_object* v___x_346_; 
v___x_324_ = 0;
v___x_325_ = 16ULL;
v___x_326_ = 24ULL;
v___x_327_ = 1280ULL;
v___x_328_ = 26ULL;
v___x_329_ = lean_unsigned_to_nat(0u);
v___x_330_ = lean_nat_dec_eq(v_scope_315_, v___x_329_);
v___x_331_ = 3;
v___x_332_ = 40ULL;
v___x_333_ = 32ULL;
v___x_334_ = 1;
v___x_335_ = 48ULL;
v___x_336_ = 43ULL;
v___x_337_ = 4;
v___x_338_ = 2;
v___x_339_ = 56ULL;
v___x_340_ = 36ULL;
v___x_341_ = 5;
v___x_342_ = lean_box(0);
v___x_343_ = 64ULL;
v___x_344_ = 768ULL;
v___x_345_ = 773ULL;
v___x_346_ = vastitas_storage_pack3(v_a_314_, v___x_324_, v___x_325_, v___x_326_, v___x_327_, v___x_328_, v___x_330_, v___x_331_, v___x_343_, v___x_344_, v___x_332_, v___x_345_, v___x_330_, v___x_326_, v___x_332_, v___x_333_);
if (lean_obj_tag(v___x_346_) == 0)
{
uint64_t v___x_347_; uint64_t v___x_348_; uint8_t v___x_349_; lean_object* v___x_350_; 
lean_dec_ref_known(v___x_346_, 1);
v___x_347_ = 80ULL;
v___x_348_ = 774ULL;
v___x_349_ = 0;
v___x_350_ = vastitas_gemm_execute(v_a_314_, v___x_331_, v___x_343_, v___x_344_, v___x_332_, v___x_345_, v___x_330_, v___x_330_, v___x_334_, v___x_333_, v___x_332_, v___x_335_, v___x_336_, v___x_330_, v___x_330_, v___x_337_, v___x_347_, v___x_344_, v___x_335_, v___x_348_, v___x_330_, v___x_349_);
if (lean_obj_tag(v___x_350_) == 0)
{
uint64_t v___x_351_; uint64_t v___x_352_; uint64_t v___x_353_; uint64_t v___x_354_; lean_object* v___x_355_; 
lean_dec_ref_known(v___x_350_, 1);
v___x_351_ = 112ULL;
v___x_352_ = 1152ULL;
v___x_353_ = 1160ULL;
v___x_354_ = 42ULL;
v___x_355_ = vastitas_storage_regroup3(v_a_314_, v___x_337_, v___x_347_, v___x_344_, v___x_335_, v___x_348_, v___x_330_, v___x_331_, v___x_351_, v___x_352_, v___x_333_, v___x_353_, v___x_330_, v___x_326_, v___x_333_, v___x_335_, v___x_335_, v___x_354_);
if (lean_obj_tag(v___x_355_) == 0)
{
uint64_t v___x_356_; uint64_t v___x_357_; lean_object* v___x_358_; 
lean_dec_ref_known(v___x_355_, 1);
v___x_356_ = 96ULL;
v___x_357_ = 1159ULL;
v___x_358_ = vastitas_gemm_execute(v_a_314_, v___x_331_, v___x_351_, v___x_352_, v___x_333_, v___x_353_, v___x_330_, v___x_330_, v___x_338_, v___x_335_, v___x_333_, v___x_339_, v___x_340_, v___x_330_, v___x_330_, v___x_341_, v___x_356_, v___x_352_, v___x_339_, v___x_357_, v___x_330_, v___x_349_);
if (lean_obj_tag(v___x_358_) == 0)
{
lean_object* v___x_359_; 
lean_dec_ref_known(v___x_358_, 1);
v___x_359_ = lean_nat_add(v_i_318_, v_step_321_);
lean_dec(v_i_318_);
v_b_317_ = v___x_342_;
v_i_318_ = v___x_359_;
goto _start;
}
else
{
lean_dec(v_i_318_);
return v___x_358_;
}
}
else
{
lean_dec(v_i_318_);
return v___x_355_;
}
}
else
{
lean_dec(v_i_318_);
return v___x_350_;
}
}
else
{
lean_dec(v_i_318_);
return v___x_346_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object* v_a_361_, lean_object* v_scope_362_, lean_object* v_range_363_, lean_object* v_b_364_, lean_object* v_i_365_, lean_object* v___y_366_){
_start:
{
lean_object* v_res_367_; 
v_res_367_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_361_, v_scope_362_, v_range_363_, v_b_364_, v_i_365_);
lean_dec_ref(v_range_363_);
lean_dec(v_scope_362_);
lean_dec(v_a_361_);
return v_res_367_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object* v_range_368_, lean_object* v_b_369_, lean_object* v_i_370_){
_start:
{
lean_object* v_stop_372_; lean_object* v_step_373_; uint8_t v___x_374_; 
v_stop_372_ = lean_ctor_get(v_range_368_, 1);
v_step_373_ = lean_ctor_get(v_range_368_, 2);
v___x_374_ = lean_nat_dec_lt(v_i_370_, v_stop_372_);
if (v___x_374_ == 0)
{
lean_object* v___x_375_; 
lean_dec(v_i_370_);
v___x_375_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_375_, 0, v_b_369_);
return v___x_375_;
}
else
{
lean_object* v___x_376_; lean_object* v___x_377_; 
v___x_376_ = lean_box(0);
v___x_377_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_377_) == 0)
{
lean_object* v___x_378_; 
lean_dec_ref_known(v___x_377_, 1);
v___x_378_ = lean_nat_add(v_i_370_, v_step_373_);
lean_dec(v_i_370_);
v_b_369_ = v___x_376_;
v_i_370_ = v___x_378_;
goto _start;
}
else
{
lean_dec(v_i_370_);
return v___x_377_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object* v_range_380_, lean_object* v_b_381_, lean_object* v_i_382_, lean_object* v___y_383_){
_start:
{
lean_object* v_res_384_; 
v_res_384_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_380_, v_b_381_, v_i_382_);
lean_dec_ref(v_range_380_);
return v_res_384_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_393_){
_start:
{
lean_object* v___x_395_; lean_object* v___x_396_; lean_object* v_impl_397_; lean_object* v___x_398_; lean_object* v___x_399_; lean_object* v___x_400_; lean_object* v___x_401_; lean_object* v_scope_402_; lean_object* v___x_403_; lean_object* v___x_404_; lean_object* v___x_405_; lean_object* v___x_406_; lean_object* v_reps_407_; lean_object* v___x_408_; lean_object* v___x_409_; lean_object* v___x_410_; uint8_t v_verify_411_; uint32_t v___x_412_; lean_object* v___x_413_; 
v___x_395_ = ((lean_object*)(lp_allocation__audit_main___closed__0));
v___x_396_ = lean_unsigned_to_nat(0u);
v_impl_397_ = l_List_get_x21Internal___redArg(v___x_395_, v_args_393_, v___x_396_);
v___x_398_ = lean_unsigned_to_nat(1u);
v___x_399_ = l_List_get_x21Internal___redArg(v___x_395_, v_args_393_, v___x_398_);
v___x_400_ = lean_string_utf8_byte_size(v___x_399_);
v___x_401_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_401_, 0, v___x_399_);
lean_ctor_set(v___x_401_, 1, v___x_396_);
lean_ctor_set(v___x_401_, 2, v___x_400_);
v_scope_402_ = l_String_Slice_toNat_x21(v___x_401_);
lean_dec_ref_known(v___x_401_, 3);
v___x_403_ = lean_unsigned_to_nat(2u);
v___x_404_ = l_List_get_x21Internal___redArg(v___x_395_, v_args_393_, v___x_403_);
v___x_405_ = lean_string_utf8_byte_size(v___x_404_);
v___x_406_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_406_, 0, v___x_404_);
lean_ctor_set(v___x_406_, 1, v___x_396_);
lean_ctor_set(v___x_406_, 2, v___x_405_);
v_reps_407_ = l_String_Slice_toNat_x21(v___x_406_);
lean_dec_ref_known(v___x_406_, 3);
v___x_408_ = lean_unsigned_to_nat(3u);
v___x_409_ = l_List_get_x21Internal___redArg(v___x_395_, v_args_393_, v___x_408_);
lean_dec(v_args_393_);
v___x_410_ = ((lean_object*)(lp_allocation__audit_main___closed__1));
v_verify_411_ = lean_string_dec_eq(v___x_409_, v___x_410_);
lean_dec(v___x_409_);
v___x_412_ = 1;
v___x_413_ = audit_mark_lean(v___x_412_);
if (lean_obj_tag(v___x_413_) == 0)
{
lean_object* v___x_414_; 
lean_dec_ref_known(v___x_413_, 1);
v___x_414_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_414_) == 0)
{
uint32_t v___x_415_; lean_object* v___x_416_; 
lean_dec_ref_known(v___x_414_, 1);
v___x_415_ = 2;
v___x_416_ = audit_mark_lean(v___x_415_);
if (lean_obj_tag(v___x_416_) == 0)
{
lean_object* v___x_417_; uint8_t v___x_418_; 
lean_dec_ref_known(v___x_416_, 1);
v___x_417_ = ((lean_object*)(lp_allocation__audit_main___closed__2));
v___x_418_ = lean_string_dec_eq(v_impl_397_, v___x_417_);
if (v___x_418_ == 0)
{
lean_object* v___x_419_; uint8_t v___x_420_; 
v___x_419_ = ((lean_object*)(lp_allocation__audit_main___closed__3));
v___x_420_ = lean_string_dec_eq(v_impl_397_, v___x_419_);
lean_dec(v_impl_397_);
if (v___x_420_ == 0)
{
uint8_t v___x_421_; 
v___x_421_ = lean_nat_dec_eq(v_scope_402_, v___x_396_);
if (v___x_421_ == 0)
{
uint64_t v___x_422_; lean_object* v___x_423_; 
v___x_422_ = 9223372036854775807ULL;
v___x_423_ = vastitas_storage_new(v___x_422_);
if (lean_obj_tag(v___x_423_) == 0)
{
lean_object* v_a_424_; lean_object* v___y_426_; uint32_t v___x_439_; uint8_t v___x_440_; uint64_t v___x_441_; lean_object* v___x_442_; 
v_a_424_ = lean_ctor_get(v___x_423_, 0);
lean_inc(v_a_424_);
lean_dec_ref_known(v___x_423_, 1);
v___x_439_ = 0;
v___x_440_ = 1;
v___x_441_ = 33284ULL;
v___x_442_ = vastitas_storage_allocate(v_a_424_, v___x_439_, v___x_440_, v___x_441_);
if (lean_obj_tag(v___x_442_) == 0)
{
uint64_t v___x_443_; uint64_t v___x_444_; uint64_t v___x_445_; uint64_t v___x_446_; lean_object* v___x_447_; 
lean_dec_ref_known(v___x_442_, 1);
v___x_443_ = 0ULL;
v___x_444_ = 1ULL;
v___x_445_ = 13842939354630062080ULL;
v___x_446_ = 4613937818241073152ULL;
v___x_447_ = vastitas_storage_fill(v_a_424_, v___x_439_, v___x_443_, v___x_441_, v___x_444_, v___x_441_, v___x_421_, v___x_440_, v___x_445_, v___x_446_);
if (lean_obj_tag(v___x_447_) == 0)
{
uint64_t v___x_448_; uint64_t v___x_449_; uint64_t v___x_450_; uint64_t v___x_451_; uint64_t v___x_452_; uint64_t v___x_453_; lean_object* v___x_454_; 
lean_dec_ref_known(v___x_447_, 1);
v___x_448_ = 16ULL;
v___x_449_ = 24ULL;
v___x_450_ = 1280ULL;
v___x_451_ = 26ULL;
v___x_452_ = 4593671619917905920ULL;
v___x_453_ = 4598175219545276416ULL;
v___x_454_ = vastitas_storage_fill(v_a_424_, v___x_439_, v___x_448_, v___x_449_, v___x_450_, v___x_451_, v___x_421_, v___x_440_, v___x_452_, v___x_453_);
if (lean_obj_tag(v___x_454_) == 0)
{
uint64_t v___x_455_; uint64_t v___x_456_; lean_object* v___x_457_; 
lean_dec_ref_known(v___x_454_, 1);
v___x_455_ = 4607182418800017408ULL;
v___x_456_ = 13826050856027422720ULL;
v___x_457_ = vastitas_storage_store(v_a_424_, v___x_439_, v___x_448_, v___x_449_, v___x_450_, v___x_451_, v___x_421_, v___x_443_, v___x_443_, v___x_440_, v___x_455_, v___x_456_);
if (lean_obj_tag(v___x_457_) == 0)
{
uint64_t v___x_458_; uint64_t v___x_459_; lean_object* v___x_460_; 
lean_dec_ref_known(v___x_457_, 1);
v___x_458_ = 23ULL;
v___x_459_ = 4604930618986332160ULL;
v___x_460_ = vastitas_storage_store(v_a_424_, v___x_439_, v___x_448_, v___x_449_, v___x_450_, v___x_451_, v___x_421_, v___x_458_, v___x_444_, v___x_440_, v___x_456_, v___x_459_);
if (lean_obj_tag(v___x_460_) == 0)
{
uint64_t v___x_461_; lean_object* v___x_462_; 
lean_dec_ref_known(v___x_460_, 1);
v___x_461_ = 2069ULL;
v___x_462_ = vastitas_storage_allocate(v_a_424_, v___x_412_, v___x_440_, v___x_461_);
if (lean_obj_tag(v___x_462_) == 0)
{
lean_object* v___x_463_; 
lean_dec_ref_known(v___x_462_, 1);
v___x_463_ = vastitas_storage_fill(v_a_424_, v___x_412_, v___x_443_, v___x_461_, v___x_444_, v___x_461_, v___x_421_, v___x_440_, v___x_445_, v___x_446_);
if (lean_obj_tag(v___x_463_) == 0)
{
uint64_t v___x_464_; uint64_t v___x_465_; uint64_t v___x_466_; uint64_t v___x_467_; uint64_t v___x_468_; lean_object* v___x_469_; 
lean_dec_ref_known(v___x_463_, 1);
v___x_464_ = 32ULL;
v___x_465_ = 40ULL;
v___x_466_ = 48ULL;
v___x_467_ = 43ULL;
v___x_468_ = 13821547256400052224ULL;
v___x_469_ = vastitas_storage_fill(v_a_424_, v___x_412_, v___x_464_, v___x_465_, v___x_466_, v___x_467_, v___x_421_, v___x_440_, v___x_468_, v___x_452_);
if (lean_obj_tag(v___x_469_) == 0)
{
uint64_t v___x_470_; uint64_t v___x_471_; lean_object* v___x_472_; 
lean_dec_ref_known(v___x_469_, 1);
v___x_470_ = 47ULL;
v___x_471_ = 4602678819172646912ULL;
v___x_472_ = vastitas_storage_store(v_a_424_, v___x_412_, v___x_464_, v___x_465_, v___x_466_, v___x_467_, v___x_421_, v___x_443_, v___x_470_, v___x_440_, v___x_471_, v___x_453_);
if (lean_obj_tag(v___x_472_) == 0)
{
uint64_t v___x_473_; uint64_t v___x_474_; lean_object* v___x_475_; 
lean_dec_ref_known(v___x_472_, 1);
v___x_473_ = 39ULL;
v___x_474_ = 13828302655841107968ULL;
v___x_475_ = vastitas_storage_store(v_a_424_, v___x_412_, v___x_464_, v___x_465_, v___x_466_, v___x_467_, v___x_421_, v___x_473_, v___x_443_, v___x_440_, v___x_474_, v___x_456_);
if (lean_obj_tag(v___x_475_) == 0)
{
uint64_t v___x_476_; lean_object* v___x_477_; 
lean_dec_ref_known(v___x_475_, 1);
v___x_476_ = 2022ULL;
v___x_477_ = vastitas_storage_allocate(v_a_424_, v___x_415_, v___x_440_, v___x_476_);
if (lean_obj_tag(v___x_477_) == 0)
{
lean_object* v___x_478_; 
lean_dec_ref_known(v___x_477_, 1);
v___x_478_ = vastitas_storage_fill(v_a_424_, v___x_415_, v___x_443_, v___x_476_, v___x_444_, v___x_476_, v___x_421_, v___x_440_, v___x_445_, v___x_446_);
if (lean_obj_tag(v___x_478_) == 0)
{
uint64_t v___x_479_; uint64_t v___x_480_; lean_object* v___x_481_; 
lean_dec_ref_known(v___x_478_, 1);
v___x_479_ = 56ULL;
v___x_480_ = 36ULL;
v___x_481_ = vastitas_storage_fill(v_a_424_, v___x_415_, v___x_466_, v___x_464_, v___x_479_, v___x_480_, v___x_421_, v___x_440_, v___x_471_, v___x_468_);
if (lean_obj_tag(v___x_481_) == 0)
{
uint64_t v___x_482_; lean_object* v___x_483_; 
lean_dec_ref_known(v___x_481_, 1);
v___x_482_ = 31ULL;
v___x_483_ = vastitas_storage_store(v_a_424_, v___x_415_, v___x_466_, v___x_464_, v___x_479_, v___x_480_, v___x_421_, v___x_482_, v___x_443_, v___x_440_, v___x_468_, v___x_471_);
if (lean_obj_tag(v___x_483_) == 0)
{
uint64_t v___x_484_; lean_object* v___x_485_; 
lean_dec_ref_known(v___x_483_, 1);
v___x_484_ = 55ULL;
v___x_485_ = vastitas_storage_store(v_a_424_, v___x_415_, v___x_466_, v___x_464_, v___x_479_, v___x_480_, v___x_421_, v___x_443_, v___x_484_, v___x_440_, v___x_459_, v___x_474_);
if (lean_obj_tag(v___x_485_) == 0)
{
uint32_t v___x_486_; uint64_t v___x_487_; lean_object* v___x_488_; 
lean_dec_ref_known(v___x_485_, 1);
v___x_486_ = 3;
v___x_487_ = 37130ULL;
v___x_488_ = vastitas_storage_allocate(v_a_424_, v___x_486_, v___x_440_, v___x_487_);
if (lean_obj_tag(v___x_488_) == 0)
{
lean_object* v___x_489_; 
lean_dec_ref_known(v___x_488_, 1);
v___x_489_ = vastitas_storage_fill(v_a_424_, v___x_486_, v___x_443_, v___x_487_, v___x_444_, v___x_487_, v___x_421_, v___x_440_, v___x_445_, v___x_446_);
if (lean_obj_tag(v___x_489_) == 0)
{
uint32_t v___x_490_; uint64_t v___x_491_; lean_object* v___x_492_; 
lean_dec_ref_known(v___x_489_, 1);
v___x_490_ = 4;
v___x_491_ = 37160ULL;
v___x_492_ = vastitas_storage_allocate(v_a_424_, v___x_490_, v___x_440_, v___x_491_);
if (lean_obj_tag(v___x_492_) == 0)
{
lean_object* v___x_493_; 
lean_dec_ref_known(v___x_492_, 1);
v___x_493_ = vastitas_storage_fill(v_a_424_, v___x_490_, v___x_443_, v___x_491_, v___x_444_, v___x_491_, v___x_421_, v___x_440_, v___x_445_, v___x_446_);
if (lean_obj_tag(v___x_493_) == 0)
{
uint32_t v___x_494_; uint64_t v___x_495_; lean_object* v___x_496_; 
lean_dec_ref_known(v___x_493_, 1);
v___x_494_ = 5;
v___x_495_ = 64913ULL;
v___x_496_ = vastitas_storage_allocate(v_a_424_, v___x_494_, v___x_440_, v___x_495_);
if (lean_obj_tag(v___x_496_) == 0)
{
lean_object* v___x_497_; 
lean_dec_ref_known(v___x_496_, 1);
v___x_497_ = vastitas_storage_fill(v_a_424_, v___x_494_, v___x_443_, v___x_495_, v___x_444_, v___x_495_, v___x_421_, v___x_440_, v___x_445_, v___x_446_);
if (lean_obj_tag(v___x_497_) == 0)
{
uint32_t v___x_498_; uint64_t v___x_499_; lean_object* v___x_500_; 
lean_dec_ref_known(v___x_497_, 1);
v___x_498_ = lean_uint32_of_nat(v_scope_402_);
v___x_499_ = lean_uint64_of_nat(v_reps_407_);
v___x_500_ = bench_begin_lean(v___x_498_, v___x_499_, v_verify_411_);
if (lean_obj_tag(v___x_500_) == 0)
{
lean_object* v___x_501_; lean_object* v___x_502_; lean_object* v___x_503_; 
lean_dec_ref_known(v___x_500_, 1);
v___x_501_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_501_, 0, v___x_396_);
lean_ctor_set(v___x_501_, 1, v_reps_407_);
lean_ctor_set(v___x_501_, 2, v___x_398_);
v___x_502_ = lean_box(0);
v___x_503_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_424_, v_scope_402_, v___x_501_, v___x_502_, v___x_396_);
lean_dec_ref_known(v___x_501_, 3);
lean_dec(v_scope_402_);
if (lean_obj_tag(v___x_503_) == 0)
{
lean_object* v___x_504_; 
lean_dec_ref_known(v___x_503_, 1);
v___x_504_ = bench_stop_lean();
if (lean_obj_tag(v___x_504_) == 0)
{
lean_object* v___x_505_; 
lean_dec_ref_known(v___x_504_, 1);
v___x_505_ = bench_verify_lean(v_a_424_, v___x_499_);
if (lean_obj_tag(v___x_505_) == 0)
{
uint64_t v___x_506_; uint64_t v___x_507_; uint64_t v___x_508_; uint64_t v___x_509_; uint64_t v___x_510_; lean_object* v___x_511_; 
lean_dec_ref_known(v___x_505_, 1);
v___x_506_ = 96ULL;
v___x_507_ = 1152ULL;
v___x_508_ = 1159ULL;
v___x_509_ = 13855852019186663424ULL;
v___x_510_ = 13847480337652776960ULL;
v___x_511_ = vastitas_storage_expect(v_a_424_, v___x_494_, v___x_506_, v___x_507_, v___x_479_, v___x_508_, v___x_421_, v___x_443_, v___x_443_, v___x_440_, v___x_509_, v___x_510_);
if (lean_obj_tag(v___x_511_) == 0)
{
uint64_t v___x_512_; uint64_t v___x_513_; lean_object* v___x_514_; 
lean_dec_ref_known(v___x_511_, 1);
v___x_512_ = 13856569450523787264ULL;
v___x_513_ = 13847183469513277440ULL;
v___x_514_ = vastitas_storage_expect(v_a_424_, v___x_494_, v___x_506_, v___x_507_, v___x_479_, v___x_508_, v___x_421_, v___x_458_, v___x_484_, v___x_440_, v___x_512_, v___x_513_);
if (lean_obj_tag(v___x_514_) == 0)
{
uint64_t v___x_515_; uint64_t v___x_516_; uint64_t v___x_517_; lean_object* v___x_518_; 
lean_dec_ref_known(v___x_514_, 1);
v___x_515_ = 1151ULL;
v___x_516_ = 13855506772535541760ULL;
v___x_517_ = 13844008079932260352ULL;
v___x_518_ = vastitas_storage_expect(v_a_424_, v___x_494_, v___x_506_, v___x_507_, v___x_479_, v___x_508_, v___x_421_, v___x_515_, v___x_443_, v___x_440_, v___x_516_, v___x_517_);
if (lean_obj_tag(v___x_518_) == 0)
{
lean_object* v___x_519_; 
lean_dec_ref_known(v___x_518_, 1);
v___x_519_ = vastitas_storage_drop(v_a_424_, v___x_494_);
if (lean_obj_tag(v___x_519_) == 0)
{
lean_object* v___x_520_; 
lean_dec_ref_known(v___x_519_, 1);
v___x_520_ = vastitas_storage_drop(v_a_424_, v___x_490_);
if (lean_obj_tag(v___x_520_) == 0)
{
lean_object* v___x_521_; 
lean_dec_ref_known(v___x_520_, 1);
v___x_521_ = vastitas_storage_drop(v_a_424_, v___x_486_);
if (lean_obj_tag(v___x_521_) == 0)
{
lean_object* v___x_522_; 
lean_dec_ref_known(v___x_521_, 1);
v___x_522_ = vastitas_storage_drop(v_a_424_, v___x_415_);
if (lean_obj_tag(v___x_522_) == 0)
{
lean_object* v___x_523_; 
lean_dec_ref_known(v___x_522_, 1);
v___x_523_ = vastitas_storage_drop(v_a_424_, v___x_412_);
if (lean_obj_tag(v___x_523_) == 0)
{
lean_object* v___x_524_; 
lean_dec_ref_known(v___x_523_, 1);
v___x_524_ = vastitas_storage_drop(v_a_424_, v___x_439_);
v___y_426_ = v___x_524_;
goto v___jp_425_;
}
else
{
v___y_426_ = v___x_523_;
goto v___jp_425_;
}
}
else
{
v___y_426_ = v___x_522_;
goto v___jp_425_;
}
}
else
{
v___y_426_ = v___x_521_;
goto v___jp_425_;
}
}
else
{
v___y_426_ = v___x_520_;
goto v___jp_425_;
}
}
else
{
v___y_426_ = v___x_519_;
goto v___jp_425_;
}
}
else
{
v___y_426_ = v___x_518_;
goto v___jp_425_;
}
}
else
{
v___y_426_ = v___x_514_;
goto v___jp_425_;
}
}
else
{
v___y_426_ = v___x_511_;
goto v___jp_425_;
}
}
else
{
v___y_426_ = v___x_505_;
goto v___jp_425_;
}
}
else
{
v___y_426_ = v___x_504_;
goto v___jp_425_;
}
}
else
{
v___y_426_ = v___x_503_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_500_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_497_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_496_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_493_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_492_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_489_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_488_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_485_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_483_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_481_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_478_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_477_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_475_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_472_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_469_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_463_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_462_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_460_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_457_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_454_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_447_;
goto v___jp_425_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v___y_426_ = v___x_442_;
goto v___jp_425_;
}
v___jp_425_:
{
if (lean_obj_tag(v___y_426_) == 0)
{
lean_object* v___x_427_; 
lean_dec_ref_known(v___y_426_, 1);
v___x_427_ = vastitas_storage_close(v_a_424_);
lean_dec(v_a_424_);
if (lean_obj_tag(v___x_427_) == 0)
{
lean_object* v___x_428_; 
lean_dec_ref_known(v___x_427_, 1);
v___x_428_ = bench_report_lean();
return v___x_428_;
}
else
{
return v___x_427_;
}
}
else
{
lean_object* v_a_429_; lean_object* v___x_430_; 
v_a_429_ = lean_ctor_get(v___y_426_, 0);
lean_inc(v_a_429_);
lean_dec_ref_known(v___y_426_, 1);
v___x_430_ = vastitas_storage_close(v_a_424_);
lean_dec(v_a_424_);
if (lean_obj_tag(v___x_430_) == 0)
{
lean_object* v___x_432_; uint8_t v_isShared_433_; uint8_t v_isSharedCheck_437_; 
v_isSharedCheck_437_ = !lean_is_exclusive(v___x_430_);
if (v_isSharedCheck_437_ == 0)
{
lean_object* v_unused_438_; 
v_unused_438_ = lean_ctor_get(v___x_430_, 0);
lean_dec(v_unused_438_);
v___x_432_ = v___x_430_;
v_isShared_433_ = v_isSharedCheck_437_;
goto v_resetjp_431_;
}
else
{
lean_dec(v___x_430_);
v___x_432_ = lean_box(0);
v_isShared_433_ = v_isSharedCheck_437_;
goto v_resetjp_431_;
}
v_resetjp_431_:
{
lean_object* v___x_435_; 
if (v_isShared_433_ == 0)
{
lean_ctor_set_tag(v___x_432_, 1);
lean_ctor_set(v___x_432_, 0, v_a_429_);
v___x_435_ = v___x_432_;
goto v_reusejp_434_;
}
else
{
lean_object* v_reuseFailAlloc_436_; 
v_reuseFailAlloc_436_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_436_, 0, v_a_429_);
v___x_435_ = v_reuseFailAlloc_436_;
goto v_reusejp_434_;
}
v_reusejp_434_:
{
return v___x_435_;
}
}
}
else
{
lean_dec(v_a_429_);
return v___x_430_;
}
}
}
}
else
{
lean_object* v_a_525_; lean_object* v___x_527_; uint8_t v_isShared_528_; uint8_t v_isSharedCheck_532_; 
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
v_a_525_ = lean_ctor_get(v___x_423_, 0);
v_isSharedCheck_532_ = !lean_is_exclusive(v___x_423_);
if (v_isSharedCheck_532_ == 0)
{
v___x_527_ = v___x_423_;
v_isShared_528_ = v_isSharedCheck_532_;
goto v_resetjp_526_;
}
else
{
lean_inc(v_a_525_);
lean_dec(v___x_423_);
v___x_527_ = lean_box(0);
v_isShared_528_ = v_isSharedCheck_532_;
goto v_resetjp_526_;
}
v_resetjp_526_:
{
lean_object* v___x_530_; 
if (v_isShared_528_ == 0)
{
v___x_530_ = v___x_527_;
goto v_reusejp_529_;
}
else
{
lean_object* v_reuseFailAlloc_531_; 
v_reuseFailAlloc_531_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_531_, 0, v_a_525_);
v___x_530_ = v_reuseFailAlloc_531_;
goto v_reusejp_529_;
}
v_reusejp_529_:
{
return v___x_530_;
}
}
}
}
else
{
uint32_t v___x_533_; uint64_t v___x_534_; lean_object* v___x_535_; 
lean_dec(v_scope_402_);
v___x_533_ = 0;
v___x_534_ = lean_uint64_of_nat(v_reps_407_);
v___x_535_ = bench_begin_lean(v___x_533_, v___x_534_, v_verify_411_);
if (lean_obj_tag(v___x_535_) == 0)
{
lean_object* v___x_536_; lean_object* v___x_537_; lean_object* v___x_538_; 
lean_dec_ref_known(v___x_535_, 1);
v___x_536_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_536_, 0, v___x_396_);
lean_ctor_set(v___x_536_, 1, v_reps_407_);
lean_ctor_set(v___x_536_, 2, v___x_398_);
v___x_537_ = lean_box(0);
v___x_538_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v___x_536_, v___x_537_, v___x_396_);
lean_dec_ref_known(v___x_536_, 3);
if (lean_obj_tag(v___x_538_) == 0)
{
lean_object* v___x_539_; 
lean_dec_ref_known(v___x_538_, 1);
v___x_539_ = bench_stop_lean();
if (lean_obj_tag(v___x_539_) == 0)
{
lean_object* v___x_540_; 
lean_dec_ref_known(v___x_539_, 1);
v___x_540_ = bench_report_lean();
return v___x_540_;
}
else
{
return v___x_539_;
}
}
else
{
return v___x_538_;
}
}
else
{
lean_dec(v_reps_407_);
return v___x_535_;
}
}
}
else
{
uint32_t v___x_541_; uint64_t v___x_542_; lean_object* v___x_543_; 
v___x_541_ = lean_uint32_of_nat(v_scope_402_);
lean_dec(v_scope_402_);
v___x_542_ = lean_uint64_of_nat(v_reps_407_);
lean_dec(v_reps_407_);
v___x_543_ = bench_c_run_lean(v___x_541_, v___x_542_, v_verify_411_);
if (lean_obj_tag(v___x_543_) == 0)
{
lean_object* v___x_544_; 
lean_dec_ref_known(v___x_543_, 1);
v___x_544_ = bench_report_lean();
return v___x_544_;
}
else
{
return v___x_543_;
}
}
}
else
{
uint32_t v___x_545_; uint64_t v___x_546_; lean_object* v___x_547_; 
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
lean_dec(v_impl_397_);
v___x_545_ = 0;
v___x_546_ = 1ULL;
v___x_547_ = bench_begin_lean(v___x_545_, v___x_546_, v___x_418_);
if (lean_obj_tag(v___x_547_) == 0)
{
lean_object* v___x_548_; 
lean_dec_ref_known(v___x_547_, 1);
v___x_548_ = lp_allocation__audit_generatedFailure();
if (lean_obj_tag(v___x_548_) == 0)
{
lean_object* v___x_550_; uint8_t v_isShared_551_; uint8_t v_isSharedCheck_556_; 
v_isSharedCheck_556_ = !lean_is_exclusive(v___x_548_);
if (v_isSharedCheck_556_ == 0)
{
lean_object* v_unused_557_; 
v_unused_557_ = lean_ctor_get(v___x_548_, 0);
lean_dec(v_unused_557_);
v___x_550_ = v___x_548_;
v_isShared_551_ = v_isSharedCheck_556_;
goto v_resetjp_549_;
}
else
{
lean_dec(v___x_548_);
v___x_550_ = lean_box(0);
v_isShared_551_ = v_isSharedCheck_556_;
goto v_resetjp_549_;
}
v_resetjp_549_:
{
lean_object* v___x_552_; lean_object* v___x_554_; 
v___x_552_ = ((lean_object*)(lp_allocation__audit_main___closed__5));
if (v_isShared_551_ == 0)
{
lean_ctor_set_tag(v___x_550_, 1);
lean_ctor_set(v___x_550_, 0, v___x_552_);
v___x_554_ = v___x_550_;
goto v_reusejp_553_;
}
else
{
lean_object* v_reuseFailAlloc_555_; 
v_reuseFailAlloc_555_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_555_, 0, v___x_552_);
v___x_554_ = v_reuseFailAlloc_555_;
goto v_reusejp_553_;
}
v_reusejp_553_:
{
return v___x_554_;
}
}
}
else
{
lean_object* v_a_558_; lean_object* v___x_559_; lean_object* v___x_560_; uint8_t v___x_561_; 
v_a_558_ = lean_ctor_get(v___x_548_, 0);
lean_inc(v_a_558_);
v___x_559_ = lean_io_error_to_string(v_a_558_);
v___x_560_ = ((lean_object*)(lp_allocation__audit_main___closed__6));
v___x_561_ = lean_string_dec_eq(v___x_559_, v___x_560_);
lean_dec_ref(v___x_559_);
if (v___x_561_ == 0)
{
return v___x_548_;
}
else
{
lean_object* v___x_562_; 
lean_dec_ref_known(v___x_548_, 1);
v___x_562_ = bench_stop_lean();
if (lean_obj_tag(v___x_562_) == 0)
{
lean_object* v___x_563_; 
lean_dec_ref_known(v___x_562_, 1);
v___x_563_ = bench_report_lean();
return v___x_563_;
}
else
{
return v___x_562_;
}
}
}
}
else
{
return v___x_547_;
}
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
lean_dec(v_impl_397_);
return v___x_416_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
lean_dec(v_impl_397_);
return v___x_414_;
}
}
else
{
lean_dec(v_reps_407_);
lean_dec(v_scope_402_);
lean_dec(v_impl_397_);
return v___x_413_;
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object* v_args_564_, lean_object* v_a_565_){
_start:
{
lean_object* v_res_566_; 
v_res_566_ = _lean_main(v_args_564_);
return v_res_566_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object* v_a_567_, lean_object* v_scope_568_, lean_object* v_range_569_, lean_object* v_b_570_, lean_object* v_i_571_, lean_object* v_hs_572_, lean_object* v_hl_573_){
_start:
{
lean_object* v___x_575_; 
v___x_575_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_567_, v_scope_568_, v_range_569_, v_b_570_, v_i_571_);
return v___x_575_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object* v_a_576_, lean_object* v_scope_577_, lean_object* v_range_578_, lean_object* v_b_579_, lean_object* v_i_580_, lean_object* v_hs_581_, lean_object* v_hl_582_, lean_object* v___y_583_){
_start:
{
lean_object* v_res_584_; 
v_res_584_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(v_a_576_, v_scope_577_, v_range_578_, v_b_579_, v_i_580_, v_hs_581_, v_hl_582_);
lean_dec_ref(v_range_578_);
lean_dec(v_scope_577_);
lean_dec(v_a_576_);
return v_res_584_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object* v_range_585_, lean_object* v_b_586_, lean_object* v_i_587_, lean_object* v_hs_588_, lean_object* v_hl_589_){
_start:
{
lean_object* v___x_591_; 
v___x_591_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_585_, v_b_586_, v_i_587_);
return v___x_591_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object* v_range_592_, lean_object* v_b_593_, lean_object* v_i_594_, lean_object* v_hs_595_, lean_object* v_hl_596_, lean_object* v___y_597_){
_start:
{
lean_object* v_res_598_; 
v_res_598_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(v_range_592_, v_b_593_, v_i_594_, v_hs_595_, v_hl_596_);
lean_dec_ref(v_range_592_);
return v_res_598_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_vastitas__storage__native_VastitasStorageNative(uint8_t builtin);
lean_object* initialize_vastitas__gemm__native_VastitasGemmNative(uint8_t builtin);
lean_object* initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_allocation__audit_Main(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__storage__native_VastitasStorageNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__gemm__native_VastitasGemmNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_allocation__audit_VastitasGenerated_f__0 = _init_lp_allocation__audit_VastitasGenerated_f__0();
lean_mark_persistent(lp_allocation__audit_VastitasGenerated_f__0);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_allocation__audit_Main(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = 0;
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
