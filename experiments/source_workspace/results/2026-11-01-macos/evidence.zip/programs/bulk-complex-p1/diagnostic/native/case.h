/* Fixture data independently constructed from cases.json. */
static const unsigned scalar = 1;
static const uint64_t dim_i=24, dim_k=40, dim_j=32, dim_a=48;
static const VStorageLayout views[7] = {{16,24,1280,26,0},{32,40,48,43,0},{48,32,56,36,0},{64,768,40,773,0},{80,768,48,774,0},{96,1152,56,1159,0},{112,1152,32,1160,0}};
static const uint64_t elements[6] = {33284,2069,2022,37130,37160,64913};
static const double values[3][2] = {{0x1.0000000000000p-3,0x1.0000000000000p-2},{-0x1.0000000000000p-2,0x1.0000000000000p-3},{0x1.0000000000000p-1,-0x1.0000000000000p-2}};
static const double sentinel[2] = {-0x1.c000000000000p+2,0x1.8000000000000p+1};
static const double alpha[2] = {1,0}, beta[2] = {0,0};
typedef struct { uint64_t row, col; double value[2]; } Patch;
static const Patch patches[3][2] = {{{0,0,{0x1.0000000000000p+0,-0x1.0000000000000p-1}},{23,1,{-0x1.0000000000000p-1,0x1.8000000000000p-1}}},{{0,47,{0x1.0000000000000p-1,0x1.0000000000000p-2}},{39,0,{-0x1.8000000000000p-1,-0x1.0000000000000p-1}}},{{31,0,{-0x1.0000000000000p-2,0x1.0000000000000p-1}},{0,55,{0x1.8000000000000p-1,-0x1.8000000000000p-1}}}};
static const Patch expected[3] = {{0,0,{-0x1.9e00000000000p+5,-0x1.c220000000000p+3}},{23,55,{-0x1.c6c8000000000p+5,-0x1.b140000000000p+3}},{1151,0,{-0x1.8a60000000000p+5,-0x1.fcc0000000000p+2}}};
