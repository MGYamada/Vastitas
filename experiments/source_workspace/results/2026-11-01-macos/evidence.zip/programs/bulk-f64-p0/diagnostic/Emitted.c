// Lean compiler output
// Module: Main
// Imports: public import Init public meta import Init public import VastitasStorageNative public import VastitasGemmNative public import VastitasKernel.IndexedRuntime
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* vastitas_storage_new(uint64_t);
lean_object* vastitas_storage_close(lean_object*);
lean_object* vastitas_storage_allocate(lean_object*, uint32_t, uint8_t, uint64_t);
lean_object* vastitas_storage_fill(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_store(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_pack3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_gemm_execute(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t);
lean_object* vastitas_storage_regroup3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_storage_expect(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_drop(lean_object*, uint32_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_List_get_x21Internal___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_String_Slice_toNat_x21(lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
uint32_t lean_uint32_of_nat(lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
lean_object* lean_io_error_to_string(lean_object*);
static lean_once_cell_t lp_allocation__audit_VastitasGenerated_f__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_allocation__audit_VastitasGenerated_f__0___closed__0;
LEAN_EXPORT lean_object* lp_allocation__audit_VastitasGenerated_f__0;
lean_object* bench_begin_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_stop_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object*);
lean_object* bench_report_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object*);
lean_object* bench_c_run_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_verify_lean(lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object*);
lean_object* audit_mark_lean(uint32_t);
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_allocation__audit_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 1, .m_capacity = 1, .m_length = 0, .m_data = ""};
static const lean_object* lp_allocation__audit_main___closed__0 = (const lean_object*)&lp_allocation__audit_main___closed__0_value;
static const lean_string_object lp_allocation__audit_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "1"};
static const lean_object* lp_allocation__audit_main___closed__1 = (const lean_object*)&lp_allocation__audit_main___closed__1_value;
static const lean_string_object lp_allocation__audit_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "failure"};
static const lean_object* lp_allocation__audit_main___closed__2 = (const lean_object*)&lp_allocation__audit_main___closed__2_value;
static const lean_string_object lp_allocation__audit_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "c"};
static const lean_object* lp_allocation__audit_main___closed__3 = (const lean_object*)&lp_allocation__audit_main___closed__3_value;
static const lean_string_object lp_allocation__audit_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "expected injected native failure"};
static const lean_object* lp_allocation__audit_main___closed__4 = (const lean_object*)&lp_allocation__audit_main___closed__4_value;
static const lean_ctor_object lp_allocation__audit_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_allocation__audit_main___closed__4_value)}};
static const lean_object* lp_allocation__audit_main___closed__5 = (const lean_object*)&lp_allocation__audit_main___closed__5_value;
static const lean_string_object lp_allocation__audit_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 44, .m_capacity = 44, .m_length = 43, .m_data = "E_NATIVE_EXPECT: stored bit pattern differs"};
static const lean_object* lp_allocation__audit_main___closed__6 = (const lean_object*)&lp_allocation__audit_main___closed__6_value;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(0u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0(void){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_obj_once(&lp_allocation__audit_VastitasGenerated_f__0___closed__0, &lp_allocation__audit_VastitasGenerated_f__0___closed__0_once, _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object* v_scope_8_, lean_object* v_reps_9_, lean_object* v_verify_10_, lean_object* v_a_00___x40___internal___hyg_11_){
_start:
{
uint32_t v_scope_boxed_12_; uint64_t v_reps_boxed_13_; uint8_t v_verify_boxed_14_; lean_object* v_res_15_; 
v_scope_boxed_12_ = lean_unbox_uint32(v_scope_8_);
lean_dec(v_scope_8_);
v_reps_boxed_13_ = lean_unbox_uint64(v_reps_9_);
lean_dec_ref(v_reps_9_);
v_verify_boxed_14_ = lean_unbox(v_verify_10_);
v_res_15_ = bench_begin_lean(v_scope_boxed_12_, v_reps_boxed_13_, v_verify_boxed_14_);
return v_res_15_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object* v_a_00___x40___internal___hyg_17_){
_start:
{
lean_object* v_res_18_; 
v_res_18_ = bench_stop_lean();
return v_res_18_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object* v_a_00___x40___internal___hyg_20_){
_start:
{
lean_object* v_res_21_; 
v_res_21_ = bench_report_lean();
return v_res_21_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object* v_scope_26_, lean_object* v_reps_27_, lean_object* v_verify_28_, lean_object* v_a_00___x40___internal___hyg_29_){
_start:
{
uint32_t v_scope_boxed_30_; uint64_t v_reps_boxed_31_; uint8_t v_verify_boxed_32_; lean_object* v_res_33_; 
v_scope_boxed_30_ = lean_unbox_uint32(v_scope_26_);
lean_dec(v_scope_26_);
v_reps_boxed_31_ = lean_unbox_uint64(v_reps_27_);
lean_dec_ref(v_reps_27_);
v_verify_boxed_32_ = lean_unbox(v_verify_28_);
v_res_33_ = bench_c_run_lean(v_scope_boxed_30_, v_reps_boxed_31_, v_verify_boxed_32_);
return v_res_33_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object* v_arena_37_, lean_object* v_reps_38_, lean_object* v_a_00___x40___internal___hyg_39_){
_start:
{
uint64_t v_reps_boxed_40_; lean_object* v_res_41_; 
v_reps_boxed_40_ = lean_unbox_uint64(v_reps_38_);
lean_dec_ref(v_reps_38_);
v_res_41_ = bench_verify_lean(v_arena_37_, v_reps_boxed_40_);
lean_dec(v_arena_37_);
return v_res_41_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce(){
_start:
{
uint64_t v___x_43_; lean_object* v___x_44_; 
v___x_43_ = 9223372036854775807ULL;
v___x_44_ = vastitas_storage_new(v___x_43_);
if (lean_obj_tag(v___x_44_) == 0)
{
lean_object* v_a_45_; lean_object* v_a_47_; lean_object* v___y_58_; uint32_t v___x_70_; uint8_t v___x_71_; uint64_t v___x_72_; lean_object* v___x_73_; 
v_a_45_ = lean_ctor_get(v___x_44_, 0);
lean_inc(v_a_45_);
lean_dec_ref_known(v___x_44_, 1);
v___x_70_ = 0;
v___x_71_ = 0;
v___x_72_ = 30720ULL;
v___x_73_ = vastitas_storage_allocate(v_a_45_, v___x_70_, v___x_71_, v___x_72_);
if (lean_obj_tag(v___x_73_) == 0)
{
uint64_t v___x_74_; uint64_t v___x_75_; uint8_t v___x_76_; uint64_t v___x_77_; lean_object* v___x_78_; 
lean_dec_ref_known(v___x_73_, 1);
v___x_74_ = 0ULL;
v___x_75_ = 1ULL;
v___x_76_ = 0;
v___x_77_ = 13842939354630062080ULL;
v___x_78_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_74_, v___x_72_, v___x_75_, v___x_72_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_78_) == 0)
{
uint64_t v___x_79_; uint64_t v___x_80_; uint64_t v___x_81_; lean_object* v___x_82_; 
lean_dec_ref_known(v___x_78_, 1);
v___x_79_ = 24ULL;
v___x_80_ = 1280ULL;
v___x_81_ = 4593671619917905920ULL;
v___x_82_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_74_, v___x_79_, v___x_80_, v___x_79_, v___x_76_, v___x_71_, v___x_81_, v___x_74_);
if (lean_obj_tag(v___x_82_) == 0)
{
uint64_t v___x_83_; lean_object* v___x_84_; 
lean_dec_ref_known(v___x_82_, 1);
v___x_83_ = 4607182418800017408ULL;
v___x_84_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_74_, v___x_79_, v___x_80_, v___x_79_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_83_, v___x_74_);
if (lean_obj_tag(v___x_84_) == 0)
{
uint64_t v___x_85_; uint64_t v___x_86_; lean_object* v___x_87_; 
lean_dec_ref_known(v___x_84_, 1);
v___x_85_ = 23ULL;
v___x_86_ = 13826050856027422720ULL;
v___x_87_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_74_, v___x_79_, v___x_80_, v___x_79_, v___x_76_, v___x_85_, v___x_75_, v___x_71_, v___x_86_, v___x_74_);
if (lean_obj_tag(v___x_87_) == 0)
{
uint32_t v___x_88_; uint64_t v___x_89_; lean_object* v___x_90_; 
lean_dec_ref_known(v___x_87_, 1);
v___x_88_ = 1;
v___x_89_ = 1920ULL;
v___x_90_ = vastitas_storage_allocate(v_a_45_, v___x_88_, v___x_71_, v___x_89_);
if (lean_obj_tag(v___x_90_) == 0)
{
lean_object* v___x_91_; 
lean_dec_ref_known(v___x_90_, 1);
v___x_91_ = vastitas_storage_fill(v_a_45_, v___x_88_, v___x_74_, v___x_89_, v___x_75_, v___x_89_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_91_) == 0)
{
uint64_t v___x_92_; uint64_t v___x_93_; uint64_t v___x_94_; lean_object* v___x_95_; 
lean_dec_ref_known(v___x_91_, 1);
v___x_92_ = 40ULL;
v___x_93_ = 48ULL;
v___x_94_ = 13821547256400052224ULL;
v___x_95_ = vastitas_storage_fill(v_a_45_, v___x_88_, v___x_74_, v___x_92_, v___x_93_, v___x_92_, v___x_76_, v___x_71_, v___x_94_, v___x_74_);
if (lean_obj_tag(v___x_95_) == 0)
{
uint64_t v___x_96_; uint64_t v___x_97_; lean_object* v___x_98_; 
lean_dec_ref_known(v___x_95_, 1);
v___x_96_ = 47ULL;
v___x_97_ = 4602678819172646912ULL;
v___x_98_ = vastitas_storage_store(v_a_45_, v___x_88_, v___x_74_, v___x_92_, v___x_93_, v___x_92_, v___x_76_, v___x_74_, v___x_96_, v___x_71_, v___x_97_, v___x_74_);
if (lean_obj_tag(v___x_98_) == 0)
{
uint64_t v___x_99_; uint64_t v___x_100_; lean_object* v___x_101_; 
lean_dec_ref_known(v___x_98_, 1);
v___x_99_ = 39ULL;
v___x_100_ = 13828302655841107968ULL;
v___x_101_ = vastitas_storage_store(v_a_45_, v___x_88_, v___x_74_, v___x_92_, v___x_93_, v___x_92_, v___x_76_, v___x_99_, v___x_74_, v___x_71_, v___x_100_, v___x_74_);
if (lean_obj_tag(v___x_101_) == 0)
{
uint32_t v___x_102_; uint64_t v___x_103_; lean_object* v___x_104_; 
lean_dec_ref_known(v___x_101_, 1);
v___x_102_ = 2;
v___x_103_ = 1792ULL;
v___x_104_ = vastitas_storage_allocate(v_a_45_, v___x_102_, v___x_71_, v___x_103_);
if (lean_obj_tag(v___x_104_) == 0)
{
lean_object* v___x_105_; 
lean_dec_ref_known(v___x_104_, 1);
v___x_105_ = vastitas_storage_fill(v_a_45_, v___x_102_, v___x_74_, v___x_103_, v___x_75_, v___x_103_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_105_) == 0)
{
uint64_t v___x_106_; uint64_t v___x_107_; lean_object* v___x_108_; 
lean_dec_ref_known(v___x_105_, 1);
v___x_106_ = 32ULL;
v___x_107_ = 56ULL;
v___x_108_ = vastitas_storage_fill(v_a_45_, v___x_102_, v___x_74_, v___x_106_, v___x_107_, v___x_106_, v___x_76_, v___x_71_, v___x_97_, v___x_74_);
if (lean_obj_tag(v___x_108_) == 0)
{
uint64_t v___x_109_; lean_object* v___x_110_; 
lean_dec_ref_known(v___x_108_, 1);
v___x_109_ = 31ULL;
v___x_110_ = vastitas_storage_store(v_a_45_, v___x_102_, v___x_74_, v___x_106_, v___x_107_, v___x_106_, v___x_76_, v___x_109_, v___x_74_, v___x_71_, v___x_94_, v___x_74_);
if (lean_obj_tag(v___x_110_) == 0)
{
uint64_t v___x_111_; uint64_t v___x_112_; lean_object* v___x_113_; 
lean_dec_ref_known(v___x_110_, 1);
v___x_111_ = 55ULL;
v___x_112_ = 4604930618986332160ULL;
v___x_113_ = vastitas_storage_store(v_a_45_, v___x_102_, v___x_74_, v___x_106_, v___x_107_, v___x_106_, v___x_76_, v___x_74_, v___x_111_, v___x_71_, v___x_112_, v___x_74_);
if (lean_obj_tag(v___x_113_) == 0)
{
uint32_t v___x_114_; uint64_t v___x_115_; lean_object* v___x_116_; 
lean_dec_ref_known(v___x_113_, 1);
v___x_114_ = 3;
v___x_115_ = 36864ULL;
v___x_116_ = vastitas_storage_allocate(v_a_45_, v___x_114_, v___x_71_, v___x_115_);
if (lean_obj_tag(v___x_116_) == 0)
{
lean_object* v___x_117_; 
lean_dec_ref_known(v___x_116_, 1);
v___x_117_ = vastitas_storage_fill(v_a_45_, v___x_114_, v___x_74_, v___x_115_, v___x_75_, v___x_115_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_117_) == 0)
{
uint32_t v___x_118_; lean_object* v___x_119_; 
lean_dec_ref_known(v___x_117_, 1);
v___x_118_ = 4;
v___x_119_ = vastitas_storage_allocate(v_a_45_, v___x_118_, v___x_71_, v___x_115_);
if (lean_obj_tag(v___x_119_) == 0)
{
lean_object* v___x_120_; 
lean_dec_ref_known(v___x_119_, 1);
v___x_120_ = vastitas_storage_fill(v_a_45_, v___x_118_, v___x_74_, v___x_115_, v___x_75_, v___x_115_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_120_) == 0)
{
uint32_t v___x_121_; uint64_t v___x_122_; lean_object* v___x_123_; 
lean_dec_ref_known(v___x_120_, 1);
v___x_121_ = 5;
v___x_122_ = 64512ULL;
v___x_123_ = vastitas_storage_allocate(v_a_45_, v___x_121_, v___x_71_, v___x_122_);
if (lean_obj_tag(v___x_123_) == 0)
{
lean_object* v___x_124_; 
lean_dec_ref_known(v___x_123_, 1);
v___x_124_ = vastitas_storage_fill(v_a_45_, v___x_121_, v___x_74_, v___x_122_, v___x_75_, v___x_122_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_124_) == 0)
{
uint64_t v___x_125_; lean_object* v___x_126_; 
lean_dec_ref_known(v___x_124_, 1);
v___x_125_ = 768ULL;
v___x_126_ = vastitas_storage_pack3(v_a_45_, v___x_70_, v___x_74_, v___x_79_, v___x_80_, v___x_79_, v___x_76_, v___x_114_, v___x_74_, v___x_125_, v___x_92_, v___x_125_, v___x_76_, v___x_79_, v___x_92_, v___x_106_);
if (lean_obj_tag(v___x_126_) == 0)
{
lean_object* v___x_127_; 
lean_dec_ref_known(v___x_126_, 1);
v___x_127_ = vastitas_gemm_execute(v_a_45_, v___x_114_, v___x_74_, v___x_125_, v___x_92_, v___x_125_, v___x_76_, v___x_76_, v___x_88_, v___x_74_, v___x_92_, v___x_93_, v___x_92_, v___x_76_, v___x_76_, v___x_118_, v___x_74_, v___x_125_, v___x_93_, v___x_125_, v___x_76_, v___x_71_);
if (lean_obj_tag(v___x_127_) == 0)
{
uint64_t v___x_128_; uint64_t v___x_129_; lean_object* v___x_130_; 
lean_dec_ref_known(v___x_127_, 1);
v___x_128_ = 1152ULL;
v___x_129_ = 42ULL;
v___x_130_ = vastitas_storage_regroup3(v_a_45_, v___x_118_, v___x_74_, v___x_125_, v___x_93_, v___x_125_, v___x_76_, v___x_114_, v___x_74_, v___x_128_, v___x_106_, v___x_128_, v___x_76_, v___x_79_, v___x_106_, v___x_93_, v___x_93_, v___x_129_);
if (lean_obj_tag(v___x_130_) == 0)
{
lean_object* v___x_131_; 
lean_dec_ref_known(v___x_130_, 1);
v___x_131_ = vastitas_gemm_execute(v_a_45_, v___x_114_, v___x_74_, v___x_128_, v___x_106_, v___x_128_, v___x_76_, v___x_76_, v___x_102_, v___x_74_, v___x_106_, v___x_107_, v___x_106_, v___x_76_, v___x_76_, v___x_121_, v___x_74_, v___x_128_, v___x_107_, v___x_128_, v___x_76_, v___x_71_);
if (lean_obj_tag(v___x_131_) == 0)
{
uint64_t v___x_132_; lean_object* v___x_133_; 
lean_dec_ref_known(v___x_131_, 1);
v___x_132_ = 13849729938443206656ULL;
v___x_133_ = vastitas_storage_expect(v_a_45_, v___x_121_, v___x_74_, v___x_128_, v___x_107_, v___x_128_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_132_, v___x_74_);
if (lean_obj_tag(v___x_133_) == 0)
{
uint64_t v___x_134_; lean_object* v___x_135_; 
lean_dec_ref_known(v___x_133_, 1);
v___x_134_ = 13850035602675728384ULL;
v___x_135_ = vastitas_storage_expect(v_a_45_, v___x_121_, v___x_74_, v___x_128_, v___x_107_, v___x_128_, v___x_76_, v___x_85_, v___x_111_, v___x_71_, v___x_134_, v___x_74_);
if (lean_obj_tag(v___x_135_) == 0)
{
uint64_t v___x_136_; uint64_t v___x_137_; lean_object* v___x_138_; 
lean_dec_ref_known(v___x_135_, 1);
v___x_136_ = 1151ULL;
v___x_137_ = 13849006459792130048ULL;
v___x_138_ = vastitas_storage_expect(v_a_45_, v___x_121_, v___x_74_, v___x_128_, v___x_107_, v___x_128_, v___x_76_, v___x_136_, v___x_74_, v___x_71_, v___x_137_, v___x_74_);
if (lean_obj_tag(v___x_138_) == 0)
{
lean_object* v___x_139_; 
lean_dec_ref_known(v___x_138_, 1);
v___x_139_ = vastitas_storage_drop(v_a_45_, v___x_121_);
if (lean_obj_tag(v___x_139_) == 0)
{
lean_object* v___x_140_; 
lean_dec_ref_known(v___x_139_, 1);
v___x_140_ = vastitas_storage_drop(v_a_45_, v___x_118_);
if (lean_obj_tag(v___x_140_) == 0)
{
lean_object* v___x_141_; 
lean_dec_ref_known(v___x_140_, 1);
v___x_141_ = vastitas_storage_drop(v_a_45_, v___x_114_);
if (lean_obj_tag(v___x_141_) == 0)
{
lean_object* v___x_142_; 
lean_dec_ref_known(v___x_141_, 1);
v___x_142_ = vastitas_storage_drop(v_a_45_, v___x_102_);
if (lean_obj_tag(v___x_142_) == 0)
{
lean_object* v___x_143_; 
lean_dec_ref_known(v___x_142_, 1);
v___x_143_ = vastitas_storage_drop(v_a_45_, v___x_88_);
if (lean_obj_tag(v___x_143_) == 0)
{
lean_object* v___x_144_; 
lean_dec_ref_known(v___x_143_, 1);
v___x_144_ = vastitas_storage_drop(v_a_45_, v___x_70_);
if (lean_obj_tag(v___x_144_) == 0)
{
lean_object* v___x_145_; 
lean_dec_ref_known(v___x_144_, 1);
v___x_145_ = lean_box(0);
v_a_47_ = v___x_145_;
goto v___jp_46_;
}
else
{
v___y_58_ = v___x_144_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_143_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_142_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_141_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_140_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_139_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_138_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_135_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_133_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_131_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_130_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_127_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_126_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_124_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_123_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_120_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_119_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_117_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_116_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_113_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_110_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_108_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_105_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_104_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_101_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_98_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_95_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_91_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_90_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_87_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_84_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_82_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_78_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_73_;
goto v___jp_57_;
}
v___jp_46_:
{
lean_object* v___x_48_; 
v___x_48_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_48_) == 0)
{
lean_object* v___x_50_; uint8_t v_isShared_51_; uint8_t v_isSharedCheck_55_; 
v_isSharedCheck_55_ = !lean_is_exclusive(v___x_48_);
if (v_isSharedCheck_55_ == 0)
{
lean_object* v_unused_56_; 
v_unused_56_ = lean_ctor_get(v___x_48_, 0);
lean_dec(v_unused_56_);
v___x_50_ = v___x_48_;
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
else
{
lean_dec(v___x_48_);
v___x_50_ = lean_box(0);
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
v_resetjp_49_:
{
lean_object* v___x_53_; 
if (v_isShared_51_ == 0)
{
lean_ctor_set(v___x_50_, 0, v_a_47_);
v___x_53_ = v___x_50_;
goto v_reusejp_52_;
}
else
{
lean_object* v_reuseFailAlloc_54_; 
v_reuseFailAlloc_54_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_54_, 0, v_a_47_);
v___x_53_ = v_reuseFailAlloc_54_;
goto v_reusejp_52_;
}
v_reusejp_52_:
{
return v___x_53_;
}
}
}
else
{
return v___x_48_;
}
}
v___jp_57_:
{
if (lean_obj_tag(v___y_58_) == 0)
{
lean_object* v_a_59_; 
v_a_59_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_59_);
lean_dec_ref_known(v___y_58_, 1);
v_a_47_ = v_a_59_;
goto v___jp_46_;
}
else
{
lean_object* v_a_60_; lean_object* v___x_61_; 
v_a_60_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_60_);
lean_dec_ref_known(v___y_58_, 1);
v___x_61_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_61_) == 0)
{
lean_object* v___x_63_; uint8_t v_isShared_64_; uint8_t v_isSharedCheck_68_; 
v_isSharedCheck_68_ = !lean_is_exclusive(v___x_61_);
if (v_isSharedCheck_68_ == 0)
{
lean_object* v_unused_69_; 
v_unused_69_ = lean_ctor_get(v___x_61_, 0);
lean_dec(v_unused_69_);
v___x_63_ = v___x_61_;
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
else
{
lean_dec(v___x_61_);
v___x_63_ = lean_box(0);
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
v_resetjp_62_:
{
lean_object* v___x_66_; 
if (v_isShared_64_ == 0)
{
lean_ctor_set_tag(v___x_63_, 1);
lean_ctor_set(v___x_63_, 0, v_a_60_);
v___x_66_ = v___x_63_;
goto v_reusejp_65_;
}
else
{
lean_object* v_reuseFailAlloc_67_; 
v_reuseFailAlloc_67_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_67_, 0, v_a_60_);
v___x_66_ = v_reuseFailAlloc_67_;
goto v_reusejp_65_;
}
v_reusejp_65_:
{
return v___x_66_;
}
}
}
else
{
lean_dec(v_a_60_);
return v___x_61_;
}
}
}
}
else
{
lean_object* v_a_146_; lean_object* v___x_148_; uint8_t v_isShared_149_; uint8_t v_isSharedCheck_153_; 
v_a_146_ = lean_ctor_get(v___x_44_, 0);
v_isSharedCheck_153_ = !lean_is_exclusive(v___x_44_);
if (v_isSharedCheck_153_ == 0)
{
v___x_148_ = v___x_44_;
v_isShared_149_ = v_isSharedCheck_153_;
goto v_resetjp_147_;
}
else
{
lean_inc(v_a_146_);
lean_dec(v___x_44_);
v___x_148_ = lean_box(0);
v_isShared_149_ = v_isSharedCheck_153_;
goto v_resetjp_147_;
}
v_resetjp_147_:
{
lean_object* v___x_151_; 
if (v_isShared_149_ == 0)
{
v___x_151_ = v___x_148_;
goto v_reusejp_150_;
}
else
{
lean_object* v_reuseFailAlloc_152_; 
v_reuseFailAlloc_152_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_152_, 0, v_a_146_);
v___x_151_ = v_reuseFailAlloc_152_;
goto v_reusejp_150_;
}
v_reusejp_150_:
{
return v___x_151_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object* v_a_154_){
_start:
{
lean_object* v_res_155_; 
v_res_155_ = lp_allocation__audit_generatedOnce();
return v_res_155_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure(){
_start:
{
uint64_t v___x_157_; lean_object* v___x_158_; 
v___x_157_ = 9223372036854775807ULL;
v___x_158_ = vastitas_storage_new(v___x_157_);
if (lean_obj_tag(v___x_158_) == 0)
{
lean_object* v_a_159_; lean_object* v_a_161_; lean_object* v___y_172_; uint32_t v___x_184_; uint8_t v___x_185_; uint64_t v___x_186_; lean_object* v___x_187_; 
v_a_159_ = lean_ctor_get(v___x_158_, 0);
lean_inc(v_a_159_);
lean_dec_ref_known(v___x_158_, 1);
v___x_184_ = 0;
v___x_185_ = 0;
v___x_186_ = 30720ULL;
v___x_187_ = vastitas_storage_allocate(v_a_159_, v___x_184_, v___x_185_, v___x_186_);
if (lean_obj_tag(v___x_187_) == 0)
{
uint64_t v___x_188_; uint64_t v___x_189_; uint8_t v___x_190_; uint64_t v___x_191_; lean_object* v___x_192_; 
lean_dec_ref_known(v___x_187_, 1);
v___x_188_ = 0ULL;
v___x_189_ = 1ULL;
v___x_190_ = 0;
v___x_191_ = 13842939354630062080ULL;
v___x_192_ = vastitas_storage_fill(v_a_159_, v___x_184_, v___x_188_, v___x_186_, v___x_189_, v___x_186_, v___x_190_, v___x_185_, v___x_191_, v___x_188_);
if (lean_obj_tag(v___x_192_) == 0)
{
uint64_t v___x_193_; uint64_t v___x_194_; uint64_t v___x_195_; lean_object* v___x_196_; 
lean_dec_ref_known(v___x_192_, 1);
v___x_193_ = 24ULL;
v___x_194_ = 1280ULL;
v___x_195_ = 4593671619917905920ULL;
v___x_196_ = vastitas_storage_fill(v_a_159_, v___x_184_, v___x_188_, v___x_193_, v___x_194_, v___x_193_, v___x_190_, v___x_185_, v___x_195_, v___x_188_);
if (lean_obj_tag(v___x_196_) == 0)
{
uint64_t v___x_197_; lean_object* v___x_198_; 
lean_dec_ref_known(v___x_196_, 1);
v___x_197_ = 4607182418800017408ULL;
v___x_198_ = vastitas_storage_store(v_a_159_, v___x_184_, v___x_188_, v___x_193_, v___x_194_, v___x_193_, v___x_190_, v___x_188_, v___x_188_, v___x_185_, v___x_197_, v___x_188_);
if (lean_obj_tag(v___x_198_) == 0)
{
uint64_t v___x_199_; uint64_t v___x_200_; lean_object* v___x_201_; 
lean_dec_ref_known(v___x_198_, 1);
v___x_199_ = 23ULL;
v___x_200_ = 13826050856027422720ULL;
v___x_201_ = vastitas_storage_store(v_a_159_, v___x_184_, v___x_188_, v___x_193_, v___x_194_, v___x_193_, v___x_190_, v___x_199_, v___x_189_, v___x_185_, v___x_200_, v___x_188_);
if (lean_obj_tag(v___x_201_) == 0)
{
uint32_t v___x_202_; uint64_t v___x_203_; lean_object* v___x_204_; 
lean_dec_ref_known(v___x_201_, 1);
v___x_202_ = 1;
v___x_203_ = 1920ULL;
v___x_204_ = vastitas_storage_allocate(v_a_159_, v___x_202_, v___x_185_, v___x_203_);
if (lean_obj_tag(v___x_204_) == 0)
{
lean_object* v___x_205_; 
lean_dec_ref_known(v___x_204_, 1);
v___x_205_ = vastitas_storage_fill(v_a_159_, v___x_202_, v___x_188_, v___x_203_, v___x_189_, v___x_203_, v___x_190_, v___x_185_, v___x_191_, v___x_188_);
if (lean_obj_tag(v___x_205_) == 0)
{
uint64_t v___x_206_; uint64_t v___x_207_; uint64_t v___x_208_; lean_object* v___x_209_; 
lean_dec_ref_known(v___x_205_, 1);
v___x_206_ = 40ULL;
v___x_207_ = 48ULL;
v___x_208_ = 13821547256400052224ULL;
v___x_209_ = vastitas_storage_fill(v_a_159_, v___x_202_, v___x_188_, v___x_206_, v___x_207_, v___x_206_, v___x_190_, v___x_185_, v___x_208_, v___x_188_);
if (lean_obj_tag(v___x_209_) == 0)
{
uint64_t v___x_210_; uint64_t v___x_211_; lean_object* v___x_212_; 
lean_dec_ref_known(v___x_209_, 1);
v___x_210_ = 47ULL;
v___x_211_ = 4602678819172646912ULL;
v___x_212_ = vastitas_storage_store(v_a_159_, v___x_202_, v___x_188_, v___x_206_, v___x_207_, v___x_206_, v___x_190_, v___x_188_, v___x_210_, v___x_185_, v___x_211_, v___x_188_);
if (lean_obj_tag(v___x_212_) == 0)
{
uint64_t v___x_213_; uint64_t v___x_214_; lean_object* v___x_215_; 
lean_dec_ref_known(v___x_212_, 1);
v___x_213_ = 39ULL;
v___x_214_ = 13828302655841107968ULL;
v___x_215_ = vastitas_storage_store(v_a_159_, v___x_202_, v___x_188_, v___x_206_, v___x_207_, v___x_206_, v___x_190_, v___x_213_, v___x_188_, v___x_185_, v___x_214_, v___x_188_);
if (lean_obj_tag(v___x_215_) == 0)
{
uint32_t v___x_216_; uint64_t v___x_217_; lean_object* v___x_218_; 
lean_dec_ref_known(v___x_215_, 1);
v___x_216_ = 2;
v___x_217_ = 1792ULL;
v___x_218_ = vastitas_storage_allocate(v_a_159_, v___x_216_, v___x_185_, v___x_217_);
if (lean_obj_tag(v___x_218_) == 0)
{
lean_object* v___x_219_; 
lean_dec_ref_known(v___x_218_, 1);
v___x_219_ = vastitas_storage_fill(v_a_159_, v___x_216_, v___x_188_, v___x_217_, v___x_189_, v___x_217_, v___x_190_, v___x_185_, v___x_191_, v___x_188_);
if (lean_obj_tag(v___x_219_) == 0)
{
uint64_t v___x_220_; uint64_t v___x_221_; lean_object* v___x_222_; 
lean_dec_ref_known(v___x_219_, 1);
v___x_220_ = 32ULL;
v___x_221_ = 56ULL;
v___x_222_ = vastitas_storage_fill(v_a_159_, v___x_216_, v___x_188_, v___x_220_, v___x_221_, v___x_220_, v___x_190_, v___x_185_, v___x_211_, v___x_188_);
if (lean_obj_tag(v___x_222_) == 0)
{
uint64_t v___x_223_; lean_object* v___x_224_; 
lean_dec_ref_known(v___x_222_, 1);
v___x_223_ = 31ULL;
v___x_224_ = vastitas_storage_store(v_a_159_, v___x_216_, v___x_188_, v___x_220_, v___x_221_, v___x_220_, v___x_190_, v___x_223_, v___x_188_, v___x_185_, v___x_208_, v___x_188_);
if (lean_obj_tag(v___x_224_) == 0)
{
uint64_t v___x_225_; uint64_t v___x_226_; lean_object* v___x_227_; 
lean_dec_ref_known(v___x_224_, 1);
v___x_225_ = 55ULL;
v___x_226_ = 4604930618986332160ULL;
v___x_227_ = vastitas_storage_store(v_a_159_, v___x_216_, v___x_188_, v___x_220_, v___x_221_, v___x_220_, v___x_190_, v___x_188_, v___x_225_, v___x_185_, v___x_226_, v___x_188_);
if (lean_obj_tag(v___x_227_) == 0)
{
uint32_t v___x_228_; uint64_t v___x_229_; lean_object* v___x_230_; 
lean_dec_ref_known(v___x_227_, 1);
v___x_228_ = 3;
v___x_229_ = 36864ULL;
v___x_230_ = vastitas_storage_allocate(v_a_159_, v___x_228_, v___x_185_, v___x_229_);
if (lean_obj_tag(v___x_230_) == 0)
{
lean_object* v___x_231_; 
lean_dec_ref_known(v___x_230_, 1);
v___x_231_ = vastitas_storage_fill(v_a_159_, v___x_228_, v___x_188_, v___x_229_, v___x_189_, v___x_229_, v___x_190_, v___x_185_, v___x_191_, v___x_188_);
if (lean_obj_tag(v___x_231_) == 0)
{
uint32_t v___x_232_; lean_object* v___x_233_; 
lean_dec_ref_known(v___x_231_, 1);
v___x_232_ = 4;
v___x_233_ = vastitas_storage_allocate(v_a_159_, v___x_232_, v___x_185_, v___x_229_);
if (lean_obj_tag(v___x_233_) == 0)
{
lean_object* v___x_234_; 
lean_dec_ref_known(v___x_233_, 1);
v___x_234_ = vastitas_storage_fill(v_a_159_, v___x_232_, v___x_188_, v___x_229_, v___x_189_, v___x_229_, v___x_190_, v___x_185_, v___x_191_, v___x_188_);
if (lean_obj_tag(v___x_234_) == 0)
{
uint32_t v___x_235_; uint64_t v___x_236_; lean_object* v___x_237_; 
lean_dec_ref_known(v___x_234_, 1);
v___x_235_ = 5;
v___x_236_ = 64512ULL;
v___x_237_ = vastitas_storage_allocate(v_a_159_, v___x_235_, v___x_185_, v___x_236_);
if (lean_obj_tag(v___x_237_) == 0)
{
lean_object* v___x_238_; 
lean_dec_ref_known(v___x_237_, 1);
v___x_238_ = vastitas_storage_fill(v_a_159_, v___x_235_, v___x_188_, v___x_236_, v___x_189_, v___x_236_, v___x_190_, v___x_185_, v___x_191_, v___x_188_);
if (lean_obj_tag(v___x_238_) == 0)
{
uint64_t v___x_239_; lean_object* v___x_240_; 
lean_dec_ref_known(v___x_238_, 1);
v___x_239_ = 768ULL;
v___x_240_ = vastitas_storage_pack3(v_a_159_, v___x_184_, v___x_188_, v___x_193_, v___x_194_, v___x_193_, v___x_190_, v___x_228_, v___x_188_, v___x_239_, v___x_206_, v___x_239_, v___x_190_, v___x_193_, v___x_206_, v___x_220_);
if (lean_obj_tag(v___x_240_) == 0)
{
lean_object* v___x_241_; 
lean_dec_ref_known(v___x_240_, 1);
v___x_241_ = vastitas_gemm_execute(v_a_159_, v___x_228_, v___x_188_, v___x_239_, v___x_206_, v___x_239_, v___x_190_, v___x_190_, v___x_202_, v___x_188_, v___x_206_, v___x_207_, v___x_206_, v___x_190_, v___x_190_, v___x_232_, v___x_188_, v___x_239_, v___x_207_, v___x_239_, v___x_190_, v___x_185_);
if (lean_obj_tag(v___x_241_) == 0)
{
uint64_t v___x_242_; uint64_t v___x_243_; lean_object* v___x_244_; 
lean_dec_ref_known(v___x_241_, 1);
v___x_242_ = 1152ULL;
v___x_243_ = 42ULL;
v___x_244_ = vastitas_storage_regroup3(v_a_159_, v___x_232_, v___x_188_, v___x_239_, v___x_207_, v___x_239_, v___x_190_, v___x_228_, v___x_188_, v___x_242_, v___x_220_, v___x_242_, v___x_190_, v___x_193_, v___x_220_, v___x_207_, v___x_207_, v___x_243_);
if (lean_obj_tag(v___x_244_) == 0)
{
lean_object* v___x_245_; 
lean_dec_ref_known(v___x_244_, 1);
v___x_245_ = vastitas_gemm_execute(v_a_159_, v___x_228_, v___x_188_, v___x_242_, v___x_220_, v___x_242_, v___x_190_, v___x_190_, v___x_216_, v___x_188_, v___x_220_, v___x_221_, v___x_220_, v___x_190_, v___x_190_, v___x_235_, v___x_188_, v___x_242_, v___x_221_, v___x_242_, v___x_190_, v___x_185_);
if (lean_obj_tag(v___x_245_) == 0)
{
uint64_t v___x_246_; lean_object* v___x_247_; 
lean_dec_ref_known(v___x_245_, 1);
v___x_246_ = 13849729938443206657ULL;
v___x_247_ = vastitas_storage_expect(v_a_159_, v___x_235_, v___x_188_, v___x_242_, v___x_221_, v___x_242_, v___x_190_, v___x_188_, v___x_188_, v___x_185_, v___x_246_, v___x_188_);
if (lean_obj_tag(v___x_247_) == 0)
{
uint64_t v___x_248_; lean_object* v___x_249_; 
lean_dec_ref_known(v___x_247_, 1);
v___x_248_ = 13850035602675728384ULL;
v___x_249_ = vastitas_storage_expect(v_a_159_, v___x_235_, v___x_188_, v___x_242_, v___x_221_, v___x_242_, v___x_190_, v___x_199_, v___x_225_, v___x_185_, v___x_248_, v___x_188_);
if (lean_obj_tag(v___x_249_) == 0)
{
uint64_t v___x_250_; uint64_t v___x_251_; lean_object* v___x_252_; 
lean_dec_ref_known(v___x_249_, 1);
v___x_250_ = 1151ULL;
v___x_251_ = 13849006459792130048ULL;
v___x_252_ = vastitas_storage_expect(v_a_159_, v___x_235_, v___x_188_, v___x_242_, v___x_221_, v___x_242_, v___x_190_, v___x_250_, v___x_188_, v___x_185_, v___x_251_, v___x_188_);
if (lean_obj_tag(v___x_252_) == 0)
{
lean_object* v___x_253_; 
lean_dec_ref_known(v___x_252_, 1);
v___x_253_ = vastitas_storage_drop(v_a_159_, v___x_235_);
if (lean_obj_tag(v___x_253_) == 0)
{
lean_object* v___x_254_; 
lean_dec_ref_known(v___x_253_, 1);
v___x_254_ = vastitas_storage_drop(v_a_159_, v___x_232_);
if (lean_obj_tag(v___x_254_) == 0)
{
lean_object* v___x_255_; 
lean_dec_ref_known(v___x_254_, 1);
v___x_255_ = vastitas_storage_drop(v_a_159_, v___x_228_);
if (lean_obj_tag(v___x_255_) == 0)
{
lean_object* v___x_256_; 
lean_dec_ref_known(v___x_255_, 1);
v___x_256_ = vastitas_storage_drop(v_a_159_, v___x_216_);
if (lean_obj_tag(v___x_256_) == 0)
{
lean_object* v___x_257_; 
lean_dec_ref_known(v___x_256_, 1);
v___x_257_ = vastitas_storage_drop(v_a_159_, v___x_202_);
if (lean_obj_tag(v___x_257_) == 0)
{
lean_object* v___x_258_; 
lean_dec_ref_known(v___x_257_, 1);
v___x_258_ = vastitas_storage_drop(v_a_159_, v___x_184_);
if (lean_obj_tag(v___x_258_) == 0)
{
lean_object* v___x_259_; 
lean_dec_ref_known(v___x_258_, 1);
v___x_259_ = lean_box(0);
v_a_161_ = v___x_259_;
goto v___jp_160_;
}
else
{
v___y_172_ = v___x_258_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_257_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_256_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_255_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_254_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_253_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_252_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_249_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_247_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_245_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_244_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_241_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_240_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_238_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_237_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_234_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_233_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_231_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_230_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_227_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_224_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_222_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_219_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_218_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_215_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_212_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_209_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_205_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_204_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_201_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_198_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_196_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_192_;
goto v___jp_171_;
}
}
else
{
v___y_172_ = v___x_187_;
goto v___jp_171_;
}
v___jp_160_:
{
lean_object* v___x_162_; 
v___x_162_ = vastitas_storage_close(v_a_159_);
lean_dec(v_a_159_);
if (lean_obj_tag(v___x_162_) == 0)
{
lean_object* v___x_164_; uint8_t v_isShared_165_; uint8_t v_isSharedCheck_169_; 
v_isSharedCheck_169_ = !lean_is_exclusive(v___x_162_);
if (v_isSharedCheck_169_ == 0)
{
lean_object* v_unused_170_; 
v_unused_170_ = lean_ctor_get(v___x_162_, 0);
lean_dec(v_unused_170_);
v___x_164_ = v___x_162_;
v_isShared_165_ = v_isSharedCheck_169_;
goto v_resetjp_163_;
}
else
{
lean_dec(v___x_162_);
v___x_164_ = lean_box(0);
v_isShared_165_ = v_isSharedCheck_169_;
goto v_resetjp_163_;
}
v_resetjp_163_:
{
lean_object* v___x_167_; 
if (v_isShared_165_ == 0)
{
lean_ctor_set(v___x_164_, 0, v_a_161_);
v___x_167_ = v___x_164_;
goto v_reusejp_166_;
}
else
{
lean_object* v_reuseFailAlloc_168_; 
v_reuseFailAlloc_168_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_168_, 0, v_a_161_);
v___x_167_ = v_reuseFailAlloc_168_;
goto v_reusejp_166_;
}
v_reusejp_166_:
{
return v___x_167_;
}
}
}
else
{
return v___x_162_;
}
}
v___jp_171_:
{
if (lean_obj_tag(v___y_172_) == 0)
{
lean_object* v_a_173_; 
v_a_173_ = lean_ctor_get(v___y_172_, 0);
lean_inc(v_a_173_);
lean_dec_ref_known(v___y_172_, 1);
v_a_161_ = v_a_173_;
goto v___jp_160_;
}
else
{
lean_object* v_a_174_; lean_object* v___x_175_; 
v_a_174_ = lean_ctor_get(v___y_172_, 0);
lean_inc(v_a_174_);
lean_dec_ref_known(v___y_172_, 1);
v___x_175_ = vastitas_storage_close(v_a_159_);
lean_dec(v_a_159_);
if (lean_obj_tag(v___x_175_) == 0)
{
lean_object* v___x_177_; uint8_t v_isShared_178_; uint8_t v_isSharedCheck_182_; 
v_isSharedCheck_182_ = !lean_is_exclusive(v___x_175_);
if (v_isSharedCheck_182_ == 0)
{
lean_object* v_unused_183_; 
v_unused_183_ = lean_ctor_get(v___x_175_, 0);
lean_dec(v_unused_183_);
v___x_177_ = v___x_175_;
v_isShared_178_ = v_isSharedCheck_182_;
goto v_resetjp_176_;
}
else
{
lean_dec(v___x_175_);
v___x_177_ = lean_box(0);
v_isShared_178_ = v_isSharedCheck_182_;
goto v_resetjp_176_;
}
v_resetjp_176_:
{
lean_object* v___x_180_; 
if (v_isShared_178_ == 0)
{
lean_ctor_set_tag(v___x_177_, 1);
lean_ctor_set(v___x_177_, 0, v_a_174_);
v___x_180_ = v___x_177_;
goto v_reusejp_179_;
}
else
{
lean_object* v_reuseFailAlloc_181_; 
v_reuseFailAlloc_181_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_181_, 0, v_a_174_);
v___x_180_ = v_reuseFailAlloc_181_;
goto v_reusejp_179_;
}
v_reusejp_179_:
{
return v___x_180_;
}
}
}
else
{
lean_dec(v_a_174_);
return v___x_175_;
}
}
}
}
else
{
lean_object* v_a_260_; lean_object* v___x_262_; uint8_t v_isShared_263_; uint8_t v_isSharedCheck_267_; 
v_a_260_ = lean_ctor_get(v___x_158_, 0);
v_isSharedCheck_267_ = !lean_is_exclusive(v___x_158_);
if (v_isSharedCheck_267_ == 0)
{
v___x_262_ = v___x_158_;
v_isShared_263_ = v_isSharedCheck_267_;
goto v_resetjp_261_;
}
else
{
lean_inc(v_a_260_);
lean_dec(v___x_158_);
v___x_262_ = lean_box(0);
v_isShared_263_ = v_isSharedCheck_267_;
goto v_resetjp_261_;
}
v_resetjp_261_:
{
lean_object* v___x_265_; 
if (v_isShared_263_ == 0)
{
v___x_265_ = v___x_262_;
goto v_reusejp_264_;
}
else
{
lean_object* v_reuseFailAlloc_266_; 
v_reuseFailAlloc_266_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_266_, 0, v_a_260_);
v___x_265_ = v_reuseFailAlloc_266_;
goto v_reusejp_264_;
}
v_reusejp_264_:
{
return v___x_265_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object* v_a_268_){
_start:
{
lean_object* v_res_269_; 
v_res_269_ = lp_allocation__audit_generatedFailure();
return v_res_269_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object* v_phase_272_, lean_object* v_a_00___x40___internal___hyg_273_){
_start:
{
uint32_t v_phase_boxed_274_; lean_object* v_res_275_; 
v_phase_boxed_274_ = lean_unbox_uint32(v_phase_272_);
lean_dec(v_phase_272_);
v_res_275_ = audit_mark_lean(v_phase_boxed_274_);
return v_res_275_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object* v_a_276_, lean_object* v_scope_277_, lean_object* v_range_278_, lean_object* v_b_279_, lean_object* v_i_280_){
_start:
{
lean_object* v_stop_282_; lean_object* v_step_283_; uint8_t v___x_284_; 
v_stop_282_ = lean_ctor_get(v_range_278_, 1);
v_step_283_ = lean_ctor_get(v_range_278_, 2);
v___x_284_ = lean_nat_dec_lt(v_i_280_, v_stop_282_);
if (v___x_284_ == 0)
{
lean_object* v___x_285_; 
lean_dec(v_i_280_);
v___x_285_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_285_, 0, v_b_279_);
return v___x_285_;
}
else
{
uint32_t v___x_286_; uint64_t v___x_287_; uint64_t v___x_288_; uint64_t v___x_289_; lean_object* v___x_290_; uint8_t v___x_291_; uint32_t v___x_292_; uint64_t v___x_293_; uint64_t v___x_294_; uint32_t v___x_295_; uint64_t v___x_296_; uint32_t v___x_297_; uint8_t v___x_298_; uint32_t v___x_299_; uint64_t v___x_300_; uint32_t v___x_301_; lean_object* v___x_302_; uint64_t v___x_303_; lean_object* v___x_304_; 
v___x_286_ = 0;
v___x_287_ = 0ULL;
v___x_288_ = 24ULL;
v___x_289_ = 1280ULL;
v___x_290_ = lean_unsigned_to_nat(0u);
v___x_291_ = lean_nat_dec_eq(v_scope_277_, v___x_290_);
v___x_292_ = 3;
v___x_293_ = 40ULL;
v___x_294_ = 32ULL;
v___x_295_ = 1;
v___x_296_ = 48ULL;
v___x_297_ = 4;
v___x_298_ = 0;
v___x_299_ = 2;
v___x_300_ = 56ULL;
v___x_301_ = 5;
v___x_302_ = lean_box(0);
v___x_303_ = 768ULL;
v___x_304_ = vastitas_storage_pack3(v_a_276_, v___x_286_, v___x_287_, v___x_288_, v___x_289_, v___x_288_, v___x_291_, v___x_292_, v___x_287_, v___x_303_, v___x_293_, v___x_303_, v___x_291_, v___x_288_, v___x_293_, v___x_294_);
if (lean_obj_tag(v___x_304_) == 0)
{
lean_object* v___x_305_; 
lean_dec_ref_known(v___x_304_, 1);
v___x_305_ = vastitas_gemm_execute(v_a_276_, v___x_292_, v___x_287_, v___x_303_, v___x_293_, v___x_303_, v___x_291_, v___x_291_, v___x_295_, v___x_287_, v___x_293_, v___x_296_, v___x_293_, v___x_291_, v___x_291_, v___x_297_, v___x_287_, v___x_303_, v___x_296_, v___x_303_, v___x_291_, v___x_298_);
if (lean_obj_tag(v___x_305_) == 0)
{
uint64_t v___x_306_; uint64_t v___x_307_; lean_object* v___x_308_; 
lean_dec_ref_known(v___x_305_, 1);
v___x_306_ = 1152ULL;
v___x_307_ = 42ULL;
v___x_308_ = vastitas_storage_regroup3(v_a_276_, v___x_297_, v___x_287_, v___x_303_, v___x_296_, v___x_303_, v___x_291_, v___x_292_, v___x_287_, v___x_306_, v___x_294_, v___x_306_, v___x_291_, v___x_288_, v___x_294_, v___x_296_, v___x_296_, v___x_307_);
if (lean_obj_tag(v___x_308_) == 0)
{
lean_object* v___x_309_; 
lean_dec_ref_known(v___x_308_, 1);
v___x_309_ = vastitas_gemm_execute(v_a_276_, v___x_292_, v___x_287_, v___x_306_, v___x_294_, v___x_306_, v___x_291_, v___x_291_, v___x_299_, v___x_287_, v___x_294_, v___x_300_, v___x_294_, v___x_291_, v___x_291_, v___x_301_, v___x_287_, v___x_306_, v___x_300_, v___x_306_, v___x_291_, v___x_298_);
if (lean_obj_tag(v___x_309_) == 0)
{
lean_object* v___x_310_; 
lean_dec_ref_known(v___x_309_, 1);
v___x_310_ = lean_nat_add(v_i_280_, v_step_283_);
lean_dec(v_i_280_);
v_b_279_ = v___x_302_;
v_i_280_ = v___x_310_;
goto _start;
}
else
{
lean_dec(v_i_280_);
return v___x_309_;
}
}
else
{
lean_dec(v_i_280_);
return v___x_308_;
}
}
else
{
lean_dec(v_i_280_);
return v___x_305_;
}
}
else
{
lean_dec(v_i_280_);
return v___x_304_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object* v_a_312_, lean_object* v_scope_313_, lean_object* v_range_314_, lean_object* v_b_315_, lean_object* v_i_316_, lean_object* v___y_317_){
_start:
{
lean_object* v_res_318_; 
v_res_318_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_312_, v_scope_313_, v_range_314_, v_b_315_, v_i_316_);
lean_dec_ref(v_range_314_);
lean_dec(v_scope_313_);
lean_dec(v_a_312_);
return v_res_318_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object* v_range_319_, lean_object* v_b_320_, lean_object* v_i_321_){
_start:
{
lean_object* v_stop_323_; lean_object* v_step_324_; uint8_t v___x_325_; 
v_stop_323_ = lean_ctor_get(v_range_319_, 1);
v_step_324_ = lean_ctor_get(v_range_319_, 2);
v___x_325_ = lean_nat_dec_lt(v_i_321_, v_stop_323_);
if (v___x_325_ == 0)
{
lean_object* v___x_326_; 
lean_dec(v_i_321_);
v___x_326_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_326_, 0, v_b_320_);
return v___x_326_;
}
else
{
lean_object* v___x_327_; lean_object* v___x_328_; 
v___x_327_ = lean_box(0);
v___x_328_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_328_) == 0)
{
lean_object* v___x_329_; 
lean_dec_ref_known(v___x_328_, 1);
v___x_329_ = lean_nat_add(v_i_321_, v_step_324_);
lean_dec(v_i_321_);
v_b_320_ = v___x_327_;
v_i_321_ = v___x_329_;
goto _start;
}
else
{
lean_dec(v_i_321_);
return v___x_328_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object* v_range_331_, lean_object* v_b_332_, lean_object* v_i_333_, lean_object* v___y_334_){
_start:
{
lean_object* v_res_335_; 
v_res_335_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_331_, v_b_332_, v_i_333_);
lean_dec_ref(v_range_331_);
return v_res_335_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_344_){
_start:
{
lean_object* v___x_346_; lean_object* v___x_347_; lean_object* v_impl_348_; lean_object* v___x_349_; lean_object* v___x_350_; lean_object* v___x_351_; lean_object* v___x_352_; lean_object* v_scope_353_; lean_object* v___x_354_; lean_object* v___x_355_; lean_object* v___x_356_; lean_object* v___x_357_; lean_object* v_reps_358_; lean_object* v___x_359_; lean_object* v___x_360_; lean_object* v___x_361_; uint8_t v_verify_362_; uint32_t v___x_363_; lean_object* v___x_364_; 
v___x_346_ = ((lean_object*)(lp_allocation__audit_main___closed__0));
v___x_347_ = lean_unsigned_to_nat(0u);
v_impl_348_ = l_List_get_x21Internal___redArg(v___x_346_, v_args_344_, v___x_347_);
v___x_349_ = lean_unsigned_to_nat(1u);
v___x_350_ = l_List_get_x21Internal___redArg(v___x_346_, v_args_344_, v___x_349_);
v___x_351_ = lean_string_utf8_byte_size(v___x_350_);
v___x_352_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_352_, 0, v___x_350_);
lean_ctor_set(v___x_352_, 1, v___x_347_);
lean_ctor_set(v___x_352_, 2, v___x_351_);
v_scope_353_ = l_String_Slice_toNat_x21(v___x_352_);
lean_dec_ref_known(v___x_352_, 3);
v___x_354_ = lean_unsigned_to_nat(2u);
v___x_355_ = l_List_get_x21Internal___redArg(v___x_346_, v_args_344_, v___x_354_);
v___x_356_ = lean_string_utf8_byte_size(v___x_355_);
v___x_357_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_357_, 0, v___x_355_);
lean_ctor_set(v___x_357_, 1, v___x_347_);
lean_ctor_set(v___x_357_, 2, v___x_356_);
v_reps_358_ = l_String_Slice_toNat_x21(v___x_357_);
lean_dec_ref_known(v___x_357_, 3);
v___x_359_ = lean_unsigned_to_nat(3u);
v___x_360_ = l_List_get_x21Internal___redArg(v___x_346_, v_args_344_, v___x_359_);
lean_dec(v_args_344_);
v___x_361_ = ((lean_object*)(lp_allocation__audit_main___closed__1));
v_verify_362_ = lean_string_dec_eq(v___x_360_, v___x_361_);
lean_dec(v___x_360_);
v___x_363_ = 1;
v___x_364_ = audit_mark_lean(v___x_363_);
if (lean_obj_tag(v___x_364_) == 0)
{
lean_object* v___x_365_; 
lean_dec_ref_known(v___x_364_, 1);
v___x_365_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_365_) == 0)
{
uint32_t v___x_366_; lean_object* v___x_367_; 
lean_dec_ref_known(v___x_365_, 1);
v___x_366_ = 2;
v___x_367_ = audit_mark_lean(v___x_366_);
if (lean_obj_tag(v___x_367_) == 0)
{
lean_object* v___x_368_; uint8_t v___x_369_; 
lean_dec_ref_known(v___x_367_, 1);
v___x_368_ = ((lean_object*)(lp_allocation__audit_main___closed__2));
v___x_369_ = lean_string_dec_eq(v_impl_348_, v___x_368_);
if (v___x_369_ == 0)
{
lean_object* v___x_370_; uint8_t v___x_371_; 
v___x_370_ = ((lean_object*)(lp_allocation__audit_main___closed__3));
v___x_371_ = lean_string_dec_eq(v_impl_348_, v___x_370_);
lean_dec(v_impl_348_);
if (v___x_371_ == 0)
{
uint8_t v___x_372_; 
v___x_372_ = lean_nat_dec_eq(v_scope_353_, v___x_347_);
if (v___x_372_ == 0)
{
uint64_t v___x_373_; lean_object* v___x_374_; 
v___x_373_ = 9223372036854775807ULL;
v___x_374_ = vastitas_storage_new(v___x_373_);
if (lean_obj_tag(v___x_374_) == 0)
{
lean_object* v_a_375_; lean_object* v___y_377_; uint32_t v___x_390_; uint8_t v___x_391_; uint64_t v___x_392_; lean_object* v___x_393_; 
v_a_375_ = lean_ctor_get(v___x_374_, 0);
lean_inc(v_a_375_);
lean_dec_ref_known(v___x_374_, 1);
v___x_390_ = 0;
v___x_391_ = 0;
v___x_392_ = 30720ULL;
v___x_393_ = vastitas_storage_allocate(v_a_375_, v___x_390_, v___x_391_, v___x_392_);
if (lean_obj_tag(v___x_393_) == 0)
{
uint64_t v___x_394_; uint64_t v___x_395_; uint64_t v___x_396_; lean_object* v___x_397_; 
lean_dec_ref_known(v___x_393_, 1);
v___x_394_ = 0ULL;
v___x_395_ = 1ULL;
v___x_396_ = 13842939354630062080ULL;
v___x_397_ = vastitas_storage_fill(v_a_375_, v___x_390_, v___x_394_, v___x_392_, v___x_395_, v___x_392_, v___x_372_, v___x_391_, v___x_396_, v___x_394_);
if (lean_obj_tag(v___x_397_) == 0)
{
uint64_t v___x_398_; uint64_t v___x_399_; uint64_t v___x_400_; lean_object* v___x_401_; 
lean_dec_ref_known(v___x_397_, 1);
v___x_398_ = 24ULL;
v___x_399_ = 1280ULL;
v___x_400_ = 4593671619917905920ULL;
v___x_401_ = vastitas_storage_fill(v_a_375_, v___x_390_, v___x_394_, v___x_398_, v___x_399_, v___x_398_, v___x_372_, v___x_391_, v___x_400_, v___x_394_);
if (lean_obj_tag(v___x_401_) == 0)
{
uint64_t v___x_402_; lean_object* v___x_403_; 
lean_dec_ref_known(v___x_401_, 1);
v___x_402_ = 4607182418800017408ULL;
v___x_403_ = vastitas_storage_store(v_a_375_, v___x_390_, v___x_394_, v___x_398_, v___x_399_, v___x_398_, v___x_372_, v___x_394_, v___x_394_, v___x_391_, v___x_402_, v___x_394_);
if (lean_obj_tag(v___x_403_) == 0)
{
uint64_t v___x_404_; uint64_t v___x_405_; lean_object* v___x_406_; 
lean_dec_ref_known(v___x_403_, 1);
v___x_404_ = 23ULL;
v___x_405_ = 13826050856027422720ULL;
v___x_406_ = vastitas_storage_store(v_a_375_, v___x_390_, v___x_394_, v___x_398_, v___x_399_, v___x_398_, v___x_372_, v___x_404_, v___x_395_, v___x_391_, v___x_405_, v___x_394_);
if (lean_obj_tag(v___x_406_) == 0)
{
uint64_t v___x_407_; lean_object* v___x_408_; 
lean_dec_ref_known(v___x_406_, 1);
v___x_407_ = 1920ULL;
v___x_408_ = vastitas_storage_allocate(v_a_375_, v___x_363_, v___x_391_, v___x_407_);
if (lean_obj_tag(v___x_408_) == 0)
{
lean_object* v___x_409_; 
lean_dec_ref_known(v___x_408_, 1);
v___x_409_ = vastitas_storage_fill(v_a_375_, v___x_363_, v___x_394_, v___x_407_, v___x_395_, v___x_407_, v___x_372_, v___x_391_, v___x_396_, v___x_394_);
if (lean_obj_tag(v___x_409_) == 0)
{
uint64_t v___x_410_; uint64_t v___x_411_; uint64_t v___x_412_; lean_object* v___x_413_; 
lean_dec_ref_known(v___x_409_, 1);
v___x_410_ = 40ULL;
v___x_411_ = 48ULL;
v___x_412_ = 13821547256400052224ULL;
v___x_413_ = vastitas_storage_fill(v_a_375_, v___x_363_, v___x_394_, v___x_410_, v___x_411_, v___x_410_, v___x_372_, v___x_391_, v___x_412_, v___x_394_);
if (lean_obj_tag(v___x_413_) == 0)
{
uint64_t v___x_414_; uint64_t v___x_415_; lean_object* v___x_416_; 
lean_dec_ref_known(v___x_413_, 1);
v___x_414_ = 47ULL;
v___x_415_ = 4602678819172646912ULL;
v___x_416_ = vastitas_storage_store(v_a_375_, v___x_363_, v___x_394_, v___x_410_, v___x_411_, v___x_410_, v___x_372_, v___x_394_, v___x_414_, v___x_391_, v___x_415_, v___x_394_);
if (lean_obj_tag(v___x_416_) == 0)
{
uint64_t v___x_417_; uint64_t v___x_418_; lean_object* v___x_419_; 
lean_dec_ref_known(v___x_416_, 1);
v___x_417_ = 39ULL;
v___x_418_ = 13828302655841107968ULL;
v___x_419_ = vastitas_storage_store(v_a_375_, v___x_363_, v___x_394_, v___x_410_, v___x_411_, v___x_410_, v___x_372_, v___x_417_, v___x_394_, v___x_391_, v___x_418_, v___x_394_);
if (lean_obj_tag(v___x_419_) == 0)
{
uint64_t v___x_420_; lean_object* v___x_421_; 
lean_dec_ref_known(v___x_419_, 1);
v___x_420_ = 1792ULL;
v___x_421_ = vastitas_storage_allocate(v_a_375_, v___x_366_, v___x_391_, v___x_420_);
if (lean_obj_tag(v___x_421_) == 0)
{
lean_object* v___x_422_; 
lean_dec_ref_known(v___x_421_, 1);
v___x_422_ = vastitas_storage_fill(v_a_375_, v___x_366_, v___x_394_, v___x_420_, v___x_395_, v___x_420_, v___x_372_, v___x_391_, v___x_396_, v___x_394_);
if (lean_obj_tag(v___x_422_) == 0)
{
uint64_t v___x_423_; uint64_t v___x_424_; lean_object* v___x_425_; 
lean_dec_ref_known(v___x_422_, 1);
v___x_423_ = 32ULL;
v___x_424_ = 56ULL;
v___x_425_ = vastitas_storage_fill(v_a_375_, v___x_366_, v___x_394_, v___x_423_, v___x_424_, v___x_423_, v___x_372_, v___x_391_, v___x_415_, v___x_394_);
if (lean_obj_tag(v___x_425_) == 0)
{
uint64_t v___x_426_; lean_object* v___x_427_; 
lean_dec_ref_known(v___x_425_, 1);
v___x_426_ = 31ULL;
v___x_427_ = vastitas_storage_store(v_a_375_, v___x_366_, v___x_394_, v___x_423_, v___x_424_, v___x_423_, v___x_372_, v___x_426_, v___x_394_, v___x_391_, v___x_412_, v___x_394_);
if (lean_obj_tag(v___x_427_) == 0)
{
uint64_t v___x_428_; uint64_t v___x_429_; lean_object* v___x_430_; 
lean_dec_ref_known(v___x_427_, 1);
v___x_428_ = 55ULL;
v___x_429_ = 4604930618986332160ULL;
v___x_430_ = vastitas_storage_store(v_a_375_, v___x_366_, v___x_394_, v___x_423_, v___x_424_, v___x_423_, v___x_372_, v___x_394_, v___x_428_, v___x_391_, v___x_429_, v___x_394_);
if (lean_obj_tag(v___x_430_) == 0)
{
uint32_t v___x_431_; uint64_t v___x_432_; lean_object* v___x_433_; 
lean_dec_ref_known(v___x_430_, 1);
v___x_431_ = 3;
v___x_432_ = 36864ULL;
v___x_433_ = vastitas_storage_allocate(v_a_375_, v___x_431_, v___x_391_, v___x_432_);
if (lean_obj_tag(v___x_433_) == 0)
{
lean_object* v___x_434_; 
lean_dec_ref_known(v___x_433_, 1);
v___x_434_ = vastitas_storage_fill(v_a_375_, v___x_431_, v___x_394_, v___x_432_, v___x_395_, v___x_432_, v___x_372_, v___x_391_, v___x_396_, v___x_394_);
if (lean_obj_tag(v___x_434_) == 0)
{
uint32_t v___x_435_; lean_object* v___x_436_; 
lean_dec_ref_known(v___x_434_, 1);
v___x_435_ = 4;
v___x_436_ = vastitas_storage_allocate(v_a_375_, v___x_435_, v___x_391_, v___x_432_);
if (lean_obj_tag(v___x_436_) == 0)
{
lean_object* v___x_437_; 
lean_dec_ref_known(v___x_436_, 1);
v___x_437_ = vastitas_storage_fill(v_a_375_, v___x_435_, v___x_394_, v___x_432_, v___x_395_, v___x_432_, v___x_372_, v___x_391_, v___x_396_, v___x_394_);
if (lean_obj_tag(v___x_437_) == 0)
{
uint32_t v___x_438_; uint64_t v___x_439_; lean_object* v___x_440_; 
lean_dec_ref_known(v___x_437_, 1);
v___x_438_ = 5;
v___x_439_ = 64512ULL;
v___x_440_ = vastitas_storage_allocate(v_a_375_, v___x_438_, v___x_391_, v___x_439_);
if (lean_obj_tag(v___x_440_) == 0)
{
lean_object* v___x_441_; 
lean_dec_ref_known(v___x_440_, 1);
v___x_441_ = vastitas_storage_fill(v_a_375_, v___x_438_, v___x_394_, v___x_439_, v___x_395_, v___x_439_, v___x_372_, v___x_391_, v___x_396_, v___x_394_);
if (lean_obj_tag(v___x_441_) == 0)
{
uint32_t v___x_442_; uint64_t v___x_443_; lean_object* v___x_444_; 
lean_dec_ref_known(v___x_441_, 1);
v___x_442_ = lean_uint32_of_nat(v_scope_353_);
v___x_443_ = lean_uint64_of_nat(v_reps_358_);
v___x_444_ = bench_begin_lean(v___x_442_, v___x_443_, v_verify_362_);
if (lean_obj_tag(v___x_444_) == 0)
{
lean_object* v___x_445_; lean_object* v___x_446_; lean_object* v___x_447_; 
lean_dec_ref_known(v___x_444_, 1);
v___x_445_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_445_, 0, v___x_347_);
lean_ctor_set(v___x_445_, 1, v_reps_358_);
lean_ctor_set(v___x_445_, 2, v___x_349_);
v___x_446_ = lean_box(0);
v___x_447_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_375_, v_scope_353_, v___x_445_, v___x_446_, v___x_347_);
lean_dec_ref_known(v___x_445_, 3);
lean_dec(v_scope_353_);
if (lean_obj_tag(v___x_447_) == 0)
{
lean_object* v___x_448_; 
lean_dec_ref_known(v___x_447_, 1);
v___x_448_ = bench_stop_lean();
if (lean_obj_tag(v___x_448_) == 0)
{
lean_object* v___x_449_; 
lean_dec_ref_known(v___x_448_, 1);
v___x_449_ = bench_verify_lean(v_a_375_, v___x_443_);
if (lean_obj_tag(v___x_449_) == 0)
{
uint64_t v___x_450_; uint64_t v___x_451_; lean_object* v___x_452_; 
lean_dec_ref_known(v___x_449_, 1);
v___x_450_ = 1152ULL;
v___x_451_ = 13849729938443206656ULL;
v___x_452_ = vastitas_storage_expect(v_a_375_, v___x_438_, v___x_394_, v___x_450_, v___x_424_, v___x_450_, v___x_372_, v___x_394_, v___x_394_, v___x_391_, v___x_451_, v___x_394_);
if (lean_obj_tag(v___x_452_) == 0)
{
uint64_t v___x_453_; lean_object* v___x_454_; 
lean_dec_ref_known(v___x_452_, 1);
v___x_453_ = 13850035602675728384ULL;
v___x_454_ = vastitas_storage_expect(v_a_375_, v___x_438_, v___x_394_, v___x_450_, v___x_424_, v___x_450_, v___x_372_, v___x_404_, v___x_428_, v___x_391_, v___x_453_, v___x_394_);
if (lean_obj_tag(v___x_454_) == 0)
{
uint64_t v___x_455_; uint64_t v___x_456_; lean_object* v___x_457_; 
lean_dec_ref_known(v___x_454_, 1);
v___x_455_ = 1151ULL;
v___x_456_ = 13849006459792130048ULL;
v___x_457_ = vastitas_storage_expect(v_a_375_, v___x_438_, v___x_394_, v___x_450_, v___x_424_, v___x_450_, v___x_372_, v___x_455_, v___x_394_, v___x_391_, v___x_456_, v___x_394_);
if (lean_obj_tag(v___x_457_) == 0)
{
lean_object* v___x_458_; 
lean_dec_ref_known(v___x_457_, 1);
v___x_458_ = vastitas_storage_drop(v_a_375_, v___x_438_);
if (lean_obj_tag(v___x_458_) == 0)
{
lean_object* v___x_459_; 
lean_dec_ref_known(v___x_458_, 1);
v___x_459_ = vastitas_storage_drop(v_a_375_, v___x_435_);
if (lean_obj_tag(v___x_459_) == 0)
{
lean_object* v___x_460_; 
lean_dec_ref_known(v___x_459_, 1);
v___x_460_ = vastitas_storage_drop(v_a_375_, v___x_431_);
if (lean_obj_tag(v___x_460_) == 0)
{
lean_object* v___x_461_; 
lean_dec_ref_known(v___x_460_, 1);
v___x_461_ = vastitas_storage_drop(v_a_375_, v___x_366_);
if (lean_obj_tag(v___x_461_) == 0)
{
lean_object* v___x_462_; 
lean_dec_ref_known(v___x_461_, 1);
v___x_462_ = vastitas_storage_drop(v_a_375_, v___x_363_);
if (lean_obj_tag(v___x_462_) == 0)
{
lean_object* v___x_463_; 
lean_dec_ref_known(v___x_462_, 1);
v___x_463_ = vastitas_storage_drop(v_a_375_, v___x_390_);
v___y_377_ = v___x_463_;
goto v___jp_376_;
}
else
{
v___y_377_ = v___x_462_;
goto v___jp_376_;
}
}
else
{
v___y_377_ = v___x_461_;
goto v___jp_376_;
}
}
else
{
v___y_377_ = v___x_460_;
goto v___jp_376_;
}
}
else
{
v___y_377_ = v___x_459_;
goto v___jp_376_;
}
}
else
{
v___y_377_ = v___x_458_;
goto v___jp_376_;
}
}
else
{
v___y_377_ = v___x_457_;
goto v___jp_376_;
}
}
else
{
v___y_377_ = v___x_454_;
goto v___jp_376_;
}
}
else
{
v___y_377_ = v___x_452_;
goto v___jp_376_;
}
}
else
{
v___y_377_ = v___x_449_;
goto v___jp_376_;
}
}
else
{
v___y_377_ = v___x_448_;
goto v___jp_376_;
}
}
else
{
v___y_377_ = v___x_447_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_444_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_441_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_440_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_437_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_436_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_434_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_433_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_430_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_427_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_425_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_422_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_421_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_419_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_416_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_413_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_409_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_408_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_406_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_403_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_401_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_397_;
goto v___jp_376_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v___y_377_ = v___x_393_;
goto v___jp_376_;
}
v___jp_376_:
{
if (lean_obj_tag(v___y_377_) == 0)
{
lean_object* v___x_378_; 
lean_dec_ref_known(v___y_377_, 1);
v___x_378_ = vastitas_storage_close(v_a_375_);
lean_dec(v_a_375_);
if (lean_obj_tag(v___x_378_) == 0)
{
lean_object* v___x_379_; 
lean_dec_ref_known(v___x_378_, 1);
v___x_379_ = bench_report_lean();
return v___x_379_;
}
else
{
return v___x_378_;
}
}
else
{
lean_object* v_a_380_; lean_object* v___x_381_; 
v_a_380_ = lean_ctor_get(v___y_377_, 0);
lean_inc(v_a_380_);
lean_dec_ref_known(v___y_377_, 1);
v___x_381_ = vastitas_storage_close(v_a_375_);
lean_dec(v_a_375_);
if (lean_obj_tag(v___x_381_) == 0)
{
lean_object* v___x_383_; uint8_t v_isShared_384_; uint8_t v_isSharedCheck_388_; 
v_isSharedCheck_388_ = !lean_is_exclusive(v___x_381_);
if (v_isSharedCheck_388_ == 0)
{
lean_object* v_unused_389_; 
v_unused_389_ = lean_ctor_get(v___x_381_, 0);
lean_dec(v_unused_389_);
v___x_383_ = v___x_381_;
v_isShared_384_ = v_isSharedCheck_388_;
goto v_resetjp_382_;
}
else
{
lean_dec(v___x_381_);
v___x_383_ = lean_box(0);
v_isShared_384_ = v_isSharedCheck_388_;
goto v_resetjp_382_;
}
v_resetjp_382_:
{
lean_object* v___x_386_; 
if (v_isShared_384_ == 0)
{
lean_ctor_set_tag(v___x_383_, 1);
lean_ctor_set(v___x_383_, 0, v_a_380_);
v___x_386_ = v___x_383_;
goto v_reusejp_385_;
}
else
{
lean_object* v_reuseFailAlloc_387_; 
v_reuseFailAlloc_387_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_387_, 0, v_a_380_);
v___x_386_ = v_reuseFailAlloc_387_;
goto v_reusejp_385_;
}
v_reusejp_385_:
{
return v___x_386_;
}
}
}
else
{
lean_dec(v_a_380_);
return v___x_381_;
}
}
}
}
else
{
lean_object* v_a_464_; lean_object* v___x_466_; uint8_t v_isShared_467_; uint8_t v_isSharedCheck_471_; 
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
v_a_464_ = lean_ctor_get(v___x_374_, 0);
v_isSharedCheck_471_ = !lean_is_exclusive(v___x_374_);
if (v_isSharedCheck_471_ == 0)
{
v___x_466_ = v___x_374_;
v_isShared_467_ = v_isSharedCheck_471_;
goto v_resetjp_465_;
}
else
{
lean_inc(v_a_464_);
lean_dec(v___x_374_);
v___x_466_ = lean_box(0);
v_isShared_467_ = v_isSharedCheck_471_;
goto v_resetjp_465_;
}
v_resetjp_465_:
{
lean_object* v___x_469_; 
if (v_isShared_467_ == 0)
{
v___x_469_ = v___x_466_;
goto v_reusejp_468_;
}
else
{
lean_object* v_reuseFailAlloc_470_; 
v_reuseFailAlloc_470_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_470_, 0, v_a_464_);
v___x_469_ = v_reuseFailAlloc_470_;
goto v_reusejp_468_;
}
v_reusejp_468_:
{
return v___x_469_;
}
}
}
}
else
{
uint32_t v___x_472_; uint64_t v___x_473_; lean_object* v___x_474_; 
lean_dec(v_scope_353_);
v___x_472_ = 0;
v___x_473_ = lean_uint64_of_nat(v_reps_358_);
v___x_474_ = bench_begin_lean(v___x_472_, v___x_473_, v_verify_362_);
if (lean_obj_tag(v___x_474_) == 0)
{
lean_object* v___x_475_; lean_object* v___x_476_; lean_object* v___x_477_; 
lean_dec_ref_known(v___x_474_, 1);
v___x_475_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_475_, 0, v___x_347_);
lean_ctor_set(v___x_475_, 1, v_reps_358_);
lean_ctor_set(v___x_475_, 2, v___x_349_);
v___x_476_ = lean_box(0);
v___x_477_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v___x_475_, v___x_476_, v___x_347_);
lean_dec_ref_known(v___x_475_, 3);
if (lean_obj_tag(v___x_477_) == 0)
{
lean_object* v___x_478_; 
lean_dec_ref_known(v___x_477_, 1);
v___x_478_ = bench_stop_lean();
if (lean_obj_tag(v___x_478_) == 0)
{
lean_object* v___x_479_; 
lean_dec_ref_known(v___x_478_, 1);
v___x_479_ = bench_report_lean();
return v___x_479_;
}
else
{
return v___x_478_;
}
}
else
{
return v___x_477_;
}
}
else
{
lean_dec(v_reps_358_);
return v___x_474_;
}
}
}
else
{
uint32_t v___x_480_; uint64_t v___x_481_; lean_object* v___x_482_; 
v___x_480_ = lean_uint32_of_nat(v_scope_353_);
lean_dec(v_scope_353_);
v___x_481_ = lean_uint64_of_nat(v_reps_358_);
lean_dec(v_reps_358_);
v___x_482_ = bench_c_run_lean(v___x_480_, v___x_481_, v_verify_362_);
if (lean_obj_tag(v___x_482_) == 0)
{
lean_object* v___x_483_; 
lean_dec_ref_known(v___x_482_, 1);
v___x_483_ = bench_report_lean();
return v___x_483_;
}
else
{
return v___x_482_;
}
}
}
else
{
uint32_t v___x_484_; uint64_t v___x_485_; lean_object* v___x_486_; 
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
lean_dec(v_impl_348_);
v___x_484_ = 0;
v___x_485_ = 1ULL;
v___x_486_ = bench_begin_lean(v___x_484_, v___x_485_, v___x_369_);
if (lean_obj_tag(v___x_486_) == 0)
{
lean_object* v___x_487_; 
lean_dec_ref_known(v___x_486_, 1);
v___x_487_ = lp_allocation__audit_generatedFailure();
if (lean_obj_tag(v___x_487_) == 0)
{
lean_object* v___x_489_; uint8_t v_isShared_490_; uint8_t v_isSharedCheck_495_; 
v_isSharedCheck_495_ = !lean_is_exclusive(v___x_487_);
if (v_isSharedCheck_495_ == 0)
{
lean_object* v_unused_496_; 
v_unused_496_ = lean_ctor_get(v___x_487_, 0);
lean_dec(v_unused_496_);
v___x_489_ = v___x_487_;
v_isShared_490_ = v_isSharedCheck_495_;
goto v_resetjp_488_;
}
else
{
lean_dec(v___x_487_);
v___x_489_ = lean_box(0);
v_isShared_490_ = v_isSharedCheck_495_;
goto v_resetjp_488_;
}
v_resetjp_488_:
{
lean_object* v___x_491_; lean_object* v___x_493_; 
v___x_491_ = ((lean_object*)(lp_allocation__audit_main___closed__5));
if (v_isShared_490_ == 0)
{
lean_ctor_set_tag(v___x_489_, 1);
lean_ctor_set(v___x_489_, 0, v___x_491_);
v___x_493_ = v___x_489_;
goto v_reusejp_492_;
}
else
{
lean_object* v_reuseFailAlloc_494_; 
v_reuseFailAlloc_494_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_494_, 0, v___x_491_);
v___x_493_ = v_reuseFailAlloc_494_;
goto v_reusejp_492_;
}
v_reusejp_492_:
{
return v___x_493_;
}
}
}
else
{
lean_object* v_a_497_; lean_object* v___x_498_; lean_object* v___x_499_; uint8_t v___x_500_; 
v_a_497_ = lean_ctor_get(v___x_487_, 0);
lean_inc(v_a_497_);
v___x_498_ = lean_io_error_to_string(v_a_497_);
v___x_499_ = ((lean_object*)(lp_allocation__audit_main___closed__6));
v___x_500_ = lean_string_dec_eq(v___x_498_, v___x_499_);
lean_dec_ref(v___x_498_);
if (v___x_500_ == 0)
{
return v___x_487_;
}
else
{
lean_object* v___x_501_; 
lean_dec_ref_known(v___x_487_, 1);
v___x_501_ = bench_stop_lean();
if (lean_obj_tag(v___x_501_) == 0)
{
lean_object* v___x_502_; 
lean_dec_ref_known(v___x_501_, 1);
v___x_502_ = bench_report_lean();
return v___x_502_;
}
else
{
return v___x_501_;
}
}
}
}
else
{
return v___x_486_;
}
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
lean_dec(v_impl_348_);
return v___x_367_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
lean_dec(v_impl_348_);
return v___x_365_;
}
}
else
{
lean_dec(v_reps_358_);
lean_dec(v_scope_353_);
lean_dec(v_impl_348_);
return v___x_364_;
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object* v_args_503_, lean_object* v_a_504_){
_start:
{
lean_object* v_res_505_; 
v_res_505_ = _lean_main(v_args_503_);
return v_res_505_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object* v_a_506_, lean_object* v_scope_507_, lean_object* v_range_508_, lean_object* v_b_509_, lean_object* v_i_510_, lean_object* v_hs_511_, lean_object* v_hl_512_){
_start:
{
lean_object* v___x_514_; 
v___x_514_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_506_, v_scope_507_, v_range_508_, v_b_509_, v_i_510_);
return v___x_514_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object* v_a_515_, lean_object* v_scope_516_, lean_object* v_range_517_, lean_object* v_b_518_, lean_object* v_i_519_, lean_object* v_hs_520_, lean_object* v_hl_521_, lean_object* v___y_522_){
_start:
{
lean_object* v_res_523_; 
v_res_523_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(v_a_515_, v_scope_516_, v_range_517_, v_b_518_, v_i_519_, v_hs_520_, v_hl_521_);
lean_dec_ref(v_range_517_);
lean_dec(v_scope_516_);
lean_dec(v_a_515_);
return v_res_523_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object* v_range_524_, lean_object* v_b_525_, lean_object* v_i_526_, lean_object* v_hs_527_, lean_object* v_hl_528_){
_start:
{
lean_object* v___x_530_; 
v___x_530_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_524_, v_b_525_, v_i_526_);
return v___x_530_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object* v_range_531_, lean_object* v_b_532_, lean_object* v_i_533_, lean_object* v_hs_534_, lean_object* v_hl_535_, lean_object* v___y_536_){
_start:
{
lean_object* v_res_537_; 
v_res_537_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(v_range_531_, v_b_532_, v_i_533_, v_hs_534_, v_hl_535_);
lean_dec_ref(v_range_531_);
return v_res_537_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_vastitas__storage__native_VastitasStorageNative(uint8_t builtin);
lean_object* initialize_vastitas__gemm__native_VastitasGemmNative(uint8_t builtin);
lean_object* initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_allocation__audit_Main(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__storage__native_VastitasStorageNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__gemm__native_VastitasGemmNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_allocation__audit_VastitasGenerated_f__0 = _init_lp_allocation__audit_VastitasGenerated_f__0();
lean_mark_persistent(lp_allocation__audit_VastitasGenerated_f__0);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_allocation__audit_Main(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = 0;
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
