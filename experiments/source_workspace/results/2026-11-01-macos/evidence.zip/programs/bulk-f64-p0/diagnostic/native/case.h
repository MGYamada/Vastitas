/* Fixture data independently constructed from cases.json. */
static const unsigned scalar = 0;
static const uint64_t dim_i=24, dim_k=40, dim_j=32, dim_a=48;
static const VStorageLayout views[7] = {{0,24,1280,24,0},{0,40,48,40,0},{0,32,56,32,0},{0,768,40,768,0},{0,768,48,768,0},{0,1152,56,1152,0},{0,1152,32,1152,0}};
static const uint64_t elements[6] = {30720,1920,1792,36864,36864,64512};
static const double values[3][2] = {{0x1.0000000000000p-3,0x0.0p+0},{-0x1.0000000000000p-2,0x0.0p+0},{0x1.0000000000000p-1,-0x0.0p+0}};
static const double sentinel[2] = {-0x1.c000000000000p+2,0x0.0p+0};
static const double alpha[2] = {1,0}, beta[2] = {0,0};
typedef struct { uint64_t row, col; double value[2]; } Patch;
static const Patch patches[3][2] = {{{0,0,{0x1.0000000000000p+0,-0x0.0p+0}},{23,1,{-0x1.0000000000000p-1,0x0.0p+0}}},{{0,47,{0x1.0000000000000p-1,0x0.0p+0}},{39,0,{-0x1.8000000000000p-1,-0x0.0p+0}}},{{31,0,{-0x1.0000000000000p-2,0x0.0p+0}},{0,55,{0x1.8000000000000p-1,-0x0.0p+0}}}};
static const Patch expected[3] = {{0,0,{-0x1.4200000000000p+4,0x0.0p+0}},{23,55,{-0x1.5360000000000p+4,0x0.0p+0}},{1151,0,{-0x1.18e0000000000p+4,0x0.0p+0}}};
