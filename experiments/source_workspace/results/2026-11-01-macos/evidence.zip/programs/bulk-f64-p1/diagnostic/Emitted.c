// Lean compiler output
// Module: Main
// Imports: public import Init public meta import Init public import VastitasStorageNative public import VastitasGemmNative public import VastitasKernel.IndexedRuntime
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* vastitas_storage_new(uint64_t);
lean_object* vastitas_storage_close(lean_object*);
lean_object* vastitas_storage_allocate(lean_object*, uint32_t, uint8_t, uint64_t);
lean_object* vastitas_storage_fill(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_store(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_pack3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_gemm_execute(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t);
lean_object* vastitas_storage_regroup3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_storage_expect(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_drop(lean_object*, uint32_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_List_get_x21Internal___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_String_Slice_toNat_x21(lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
uint32_t lean_uint32_of_nat(lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
lean_object* lean_io_error_to_string(lean_object*);
static lean_once_cell_t lp_allocation__audit_VastitasGenerated_f__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_allocation__audit_VastitasGenerated_f__0___closed__0;
LEAN_EXPORT lean_object* lp_allocation__audit_VastitasGenerated_f__0;
lean_object* bench_begin_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_stop_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object*);
lean_object* bench_report_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object*);
lean_object* bench_c_run_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_verify_lean(lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object*);
lean_object* audit_mark_lean(uint32_t);
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_allocation__audit_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 1, .m_capacity = 1, .m_length = 0, .m_data = ""};
static const lean_object* lp_allocation__audit_main___closed__0 = (const lean_object*)&lp_allocation__audit_main___closed__0_value;
static const lean_string_object lp_allocation__audit_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "1"};
static const lean_object* lp_allocation__audit_main___closed__1 = (const lean_object*)&lp_allocation__audit_main___closed__1_value;
static const lean_string_object lp_allocation__audit_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "failure"};
static const lean_object* lp_allocation__audit_main___closed__2 = (const lean_object*)&lp_allocation__audit_main___closed__2_value;
static const lean_string_object lp_allocation__audit_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "c"};
static const lean_object* lp_allocation__audit_main___closed__3 = (const lean_object*)&lp_allocation__audit_main___closed__3_value;
static const lean_string_object lp_allocation__audit_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "expected injected native failure"};
static const lean_object* lp_allocation__audit_main___closed__4 = (const lean_object*)&lp_allocation__audit_main___closed__4_value;
static const lean_ctor_object lp_allocation__audit_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_allocation__audit_main___closed__4_value)}};
static const lean_object* lp_allocation__audit_main___closed__5 = (const lean_object*)&lp_allocation__audit_main___closed__5_value;
static const lean_string_object lp_allocation__audit_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 44, .m_capacity = 44, .m_length = 43, .m_data = "E_NATIVE_EXPECT: stored bit pattern differs"};
static const lean_object* lp_allocation__audit_main___closed__6 = (const lean_object*)&lp_allocation__audit_main___closed__6_value;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(0u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0(void){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_obj_once(&lp_allocation__audit_VastitasGenerated_f__0___closed__0, &lp_allocation__audit_VastitasGenerated_f__0___closed__0_once, _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object* v_scope_8_, lean_object* v_reps_9_, lean_object* v_verify_10_, lean_object* v_a_00___x40___internal___hyg_11_){
_start:
{
uint32_t v_scope_boxed_12_; uint64_t v_reps_boxed_13_; uint8_t v_verify_boxed_14_; lean_object* v_res_15_; 
v_scope_boxed_12_ = lean_unbox_uint32(v_scope_8_);
lean_dec(v_scope_8_);
v_reps_boxed_13_ = lean_unbox_uint64(v_reps_9_);
lean_dec_ref(v_reps_9_);
v_verify_boxed_14_ = lean_unbox(v_verify_10_);
v_res_15_ = bench_begin_lean(v_scope_boxed_12_, v_reps_boxed_13_, v_verify_boxed_14_);
return v_res_15_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object* v_a_00___x40___internal___hyg_17_){
_start:
{
lean_object* v_res_18_; 
v_res_18_ = bench_stop_lean();
return v_res_18_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object* v_a_00___x40___internal___hyg_20_){
_start:
{
lean_object* v_res_21_; 
v_res_21_ = bench_report_lean();
return v_res_21_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object* v_scope_26_, lean_object* v_reps_27_, lean_object* v_verify_28_, lean_object* v_a_00___x40___internal___hyg_29_){
_start:
{
uint32_t v_scope_boxed_30_; uint64_t v_reps_boxed_31_; uint8_t v_verify_boxed_32_; lean_object* v_res_33_; 
v_scope_boxed_30_ = lean_unbox_uint32(v_scope_26_);
lean_dec(v_scope_26_);
v_reps_boxed_31_ = lean_unbox_uint64(v_reps_27_);
lean_dec_ref(v_reps_27_);
v_verify_boxed_32_ = lean_unbox(v_verify_28_);
v_res_33_ = bench_c_run_lean(v_scope_boxed_30_, v_reps_boxed_31_, v_verify_boxed_32_);
return v_res_33_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object* v_arena_37_, lean_object* v_reps_38_, lean_object* v_a_00___x40___internal___hyg_39_){
_start:
{
uint64_t v_reps_boxed_40_; lean_object* v_res_41_; 
v_reps_boxed_40_ = lean_unbox_uint64(v_reps_38_);
lean_dec_ref(v_reps_38_);
v_res_41_ = bench_verify_lean(v_arena_37_, v_reps_boxed_40_);
lean_dec(v_arena_37_);
return v_res_41_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce(){
_start:
{
uint64_t v___x_43_; lean_object* v___x_44_; 
v___x_43_ = 9223372036854775807ULL;
v___x_44_ = vastitas_storage_new(v___x_43_);
if (lean_obj_tag(v___x_44_) == 0)
{
lean_object* v_a_45_; lean_object* v_a_47_; lean_object* v___y_58_; uint32_t v___x_70_; uint8_t v___x_71_; uint64_t v___x_72_; lean_object* v___x_73_; 
v_a_45_ = lean_ctor_get(v___x_44_, 0);
lean_inc(v_a_45_);
lean_dec_ref_known(v___x_44_, 1);
v___x_70_ = 0;
v___x_71_ = 0;
v___x_72_ = 33284ULL;
v___x_73_ = vastitas_storage_allocate(v_a_45_, v___x_70_, v___x_71_, v___x_72_);
if (lean_obj_tag(v___x_73_) == 0)
{
uint64_t v___x_74_; uint64_t v___x_75_; uint8_t v___x_76_; uint64_t v___x_77_; lean_object* v___x_78_; 
lean_dec_ref_known(v___x_73_, 1);
v___x_74_ = 0ULL;
v___x_75_ = 1ULL;
v___x_76_ = 0;
v___x_77_ = 13842939354630062080ULL;
v___x_78_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_74_, v___x_72_, v___x_75_, v___x_72_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_78_) == 0)
{
uint64_t v___x_79_; uint64_t v___x_80_; uint64_t v___x_81_; uint64_t v___x_82_; uint64_t v___x_83_; lean_object* v___x_84_; 
lean_dec_ref_known(v___x_78_, 1);
v___x_79_ = 8ULL;
v___x_80_ = 24ULL;
v___x_81_ = 1280ULL;
v___x_82_ = 26ULL;
v___x_83_ = 4593671619917905920ULL;
v___x_84_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_79_, v___x_80_, v___x_81_, v___x_82_, v___x_76_, v___x_71_, v___x_83_, v___x_74_);
if (lean_obj_tag(v___x_84_) == 0)
{
uint64_t v___x_85_; lean_object* v___x_86_; 
lean_dec_ref_known(v___x_84_, 1);
v___x_85_ = 4607182418800017408ULL;
v___x_86_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_79_, v___x_80_, v___x_81_, v___x_82_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_85_, v___x_74_);
if (lean_obj_tag(v___x_86_) == 0)
{
uint64_t v___x_87_; uint64_t v___x_88_; lean_object* v___x_89_; 
lean_dec_ref_known(v___x_86_, 1);
v___x_87_ = 23ULL;
v___x_88_ = 13826050856027422720ULL;
v___x_89_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_79_, v___x_80_, v___x_81_, v___x_82_, v___x_76_, v___x_87_, v___x_75_, v___x_71_, v___x_88_, v___x_74_);
if (lean_obj_tag(v___x_89_) == 0)
{
uint32_t v___x_90_; uint64_t v___x_91_; lean_object* v___x_92_; 
lean_dec_ref_known(v___x_89_, 1);
v___x_90_ = 1;
v___x_91_ = 2069ULL;
v___x_92_ = vastitas_storage_allocate(v_a_45_, v___x_90_, v___x_71_, v___x_91_);
if (lean_obj_tag(v___x_92_) == 0)
{
lean_object* v___x_93_; 
lean_dec_ref_known(v___x_92_, 1);
v___x_93_ = vastitas_storage_fill(v_a_45_, v___x_90_, v___x_74_, v___x_91_, v___x_75_, v___x_91_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_93_) == 0)
{
uint64_t v___x_94_; uint64_t v___x_95_; uint64_t v___x_96_; uint64_t v___x_97_; uint64_t v___x_98_; lean_object* v___x_99_; 
lean_dec_ref_known(v___x_93_, 1);
v___x_94_ = 16ULL;
v___x_95_ = 40ULL;
v___x_96_ = 48ULL;
v___x_97_ = 43ULL;
v___x_98_ = 13821547256400052224ULL;
v___x_99_ = vastitas_storage_fill(v_a_45_, v___x_90_, v___x_94_, v___x_95_, v___x_96_, v___x_97_, v___x_76_, v___x_71_, v___x_98_, v___x_74_);
if (lean_obj_tag(v___x_99_) == 0)
{
uint64_t v___x_100_; uint64_t v___x_101_; lean_object* v___x_102_; 
lean_dec_ref_known(v___x_99_, 1);
v___x_100_ = 47ULL;
v___x_101_ = 4602678819172646912ULL;
v___x_102_ = vastitas_storage_store(v_a_45_, v___x_90_, v___x_94_, v___x_95_, v___x_96_, v___x_97_, v___x_76_, v___x_74_, v___x_100_, v___x_71_, v___x_101_, v___x_74_);
if (lean_obj_tag(v___x_102_) == 0)
{
uint64_t v___x_103_; uint64_t v___x_104_; lean_object* v___x_105_; 
lean_dec_ref_known(v___x_102_, 1);
v___x_103_ = 39ULL;
v___x_104_ = 13828302655841107968ULL;
v___x_105_ = vastitas_storage_store(v_a_45_, v___x_90_, v___x_94_, v___x_95_, v___x_96_, v___x_97_, v___x_76_, v___x_103_, v___x_74_, v___x_71_, v___x_104_, v___x_74_);
if (lean_obj_tag(v___x_105_) == 0)
{
uint32_t v___x_106_; uint64_t v___x_107_; lean_object* v___x_108_; 
lean_dec_ref_known(v___x_105_, 1);
v___x_106_ = 2;
v___x_107_ = 2022ULL;
v___x_108_ = vastitas_storage_allocate(v_a_45_, v___x_106_, v___x_71_, v___x_107_);
if (lean_obj_tag(v___x_108_) == 0)
{
lean_object* v___x_109_; 
lean_dec_ref_known(v___x_108_, 1);
v___x_109_ = vastitas_storage_fill(v_a_45_, v___x_106_, v___x_74_, v___x_107_, v___x_75_, v___x_107_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_109_) == 0)
{
uint64_t v___x_110_; uint64_t v___x_111_; uint64_t v___x_112_; lean_object* v___x_113_; 
lean_dec_ref_known(v___x_109_, 1);
v___x_110_ = 32ULL;
v___x_111_ = 56ULL;
v___x_112_ = 36ULL;
v___x_113_ = vastitas_storage_fill(v_a_45_, v___x_106_, v___x_80_, v___x_110_, v___x_111_, v___x_112_, v___x_76_, v___x_71_, v___x_101_, v___x_74_);
if (lean_obj_tag(v___x_113_) == 0)
{
uint64_t v___x_114_; lean_object* v___x_115_; 
lean_dec_ref_known(v___x_113_, 1);
v___x_114_ = 31ULL;
v___x_115_ = vastitas_storage_store(v_a_45_, v___x_106_, v___x_80_, v___x_110_, v___x_111_, v___x_112_, v___x_76_, v___x_114_, v___x_74_, v___x_71_, v___x_98_, v___x_74_);
if (lean_obj_tag(v___x_115_) == 0)
{
uint64_t v___x_116_; uint64_t v___x_117_; lean_object* v___x_118_; 
lean_dec_ref_known(v___x_115_, 1);
v___x_116_ = 55ULL;
v___x_117_ = 4604930618986332160ULL;
v___x_118_ = vastitas_storage_store(v_a_45_, v___x_106_, v___x_80_, v___x_110_, v___x_111_, v___x_112_, v___x_76_, v___x_74_, v___x_116_, v___x_71_, v___x_117_, v___x_74_);
if (lean_obj_tag(v___x_118_) == 0)
{
uint32_t v___x_119_; uint64_t v___x_120_; lean_object* v___x_121_; 
lean_dec_ref_known(v___x_118_, 1);
v___x_119_ = 3;
v___x_120_ = 37130ULL;
v___x_121_ = vastitas_storage_allocate(v_a_45_, v___x_119_, v___x_71_, v___x_120_);
if (lean_obj_tag(v___x_121_) == 0)
{
lean_object* v___x_122_; 
lean_dec_ref_known(v___x_121_, 1);
v___x_122_ = vastitas_storage_fill(v_a_45_, v___x_119_, v___x_74_, v___x_120_, v___x_75_, v___x_120_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_122_) == 0)
{
uint32_t v___x_123_; uint64_t v___x_124_; lean_object* v___x_125_; 
lean_dec_ref_known(v___x_122_, 1);
v___x_123_ = 4;
v___x_124_ = 37160ULL;
v___x_125_ = vastitas_storage_allocate(v_a_45_, v___x_123_, v___x_71_, v___x_124_);
if (lean_obj_tag(v___x_125_) == 0)
{
lean_object* v___x_126_; 
lean_dec_ref_known(v___x_125_, 1);
v___x_126_ = vastitas_storage_fill(v_a_45_, v___x_123_, v___x_74_, v___x_124_, v___x_75_, v___x_124_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_126_) == 0)
{
uint32_t v___x_127_; uint64_t v___x_128_; lean_object* v___x_129_; 
lean_dec_ref_known(v___x_126_, 1);
v___x_127_ = 5;
v___x_128_ = 64913ULL;
v___x_129_ = vastitas_storage_allocate(v_a_45_, v___x_127_, v___x_71_, v___x_128_);
if (lean_obj_tag(v___x_129_) == 0)
{
lean_object* v___x_130_; 
lean_dec_ref_known(v___x_129_, 1);
v___x_130_ = vastitas_storage_fill(v_a_45_, v___x_127_, v___x_74_, v___x_128_, v___x_75_, v___x_128_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_130_) == 0)
{
uint64_t v___x_131_; uint64_t v___x_132_; lean_object* v___x_133_; 
lean_dec_ref_known(v___x_130_, 1);
v___x_131_ = 768ULL;
v___x_132_ = 773ULL;
v___x_133_ = vastitas_storage_pack3(v_a_45_, v___x_70_, v___x_79_, v___x_80_, v___x_81_, v___x_82_, v___x_76_, v___x_119_, v___x_110_, v___x_131_, v___x_95_, v___x_132_, v___x_76_, v___x_80_, v___x_95_, v___x_110_);
if (lean_obj_tag(v___x_133_) == 0)
{
uint64_t v___x_134_; lean_object* v___x_135_; 
lean_dec_ref_known(v___x_133_, 1);
v___x_134_ = 774ULL;
v___x_135_ = vastitas_gemm_execute(v_a_45_, v___x_119_, v___x_110_, v___x_131_, v___x_95_, v___x_132_, v___x_76_, v___x_76_, v___x_90_, v___x_94_, v___x_95_, v___x_96_, v___x_97_, v___x_76_, v___x_76_, v___x_123_, v___x_95_, v___x_131_, v___x_96_, v___x_134_, v___x_76_, v___x_71_);
if (lean_obj_tag(v___x_135_) == 0)
{
uint64_t v___x_136_; uint64_t v___x_137_; uint64_t v___x_138_; lean_object* v___x_139_; 
lean_dec_ref_known(v___x_135_, 1);
v___x_136_ = 1152ULL;
v___x_137_ = 1160ULL;
v___x_138_ = 42ULL;
v___x_139_ = vastitas_storage_regroup3(v_a_45_, v___x_123_, v___x_95_, v___x_131_, v___x_96_, v___x_134_, v___x_76_, v___x_119_, v___x_111_, v___x_136_, v___x_110_, v___x_137_, v___x_76_, v___x_80_, v___x_110_, v___x_96_, v___x_96_, v___x_138_);
if (lean_obj_tag(v___x_139_) == 0)
{
uint64_t v___x_140_; lean_object* v___x_141_; 
lean_dec_ref_known(v___x_139_, 1);
v___x_140_ = 1159ULL;
v___x_141_ = vastitas_gemm_execute(v_a_45_, v___x_119_, v___x_111_, v___x_136_, v___x_110_, v___x_137_, v___x_76_, v___x_76_, v___x_106_, v___x_80_, v___x_110_, v___x_111_, v___x_112_, v___x_76_, v___x_76_, v___x_127_, v___x_96_, v___x_136_, v___x_111_, v___x_140_, v___x_76_, v___x_71_);
if (lean_obj_tag(v___x_141_) == 0)
{
uint64_t v___x_142_; lean_object* v___x_143_; 
lean_dec_ref_known(v___x_141_, 1);
v___x_142_ = 13849729938443206656ULL;
v___x_143_ = vastitas_storage_expect(v_a_45_, v___x_127_, v___x_96_, v___x_136_, v___x_111_, v___x_140_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_142_, v___x_74_);
if (lean_obj_tag(v___x_143_) == 0)
{
uint64_t v___x_144_; lean_object* v___x_145_; 
lean_dec_ref_known(v___x_143_, 1);
v___x_144_ = 13850035602675728384ULL;
v___x_145_ = vastitas_storage_expect(v_a_45_, v___x_127_, v___x_96_, v___x_136_, v___x_111_, v___x_140_, v___x_76_, v___x_87_, v___x_116_, v___x_71_, v___x_144_, v___x_74_);
if (lean_obj_tag(v___x_145_) == 0)
{
uint64_t v___x_146_; uint64_t v___x_147_; lean_object* v___x_148_; 
lean_dec_ref_known(v___x_145_, 1);
v___x_146_ = 1151ULL;
v___x_147_ = 13849006459792130048ULL;
v___x_148_ = vastitas_storage_expect(v_a_45_, v___x_127_, v___x_96_, v___x_136_, v___x_111_, v___x_140_, v___x_76_, v___x_146_, v___x_74_, v___x_71_, v___x_147_, v___x_74_);
if (lean_obj_tag(v___x_148_) == 0)
{
lean_object* v___x_149_; 
lean_dec_ref_known(v___x_148_, 1);
v___x_149_ = vastitas_storage_drop(v_a_45_, v___x_127_);
if (lean_obj_tag(v___x_149_) == 0)
{
lean_object* v___x_150_; 
lean_dec_ref_known(v___x_149_, 1);
v___x_150_ = vastitas_storage_drop(v_a_45_, v___x_123_);
if (lean_obj_tag(v___x_150_) == 0)
{
lean_object* v___x_151_; 
lean_dec_ref_known(v___x_150_, 1);
v___x_151_ = vastitas_storage_drop(v_a_45_, v___x_119_);
if (lean_obj_tag(v___x_151_) == 0)
{
lean_object* v___x_152_; 
lean_dec_ref_known(v___x_151_, 1);
v___x_152_ = vastitas_storage_drop(v_a_45_, v___x_106_);
if (lean_obj_tag(v___x_152_) == 0)
{
lean_object* v___x_153_; 
lean_dec_ref_known(v___x_152_, 1);
v___x_153_ = vastitas_storage_drop(v_a_45_, v___x_90_);
if (lean_obj_tag(v___x_153_) == 0)
{
lean_object* v___x_154_; 
lean_dec_ref_known(v___x_153_, 1);
v___x_154_ = vastitas_storage_drop(v_a_45_, v___x_70_);
if (lean_obj_tag(v___x_154_) == 0)
{
lean_object* v___x_155_; 
lean_dec_ref_known(v___x_154_, 1);
v___x_155_ = lean_box(0);
v_a_47_ = v___x_155_;
goto v___jp_46_;
}
else
{
v___y_58_ = v___x_154_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_153_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_152_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_151_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_150_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_149_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_148_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_145_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_143_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_141_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_139_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_135_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_133_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_130_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_129_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_126_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_125_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_122_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_121_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_118_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_115_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_113_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_109_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_108_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_105_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_102_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_99_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_93_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_92_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_89_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_86_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_84_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_78_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_73_;
goto v___jp_57_;
}
v___jp_46_:
{
lean_object* v___x_48_; 
v___x_48_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_48_) == 0)
{
lean_object* v___x_50_; uint8_t v_isShared_51_; uint8_t v_isSharedCheck_55_; 
v_isSharedCheck_55_ = !lean_is_exclusive(v___x_48_);
if (v_isSharedCheck_55_ == 0)
{
lean_object* v_unused_56_; 
v_unused_56_ = lean_ctor_get(v___x_48_, 0);
lean_dec(v_unused_56_);
v___x_50_ = v___x_48_;
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
else
{
lean_dec(v___x_48_);
v___x_50_ = lean_box(0);
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
v_resetjp_49_:
{
lean_object* v___x_53_; 
if (v_isShared_51_ == 0)
{
lean_ctor_set(v___x_50_, 0, v_a_47_);
v___x_53_ = v___x_50_;
goto v_reusejp_52_;
}
else
{
lean_object* v_reuseFailAlloc_54_; 
v_reuseFailAlloc_54_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_54_, 0, v_a_47_);
v___x_53_ = v_reuseFailAlloc_54_;
goto v_reusejp_52_;
}
v_reusejp_52_:
{
return v___x_53_;
}
}
}
else
{
return v___x_48_;
}
}
v___jp_57_:
{
if (lean_obj_tag(v___y_58_) == 0)
{
lean_object* v_a_59_; 
v_a_59_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_59_);
lean_dec_ref_known(v___y_58_, 1);
v_a_47_ = v_a_59_;
goto v___jp_46_;
}
else
{
lean_object* v_a_60_; lean_object* v___x_61_; 
v_a_60_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_60_);
lean_dec_ref_known(v___y_58_, 1);
v___x_61_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_61_) == 0)
{
lean_object* v___x_63_; uint8_t v_isShared_64_; uint8_t v_isSharedCheck_68_; 
v_isSharedCheck_68_ = !lean_is_exclusive(v___x_61_);
if (v_isSharedCheck_68_ == 0)
{
lean_object* v_unused_69_; 
v_unused_69_ = lean_ctor_get(v___x_61_, 0);
lean_dec(v_unused_69_);
v___x_63_ = v___x_61_;
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
else
{
lean_dec(v___x_61_);
v___x_63_ = lean_box(0);
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
v_resetjp_62_:
{
lean_object* v___x_66_; 
if (v_isShared_64_ == 0)
{
lean_ctor_set_tag(v___x_63_, 1);
lean_ctor_set(v___x_63_, 0, v_a_60_);
v___x_66_ = v___x_63_;
goto v_reusejp_65_;
}
else
{
lean_object* v_reuseFailAlloc_67_; 
v_reuseFailAlloc_67_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_67_, 0, v_a_60_);
v___x_66_ = v_reuseFailAlloc_67_;
goto v_reusejp_65_;
}
v_reusejp_65_:
{
return v___x_66_;
}
}
}
else
{
lean_dec(v_a_60_);
return v___x_61_;
}
}
}
}
else
{
lean_object* v_a_156_; lean_object* v___x_158_; uint8_t v_isShared_159_; uint8_t v_isSharedCheck_163_; 
v_a_156_ = lean_ctor_get(v___x_44_, 0);
v_isSharedCheck_163_ = !lean_is_exclusive(v___x_44_);
if (v_isSharedCheck_163_ == 0)
{
v___x_158_ = v___x_44_;
v_isShared_159_ = v_isSharedCheck_163_;
goto v_resetjp_157_;
}
else
{
lean_inc(v_a_156_);
lean_dec(v___x_44_);
v___x_158_ = lean_box(0);
v_isShared_159_ = v_isSharedCheck_163_;
goto v_resetjp_157_;
}
v_resetjp_157_:
{
lean_object* v___x_161_; 
if (v_isShared_159_ == 0)
{
v___x_161_ = v___x_158_;
goto v_reusejp_160_;
}
else
{
lean_object* v_reuseFailAlloc_162_; 
v_reuseFailAlloc_162_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_162_, 0, v_a_156_);
v___x_161_ = v_reuseFailAlloc_162_;
goto v_reusejp_160_;
}
v_reusejp_160_:
{
return v___x_161_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object* v_a_164_){
_start:
{
lean_object* v_res_165_; 
v_res_165_ = lp_allocation__audit_generatedOnce();
return v_res_165_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure(){
_start:
{
uint64_t v___x_167_; lean_object* v___x_168_; 
v___x_167_ = 9223372036854775807ULL;
v___x_168_ = vastitas_storage_new(v___x_167_);
if (lean_obj_tag(v___x_168_) == 0)
{
lean_object* v_a_169_; lean_object* v_a_171_; lean_object* v___y_182_; uint32_t v___x_194_; uint8_t v___x_195_; uint64_t v___x_196_; lean_object* v___x_197_; 
v_a_169_ = lean_ctor_get(v___x_168_, 0);
lean_inc(v_a_169_);
lean_dec_ref_known(v___x_168_, 1);
v___x_194_ = 0;
v___x_195_ = 0;
v___x_196_ = 33284ULL;
v___x_197_ = vastitas_storage_allocate(v_a_169_, v___x_194_, v___x_195_, v___x_196_);
if (lean_obj_tag(v___x_197_) == 0)
{
uint64_t v___x_198_; uint64_t v___x_199_; uint8_t v___x_200_; uint64_t v___x_201_; lean_object* v___x_202_; 
lean_dec_ref_known(v___x_197_, 1);
v___x_198_ = 0ULL;
v___x_199_ = 1ULL;
v___x_200_ = 0;
v___x_201_ = 13842939354630062080ULL;
v___x_202_ = vastitas_storage_fill(v_a_169_, v___x_194_, v___x_198_, v___x_196_, v___x_199_, v___x_196_, v___x_200_, v___x_195_, v___x_201_, v___x_198_);
if (lean_obj_tag(v___x_202_) == 0)
{
uint64_t v___x_203_; uint64_t v___x_204_; uint64_t v___x_205_; uint64_t v___x_206_; uint64_t v___x_207_; lean_object* v___x_208_; 
lean_dec_ref_known(v___x_202_, 1);
v___x_203_ = 8ULL;
v___x_204_ = 24ULL;
v___x_205_ = 1280ULL;
v___x_206_ = 26ULL;
v___x_207_ = 4593671619917905920ULL;
v___x_208_ = vastitas_storage_fill(v_a_169_, v___x_194_, v___x_203_, v___x_204_, v___x_205_, v___x_206_, v___x_200_, v___x_195_, v___x_207_, v___x_198_);
if (lean_obj_tag(v___x_208_) == 0)
{
uint64_t v___x_209_; lean_object* v___x_210_; 
lean_dec_ref_known(v___x_208_, 1);
v___x_209_ = 4607182418800017408ULL;
v___x_210_ = vastitas_storage_store(v_a_169_, v___x_194_, v___x_203_, v___x_204_, v___x_205_, v___x_206_, v___x_200_, v___x_198_, v___x_198_, v___x_195_, v___x_209_, v___x_198_);
if (lean_obj_tag(v___x_210_) == 0)
{
uint64_t v___x_211_; uint64_t v___x_212_; lean_object* v___x_213_; 
lean_dec_ref_known(v___x_210_, 1);
v___x_211_ = 23ULL;
v___x_212_ = 13826050856027422720ULL;
v___x_213_ = vastitas_storage_store(v_a_169_, v___x_194_, v___x_203_, v___x_204_, v___x_205_, v___x_206_, v___x_200_, v___x_211_, v___x_199_, v___x_195_, v___x_212_, v___x_198_);
if (lean_obj_tag(v___x_213_) == 0)
{
uint32_t v___x_214_; uint64_t v___x_215_; lean_object* v___x_216_; 
lean_dec_ref_known(v___x_213_, 1);
v___x_214_ = 1;
v___x_215_ = 2069ULL;
v___x_216_ = vastitas_storage_allocate(v_a_169_, v___x_214_, v___x_195_, v___x_215_);
if (lean_obj_tag(v___x_216_) == 0)
{
lean_object* v___x_217_; 
lean_dec_ref_known(v___x_216_, 1);
v___x_217_ = vastitas_storage_fill(v_a_169_, v___x_214_, v___x_198_, v___x_215_, v___x_199_, v___x_215_, v___x_200_, v___x_195_, v___x_201_, v___x_198_);
if (lean_obj_tag(v___x_217_) == 0)
{
uint64_t v___x_218_; uint64_t v___x_219_; uint64_t v___x_220_; uint64_t v___x_221_; uint64_t v___x_222_; lean_object* v___x_223_; 
lean_dec_ref_known(v___x_217_, 1);
v___x_218_ = 16ULL;
v___x_219_ = 40ULL;
v___x_220_ = 48ULL;
v___x_221_ = 43ULL;
v___x_222_ = 13821547256400052224ULL;
v___x_223_ = vastitas_storage_fill(v_a_169_, v___x_214_, v___x_218_, v___x_219_, v___x_220_, v___x_221_, v___x_200_, v___x_195_, v___x_222_, v___x_198_);
if (lean_obj_tag(v___x_223_) == 0)
{
uint64_t v___x_224_; uint64_t v___x_225_; lean_object* v___x_226_; 
lean_dec_ref_known(v___x_223_, 1);
v___x_224_ = 47ULL;
v___x_225_ = 4602678819172646912ULL;
v___x_226_ = vastitas_storage_store(v_a_169_, v___x_214_, v___x_218_, v___x_219_, v___x_220_, v___x_221_, v___x_200_, v___x_198_, v___x_224_, v___x_195_, v___x_225_, v___x_198_);
if (lean_obj_tag(v___x_226_) == 0)
{
uint64_t v___x_227_; uint64_t v___x_228_; lean_object* v___x_229_; 
lean_dec_ref_known(v___x_226_, 1);
v___x_227_ = 39ULL;
v___x_228_ = 13828302655841107968ULL;
v___x_229_ = vastitas_storage_store(v_a_169_, v___x_214_, v___x_218_, v___x_219_, v___x_220_, v___x_221_, v___x_200_, v___x_227_, v___x_198_, v___x_195_, v___x_228_, v___x_198_);
if (lean_obj_tag(v___x_229_) == 0)
{
uint32_t v___x_230_; uint64_t v___x_231_; lean_object* v___x_232_; 
lean_dec_ref_known(v___x_229_, 1);
v___x_230_ = 2;
v___x_231_ = 2022ULL;
v___x_232_ = vastitas_storage_allocate(v_a_169_, v___x_230_, v___x_195_, v___x_231_);
if (lean_obj_tag(v___x_232_) == 0)
{
lean_object* v___x_233_; 
lean_dec_ref_known(v___x_232_, 1);
v___x_233_ = vastitas_storage_fill(v_a_169_, v___x_230_, v___x_198_, v___x_231_, v___x_199_, v___x_231_, v___x_200_, v___x_195_, v___x_201_, v___x_198_);
if (lean_obj_tag(v___x_233_) == 0)
{
uint64_t v___x_234_; uint64_t v___x_235_; uint64_t v___x_236_; lean_object* v___x_237_; 
lean_dec_ref_known(v___x_233_, 1);
v___x_234_ = 32ULL;
v___x_235_ = 56ULL;
v___x_236_ = 36ULL;
v___x_237_ = vastitas_storage_fill(v_a_169_, v___x_230_, v___x_204_, v___x_234_, v___x_235_, v___x_236_, v___x_200_, v___x_195_, v___x_225_, v___x_198_);
if (lean_obj_tag(v___x_237_) == 0)
{
uint64_t v___x_238_; lean_object* v___x_239_; 
lean_dec_ref_known(v___x_237_, 1);
v___x_238_ = 31ULL;
v___x_239_ = vastitas_storage_store(v_a_169_, v___x_230_, v___x_204_, v___x_234_, v___x_235_, v___x_236_, v___x_200_, v___x_238_, v___x_198_, v___x_195_, v___x_222_, v___x_198_);
if (lean_obj_tag(v___x_239_) == 0)
{
uint64_t v___x_240_; uint64_t v___x_241_; lean_object* v___x_242_; 
lean_dec_ref_known(v___x_239_, 1);
v___x_240_ = 55ULL;
v___x_241_ = 4604930618986332160ULL;
v___x_242_ = vastitas_storage_store(v_a_169_, v___x_230_, v___x_204_, v___x_234_, v___x_235_, v___x_236_, v___x_200_, v___x_198_, v___x_240_, v___x_195_, v___x_241_, v___x_198_);
if (lean_obj_tag(v___x_242_) == 0)
{
uint32_t v___x_243_; uint64_t v___x_244_; lean_object* v___x_245_; 
lean_dec_ref_known(v___x_242_, 1);
v___x_243_ = 3;
v___x_244_ = 37130ULL;
v___x_245_ = vastitas_storage_allocate(v_a_169_, v___x_243_, v___x_195_, v___x_244_);
if (lean_obj_tag(v___x_245_) == 0)
{
lean_object* v___x_246_; 
lean_dec_ref_known(v___x_245_, 1);
v___x_246_ = vastitas_storage_fill(v_a_169_, v___x_243_, v___x_198_, v___x_244_, v___x_199_, v___x_244_, v___x_200_, v___x_195_, v___x_201_, v___x_198_);
if (lean_obj_tag(v___x_246_) == 0)
{
uint32_t v___x_247_; uint64_t v___x_248_; lean_object* v___x_249_; 
lean_dec_ref_known(v___x_246_, 1);
v___x_247_ = 4;
v___x_248_ = 37160ULL;
v___x_249_ = vastitas_storage_allocate(v_a_169_, v___x_247_, v___x_195_, v___x_248_);
if (lean_obj_tag(v___x_249_) == 0)
{
lean_object* v___x_250_; 
lean_dec_ref_known(v___x_249_, 1);
v___x_250_ = vastitas_storage_fill(v_a_169_, v___x_247_, v___x_198_, v___x_248_, v___x_199_, v___x_248_, v___x_200_, v___x_195_, v___x_201_, v___x_198_);
if (lean_obj_tag(v___x_250_) == 0)
{
uint32_t v___x_251_; uint64_t v___x_252_; lean_object* v___x_253_; 
lean_dec_ref_known(v___x_250_, 1);
v___x_251_ = 5;
v___x_252_ = 64913ULL;
v___x_253_ = vastitas_storage_allocate(v_a_169_, v___x_251_, v___x_195_, v___x_252_);
if (lean_obj_tag(v___x_253_) == 0)
{
lean_object* v___x_254_; 
lean_dec_ref_known(v___x_253_, 1);
v___x_254_ = vastitas_storage_fill(v_a_169_, v___x_251_, v___x_198_, v___x_252_, v___x_199_, v___x_252_, v___x_200_, v___x_195_, v___x_201_, v___x_198_);
if (lean_obj_tag(v___x_254_) == 0)
{
uint64_t v___x_255_; uint64_t v___x_256_; lean_object* v___x_257_; 
lean_dec_ref_known(v___x_254_, 1);
v___x_255_ = 768ULL;
v___x_256_ = 773ULL;
v___x_257_ = vastitas_storage_pack3(v_a_169_, v___x_194_, v___x_203_, v___x_204_, v___x_205_, v___x_206_, v___x_200_, v___x_243_, v___x_234_, v___x_255_, v___x_219_, v___x_256_, v___x_200_, v___x_204_, v___x_219_, v___x_234_);
if (lean_obj_tag(v___x_257_) == 0)
{
uint64_t v___x_258_; lean_object* v___x_259_; 
lean_dec_ref_known(v___x_257_, 1);
v___x_258_ = 774ULL;
v___x_259_ = vastitas_gemm_execute(v_a_169_, v___x_243_, v___x_234_, v___x_255_, v___x_219_, v___x_256_, v___x_200_, v___x_200_, v___x_214_, v___x_218_, v___x_219_, v___x_220_, v___x_221_, v___x_200_, v___x_200_, v___x_247_, v___x_219_, v___x_255_, v___x_220_, v___x_258_, v___x_200_, v___x_195_);
if (lean_obj_tag(v___x_259_) == 0)
{
uint64_t v___x_260_; uint64_t v___x_261_; uint64_t v___x_262_; lean_object* v___x_263_; 
lean_dec_ref_known(v___x_259_, 1);
v___x_260_ = 1152ULL;
v___x_261_ = 1160ULL;
v___x_262_ = 42ULL;
v___x_263_ = vastitas_storage_regroup3(v_a_169_, v___x_247_, v___x_219_, v___x_255_, v___x_220_, v___x_258_, v___x_200_, v___x_243_, v___x_235_, v___x_260_, v___x_234_, v___x_261_, v___x_200_, v___x_204_, v___x_234_, v___x_220_, v___x_220_, v___x_262_);
if (lean_obj_tag(v___x_263_) == 0)
{
uint64_t v___x_264_; lean_object* v___x_265_; 
lean_dec_ref_known(v___x_263_, 1);
v___x_264_ = 1159ULL;
v___x_265_ = vastitas_gemm_execute(v_a_169_, v___x_243_, v___x_235_, v___x_260_, v___x_234_, v___x_261_, v___x_200_, v___x_200_, v___x_230_, v___x_204_, v___x_234_, v___x_235_, v___x_236_, v___x_200_, v___x_200_, v___x_251_, v___x_220_, v___x_260_, v___x_235_, v___x_264_, v___x_200_, v___x_195_);
if (lean_obj_tag(v___x_265_) == 0)
{
uint64_t v___x_266_; lean_object* v___x_267_; 
lean_dec_ref_known(v___x_265_, 1);
v___x_266_ = 13849729938443206657ULL;
v___x_267_ = vastitas_storage_expect(v_a_169_, v___x_251_, v___x_220_, v___x_260_, v___x_235_, v___x_264_, v___x_200_, v___x_198_, v___x_198_, v___x_195_, v___x_266_, v___x_198_);
if (lean_obj_tag(v___x_267_) == 0)
{
uint64_t v___x_268_; lean_object* v___x_269_; 
lean_dec_ref_known(v___x_267_, 1);
v___x_268_ = 13850035602675728384ULL;
v___x_269_ = vastitas_storage_expect(v_a_169_, v___x_251_, v___x_220_, v___x_260_, v___x_235_, v___x_264_, v___x_200_, v___x_211_, v___x_240_, v___x_195_, v___x_268_, v___x_198_);
if (lean_obj_tag(v___x_269_) == 0)
{
uint64_t v___x_270_; uint64_t v___x_271_; lean_object* v___x_272_; 
lean_dec_ref_known(v___x_269_, 1);
v___x_270_ = 1151ULL;
v___x_271_ = 13849006459792130048ULL;
v___x_272_ = vastitas_storage_expect(v_a_169_, v___x_251_, v___x_220_, v___x_260_, v___x_235_, v___x_264_, v___x_200_, v___x_270_, v___x_198_, v___x_195_, v___x_271_, v___x_198_);
if (lean_obj_tag(v___x_272_) == 0)
{
lean_object* v___x_273_; 
lean_dec_ref_known(v___x_272_, 1);
v___x_273_ = vastitas_storage_drop(v_a_169_, v___x_251_);
if (lean_obj_tag(v___x_273_) == 0)
{
lean_object* v___x_274_; 
lean_dec_ref_known(v___x_273_, 1);
v___x_274_ = vastitas_storage_drop(v_a_169_, v___x_247_);
if (lean_obj_tag(v___x_274_) == 0)
{
lean_object* v___x_275_; 
lean_dec_ref_known(v___x_274_, 1);
v___x_275_ = vastitas_storage_drop(v_a_169_, v___x_243_);
if (lean_obj_tag(v___x_275_) == 0)
{
lean_object* v___x_276_; 
lean_dec_ref_known(v___x_275_, 1);
v___x_276_ = vastitas_storage_drop(v_a_169_, v___x_230_);
if (lean_obj_tag(v___x_276_) == 0)
{
lean_object* v___x_277_; 
lean_dec_ref_known(v___x_276_, 1);
v___x_277_ = vastitas_storage_drop(v_a_169_, v___x_214_);
if (lean_obj_tag(v___x_277_) == 0)
{
lean_object* v___x_278_; 
lean_dec_ref_known(v___x_277_, 1);
v___x_278_ = vastitas_storage_drop(v_a_169_, v___x_194_);
if (lean_obj_tag(v___x_278_) == 0)
{
lean_object* v___x_279_; 
lean_dec_ref_known(v___x_278_, 1);
v___x_279_ = lean_box(0);
v_a_171_ = v___x_279_;
goto v___jp_170_;
}
else
{
v___y_182_ = v___x_278_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_277_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_276_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_275_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_274_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_273_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_272_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_269_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_267_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_265_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_263_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_259_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_257_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_254_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_253_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_250_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_249_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_246_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_245_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_242_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_239_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_237_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_233_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_232_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_229_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_226_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_223_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_217_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_216_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_213_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_210_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_208_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_202_;
goto v___jp_181_;
}
}
else
{
v___y_182_ = v___x_197_;
goto v___jp_181_;
}
v___jp_170_:
{
lean_object* v___x_172_; 
v___x_172_ = vastitas_storage_close(v_a_169_);
lean_dec(v_a_169_);
if (lean_obj_tag(v___x_172_) == 0)
{
lean_object* v___x_174_; uint8_t v_isShared_175_; uint8_t v_isSharedCheck_179_; 
v_isSharedCheck_179_ = !lean_is_exclusive(v___x_172_);
if (v_isSharedCheck_179_ == 0)
{
lean_object* v_unused_180_; 
v_unused_180_ = lean_ctor_get(v___x_172_, 0);
lean_dec(v_unused_180_);
v___x_174_ = v___x_172_;
v_isShared_175_ = v_isSharedCheck_179_;
goto v_resetjp_173_;
}
else
{
lean_dec(v___x_172_);
v___x_174_ = lean_box(0);
v_isShared_175_ = v_isSharedCheck_179_;
goto v_resetjp_173_;
}
v_resetjp_173_:
{
lean_object* v___x_177_; 
if (v_isShared_175_ == 0)
{
lean_ctor_set(v___x_174_, 0, v_a_171_);
v___x_177_ = v___x_174_;
goto v_reusejp_176_;
}
else
{
lean_object* v_reuseFailAlloc_178_; 
v_reuseFailAlloc_178_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_178_, 0, v_a_171_);
v___x_177_ = v_reuseFailAlloc_178_;
goto v_reusejp_176_;
}
v_reusejp_176_:
{
return v___x_177_;
}
}
}
else
{
return v___x_172_;
}
}
v___jp_181_:
{
if (lean_obj_tag(v___y_182_) == 0)
{
lean_object* v_a_183_; 
v_a_183_ = lean_ctor_get(v___y_182_, 0);
lean_inc(v_a_183_);
lean_dec_ref_known(v___y_182_, 1);
v_a_171_ = v_a_183_;
goto v___jp_170_;
}
else
{
lean_object* v_a_184_; lean_object* v___x_185_; 
v_a_184_ = lean_ctor_get(v___y_182_, 0);
lean_inc(v_a_184_);
lean_dec_ref_known(v___y_182_, 1);
v___x_185_ = vastitas_storage_close(v_a_169_);
lean_dec(v_a_169_);
if (lean_obj_tag(v___x_185_) == 0)
{
lean_object* v___x_187_; uint8_t v_isShared_188_; uint8_t v_isSharedCheck_192_; 
v_isSharedCheck_192_ = !lean_is_exclusive(v___x_185_);
if (v_isSharedCheck_192_ == 0)
{
lean_object* v_unused_193_; 
v_unused_193_ = lean_ctor_get(v___x_185_, 0);
lean_dec(v_unused_193_);
v___x_187_ = v___x_185_;
v_isShared_188_ = v_isSharedCheck_192_;
goto v_resetjp_186_;
}
else
{
lean_dec(v___x_185_);
v___x_187_ = lean_box(0);
v_isShared_188_ = v_isSharedCheck_192_;
goto v_resetjp_186_;
}
v_resetjp_186_:
{
lean_object* v___x_190_; 
if (v_isShared_188_ == 0)
{
lean_ctor_set_tag(v___x_187_, 1);
lean_ctor_set(v___x_187_, 0, v_a_184_);
v___x_190_ = v___x_187_;
goto v_reusejp_189_;
}
else
{
lean_object* v_reuseFailAlloc_191_; 
v_reuseFailAlloc_191_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_191_, 0, v_a_184_);
v___x_190_ = v_reuseFailAlloc_191_;
goto v_reusejp_189_;
}
v_reusejp_189_:
{
return v___x_190_;
}
}
}
else
{
lean_dec(v_a_184_);
return v___x_185_;
}
}
}
}
else
{
lean_object* v_a_280_; lean_object* v___x_282_; uint8_t v_isShared_283_; uint8_t v_isSharedCheck_287_; 
v_a_280_ = lean_ctor_get(v___x_168_, 0);
v_isSharedCheck_287_ = !lean_is_exclusive(v___x_168_);
if (v_isSharedCheck_287_ == 0)
{
v___x_282_ = v___x_168_;
v_isShared_283_ = v_isSharedCheck_287_;
goto v_resetjp_281_;
}
else
{
lean_inc(v_a_280_);
lean_dec(v___x_168_);
v___x_282_ = lean_box(0);
v_isShared_283_ = v_isSharedCheck_287_;
goto v_resetjp_281_;
}
v_resetjp_281_:
{
lean_object* v___x_285_; 
if (v_isShared_283_ == 0)
{
v___x_285_ = v___x_282_;
goto v_reusejp_284_;
}
else
{
lean_object* v_reuseFailAlloc_286_; 
v_reuseFailAlloc_286_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_286_, 0, v_a_280_);
v___x_285_ = v_reuseFailAlloc_286_;
goto v_reusejp_284_;
}
v_reusejp_284_:
{
return v___x_285_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object* v_a_288_){
_start:
{
lean_object* v_res_289_; 
v_res_289_ = lp_allocation__audit_generatedFailure();
return v_res_289_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object* v_phase_292_, lean_object* v_a_00___x40___internal___hyg_293_){
_start:
{
uint32_t v_phase_boxed_294_; lean_object* v_res_295_; 
v_phase_boxed_294_ = lean_unbox_uint32(v_phase_292_);
lean_dec(v_phase_292_);
v_res_295_ = audit_mark_lean(v_phase_boxed_294_);
return v_res_295_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object* v_a_296_, lean_object* v_scope_297_, lean_object* v_range_298_, lean_object* v_b_299_, lean_object* v_i_300_){
_start:
{
lean_object* v_stop_302_; lean_object* v_step_303_; uint8_t v___x_304_; 
v_stop_302_ = lean_ctor_get(v_range_298_, 1);
v_step_303_ = lean_ctor_get(v_range_298_, 2);
v___x_304_ = lean_nat_dec_lt(v_i_300_, v_stop_302_);
if (v___x_304_ == 0)
{
lean_object* v___x_305_; 
lean_dec(v_i_300_);
v___x_305_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_305_, 0, v_b_299_);
return v___x_305_;
}
else
{
uint32_t v___x_306_; uint64_t v___x_307_; uint64_t v___x_308_; uint64_t v___x_309_; uint64_t v___x_310_; lean_object* v___x_311_; uint8_t v___x_312_; uint32_t v___x_313_; uint64_t v___x_314_; uint64_t v___x_315_; uint32_t v___x_316_; uint64_t v___x_317_; uint64_t v___x_318_; uint64_t v___x_319_; uint32_t v___x_320_; uint8_t v___x_321_; uint64_t v___x_322_; uint32_t v___x_323_; uint64_t v___x_324_; uint32_t v___x_325_; lean_object* v___x_326_; uint64_t v___x_327_; uint64_t v___x_328_; lean_object* v___x_329_; 
v___x_306_ = 0;
v___x_307_ = 8ULL;
v___x_308_ = 24ULL;
v___x_309_ = 1280ULL;
v___x_310_ = 26ULL;
v___x_311_ = lean_unsigned_to_nat(0u);
v___x_312_ = lean_nat_dec_eq(v_scope_297_, v___x_311_);
v___x_313_ = 3;
v___x_314_ = 32ULL;
v___x_315_ = 40ULL;
v___x_316_ = 1;
v___x_317_ = 16ULL;
v___x_318_ = 48ULL;
v___x_319_ = 43ULL;
v___x_320_ = 4;
v___x_321_ = 0;
v___x_322_ = 56ULL;
v___x_323_ = 2;
v___x_324_ = 36ULL;
v___x_325_ = 5;
v___x_326_ = lean_box(0);
v___x_327_ = 768ULL;
v___x_328_ = 773ULL;
v___x_329_ = vastitas_storage_pack3(v_a_296_, v___x_306_, v___x_307_, v___x_308_, v___x_309_, v___x_310_, v___x_312_, v___x_313_, v___x_314_, v___x_327_, v___x_315_, v___x_328_, v___x_312_, v___x_308_, v___x_315_, v___x_314_);
if (lean_obj_tag(v___x_329_) == 0)
{
uint64_t v___x_330_; lean_object* v___x_331_; 
lean_dec_ref_known(v___x_329_, 1);
v___x_330_ = 774ULL;
v___x_331_ = vastitas_gemm_execute(v_a_296_, v___x_313_, v___x_314_, v___x_327_, v___x_315_, v___x_328_, v___x_312_, v___x_312_, v___x_316_, v___x_317_, v___x_315_, v___x_318_, v___x_319_, v___x_312_, v___x_312_, v___x_320_, v___x_315_, v___x_327_, v___x_318_, v___x_330_, v___x_312_, v___x_321_);
if (lean_obj_tag(v___x_331_) == 0)
{
uint64_t v___x_332_; uint64_t v___x_333_; uint64_t v___x_334_; lean_object* v___x_335_; 
lean_dec_ref_known(v___x_331_, 1);
v___x_332_ = 1152ULL;
v___x_333_ = 1160ULL;
v___x_334_ = 42ULL;
v___x_335_ = vastitas_storage_regroup3(v_a_296_, v___x_320_, v___x_315_, v___x_327_, v___x_318_, v___x_330_, v___x_312_, v___x_313_, v___x_322_, v___x_332_, v___x_314_, v___x_333_, v___x_312_, v___x_308_, v___x_314_, v___x_318_, v___x_318_, v___x_334_);
if (lean_obj_tag(v___x_335_) == 0)
{
uint64_t v___x_336_; lean_object* v___x_337_; 
lean_dec_ref_known(v___x_335_, 1);
v___x_336_ = 1159ULL;
v___x_337_ = vastitas_gemm_execute(v_a_296_, v___x_313_, v___x_322_, v___x_332_, v___x_314_, v___x_333_, v___x_312_, v___x_312_, v___x_323_, v___x_308_, v___x_314_, v___x_322_, v___x_324_, v___x_312_, v___x_312_, v___x_325_, v___x_318_, v___x_332_, v___x_322_, v___x_336_, v___x_312_, v___x_321_);
if (lean_obj_tag(v___x_337_) == 0)
{
lean_object* v___x_338_; 
lean_dec_ref_known(v___x_337_, 1);
v___x_338_ = lean_nat_add(v_i_300_, v_step_303_);
lean_dec(v_i_300_);
v_b_299_ = v___x_326_;
v_i_300_ = v___x_338_;
goto _start;
}
else
{
lean_dec(v_i_300_);
return v___x_337_;
}
}
else
{
lean_dec(v_i_300_);
return v___x_335_;
}
}
else
{
lean_dec(v_i_300_);
return v___x_331_;
}
}
else
{
lean_dec(v_i_300_);
return v___x_329_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object* v_a_340_, lean_object* v_scope_341_, lean_object* v_range_342_, lean_object* v_b_343_, lean_object* v_i_344_, lean_object* v___y_345_){
_start:
{
lean_object* v_res_346_; 
v_res_346_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_340_, v_scope_341_, v_range_342_, v_b_343_, v_i_344_);
lean_dec_ref(v_range_342_);
lean_dec(v_scope_341_);
lean_dec(v_a_340_);
return v_res_346_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object* v_range_347_, lean_object* v_b_348_, lean_object* v_i_349_){
_start:
{
lean_object* v_stop_351_; lean_object* v_step_352_; uint8_t v___x_353_; 
v_stop_351_ = lean_ctor_get(v_range_347_, 1);
v_step_352_ = lean_ctor_get(v_range_347_, 2);
v___x_353_ = lean_nat_dec_lt(v_i_349_, v_stop_351_);
if (v___x_353_ == 0)
{
lean_object* v___x_354_; 
lean_dec(v_i_349_);
v___x_354_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_354_, 0, v_b_348_);
return v___x_354_;
}
else
{
lean_object* v___x_355_; lean_object* v___x_356_; 
v___x_355_ = lean_box(0);
v___x_356_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_356_) == 0)
{
lean_object* v___x_357_; 
lean_dec_ref_known(v___x_356_, 1);
v___x_357_ = lean_nat_add(v_i_349_, v_step_352_);
lean_dec(v_i_349_);
v_b_348_ = v___x_355_;
v_i_349_ = v___x_357_;
goto _start;
}
else
{
lean_dec(v_i_349_);
return v___x_356_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object* v_range_359_, lean_object* v_b_360_, lean_object* v_i_361_, lean_object* v___y_362_){
_start:
{
lean_object* v_res_363_; 
v_res_363_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_359_, v_b_360_, v_i_361_);
lean_dec_ref(v_range_359_);
return v_res_363_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_372_){
_start:
{
lean_object* v___x_374_; lean_object* v___x_375_; lean_object* v_impl_376_; lean_object* v___x_377_; lean_object* v___x_378_; lean_object* v___x_379_; lean_object* v___x_380_; lean_object* v_scope_381_; lean_object* v___x_382_; lean_object* v___x_383_; lean_object* v___x_384_; lean_object* v___x_385_; lean_object* v_reps_386_; lean_object* v___x_387_; lean_object* v___x_388_; lean_object* v___x_389_; uint8_t v_verify_390_; uint32_t v___x_391_; lean_object* v___x_392_; 
v___x_374_ = ((lean_object*)(lp_allocation__audit_main___closed__0));
v___x_375_ = lean_unsigned_to_nat(0u);
v_impl_376_ = l_List_get_x21Internal___redArg(v___x_374_, v_args_372_, v___x_375_);
v___x_377_ = lean_unsigned_to_nat(1u);
v___x_378_ = l_List_get_x21Internal___redArg(v___x_374_, v_args_372_, v___x_377_);
v___x_379_ = lean_string_utf8_byte_size(v___x_378_);
v___x_380_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_380_, 0, v___x_378_);
lean_ctor_set(v___x_380_, 1, v___x_375_);
lean_ctor_set(v___x_380_, 2, v___x_379_);
v_scope_381_ = l_String_Slice_toNat_x21(v___x_380_);
lean_dec_ref_known(v___x_380_, 3);
v___x_382_ = lean_unsigned_to_nat(2u);
v___x_383_ = l_List_get_x21Internal___redArg(v___x_374_, v_args_372_, v___x_382_);
v___x_384_ = lean_string_utf8_byte_size(v___x_383_);
v___x_385_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_385_, 0, v___x_383_);
lean_ctor_set(v___x_385_, 1, v___x_375_);
lean_ctor_set(v___x_385_, 2, v___x_384_);
v_reps_386_ = l_String_Slice_toNat_x21(v___x_385_);
lean_dec_ref_known(v___x_385_, 3);
v___x_387_ = lean_unsigned_to_nat(3u);
v___x_388_ = l_List_get_x21Internal___redArg(v___x_374_, v_args_372_, v___x_387_);
lean_dec(v_args_372_);
v___x_389_ = ((lean_object*)(lp_allocation__audit_main___closed__1));
v_verify_390_ = lean_string_dec_eq(v___x_388_, v___x_389_);
lean_dec(v___x_388_);
v___x_391_ = 1;
v___x_392_ = audit_mark_lean(v___x_391_);
if (lean_obj_tag(v___x_392_) == 0)
{
lean_object* v___x_393_; 
lean_dec_ref_known(v___x_392_, 1);
v___x_393_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_393_) == 0)
{
uint32_t v___x_394_; lean_object* v___x_395_; 
lean_dec_ref_known(v___x_393_, 1);
v___x_394_ = 2;
v___x_395_ = audit_mark_lean(v___x_394_);
if (lean_obj_tag(v___x_395_) == 0)
{
lean_object* v___x_396_; uint8_t v___x_397_; 
lean_dec_ref_known(v___x_395_, 1);
v___x_396_ = ((lean_object*)(lp_allocation__audit_main___closed__2));
v___x_397_ = lean_string_dec_eq(v_impl_376_, v___x_396_);
if (v___x_397_ == 0)
{
lean_object* v___x_398_; uint8_t v___x_399_; 
v___x_398_ = ((lean_object*)(lp_allocation__audit_main___closed__3));
v___x_399_ = lean_string_dec_eq(v_impl_376_, v___x_398_);
lean_dec(v_impl_376_);
if (v___x_399_ == 0)
{
uint8_t v___x_400_; 
v___x_400_ = lean_nat_dec_eq(v_scope_381_, v___x_375_);
if (v___x_400_ == 0)
{
uint64_t v___x_401_; lean_object* v___x_402_; 
v___x_401_ = 9223372036854775807ULL;
v___x_402_ = vastitas_storage_new(v___x_401_);
if (lean_obj_tag(v___x_402_) == 0)
{
lean_object* v_a_403_; lean_object* v___y_405_; uint32_t v___x_418_; uint8_t v___x_419_; uint64_t v___x_420_; lean_object* v___x_421_; 
v_a_403_ = lean_ctor_get(v___x_402_, 0);
lean_inc(v_a_403_);
lean_dec_ref_known(v___x_402_, 1);
v___x_418_ = 0;
v___x_419_ = 0;
v___x_420_ = 33284ULL;
v___x_421_ = vastitas_storage_allocate(v_a_403_, v___x_418_, v___x_419_, v___x_420_);
if (lean_obj_tag(v___x_421_) == 0)
{
uint64_t v___x_422_; uint64_t v___x_423_; uint64_t v___x_424_; lean_object* v___x_425_; 
lean_dec_ref_known(v___x_421_, 1);
v___x_422_ = 0ULL;
v___x_423_ = 1ULL;
v___x_424_ = 13842939354630062080ULL;
v___x_425_ = vastitas_storage_fill(v_a_403_, v___x_418_, v___x_422_, v___x_420_, v___x_423_, v___x_420_, v___x_400_, v___x_419_, v___x_424_, v___x_422_);
if (lean_obj_tag(v___x_425_) == 0)
{
uint64_t v___x_426_; uint64_t v___x_427_; uint64_t v___x_428_; uint64_t v___x_429_; uint64_t v___x_430_; lean_object* v___x_431_; 
lean_dec_ref_known(v___x_425_, 1);
v___x_426_ = 8ULL;
v___x_427_ = 24ULL;
v___x_428_ = 1280ULL;
v___x_429_ = 26ULL;
v___x_430_ = 4593671619917905920ULL;
v___x_431_ = vastitas_storage_fill(v_a_403_, v___x_418_, v___x_426_, v___x_427_, v___x_428_, v___x_429_, v___x_400_, v___x_419_, v___x_430_, v___x_422_);
if (lean_obj_tag(v___x_431_) == 0)
{
uint64_t v___x_432_; lean_object* v___x_433_; 
lean_dec_ref_known(v___x_431_, 1);
v___x_432_ = 4607182418800017408ULL;
v___x_433_ = vastitas_storage_store(v_a_403_, v___x_418_, v___x_426_, v___x_427_, v___x_428_, v___x_429_, v___x_400_, v___x_422_, v___x_422_, v___x_419_, v___x_432_, v___x_422_);
if (lean_obj_tag(v___x_433_) == 0)
{
uint64_t v___x_434_; uint64_t v___x_435_; lean_object* v___x_436_; 
lean_dec_ref_known(v___x_433_, 1);
v___x_434_ = 23ULL;
v___x_435_ = 13826050856027422720ULL;
v___x_436_ = vastitas_storage_store(v_a_403_, v___x_418_, v___x_426_, v___x_427_, v___x_428_, v___x_429_, v___x_400_, v___x_434_, v___x_423_, v___x_419_, v___x_435_, v___x_422_);
if (lean_obj_tag(v___x_436_) == 0)
{
uint64_t v___x_437_; lean_object* v___x_438_; 
lean_dec_ref_known(v___x_436_, 1);
v___x_437_ = 2069ULL;
v___x_438_ = vastitas_storage_allocate(v_a_403_, v___x_391_, v___x_419_, v___x_437_);
if (lean_obj_tag(v___x_438_) == 0)
{
lean_object* v___x_439_; 
lean_dec_ref_known(v___x_438_, 1);
v___x_439_ = vastitas_storage_fill(v_a_403_, v___x_391_, v___x_422_, v___x_437_, v___x_423_, v___x_437_, v___x_400_, v___x_419_, v___x_424_, v___x_422_);
if (lean_obj_tag(v___x_439_) == 0)
{
uint64_t v___x_440_; uint64_t v___x_441_; uint64_t v___x_442_; uint64_t v___x_443_; uint64_t v___x_444_; lean_object* v___x_445_; 
lean_dec_ref_known(v___x_439_, 1);
v___x_440_ = 16ULL;
v___x_441_ = 40ULL;
v___x_442_ = 48ULL;
v___x_443_ = 43ULL;
v___x_444_ = 13821547256400052224ULL;
v___x_445_ = vastitas_storage_fill(v_a_403_, v___x_391_, v___x_440_, v___x_441_, v___x_442_, v___x_443_, v___x_400_, v___x_419_, v___x_444_, v___x_422_);
if (lean_obj_tag(v___x_445_) == 0)
{
uint64_t v___x_446_; uint64_t v___x_447_; lean_object* v___x_448_; 
lean_dec_ref_known(v___x_445_, 1);
v___x_446_ = 47ULL;
v___x_447_ = 4602678819172646912ULL;
v___x_448_ = vastitas_storage_store(v_a_403_, v___x_391_, v___x_440_, v___x_441_, v___x_442_, v___x_443_, v___x_400_, v___x_422_, v___x_446_, v___x_419_, v___x_447_, v___x_422_);
if (lean_obj_tag(v___x_448_) == 0)
{
uint64_t v___x_449_; uint64_t v___x_450_; lean_object* v___x_451_; 
lean_dec_ref_known(v___x_448_, 1);
v___x_449_ = 39ULL;
v___x_450_ = 13828302655841107968ULL;
v___x_451_ = vastitas_storage_store(v_a_403_, v___x_391_, v___x_440_, v___x_441_, v___x_442_, v___x_443_, v___x_400_, v___x_449_, v___x_422_, v___x_419_, v___x_450_, v___x_422_);
if (lean_obj_tag(v___x_451_) == 0)
{
uint64_t v___x_452_; lean_object* v___x_453_; 
lean_dec_ref_known(v___x_451_, 1);
v___x_452_ = 2022ULL;
v___x_453_ = vastitas_storage_allocate(v_a_403_, v___x_394_, v___x_419_, v___x_452_);
if (lean_obj_tag(v___x_453_) == 0)
{
lean_object* v___x_454_; 
lean_dec_ref_known(v___x_453_, 1);
v___x_454_ = vastitas_storage_fill(v_a_403_, v___x_394_, v___x_422_, v___x_452_, v___x_423_, v___x_452_, v___x_400_, v___x_419_, v___x_424_, v___x_422_);
if (lean_obj_tag(v___x_454_) == 0)
{
uint64_t v___x_455_; uint64_t v___x_456_; uint64_t v___x_457_; lean_object* v___x_458_; 
lean_dec_ref_known(v___x_454_, 1);
v___x_455_ = 32ULL;
v___x_456_ = 56ULL;
v___x_457_ = 36ULL;
v___x_458_ = vastitas_storage_fill(v_a_403_, v___x_394_, v___x_427_, v___x_455_, v___x_456_, v___x_457_, v___x_400_, v___x_419_, v___x_447_, v___x_422_);
if (lean_obj_tag(v___x_458_) == 0)
{
uint64_t v___x_459_; lean_object* v___x_460_; 
lean_dec_ref_known(v___x_458_, 1);
v___x_459_ = 31ULL;
v___x_460_ = vastitas_storage_store(v_a_403_, v___x_394_, v___x_427_, v___x_455_, v___x_456_, v___x_457_, v___x_400_, v___x_459_, v___x_422_, v___x_419_, v___x_444_, v___x_422_);
if (lean_obj_tag(v___x_460_) == 0)
{
uint64_t v___x_461_; uint64_t v___x_462_; lean_object* v___x_463_; 
lean_dec_ref_known(v___x_460_, 1);
v___x_461_ = 55ULL;
v___x_462_ = 4604930618986332160ULL;
v___x_463_ = vastitas_storage_store(v_a_403_, v___x_394_, v___x_427_, v___x_455_, v___x_456_, v___x_457_, v___x_400_, v___x_422_, v___x_461_, v___x_419_, v___x_462_, v___x_422_);
if (lean_obj_tag(v___x_463_) == 0)
{
uint32_t v___x_464_; uint64_t v___x_465_; lean_object* v___x_466_; 
lean_dec_ref_known(v___x_463_, 1);
v___x_464_ = 3;
v___x_465_ = 37130ULL;
v___x_466_ = vastitas_storage_allocate(v_a_403_, v___x_464_, v___x_419_, v___x_465_);
if (lean_obj_tag(v___x_466_) == 0)
{
lean_object* v___x_467_; 
lean_dec_ref_known(v___x_466_, 1);
v___x_467_ = vastitas_storage_fill(v_a_403_, v___x_464_, v___x_422_, v___x_465_, v___x_423_, v___x_465_, v___x_400_, v___x_419_, v___x_424_, v___x_422_);
if (lean_obj_tag(v___x_467_) == 0)
{
uint32_t v___x_468_; uint64_t v___x_469_; lean_object* v___x_470_; 
lean_dec_ref_known(v___x_467_, 1);
v___x_468_ = 4;
v___x_469_ = 37160ULL;
v___x_470_ = vastitas_storage_allocate(v_a_403_, v___x_468_, v___x_419_, v___x_469_);
if (lean_obj_tag(v___x_470_) == 0)
{
lean_object* v___x_471_; 
lean_dec_ref_known(v___x_470_, 1);
v___x_471_ = vastitas_storage_fill(v_a_403_, v___x_468_, v___x_422_, v___x_469_, v___x_423_, v___x_469_, v___x_400_, v___x_419_, v___x_424_, v___x_422_);
if (lean_obj_tag(v___x_471_) == 0)
{
uint32_t v___x_472_; uint64_t v___x_473_; lean_object* v___x_474_; 
lean_dec_ref_known(v___x_471_, 1);
v___x_472_ = 5;
v___x_473_ = 64913ULL;
v___x_474_ = vastitas_storage_allocate(v_a_403_, v___x_472_, v___x_419_, v___x_473_);
if (lean_obj_tag(v___x_474_) == 0)
{
lean_object* v___x_475_; 
lean_dec_ref_known(v___x_474_, 1);
v___x_475_ = vastitas_storage_fill(v_a_403_, v___x_472_, v___x_422_, v___x_473_, v___x_423_, v___x_473_, v___x_400_, v___x_419_, v___x_424_, v___x_422_);
if (lean_obj_tag(v___x_475_) == 0)
{
uint32_t v___x_476_; uint64_t v___x_477_; lean_object* v___x_478_; 
lean_dec_ref_known(v___x_475_, 1);
v___x_476_ = lean_uint32_of_nat(v_scope_381_);
v___x_477_ = lean_uint64_of_nat(v_reps_386_);
v___x_478_ = bench_begin_lean(v___x_476_, v___x_477_, v_verify_390_);
if (lean_obj_tag(v___x_478_) == 0)
{
lean_object* v___x_479_; lean_object* v___x_480_; lean_object* v___x_481_; 
lean_dec_ref_known(v___x_478_, 1);
v___x_479_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_479_, 0, v___x_375_);
lean_ctor_set(v___x_479_, 1, v_reps_386_);
lean_ctor_set(v___x_479_, 2, v___x_377_);
v___x_480_ = lean_box(0);
v___x_481_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_403_, v_scope_381_, v___x_479_, v___x_480_, v___x_375_);
lean_dec_ref_known(v___x_479_, 3);
lean_dec(v_scope_381_);
if (lean_obj_tag(v___x_481_) == 0)
{
lean_object* v___x_482_; 
lean_dec_ref_known(v___x_481_, 1);
v___x_482_ = bench_stop_lean();
if (lean_obj_tag(v___x_482_) == 0)
{
lean_object* v___x_483_; 
lean_dec_ref_known(v___x_482_, 1);
v___x_483_ = bench_verify_lean(v_a_403_, v___x_477_);
if (lean_obj_tag(v___x_483_) == 0)
{
uint64_t v___x_484_; uint64_t v___x_485_; uint64_t v___x_486_; lean_object* v___x_487_; 
lean_dec_ref_known(v___x_483_, 1);
v___x_484_ = 1152ULL;
v___x_485_ = 1159ULL;
v___x_486_ = 13849729938443206656ULL;
v___x_487_ = vastitas_storage_expect(v_a_403_, v___x_472_, v___x_442_, v___x_484_, v___x_456_, v___x_485_, v___x_400_, v___x_422_, v___x_422_, v___x_419_, v___x_486_, v___x_422_);
if (lean_obj_tag(v___x_487_) == 0)
{
uint64_t v___x_488_; lean_object* v___x_489_; 
lean_dec_ref_known(v___x_487_, 1);
v___x_488_ = 13850035602675728384ULL;
v___x_489_ = vastitas_storage_expect(v_a_403_, v___x_472_, v___x_442_, v___x_484_, v___x_456_, v___x_485_, v___x_400_, v___x_434_, v___x_461_, v___x_419_, v___x_488_, v___x_422_);
if (lean_obj_tag(v___x_489_) == 0)
{
uint64_t v___x_490_; uint64_t v___x_491_; lean_object* v___x_492_; 
lean_dec_ref_known(v___x_489_, 1);
v___x_490_ = 1151ULL;
v___x_491_ = 13849006459792130048ULL;
v___x_492_ = vastitas_storage_expect(v_a_403_, v___x_472_, v___x_442_, v___x_484_, v___x_456_, v___x_485_, v___x_400_, v___x_490_, v___x_422_, v___x_419_, v___x_491_, v___x_422_);
if (lean_obj_tag(v___x_492_) == 0)
{
lean_object* v___x_493_; 
lean_dec_ref_known(v___x_492_, 1);
v___x_493_ = vastitas_storage_drop(v_a_403_, v___x_472_);
if (lean_obj_tag(v___x_493_) == 0)
{
lean_object* v___x_494_; 
lean_dec_ref_known(v___x_493_, 1);
v___x_494_ = vastitas_storage_drop(v_a_403_, v___x_468_);
if (lean_obj_tag(v___x_494_) == 0)
{
lean_object* v___x_495_; 
lean_dec_ref_known(v___x_494_, 1);
v___x_495_ = vastitas_storage_drop(v_a_403_, v___x_464_);
if (lean_obj_tag(v___x_495_) == 0)
{
lean_object* v___x_496_; 
lean_dec_ref_known(v___x_495_, 1);
v___x_496_ = vastitas_storage_drop(v_a_403_, v___x_394_);
if (lean_obj_tag(v___x_496_) == 0)
{
lean_object* v___x_497_; 
lean_dec_ref_known(v___x_496_, 1);
v___x_497_ = vastitas_storage_drop(v_a_403_, v___x_391_);
if (lean_obj_tag(v___x_497_) == 0)
{
lean_object* v___x_498_; 
lean_dec_ref_known(v___x_497_, 1);
v___x_498_ = vastitas_storage_drop(v_a_403_, v___x_418_);
v___y_405_ = v___x_498_;
goto v___jp_404_;
}
else
{
v___y_405_ = v___x_497_;
goto v___jp_404_;
}
}
else
{
v___y_405_ = v___x_496_;
goto v___jp_404_;
}
}
else
{
v___y_405_ = v___x_495_;
goto v___jp_404_;
}
}
else
{
v___y_405_ = v___x_494_;
goto v___jp_404_;
}
}
else
{
v___y_405_ = v___x_493_;
goto v___jp_404_;
}
}
else
{
v___y_405_ = v___x_492_;
goto v___jp_404_;
}
}
else
{
v___y_405_ = v___x_489_;
goto v___jp_404_;
}
}
else
{
v___y_405_ = v___x_487_;
goto v___jp_404_;
}
}
else
{
v___y_405_ = v___x_483_;
goto v___jp_404_;
}
}
else
{
v___y_405_ = v___x_482_;
goto v___jp_404_;
}
}
else
{
v___y_405_ = v___x_481_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_478_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_475_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_474_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_471_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_470_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_467_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_466_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_463_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_460_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_458_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_454_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_453_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_451_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_448_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_445_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_439_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_438_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_436_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_433_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_431_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_425_;
goto v___jp_404_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v___y_405_ = v___x_421_;
goto v___jp_404_;
}
v___jp_404_:
{
if (lean_obj_tag(v___y_405_) == 0)
{
lean_object* v___x_406_; 
lean_dec_ref_known(v___y_405_, 1);
v___x_406_ = vastitas_storage_close(v_a_403_);
lean_dec(v_a_403_);
if (lean_obj_tag(v___x_406_) == 0)
{
lean_object* v___x_407_; 
lean_dec_ref_known(v___x_406_, 1);
v___x_407_ = bench_report_lean();
return v___x_407_;
}
else
{
return v___x_406_;
}
}
else
{
lean_object* v_a_408_; lean_object* v___x_409_; 
v_a_408_ = lean_ctor_get(v___y_405_, 0);
lean_inc(v_a_408_);
lean_dec_ref_known(v___y_405_, 1);
v___x_409_ = vastitas_storage_close(v_a_403_);
lean_dec(v_a_403_);
if (lean_obj_tag(v___x_409_) == 0)
{
lean_object* v___x_411_; uint8_t v_isShared_412_; uint8_t v_isSharedCheck_416_; 
v_isSharedCheck_416_ = !lean_is_exclusive(v___x_409_);
if (v_isSharedCheck_416_ == 0)
{
lean_object* v_unused_417_; 
v_unused_417_ = lean_ctor_get(v___x_409_, 0);
lean_dec(v_unused_417_);
v___x_411_ = v___x_409_;
v_isShared_412_ = v_isSharedCheck_416_;
goto v_resetjp_410_;
}
else
{
lean_dec(v___x_409_);
v___x_411_ = lean_box(0);
v_isShared_412_ = v_isSharedCheck_416_;
goto v_resetjp_410_;
}
v_resetjp_410_:
{
lean_object* v___x_414_; 
if (v_isShared_412_ == 0)
{
lean_ctor_set_tag(v___x_411_, 1);
lean_ctor_set(v___x_411_, 0, v_a_408_);
v___x_414_ = v___x_411_;
goto v_reusejp_413_;
}
else
{
lean_object* v_reuseFailAlloc_415_; 
v_reuseFailAlloc_415_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_415_, 0, v_a_408_);
v___x_414_ = v_reuseFailAlloc_415_;
goto v_reusejp_413_;
}
v_reusejp_413_:
{
return v___x_414_;
}
}
}
else
{
lean_dec(v_a_408_);
return v___x_409_;
}
}
}
}
else
{
lean_object* v_a_499_; lean_object* v___x_501_; uint8_t v_isShared_502_; uint8_t v_isSharedCheck_506_; 
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
v_a_499_ = lean_ctor_get(v___x_402_, 0);
v_isSharedCheck_506_ = !lean_is_exclusive(v___x_402_);
if (v_isSharedCheck_506_ == 0)
{
v___x_501_ = v___x_402_;
v_isShared_502_ = v_isSharedCheck_506_;
goto v_resetjp_500_;
}
else
{
lean_inc(v_a_499_);
lean_dec(v___x_402_);
v___x_501_ = lean_box(0);
v_isShared_502_ = v_isSharedCheck_506_;
goto v_resetjp_500_;
}
v_resetjp_500_:
{
lean_object* v___x_504_; 
if (v_isShared_502_ == 0)
{
v___x_504_ = v___x_501_;
goto v_reusejp_503_;
}
else
{
lean_object* v_reuseFailAlloc_505_; 
v_reuseFailAlloc_505_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_505_, 0, v_a_499_);
v___x_504_ = v_reuseFailAlloc_505_;
goto v_reusejp_503_;
}
v_reusejp_503_:
{
return v___x_504_;
}
}
}
}
else
{
uint32_t v___x_507_; uint64_t v___x_508_; lean_object* v___x_509_; 
lean_dec(v_scope_381_);
v___x_507_ = 0;
v___x_508_ = lean_uint64_of_nat(v_reps_386_);
v___x_509_ = bench_begin_lean(v___x_507_, v___x_508_, v_verify_390_);
if (lean_obj_tag(v___x_509_) == 0)
{
lean_object* v___x_510_; lean_object* v___x_511_; lean_object* v___x_512_; 
lean_dec_ref_known(v___x_509_, 1);
v___x_510_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_510_, 0, v___x_375_);
lean_ctor_set(v___x_510_, 1, v_reps_386_);
lean_ctor_set(v___x_510_, 2, v___x_377_);
v___x_511_ = lean_box(0);
v___x_512_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v___x_510_, v___x_511_, v___x_375_);
lean_dec_ref_known(v___x_510_, 3);
if (lean_obj_tag(v___x_512_) == 0)
{
lean_object* v___x_513_; 
lean_dec_ref_known(v___x_512_, 1);
v___x_513_ = bench_stop_lean();
if (lean_obj_tag(v___x_513_) == 0)
{
lean_object* v___x_514_; 
lean_dec_ref_known(v___x_513_, 1);
v___x_514_ = bench_report_lean();
return v___x_514_;
}
else
{
return v___x_513_;
}
}
else
{
return v___x_512_;
}
}
else
{
lean_dec(v_reps_386_);
return v___x_509_;
}
}
}
else
{
uint32_t v___x_515_; uint64_t v___x_516_; lean_object* v___x_517_; 
v___x_515_ = lean_uint32_of_nat(v_scope_381_);
lean_dec(v_scope_381_);
v___x_516_ = lean_uint64_of_nat(v_reps_386_);
lean_dec(v_reps_386_);
v___x_517_ = bench_c_run_lean(v___x_515_, v___x_516_, v_verify_390_);
if (lean_obj_tag(v___x_517_) == 0)
{
lean_object* v___x_518_; 
lean_dec_ref_known(v___x_517_, 1);
v___x_518_ = bench_report_lean();
return v___x_518_;
}
else
{
return v___x_517_;
}
}
}
else
{
uint32_t v___x_519_; uint64_t v___x_520_; lean_object* v___x_521_; 
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
lean_dec(v_impl_376_);
v___x_519_ = 0;
v___x_520_ = 1ULL;
v___x_521_ = bench_begin_lean(v___x_519_, v___x_520_, v___x_397_);
if (lean_obj_tag(v___x_521_) == 0)
{
lean_object* v___x_522_; 
lean_dec_ref_known(v___x_521_, 1);
v___x_522_ = lp_allocation__audit_generatedFailure();
if (lean_obj_tag(v___x_522_) == 0)
{
lean_object* v___x_524_; uint8_t v_isShared_525_; uint8_t v_isSharedCheck_530_; 
v_isSharedCheck_530_ = !lean_is_exclusive(v___x_522_);
if (v_isSharedCheck_530_ == 0)
{
lean_object* v_unused_531_; 
v_unused_531_ = lean_ctor_get(v___x_522_, 0);
lean_dec(v_unused_531_);
v___x_524_ = v___x_522_;
v_isShared_525_ = v_isSharedCheck_530_;
goto v_resetjp_523_;
}
else
{
lean_dec(v___x_522_);
v___x_524_ = lean_box(0);
v_isShared_525_ = v_isSharedCheck_530_;
goto v_resetjp_523_;
}
v_resetjp_523_:
{
lean_object* v___x_526_; lean_object* v___x_528_; 
v___x_526_ = ((lean_object*)(lp_allocation__audit_main___closed__5));
if (v_isShared_525_ == 0)
{
lean_ctor_set_tag(v___x_524_, 1);
lean_ctor_set(v___x_524_, 0, v___x_526_);
v___x_528_ = v___x_524_;
goto v_reusejp_527_;
}
else
{
lean_object* v_reuseFailAlloc_529_; 
v_reuseFailAlloc_529_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_529_, 0, v___x_526_);
v___x_528_ = v_reuseFailAlloc_529_;
goto v_reusejp_527_;
}
v_reusejp_527_:
{
return v___x_528_;
}
}
}
else
{
lean_object* v_a_532_; lean_object* v___x_533_; lean_object* v___x_534_; uint8_t v___x_535_; 
v_a_532_ = lean_ctor_get(v___x_522_, 0);
lean_inc(v_a_532_);
v___x_533_ = lean_io_error_to_string(v_a_532_);
v___x_534_ = ((lean_object*)(lp_allocation__audit_main___closed__6));
v___x_535_ = lean_string_dec_eq(v___x_533_, v___x_534_);
lean_dec_ref(v___x_533_);
if (v___x_535_ == 0)
{
return v___x_522_;
}
else
{
lean_object* v___x_536_; 
lean_dec_ref_known(v___x_522_, 1);
v___x_536_ = bench_stop_lean();
if (lean_obj_tag(v___x_536_) == 0)
{
lean_object* v___x_537_; 
lean_dec_ref_known(v___x_536_, 1);
v___x_537_ = bench_report_lean();
return v___x_537_;
}
else
{
return v___x_536_;
}
}
}
}
else
{
return v___x_521_;
}
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
lean_dec(v_impl_376_);
return v___x_395_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
lean_dec(v_impl_376_);
return v___x_393_;
}
}
else
{
lean_dec(v_reps_386_);
lean_dec(v_scope_381_);
lean_dec(v_impl_376_);
return v___x_392_;
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object* v_args_538_, lean_object* v_a_539_){
_start:
{
lean_object* v_res_540_; 
v_res_540_ = _lean_main(v_args_538_);
return v_res_540_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object* v_a_541_, lean_object* v_scope_542_, lean_object* v_range_543_, lean_object* v_b_544_, lean_object* v_i_545_, lean_object* v_hs_546_, lean_object* v_hl_547_){
_start:
{
lean_object* v___x_549_; 
v___x_549_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_541_, v_scope_542_, v_range_543_, v_b_544_, v_i_545_);
return v___x_549_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object* v_a_550_, lean_object* v_scope_551_, lean_object* v_range_552_, lean_object* v_b_553_, lean_object* v_i_554_, lean_object* v_hs_555_, lean_object* v_hl_556_, lean_object* v___y_557_){
_start:
{
lean_object* v_res_558_; 
v_res_558_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(v_a_550_, v_scope_551_, v_range_552_, v_b_553_, v_i_554_, v_hs_555_, v_hl_556_);
lean_dec_ref(v_range_552_);
lean_dec(v_scope_551_);
lean_dec(v_a_550_);
return v_res_558_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object* v_range_559_, lean_object* v_b_560_, lean_object* v_i_561_, lean_object* v_hs_562_, lean_object* v_hl_563_){
_start:
{
lean_object* v___x_565_; 
v___x_565_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_559_, v_b_560_, v_i_561_);
return v___x_565_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object* v_range_566_, lean_object* v_b_567_, lean_object* v_i_568_, lean_object* v_hs_569_, lean_object* v_hl_570_, lean_object* v___y_571_){
_start:
{
lean_object* v_res_572_; 
v_res_572_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(v_range_566_, v_b_567_, v_i_568_, v_hs_569_, v_hl_570_);
lean_dec_ref(v_range_566_);
return v_res_572_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_vastitas__storage__native_VastitasStorageNative(uint8_t builtin);
lean_object* initialize_vastitas__gemm__native_VastitasGemmNative(uint8_t builtin);
lean_object* initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_allocation__audit_Main(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__storage__native_VastitasStorageNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__gemm__native_VastitasGemmNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_allocation__audit_VastitasGenerated_f__0 = _init_lp_allocation__audit_VastitasGenerated_f__0();
lean_mark_persistent(lp_allocation__audit_VastitasGenerated_f__0);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_allocation__audit_Main(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = 0;
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
