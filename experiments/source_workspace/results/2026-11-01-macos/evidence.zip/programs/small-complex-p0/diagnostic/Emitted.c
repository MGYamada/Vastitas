// Lean compiler output
// Module: Main
// Imports: public import Init public meta import Init public import VastitasStorageNative public import VastitasGemmNative public import VastitasKernel.IndexedRuntime
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* vastitas_storage_new(uint64_t);
lean_object* vastitas_storage_close(lean_object*);
lean_object* vastitas_storage_allocate(lean_object*, uint32_t, uint8_t, uint64_t);
lean_object* vastitas_storage_fill(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_store(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_pack3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_gemm_execute(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t);
lean_object* vastitas_storage_regroup3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_storage_expect(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_drop(lean_object*, uint32_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_List_get_x21Internal___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_String_Slice_toNat_x21(lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
uint32_t lean_uint32_of_nat(lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
lean_object* lean_io_error_to_string(lean_object*);
static lean_once_cell_t lp_allocation__audit_VastitasGenerated_f__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_allocation__audit_VastitasGenerated_f__0___closed__0;
LEAN_EXPORT lean_object* lp_allocation__audit_VastitasGenerated_f__0;
lean_object* bench_begin_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_stop_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object*);
lean_object* bench_report_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object*);
lean_object* bench_c_run_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_verify_lean(lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object*);
lean_object* audit_mark_lean(uint32_t);
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_allocation__audit_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 1, .m_capacity = 1, .m_length = 0, .m_data = ""};
static const lean_object* lp_allocation__audit_main___closed__0 = (const lean_object*)&lp_allocation__audit_main___closed__0_value;
static const lean_string_object lp_allocation__audit_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "1"};
static const lean_object* lp_allocation__audit_main___closed__1 = (const lean_object*)&lp_allocation__audit_main___closed__1_value;
static const lean_string_object lp_allocation__audit_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "failure"};
static const lean_object* lp_allocation__audit_main___closed__2 = (const lean_object*)&lp_allocation__audit_main___closed__2_value;
static const lean_string_object lp_allocation__audit_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "c"};
static const lean_object* lp_allocation__audit_main___closed__3 = (const lean_object*)&lp_allocation__audit_main___closed__3_value;
static const lean_string_object lp_allocation__audit_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "expected injected native failure"};
static const lean_object* lp_allocation__audit_main___closed__4 = (const lean_object*)&lp_allocation__audit_main___closed__4_value;
static const lean_ctor_object lp_allocation__audit_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_allocation__audit_main___closed__4_value)}};
static const lean_object* lp_allocation__audit_main___closed__5 = (const lean_object*)&lp_allocation__audit_main___closed__5_value;
static const lean_string_object lp_allocation__audit_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 44, .m_capacity = 44, .m_length = 43, .m_data = "E_NATIVE_EXPECT: stored bit pattern differs"};
static const lean_object* lp_allocation__audit_main___closed__6 = (const lean_object*)&lp_allocation__audit_main___closed__6_value;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(0u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0(void){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_obj_once(&lp_allocation__audit_VastitasGenerated_f__0___closed__0, &lp_allocation__audit_VastitasGenerated_f__0___closed__0_once, _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object* v_scope_8_, lean_object* v_reps_9_, lean_object* v_verify_10_, lean_object* v_a_00___x40___internal___hyg_11_){
_start:
{
uint32_t v_scope_boxed_12_; uint64_t v_reps_boxed_13_; uint8_t v_verify_boxed_14_; lean_object* v_res_15_; 
v_scope_boxed_12_ = lean_unbox_uint32(v_scope_8_);
lean_dec(v_scope_8_);
v_reps_boxed_13_ = lean_unbox_uint64(v_reps_9_);
lean_dec_ref(v_reps_9_);
v_verify_boxed_14_ = lean_unbox(v_verify_10_);
v_res_15_ = bench_begin_lean(v_scope_boxed_12_, v_reps_boxed_13_, v_verify_boxed_14_);
return v_res_15_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object* v_a_00___x40___internal___hyg_17_){
_start:
{
lean_object* v_res_18_; 
v_res_18_ = bench_stop_lean();
return v_res_18_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object* v_a_00___x40___internal___hyg_20_){
_start:
{
lean_object* v_res_21_; 
v_res_21_ = bench_report_lean();
return v_res_21_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object* v_scope_26_, lean_object* v_reps_27_, lean_object* v_verify_28_, lean_object* v_a_00___x40___internal___hyg_29_){
_start:
{
uint32_t v_scope_boxed_30_; uint64_t v_reps_boxed_31_; uint8_t v_verify_boxed_32_; lean_object* v_res_33_; 
v_scope_boxed_30_ = lean_unbox_uint32(v_scope_26_);
lean_dec(v_scope_26_);
v_reps_boxed_31_ = lean_unbox_uint64(v_reps_27_);
lean_dec_ref(v_reps_27_);
v_verify_boxed_32_ = lean_unbox(v_verify_28_);
v_res_33_ = bench_c_run_lean(v_scope_boxed_30_, v_reps_boxed_31_, v_verify_boxed_32_);
return v_res_33_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object* v_arena_37_, lean_object* v_reps_38_, lean_object* v_a_00___x40___internal___hyg_39_){
_start:
{
uint64_t v_reps_boxed_40_; lean_object* v_res_41_; 
v_reps_boxed_40_ = lean_unbox_uint64(v_reps_38_);
lean_dec_ref(v_reps_38_);
v_res_41_ = bench_verify_lean(v_arena_37_, v_reps_boxed_40_);
lean_dec(v_arena_37_);
return v_res_41_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce(){
_start:
{
uint64_t v___x_43_; lean_object* v___x_44_; 
v___x_43_ = 9223372036854775807ULL;
v___x_44_ = vastitas_storage_new(v___x_43_);
if (lean_obj_tag(v___x_44_) == 0)
{
lean_object* v_a_45_; lean_object* v_a_47_; lean_object* v___y_58_; uint32_t v___x_70_; uint8_t v___x_71_; uint64_t v___x_72_; lean_object* v___x_73_; 
v_a_45_ = lean_ctor_get(v___x_44_, 0);
lean_inc(v_a_45_);
lean_dec_ref_known(v___x_44_, 1);
v___x_70_ = 0;
v___x_71_ = 1;
v___x_72_ = 595ULL;
v___x_73_ = vastitas_storage_allocate(v_a_45_, v___x_70_, v___x_71_, v___x_72_);
if (lean_obj_tag(v___x_73_) == 0)
{
uint64_t v___x_74_; uint64_t v___x_75_; uint8_t v___x_76_; uint64_t v___x_77_; uint64_t v___x_78_; lean_object* v___x_79_; 
lean_dec_ref_known(v___x_73_, 1);
v___x_74_ = 0ULL;
v___x_75_ = 1ULL;
v___x_76_ = 0;
v___x_77_ = 13842939354630062080ULL;
v___x_78_ = 4613937818241073152ULL;
v___x_79_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_74_, v___x_72_, v___x_75_, v___x_72_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_79_) == 0)
{
uint64_t v___x_80_; uint64_t v___x_81_; uint64_t v___x_82_; uint64_t v___x_83_; lean_object* v___x_84_; 
lean_dec_ref_known(v___x_79_, 1);
v___x_80_ = 7ULL;
v___x_81_ = 85ULL;
v___x_82_ = 4593671619917905920ULL;
v___x_83_ = 4598175219545276416ULL;
v___x_84_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_74_, v___x_80_, v___x_81_, v___x_80_, v___x_76_, v___x_71_, v___x_82_, v___x_83_);
if (lean_obj_tag(v___x_84_) == 0)
{
uint64_t v___x_85_; uint64_t v___x_86_; lean_object* v___x_87_; 
lean_dec_ref_known(v___x_84_, 1);
v___x_85_ = 4607182418800017408ULL;
v___x_86_ = 13826050856027422720ULL;
v___x_87_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_74_, v___x_80_, v___x_81_, v___x_80_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_85_, v___x_86_);
if (lean_obj_tag(v___x_87_) == 0)
{
uint64_t v___x_88_; uint64_t v___x_89_; lean_object* v___x_90_; 
lean_dec_ref_known(v___x_87_, 1);
v___x_88_ = 6ULL;
v___x_89_ = 4604930618986332160ULL;
v___x_90_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_74_, v___x_80_, v___x_81_, v___x_80_, v___x_76_, v___x_88_, v___x_75_, v___x_71_, v___x_86_, v___x_89_);
if (lean_obj_tag(v___x_90_) == 0)
{
uint32_t v___x_91_; uint64_t v___x_92_; lean_object* v___x_93_; 
lean_dec_ref_known(v___x_90_, 1);
v___x_91_ = 1;
v___x_92_ = 187ULL;
v___x_93_ = vastitas_storage_allocate(v_a_45_, v___x_91_, v___x_71_, v___x_92_);
if (lean_obj_tag(v___x_93_) == 0)
{
lean_object* v___x_94_; 
lean_dec_ref_known(v___x_93_, 1);
v___x_94_ = vastitas_storage_fill(v_a_45_, v___x_91_, v___x_74_, v___x_92_, v___x_75_, v___x_92_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_94_) == 0)
{
uint64_t v___x_95_; uint64_t v___x_96_; uint64_t v___x_97_; lean_object* v___x_98_; 
lean_dec_ref_known(v___x_94_, 1);
v___x_95_ = 17ULL;
v___x_96_ = 11ULL;
v___x_97_ = 13821547256400052224ULL;
v___x_98_ = vastitas_storage_fill(v_a_45_, v___x_91_, v___x_74_, v___x_95_, v___x_96_, v___x_95_, v___x_76_, v___x_71_, v___x_97_, v___x_82_);
if (lean_obj_tag(v___x_98_) == 0)
{
uint64_t v___x_99_; uint64_t v___x_100_; lean_object* v___x_101_; 
lean_dec_ref_known(v___x_98_, 1);
v___x_99_ = 10ULL;
v___x_100_ = 4602678819172646912ULL;
v___x_101_ = vastitas_storage_store(v_a_45_, v___x_91_, v___x_74_, v___x_95_, v___x_96_, v___x_95_, v___x_76_, v___x_74_, v___x_99_, v___x_71_, v___x_100_, v___x_83_);
if (lean_obj_tag(v___x_101_) == 0)
{
uint64_t v___x_102_; uint64_t v___x_103_; lean_object* v___x_104_; 
lean_dec_ref_known(v___x_101_, 1);
v___x_102_ = 16ULL;
v___x_103_ = 13828302655841107968ULL;
v___x_104_ = vastitas_storage_store(v_a_45_, v___x_91_, v___x_74_, v___x_95_, v___x_96_, v___x_95_, v___x_76_, v___x_102_, v___x_74_, v___x_71_, v___x_103_, v___x_86_);
if (lean_obj_tag(v___x_104_) == 0)
{
uint32_t v___x_105_; uint64_t v___x_106_; lean_object* v___x_107_; 
lean_dec_ref_known(v___x_104_, 1);
v___x_105_ = 2;
v___x_106_ = 65ULL;
v___x_107_ = vastitas_storage_allocate(v_a_45_, v___x_105_, v___x_71_, v___x_106_);
if (lean_obj_tag(v___x_107_) == 0)
{
lean_object* v___x_108_; 
lean_dec_ref_known(v___x_107_, 1);
v___x_108_ = vastitas_storage_fill(v_a_45_, v___x_105_, v___x_74_, v___x_106_, v___x_75_, v___x_106_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_108_) == 0)
{
uint64_t v___x_109_; uint64_t v___x_110_; lean_object* v___x_111_; 
lean_dec_ref_known(v___x_108_, 1);
v___x_109_ = 5ULL;
v___x_110_ = 13ULL;
v___x_111_ = vastitas_storage_fill(v_a_45_, v___x_105_, v___x_74_, v___x_109_, v___x_110_, v___x_109_, v___x_76_, v___x_71_, v___x_100_, v___x_97_);
if (lean_obj_tag(v___x_111_) == 0)
{
uint64_t v___x_112_; lean_object* v___x_113_; 
lean_dec_ref_known(v___x_111_, 1);
v___x_112_ = 4ULL;
v___x_113_ = vastitas_storage_store(v_a_45_, v___x_105_, v___x_74_, v___x_109_, v___x_110_, v___x_109_, v___x_76_, v___x_112_, v___x_74_, v___x_71_, v___x_97_, v___x_100_);
if (lean_obj_tag(v___x_113_) == 0)
{
uint64_t v___x_114_; lean_object* v___x_115_; 
lean_dec_ref_known(v___x_113_, 1);
v___x_114_ = 12ULL;
v___x_115_ = vastitas_storage_store(v_a_45_, v___x_105_, v___x_74_, v___x_109_, v___x_110_, v___x_109_, v___x_76_, v___x_74_, v___x_114_, v___x_71_, v___x_89_, v___x_103_);
if (lean_obj_tag(v___x_115_) == 0)
{
uint32_t v___x_116_; lean_object* v___x_117_; 
lean_dec_ref_known(v___x_115_, 1);
v___x_116_ = 3;
v___x_117_ = vastitas_storage_allocate(v_a_45_, v___x_116_, v___x_71_, v___x_72_);
if (lean_obj_tag(v___x_117_) == 0)
{
lean_object* v___x_118_; 
lean_dec_ref_known(v___x_117_, 1);
v___x_118_ = vastitas_storage_fill(v_a_45_, v___x_116_, v___x_74_, v___x_72_, v___x_75_, v___x_72_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_118_) == 0)
{
uint32_t v___x_119_; uint64_t v___x_120_; lean_object* v___x_121_; 
lean_dec_ref_known(v___x_118_, 1);
v___x_119_ = 4;
v___x_120_ = 385ULL;
v___x_121_ = vastitas_storage_allocate(v_a_45_, v___x_119_, v___x_71_, v___x_120_);
if (lean_obj_tag(v___x_121_) == 0)
{
lean_object* v___x_122_; 
lean_dec_ref_known(v___x_121_, 1);
v___x_122_ = vastitas_storage_fill(v_a_45_, v___x_119_, v___x_74_, v___x_120_, v___x_75_, v___x_120_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_122_) == 0)
{
uint32_t v___x_123_; uint64_t v___x_124_; lean_object* v___x_125_; 
lean_dec_ref_known(v___x_122_, 1);
v___x_123_ = 5;
v___x_124_ = 1001ULL;
v___x_125_ = vastitas_storage_allocate(v_a_45_, v___x_123_, v___x_71_, v___x_124_);
if (lean_obj_tag(v___x_125_) == 0)
{
lean_object* v___x_126_; 
lean_dec_ref_known(v___x_125_, 1);
v___x_126_ = vastitas_storage_fill(v_a_45_, v___x_123_, v___x_74_, v___x_124_, v___x_75_, v___x_124_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_126_) == 0)
{
uint64_t v___x_127_; lean_object* v___x_128_; 
lean_dec_ref_known(v___x_126_, 1);
v___x_127_ = 35ULL;
v___x_128_ = vastitas_storage_pack3(v_a_45_, v___x_70_, v___x_74_, v___x_80_, v___x_81_, v___x_80_, v___x_76_, v___x_116_, v___x_74_, v___x_127_, v___x_95_, v___x_127_, v___x_76_, v___x_80_, v___x_95_, v___x_109_);
if (lean_obj_tag(v___x_128_) == 0)
{
uint8_t v___x_129_; lean_object* v___x_130_; 
lean_dec_ref_known(v___x_128_, 1);
v___x_129_ = 0;
v___x_130_ = vastitas_gemm_execute(v_a_45_, v___x_116_, v___x_74_, v___x_127_, v___x_95_, v___x_127_, v___x_76_, v___x_76_, v___x_91_, v___x_74_, v___x_95_, v___x_96_, v___x_95_, v___x_76_, v___x_76_, v___x_119_, v___x_74_, v___x_127_, v___x_96_, v___x_127_, v___x_76_, v___x_129_);
if (lean_obj_tag(v___x_130_) == 0)
{
uint64_t v___x_131_; uint64_t v___x_132_; uint64_t v___x_133_; lean_object* v___x_134_; 
lean_dec_ref_known(v___x_130_, 1);
v___x_131_ = 77ULL;
v___x_132_ = 48ULL;
v___x_133_ = 42ULL;
v___x_134_ = vastitas_storage_regroup3(v_a_45_, v___x_119_, v___x_74_, v___x_127_, v___x_96_, v___x_127_, v___x_76_, v___x_116_, v___x_74_, v___x_131_, v___x_109_, v___x_131_, v___x_76_, v___x_80_, v___x_109_, v___x_96_, v___x_132_, v___x_133_);
if (lean_obj_tag(v___x_134_) == 0)
{
lean_object* v___x_135_; 
lean_dec_ref_known(v___x_134_, 1);
v___x_135_ = vastitas_gemm_execute(v_a_45_, v___x_116_, v___x_74_, v___x_131_, v___x_109_, v___x_131_, v___x_76_, v___x_76_, v___x_105_, v___x_74_, v___x_109_, v___x_110_, v___x_109_, v___x_76_, v___x_76_, v___x_123_, v___x_74_, v___x_131_, v___x_110_, v___x_131_, v___x_76_, v___x_129_);
if (lean_obj_tag(v___x_135_) == 0)
{
uint64_t v___x_136_; uint64_t v___x_137_; lean_object* v___x_138_; 
lean_dec_ref_known(v___x_135_, 1);
v___x_136_ = 13835471471654207488ULL;
v___x_137_ = 13830941483747770368ULL;
v___x_138_ = vastitas_storage_expect(v_a_45_, v___x_123_, v___x_74_, v___x_131_, v___x_110_, v___x_131_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_136_, v___x_137_);
if (lean_obj_tag(v___x_138_) == 0)
{
uint64_t v___x_139_; uint64_t v___x_140_; lean_object* v___x_141_; 
lean_dec_ref_known(v___x_138_, 1);
v___x_139_ = 13840120206816444416ULL;
v___x_140_ = 13831803500863946752ULL;
v___x_141_ = vastitas_storage_expect(v_a_45_, v___x_123_, v___x_74_, v___x_131_, v___x_110_, v___x_131_, v___x_76_, v___x_88_, v___x_114_, v___x_71_, v___x_139_, v___x_140_);
if (lean_obj_tag(v___x_141_) == 0)
{
uint64_t v___x_142_; uint64_t v___x_143_; uint64_t v___x_144_; lean_object* v___x_145_; 
lean_dec_ref_known(v___x_141_, 1);
v___x_142_ = 76ULL;
v___x_143_ = 13835172404491452416ULL;
v___x_144_ = 13827528599655153664ULL;
v___x_145_ = vastitas_storage_expect(v_a_45_, v___x_123_, v___x_74_, v___x_131_, v___x_110_, v___x_131_, v___x_76_, v___x_142_, v___x_74_, v___x_71_, v___x_143_, v___x_144_);
if (lean_obj_tag(v___x_145_) == 0)
{
lean_object* v___x_146_; 
lean_dec_ref_known(v___x_145_, 1);
v___x_146_ = vastitas_storage_drop(v_a_45_, v___x_123_);
if (lean_obj_tag(v___x_146_) == 0)
{
lean_object* v___x_147_; 
lean_dec_ref_known(v___x_146_, 1);
v___x_147_ = vastitas_storage_drop(v_a_45_, v___x_119_);
if (lean_obj_tag(v___x_147_) == 0)
{
lean_object* v___x_148_; 
lean_dec_ref_known(v___x_147_, 1);
v___x_148_ = vastitas_storage_drop(v_a_45_, v___x_116_);
if (lean_obj_tag(v___x_148_) == 0)
{
lean_object* v___x_149_; 
lean_dec_ref_known(v___x_148_, 1);
v___x_149_ = vastitas_storage_drop(v_a_45_, v___x_105_);
if (lean_obj_tag(v___x_149_) == 0)
{
lean_object* v___x_150_; 
lean_dec_ref_known(v___x_149_, 1);
v___x_150_ = vastitas_storage_drop(v_a_45_, v___x_91_);
if (lean_obj_tag(v___x_150_) == 0)
{
lean_object* v___x_151_; 
lean_dec_ref_known(v___x_150_, 1);
v___x_151_ = vastitas_storage_drop(v_a_45_, v___x_70_);
if (lean_obj_tag(v___x_151_) == 0)
{
lean_object* v___x_152_; 
lean_dec_ref_known(v___x_151_, 1);
v___x_152_ = lean_box(0);
v_a_47_ = v___x_152_;
goto v___jp_46_;
}
else
{
v___y_58_ = v___x_151_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_150_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_149_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_148_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_147_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_146_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_145_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_141_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_138_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_135_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_134_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_130_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_128_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_126_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_125_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_122_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_121_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_118_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_117_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_115_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_113_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_111_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_108_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_107_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_104_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_101_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_98_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_94_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_93_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_90_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_87_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_84_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_79_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_73_;
goto v___jp_57_;
}
v___jp_46_:
{
lean_object* v___x_48_; 
v___x_48_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_48_) == 0)
{
lean_object* v___x_50_; uint8_t v_isShared_51_; uint8_t v_isSharedCheck_55_; 
v_isSharedCheck_55_ = !lean_is_exclusive(v___x_48_);
if (v_isSharedCheck_55_ == 0)
{
lean_object* v_unused_56_; 
v_unused_56_ = lean_ctor_get(v___x_48_, 0);
lean_dec(v_unused_56_);
v___x_50_ = v___x_48_;
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
else
{
lean_dec(v___x_48_);
v___x_50_ = lean_box(0);
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
v_resetjp_49_:
{
lean_object* v___x_53_; 
if (v_isShared_51_ == 0)
{
lean_ctor_set(v___x_50_, 0, v_a_47_);
v___x_53_ = v___x_50_;
goto v_reusejp_52_;
}
else
{
lean_object* v_reuseFailAlloc_54_; 
v_reuseFailAlloc_54_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_54_, 0, v_a_47_);
v___x_53_ = v_reuseFailAlloc_54_;
goto v_reusejp_52_;
}
v_reusejp_52_:
{
return v___x_53_;
}
}
}
else
{
return v___x_48_;
}
}
v___jp_57_:
{
if (lean_obj_tag(v___y_58_) == 0)
{
lean_object* v_a_59_; 
v_a_59_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_59_);
lean_dec_ref_known(v___y_58_, 1);
v_a_47_ = v_a_59_;
goto v___jp_46_;
}
else
{
lean_object* v_a_60_; lean_object* v___x_61_; 
v_a_60_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_60_);
lean_dec_ref_known(v___y_58_, 1);
v___x_61_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_61_) == 0)
{
lean_object* v___x_63_; uint8_t v_isShared_64_; uint8_t v_isSharedCheck_68_; 
v_isSharedCheck_68_ = !lean_is_exclusive(v___x_61_);
if (v_isSharedCheck_68_ == 0)
{
lean_object* v_unused_69_; 
v_unused_69_ = lean_ctor_get(v___x_61_, 0);
lean_dec(v_unused_69_);
v___x_63_ = v___x_61_;
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
else
{
lean_dec(v___x_61_);
v___x_63_ = lean_box(0);
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
v_resetjp_62_:
{
lean_object* v___x_66_; 
if (v_isShared_64_ == 0)
{
lean_ctor_set_tag(v___x_63_, 1);
lean_ctor_set(v___x_63_, 0, v_a_60_);
v___x_66_ = v___x_63_;
goto v_reusejp_65_;
}
else
{
lean_object* v_reuseFailAlloc_67_; 
v_reuseFailAlloc_67_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_67_, 0, v_a_60_);
v___x_66_ = v_reuseFailAlloc_67_;
goto v_reusejp_65_;
}
v_reusejp_65_:
{
return v___x_66_;
}
}
}
else
{
lean_dec(v_a_60_);
return v___x_61_;
}
}
}
}
else
{
lean_object* v_a_153_; lean_object* v___x_155_; uint8_t v_isShared_156_; uint8_t v_isSharedCheck_160_; 
v_a_153_ = lean_ctor_get(v___x_44_, 0);
v_isSharedCheck_160_ = !lean_is_exclusive(v___x_44_);
if (v_isSharedCheck_160_ == 0)
{
v___x_155_ = v___x_44_;
v_isShared_156_ = v_isSharedCheck_160_;
goto v_resetjp_154_;
}
else
{
lean_inc(v_a_153_);
lean_dec(v___x_44_);
v___x_155_ = lean_box(0);
v_isShared_156_ = v_isSharedCheck_160_;
goto v_resetjp_154_;
}
v_resetjp_154_:
{
lean_object* v___x_158_; 
if (v_isShared_156_ == 0)
{
v___x_158_ = v___x_155_;
goto v_reusejp_157_;
}
else
{
lean_object* v_reuseFailAlloc_159_; 
v_reuseFailAlloc_159_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_159_, 0, v_a_153_);
v___x_158_ = v_reuseFailAlloc_159_;
goto v_reusejp_157_;
}
v_reusejp_157_:
{
return v___x_158_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object* v_a_161_){
_start:
{
lean_object* v_res_162_; 
v_res_162_ = lp_allocation__audit_generatedOnce();
return v_res_162_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure(){
_start:
{
uint64_t v___x_164_; lean_object* v___x_165_; 
v___x_164_ = 9223372036854775807ULL;
v___x_165_ = vastitas_storage_new(v___x_164_);
if (lean_obj_tag(v___x_165_) == 0)
{
lean_object* v_a_166_; lean_object* v_a_168_; lean_object* v___y_179_; uint32_t v___x_191_; uint8_t v___x_192_; uint64_t v___x_193_; lean_object* v___x_194_; 
v_a_166_ = lean_ctor_get(v___x_165_, 0);
lean_inc(v_a_166_);
lean_dec_ref_known(v___x_165_, 1);
v___x_191_ = 0;
v___x_192_ = 1;
v___x_193_ = 595ULL;
v___x_194_ = vastitas_storage_allocate(v_a_166_, v___x_191_, v___x_192_, v___x_193_);
if (lean_obj_tag(v___x_194_) == 0)
{
uint64_t v___x_195_; uint64_t v___x_196_; uint8_t v___x_197_; uint64_t v___x_198_; uint64_t v___x_199_; lean_object* v___x_200_; 
lean_dec_ref_known(v___x_194_, 1);
v___x_195_ = 0ULL;
v___x_196_ = 1ULL;
v___x_197_ = 0;
v___x_198_ = 13842939354630062080ULL;
v___x_199_ = 4613937818241073152ULL;
v___x_200_ = vastitas_storage_fill(v_a_166_, v___x_191_, v___x_195_, v___x_193_, v___x_196_, v___x_193_, v___x_197_, v___x_192_, v___x_198_, v___x_199_);
if (lean_obj_tag(v___x_200_) == 0)
{
uint64_t v___x_201_; uint64_t v___x_202_; uint64_t v___x_203_; uint64_t v___x_204_; lean_object* v___x_205_; 
lean_dec_ref_known(v___x_200_, 1);
v___x_201_ = 7ULL;
v___x_202_ = 85ULL;
v___x_203_ = 4593671619917905920ULL;
v___x_204_ = 4598175219545276416ULL;
v___x_205_ = vastitas_storage_fill(v_a_166_, v___x_191_, v___x_195_, v___x_201_, v___x_202_, v___x_201_, v___x_197_, v___x_192_, v___x_203_, v___x_204_);
if (lean_obj_tag(v___x_205_) == 0)
{
uint64_t v___x_206_; uint64_t v___x_207_; lean_object* v___x_208_; 
lean_dec_ref_known(v___x_205_, 1);
v___x_206_ = 4607182418800017408ULL;
v___x_207_ = 13826050856027422720ULL;
v___x_208_ = vastitas_storage_store(v_a_166_, v___x_191_, v___x_195_, v___x_201_, v___x_202_, v___x_201_, v___x_197_, v___x_195_, v___x_195_, v___x_192_, v___x_206_, v___x_207_);
if (lean_obj_tag(v___x_208_) == 0)
{
uint64_t v___x_209_; uint64_t v___x_210_; lean_object* v___x_211_; 
lean_dec_ref_known(v___x_208_, 1);
v___x_209_ = 6ULL;
v___x_210_ = 4604930618986332160ULL;
v___x_211_ = vastitas_storage_store(v_a_166_, v___x_191_, v___x_195_, v___x_201_, v___x_202_, v___x_201_, v___x_197_, v___x_209_, v___x_196_, v___x_192_, v___x_207_, v___x_210_);
if (lean_obj_tag(v___x_211_) == 0)
{
uint32_t v___x_212_; uint64_t v___x_213_; lean_object* v___x_214_; 
lean_dec_ref_known(v___x_211_, 1);
v___x_212_ = 1;
v___x_213_ = 187ULL;
v___x_214_ = vastitas_storage_allocate(v_a_166_, v___x_212_, v___x_192_, v___x_213_);
if (lean_obj_tag(v___x_214_) == 0)
{
lean_object* v___x_215_; 
lean_dec_ref_known(v___x_214_, 1);
v___x_215_ = vastitas_storage_fill(v_a_166_, v___x_212_, v___x_195_, v___x_213_, v___x_196_, v___x_213_, v___x_197_, v___x_192_, v___x_198_, v___x_199_);
if (lean_obj_tag(v___x_215_) == 0)
{
uint64_t v___x_216_; uint64_t v___x_217_; uint64_t v___x_218_; lean_object* v___x_219_; 
lean_dec_ref_known(v___x_215_, 1);
v___x_216_ = 17ULL;
v___x_217_ = 11ULL;
v___x_218_ = 13821547256400052224ULL;
v___x_219_ = vastitas_storage_fill(v_a_166_, v___x_212_, v___x_195_, v___x_216_, v___x_217_, v___x_216_, v___x_197_, v___x_192_, v___x_218_, v___x_203_);
if (lean_obj_tag(v___x_219_) == 0)
{
uint64_t v___x_220_; uint64_t v___x_221_; lean_object* v___x_222_; 
lean_dec_ref_known(v___x_219_, 1);
v___x_220_ = 10ULL;
v___x_221_ = 4602678819172646912ULL;
v___x_222_ = vastitas_storage_store(v_a_166_, v___x_212_, v___x_195_, v___x_216_, v___x_217_, v___x_216_, v___x_197_, v___x_195_, v___x_220_, v___x_192_, v___x_221_, v___x_204_);
if (lean_obj_tag(v___x_222_) == 0)
{
uint64_t v___x_223_; uint64_t v___x_224_; lean_object* v___x_225_; 
lean_dec_ref_known(v___x_222_, 1);
v___x_223_ = 16ULL;
v___x_224_ = 13828302655841107968ULL;
v___x_225_ = vastitas_storage_store(v_a_166_, v___x_212_, v___x_195_, v___x_216_, v___x_217_, v___x_216_, v___x_197_, v___x_223_, v___x_195_, v___x_192_, v___x_224_, v___x_207_);
if (lean_obj_tag(v___x_225_) == 0)
{
uint32_t v___x_226_; uint64_t v___x_227_; lean_object* v___x_228_; 
lean_dec_ref_known(v___x_225_, 1);
v___x_226_ = 2;
v___x_227_ = 65ULL;
v___x_228_ = vastitas_storage_allocate(v_a_166_, v___x_226_, v___x_192_, v___x_227_);
if (lean_obj_tag(v___x_228_) == 0)
{
lean_object* v___x_229_; 
lean_dec_ref_known(v___x_228_, 1);
v___x_229_ = vastitas_storage_fill(v_a_166_, v___x_226_, v___x_195_, v___x_227_, v___x_196_, v___x_227_, v___x_197_, v___x_192_, v___x_198_, v___x_199_);
if (lean_obj_tag(v___x_229_) == 0)
{
uint64_t v___x_230_; uint64_t v___x_231_; lean_object* v___x_232_; 
lean_dec_ref_known(v___x_229_, 1);
v___x_230_ = 5ULL;
v___x_231_ = 13ULL;
v___x_232_ = vastitas_storage_fill(v_a_166_, v___x_226_, v___x_195_, v___x_230_, v___x_231_, v___x_230_, v___x_197_, v___x_192_, v___x_221_, v___x_218_);
if (lean_obj_tag(v___x_232_) == 0)
{
uint64_t v___x_233_; lean_object* v___x_234_; 
lean_dec_ref_known(v___x_232_, 1);
v___x_233_ = 4ULL;
v___x_234_ = vastitas_storage_store(v_a_166_, v___x_226_, v___x_195_, v___x_230_, v___x_231_, v___x_230_, v___x_197_, v___x_233_, v___x_195_, v___x_192_, v___x_218_, v___x_221_);
if (lean_obj_tag(v___x_234_) == 0)
{
uint64_t v___x_235_; lean_object* v___x_236_; 
lean_dec_ref_known(v___x_234_, 1);
v___x_235_ = 12ULL;
v___x_236_ = vastitas_storage_store(v_a_166_, v___x_226_, v___x_195_, v___x_230_, v___x_231_, v___x_230_, v___x_197_, v___x_195_, v___x_235_, v___x_192_, v___x_210_, v___x_224_);
if (lean_obj_tag(v___x_236_) == 0)
{
uint32_t v___x_237_; lean_object* v___x_238_; 
lean_dec_ref_known(v___x_236_, 1);
v___x_237_ = 3;
v___x_238_ = vastitas_storage_allocate(v_a_166_, v___x_237_, v___x_192_, v___x_193_);
if (lean_obj_tag(v___x_238_) == 0)
{
lean_object* v___x_239_; 
lean_dec_ref_known(v___x_238_, 1);
v___x_239_ = vastitas_storage_fill(v_a_166_, v___x_237_, v___x_195_, v___x_193_, v___x_196_, v___x_193_, v___x_197_, v___x_192_, v___x_198_, v___x_199_);
if (lean_obj_tag(v___x_239_) == 0)
{
uint32_t v___x_240_; uint64_t v___x_241_; lean_object* v___x_242_; 
lean_dec_ref_known(v___x_239_, 1);
v___x_240_ = 4;
v___x_241_ = 385ULL;
v___x_242_ = vastitas_storage_allocate(v_a_166_, v___x_240_, v___x_192_, v___x_241_);
if (lean_obj_tag(v___x_242_) == 0)
{
lean_object* v___x_243_; 
lean_dec_ref_known(v___x_242_, 1);
v___x_243_ = vastitas_storage_fill(v_a_166_, v___x_240_, v___x_195_, v___x_241_, v___x_196_, v___x_241_, v___x_197_, v___x_192_, v___x_198_, v___x_199_);
if (lean_obj_tag(v___x_243_) == 0)
{
uint32_t v___x_244_; uint64_t v___x_245_; lean_object* v___x_246_; 
lean_dec_ref_known(v___x_243_, 1);
v___x_244_ = 5;
v___x_245_ = 1001ULL;
v___x_246_ = vastitas_storage_allocate(v_a_166_, v___x_244_, v___x_192_, v___x_245_);
if (lean_obj_tag(v___x_246_) == 0)
{
lean_object* v___x_247_; 
lean_dec_ref_known(v___x_246_, 1);
v___x_247_ = vastitas_storage_fill(v_a_166_, v___x_244_, v___x_195_, v___x_245_, v___x_196_, v___x_245_, v___x_197_, v___x_192_, v___x_198_, v___x_199_);
if (lean_obj_tag(v___x_247_) == 0)
{
uint64_t v___x_248_; lean_object* v___x_249_; 
lean_dec_ref_known(v___x_247_, 1);
v___x_248_ = 35ULL;
v___x_249_ = vastitas_storage_pack3(v_a_166_, v___x_191_, v___x_195_, v___x_201_, v___x_202_, v___x_201_, v___x_197_, v___x_237_, v___x_195_, v___x_248_, v___x_216_, v___x_248_, v___x_197_, v___x_201_, v___x_216_, v___x_230_);
if (lean_obj_tag(v___x_249_) == 0)
{
uint8_t v___x_250_; lean_object* v___x_251_; 
lean_dec_ref_known(v___x_249_, 1);
v___x_250_ = 0;
v___x_251_ = vastitas_gemm_execute(v_a_166_, v___x_237_, v___x_195_, v___x_248_, v___x_216_, v___x_248_, v___x_197_, v___x_197_, v___x_212_, v___x_195_, v___x_216_, v___x_217_, v___x_216_, v___x_197_, v___x_197_, v___x_240_, v___x_195_, v___x_248_, v___x_217_, v___x_248_, v___x_197_, v___x_250_);
if (lean_obj_tag(v___x_251_) == 0)
{
uint64_t v___x_252_; uint64_t v___x_253_; uint64_t v___x_254_; lean_object* v___x_255_; 
lean_dec_ref_known(v___x_251_, 1);
v___x_252_ = 77ULL;
v___x_253_ = 48ULL;
v___x_254_ = 42ULL;
v___x_255_ = vastitas_storage_regroup3(v_a_166_, v___x_240_, v___x_195_, v___x_248_, v___x_217_, v___x_248_, v___x_197_, v___x_237_, v___x_195_, v___x_252_, v___x_230_, v___x_252_, v___x_197_, v___x_201_, v___x_230_, v___x_217_, v___x_253_, v___x_254_);
if (lean_obj_tag(v___x_255_) == 0)
{
lean_object* v___x_256_; 
lean_dec_ref_known(v___x_255_, 1);
v___x_256_ = vastitas_gemm_execute(v_a_166_, v___x_237_, v___x_195_, v___x_252_, v___x_230_, v___x_252_, v___x_197_, v___x_197_, v___x_226_, v___x_195_, v___x_230_, v___x_231_, v___x_230_, v___x_197_, v___x_197_, v___x_244_, v___x_195_, v___x_252_, v___x_231_, v___x_252_, v___x_197_, v___x_250_);
if (lean_obj_tag(v___x_256_) == 0)
{
uint64_t v___x_257_; uint64_t v___x_258_; lean_object* v___x_259_; 
lean_dec_ref_known(v___x_256_, 1);
v___x_257_ = 13835471471654207489ULL;
v___x_258_ = 13830941483747770368ULL;
v___x_259_ = vastitas_storage_expect(v_a_166_, v___x_244_, v___x_195_, v___x_252_, v___x_231_, v___x_252_, v___x_197_, v___x_195_, v___x_195_, v___x_192_, v___x_257_, v___x_258_);
if (lean_obj_tag(v___x_259_) == 0)
{
uint64_t v___x_260_; uint64_t v___x_261_; lean_object* v___x_262_; 
lean_dec_ref_known(v___x_259_, 1);
v___x_260_ = 13840120206816444416ULL;
v___x_261_ = 13831803500863946752ULL;
v___x_262_ = vastitas_storage_expect(v_a_166_, v___x_244_, v___x_195_, v___x_252_, v___x_231_, v___x_252_, v___x_197_, v___x_209_, v___x_235_, v___x_192_, v___x_260_, v___x_261_);
if (lean_obj_tag(v___x_262_) == 0)
{
uint64_t v___x_263_; uint64_t v___x_264_; uint64_t v___x_265_; lean_object* v___x_266_; 
lean_dec_ref_known(v___x_262_, 1);
v___x_263_ = 76ULL;
v___x_264_ = 13835172404491452416ULL;
v___x_265_ = 13827528599655153664ULL;
v___x_266_ = vastitas_storage_expect(v_a_166_, v___x_244_, v___x_195_, v___x_252_, v___x_231_, v___x_252_, v___x_197_, v___x_263_, v___x_195_, v___x_192_, v___x_264_, v___x_265_);
if (lean_obj_tag(v___x_266_) == 0)
{
lean_object* v___x_267_; 
lean_dec_ref_known(v___x_266_, 1);
v___x_267_ = vastitas_storage_drop(v_a_166_, v___x_244_);
if (lean_obj_tag(v___x_267_) == 0)
{
lean_object* v___x_268_; 
lean_dec_ref_known(v___x_267_, 1);
v___x_268_ = vastitas_storage_drop(v_a_166_, v___x_240_);
if (lean_obj_tag(v___x_268_) == 0)
{
lean_object* v___x_269_; 
lean_dec_ref_known(v___x_268_, 1);
v___x_269_ = vastitas_storage_drop(v_a_166_, v___x_237_);
if (lean_obj_tag(v___x_269_) == 0)
{
lean_object* v___x_270_; 
lean_dec_ref_known(v___x_269_, 1);
v___x_270_ = vastitas_storage_drop(v_a_166_, v___x_226_);
if (lean_obj_tag(v___x_270_) == 0)
{
lean_object* v___x_271_; 
lean_dec_ref_known(v___x_270_, 1);
v___x_271_ = vastitas_storage_drop(v_a_166_, v___x_212_);
if (lean_obj_tag(v___x_271_) == 0)
{
lean_object* v___x_272_; 
lean_dec_ref_known(v___x_271_, 1);
v___x_272_ = vastitas_storage_drop(v_a_166_, v___x_191_);
if (lean_obj_tag(v___x_272_) == 0)
{
lean_object* v___x_273_; 
lean_dec_ref_known(v___x_272_, 1);
v___x_273_ = lean_box(0);
v_a_168_ = v___x_273_;
goto v___jp_167_;
}
else
{
v___y_179_ = v___x_272_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_271_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_270_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_269_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_268_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_267_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_266_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_262_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_259_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_256_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_255_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_251_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_249_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_247_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_246_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_243_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_242_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_239_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_238_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_236_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_234_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_232_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_229_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_228_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_225_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_222_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_219_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_215_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_214_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_211_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_208_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_205_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_200_;
goto v___jp_178_;
}
}
else
{
v___y_179_ = v___x_194_;
goto v___jp_178_;
}
v___jp_167_:
{
lean_object* v___x_169_; 
v___x_169_ = vastitas_storage_close(v_a_166_);
lean_dec(v_a_166_);
if (lean_obj_tag(v___x_169_) == 0)
{
lean_object* v___x_171_; uint8_t v_isShared_172_; uint8_t v_isSharedCheck_176_; 
v_isSharedCheck_176_ = !lean_is_exclusive(v___x_169_);
if (v_isSharedCheck_176_ == 0)
{
lean_object* v_unused_177_; 
v_unused_177_ = lean_ctor_get(v___x_169_, 0);
lean_dec(v_unused_177_);
v___x_171_ = v___x_169_;
v_isShared_172_ = v_isSharedCheck_176_;
goto v_resetjp_170_;
}
else
{
lean_dec(v___x_169_);
v___x_171_ = lean_box(0);
v_isShared_172_ = v_isSharedCheck_176_;
goto v_resetjp_170_;
}
v_resetjp_170_:
{
lean_object* v___x_174_; 
if (v_isShared_172_ == 0)
{
lean_ctor_set(v___x_171_, 0, v_a_168_);
v___x_174_ = v___x_171_;
goto v_reusejp_173_;
}
else
{
lean_object* v_reuseFailAlloc_175_; 
v_reuseFailAlloc_175_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_175_, 0, v_a_168_);
v___x_174_ = v_reuseFailAlloc_175_;
goto v_reusejp_173_;
}
v_reusejp_173_:
{
return v___x_174_;
}
}
}
else
{
return v___x_169_;
}
}
v___jp_178_:
{
if (lean_obj_tag(v___y_179_) == 0)
{
lean_object* v_a_180_; 
v_a_180_ = lean_ctor_get(v___y_179_, 0);
lean_inc(v_a_180_);
lean_dec_ref_known(v___y_179_, 1);
v_a_168_ = v_a_180_;
goto v___jp_167_;
}
else
{
lean_object* v_a_181_; lean_object* v___x_182_; 
v_a_181_ = lean_ctor_get(v___y_179_, 0);
lean_inc(v_a_181_);
lean_dec_ref_known(v___y_179_, 1);
v___x_182_ = vastitas_storage_close(v_a_166_);
lean_dec(v_a_166_);
if (lean_obj_tag(v___x_182_) == 0)
{
lean_object* v___x_184_; uint8_t v_isShared_185_; uint8_t v_isSharedCheck_189_; 
v_isSharedCheck_189_ = !lean_is_exclusive(v___x_182_);
if (v_isSharedCheck_189_ == 0)
{
lean_object* v_unused_190_; 
v_unused_190_ = lean_ctor_get(v___x_182_, 0);
lean_dec(v_unused_190_);
v___x_184_ = v___x_182_;
v_isShared_185_ = v_isSharedCheck_189_;
goto v_resetjp_183_;
}
else
{
lean_dec(v___x_182_);
v___x_184_ = lean_box(0);
v_isShared_185_ = v_isSharedCheck_189_;
goto v_resetjp_183_;
}
v_resetjp_183_:
{
lean_object* v___x_187_; 
if (v_isShared_185_ == 0)
{
lean_ctor_set_tag(v___x_184_, 1);
lean_ctor_set(v___x_184_, 0, v_a_181_);
v___x_187_ = v___x_184_;
goto v_reusejp_186_;
}
else
{
lean_object* v_reuseFailAlloc_188_; 
v_reuseFailAlloc_188_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_188_, 0, v_a_181_);
v___x_187_ = v_reuseFailAlloc_188_;
goto v_reusejp_186_;
}
v_reusejp_186_:
{
return v___x_187_;
}
}
}
else
{
lean_dec(v_a_181_);
return v___x_182_;
}
}
}
}
else
{
lean_object* v_a_274_; lean_object* v___x_276_; uint8_t v_isShared_277_; uint8_t v_isSharedCheck_281_; 
v_a_274_ = lean_ctor_get(v___x_165_, 0);
v_isSharedCheck_281_ = !lean_is_exclusive(v___x_165_);
if (v_isSharedCheck_281_ == 0)
{
v___x_276_ = v___x_165_;
v_isShared_277_ = v_isSharedCheck_281_;
goto v_resetjp_275_;
}
else
{
lean_inc(v_a_274_);
lean_dec(v___x_165_);
v___x_276_ = lean_box(0);
v_isShared_277_ = v_isSharedCheck_281_;
goto v_resetjp_275_;
}
v_resetjp_275_:
{
lean_object* v___x_279_; 
if (v_isShared_277_ == 0)
{
v___x_279_ = v___x_276_;
goto v_reusejp_278_;
}
else
{
lean_object* v_reuseFailAlloc_280_; 
v_reuseFailAlloc_280_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_280_, 0, v_a_274_);
v___x_279_ = v_reuseFailAlloc_280_;
goto v_reusejp_278_;
}
v_reusejp_278_:
{
return v___x_279_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object* v_a_282_){
_start:
{
lean_object* v_res_283_; 
v_res_283_ = lp_allocation__audit_generatedFailure();
return v_res_283_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object* v_phase_286_, lean_object* v_a_00___x40___internal___hyg_287_){
_start:
{
uint32_t v_phase_boxed_288_; lean_object* v_res_289_; 
v_phase_boxed_288_ = lean_unbox_uint32(v_phase_286_);
lean_dec(v_phase_286_);
v_res_289_ = audit_mark_lean(v_phase_boxed_288_);
return v_res_289_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object* v_a_290_, lean_object* v_scope_291_, lean_object* v_range_292_, lean_object* v_b_293_, lean_object* v_i_294_){
_start:
{
lean_object* v_stop_296_; lean_object* v_step_297_; uint8_t v___x_298_; 
v_stop_296_ = lean_ctor_get(v_range_292_, 1);
v_step_297_ = lean_ctor_get(v_range_292_, 2);
v___x_298_ = lean_nat_dec_lt(v_i_294_, v_stop_296_);
if (v___x_298_ == 0)
{
lean_object* v___x_299_; 
lean_dec(v_i_294_);
v___x_299_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_299_, 0, v_b_293_);
return v___x_299_;
}
else
{
uint32_t v___x_300_; uint64_t v___x_301_; uint64_t v___x_302_; uint64_t v___x_303_; lean_object* v___x_304_; uint8_t v___x_305_; uint32_t v___x_306_; uint64_t v___x_307_; uint64_t v___x_308_; uint32_t v___x_309_; uint64_t v___x_310_; uint32_t v___x_311_; uint32_t v___x_312_; uint64_t v___x_313_; uint32_t v___x_314_; lean_object* v___x_315_; uint64_t v___x_316_; lean_object* v___x_317_; 
v___x_300_ = 0;
v___x_301_ = 0ULL;
v___x_302_ = 7ULL;
v___x_303_ = 85ULL;
v___x_304_ = lean_unsigned_to_nat(0u);
v___x_305_ = lean_nat_dec_eq(v_scope_291_, v___x_304_);
v___x_306_ = 3;
v___x_307_ = 17ULL;
v___x_308_ = 5ULL;
v___x_309_ = 1;
v___x_310_ = 11ULL;
v___x_311_ = 4;
v___x_312_ = 2;
v___x_313_ = 13ULL;
v___x_314_ = 5;
v___x_315_ = lean_box(0);
v___x_316_ = 35ULL;
v___x_317_ = vastitas_storage_pack3(v_a_290_, v___x_300_, v___x_301_, v___x_302_, v___x_303_, v___x_302_, v___x_305_, v___x_306_, v___x_301_, v___x_316_, v___x_307_, v___x_316_, v___x_305_, v___x_302_, v___x_307_, v___x_308_);
if (lean_obj_tag(v___x_317_) == 0)
{
uint8_t v___x_318_; lean_object* v___x_319_; 
lean_dec_ref_known(v___x_317_, 1);
v___x_318_ = 0;
v___x_319_ = vastitas_gemm_execute(v_a_290_, v___x_306_, v___x_301_, v___x_316_, v___x_307_, v___x_316_, v___x_305_, v___x_305_, v___x_309_, v___x_301_, v___x_307_, v___x_310_, v___x_307_, v___x_305_, v___x_305_, v___x_311_, v___x_301_, v___x_316_, v___x_310_, v___x_316_, v___x_305_, v___x_318_);
if (lean_obj_tag(v___x_319_) == 0)
{
uint64_t v___x_320_; uint64_t v___x_321_; uint64_t v___x_322_; lean_object* v___x_323_; 
lean_dec_ref_known(v___x_319_, 1);
v___x_320_ = 77ULL;
v___x_321_ = 48ULL;
v___x_322_ = 42ULL;
v___x_323_ = vastitas_storage_regroup3(v_a_290_, v___x_311_, v___x_301_, v___x_316_, v___x_310_, v___x_316_, v___x_305_, v___x_306_, v___x_301_, v___x_320_, v___x_308_, v___x_320_, v___x_305_, v___x_302_, v___x_308_, v___x_310_, v___x_321_, v___x_322_);
if (lean_obj_tag(v___x_323_) == 0)
{
lean_object* v___x_324_; 
lean_dec_ref_known(v___x_323_, 1);
v___x_324_ = vastitas_gemm_execute(v_a_290_, v___x_306_, v___x_301_, v___x_320_, v___x_308_, v___x_320_, v___x_305_, v___x_305_, v___x_312_, v___x_301_, v___x_308_, v___x_313_, v___x_308_, v___x_305_, v___x_305_, v___x_314_, v___x_301_, v___x_320_, v___x_313_, v___x_320_, v___x_305_, v___x_318_);
if (lean_obj_tag(v___x_324_) == 0)
{
lean_object* v___x_325_; 
lean_dec_ref_known(v___x_324_, 1);
v___x_325_ = lean_nat_add(v_i_294_, v_step_297_);
lean_dec(v_i_294_);
v_b_293_ = v___x_315_;
v_i_294_ = v___x_325_;
goto _start;
}
else
{
lean_dec(v_i_294_);
return v___x_324_;
}
}
else
{
lean_dec(v_i_294_);
return v___x_323_;
}
}
else
{
lean_dec(v_i_294_);
return v___x_319_;
}
}
else
{
lean_dec(v_i_294_);
return v___x_317_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object* v_a_327_, lean_object* v_scope_328_, lean_object* v_range_329_, lean_object* v_b_330_, lean_object* v_i_331_, lean_object* v___y_332_){
_start:
{
lean_object* v_res_333_; 
v_res_333_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_327_, v_scope_328_, v_range_329_, v_b_330_, v_i_331_);
lean_dec_ref(v_range_329_);
lean_dec(v_scope_328_);
lean_dec(v_a_327_);
return v_res_333_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object* v_range_334_, lean_object* v_b_335_, lean_object* v_i_336_){
_start:
{
lean_object* v_stop_338_; lean_object* v_step_339_; uint8_t v___x_340_; 
v_stop_338_ = lean_ctor_get(v_range_334_, 1);
v_step_339_ = lean_ctor_get(v_range_334_, 2);
v___x_340_ = lean_nat_dec_lt(v_i_336_, v_stop_338_);
if (v___x_340_ == 0)
{
lean_object* v___x_341_; 
lean_dec(v_i_336_);
v___x_341_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_341_, 0, v_b_335_);
return v___x_341_;
}
else
{
lean_object* v___x_342_; lean_object* v___x_343_; 
v___x_342_ = lean_box(0);
v___x_343_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_343_) == 0)
{
lean_object* v___x_344_; 
lean_dec_ref_known(v___x_343_, 1);
v___x_344_ = lean_nat_add(v_i_336_, v_step_339_);
lean_dec(v_i_336_);
v_b_335_ = v___x_342_;
v_i_336_ = v___x_344_;
goto _start;
}
else
{
lean_dec(v_i_336_);
return v___x_343_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object* v_range_346_, lean_object* v_b_347_, lean_object* v_i_348_, lean_object* v___y_349_){
_start:
{
lean_object* v_res_350_; 
v_res_350_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_346_, v_b_347_, v_i_348_);
lean_dec_ref(v_range_346_);
return v_res_350_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_359_){
_start:
{
lean_object* v___x_361_; lean_object* v___x_362_; lean_object* v_impl_363_; lean_object* v___x_364_; lean_object* v___x_365_; lean_object* v___x_366_; lean_object* v___x_367_; lean_object* v_scope_368_; lean_object* v___x_369_; lean_object* v___x_370_; lean_object* v___x_371_; lean_object* v___x_372_; lean_object* v_reps_373_; lean_object* v___x_374_; lean_object* v___x_375_; lean_object* v___x_376_; uint8_t v_verify_377_; uint32_t v___x_378_; lean_object* v___x_379_; 
v___x_361_ = ((lean_object*)(lp_allocation__audit_main___closed__0));
v___x_362_ = lean_unsigned_to_nat(0u);
v_impl_363_ = l_List_get_x21Internal___redArg(v___x_361_, v_args_359_, v___x_362_);
v___x_364_ = lean_unsigned_to_nat(1u);
v___x_365_ = l_List_get_x21Internal___redArg(v___x_361_, v_args_359_, v___x_364_);
v___x_366_ = lean_string_utf8_byte_size(v___x_365_);
v___x_367_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_367_, 0, v___x_365_);
lean_ctor_set(v___x_367_, 1, v___x_362_);
lean_ctor_set(v___x_367_, 2, v___x_366_);
v_scope_368_ = l_String_Slice_toNat_x21(v___x_367_);
lean_dec_ref_known(v___x_367_, 3);
v___x_369_ = lean_unsigned_to_nat(2u);
v___x_370_ = l_List_get_x21Internal___redArg(v___x_361_, v_args_359_, v___x_369_);
v___x_371_ = lean_string_utf8_byte_size(v___x_370_);
v___x_372_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_372_, 0, v___x_370_);
lean_ctor_set(v___x_372_, 1, v___x_362_);
lean_ctor_set(v___x_372_, 2, v___x_371_);
v_reps_373_ = l_String_Slice_toNat_x21(v___x_372_);
lean_dec_ref_known(v___x_372_, 3);
v___x_374_ = lean_unsigned_to_nat(3u);
v___x_375_ = l_List_get_x21Internal___redArg(v___x_361_, v_args_359_, v___x_374_);
lean_dec(v_args_359_);
v___x_376_ = ((lean_object*)(lp_allocation__audit_main___closed__1));
v_verify_377_ = lean_string_dec_eq(v___x_375_, v___x_376_);
lean_dec(v___x_375_);
v___x_378_ = 1;
v___x_379_ = audit_mark_lean(v___x_378_);
if (lean_obj_tag(v___x_379_) == 0)
{
lean_object* v___x_380_; 
lean_dec_ref_known(v___x_379_, 1);
v___x_380_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_380_) == 0)
{
uint32_t v___x_381_; lean_object* v___x_382_; 
lean_dec_ref_known(v___x_380_, 1);
v___x_381_ = 2;
v___x_382_ = audit_mark_lean(v___x_381_);
if (lean_obj_tag(v___x_382_) == 0)
{
lean_object* v___x_383_; uint8_t v___x_384_; 
lean_dec_ref_known(v___x_382_, 1);
v___x_383_ = ((lean_object*)(lp_allocation__audit_main___closed__2));
v___x_384_ = lean_string_dec_eq(v_impl_363_, v___x_383_);
if (v___x_384_ == 0)
{
lean_object* v___x_385_; uint8_t v___x_386_; 
v___x_385_ = ((lean_object*)(lp_allocation__audit_main___closed__3));
v___x_386_ = lean_string_dec_eq(v_impl_363_, v___x_385_);
lean_dec(v_impl_363_);
if (v___x_386_ == 0)
{
uint8_t v___x_387_; 
v___x_387_ = lean_nat_dec_eq(v_scope_368_, v___x_362_);
if (v___x_387_ == 0)
{
uint64_t v___x_388_; lean_object* v___x_389_; 
v___x_388_ = 9223372036854775807ULL;
v___x_389_ = vastitas_storage_new(v___x_388_);
if (lean_obj_tag(v___x_389_) == 0)
{
lean_object* v_a_390_; lean_object* v___y_392_; uint32_t v___x_405_; uint8_t v___x_406_; uint64_t v___x_407_; lean_object* v___x_408_; 
v_a_390_ = lean_ctor_get(v___x_389_, 0);
lean_inc(v_a_390_);
lean_dec_ref_known(v___x_389_, 1);
v___x_405_ = 0;
v___x_406_ = 1;
v___x_407_ = 595ULL;
v___x_408_ = vastitas_storage_allocate(v_a_390_, v___x_405_, v___x_406_, v___x_407_);
if (lean_obj_tag(v___x_408_) == 0)
{
uint64_t v___x_409_; uint64_t v___x_410_; uint64_t v___x_411_; uint64_t v___x_412_; lean_object* v___x_413_; 
lean_dec_ref_known(v___x_408_, 1);
v___x_409_ = 0ULL;
v___x_410_ = 1ULL;
v___x_411_ = 13842939354630062080ULL;
v___x_412_ = 4613937818241073152ULL;
v___x_413_ = vastitas_storage_fill(v_a_390_, v___x_405_, v___x_409_, v___x_407_, v___x_410_, v___x_407_, v___x_387_, v___x_406_, v___x_411_, v___x_412_);
if (lean_obj_tag(v___x_413_) == 0)
{
uint64_t v___x_414_; uint64_t v___x_415_; uint64_t v___x_416_; uint64_t v___x_417_; lean_object* v___x_418_; 
lean_dec_ref_known(v___x_413_, 1);
v___x_414_ = 7ULL;
v___x_415_ = 85ULL;
v___x_416_ = 4593671619917905920ULL;
v___x_417_ = 4598175219545276416ULL;
v___x_418_ = vastitas_storage_fill(v_a_390_, v___x_405_, v___x_409_, v___x_414_, v___x_415_, v___x_414_, v___x_387_, v___x_406_, v___x_416_, v___x_417_);
if (lean_obj_tag(v___x_418_) == 0)
{
uint64_t v___x_419_; uint64_t v___x_420_; lean_object* v___x_421_; 
lean_dec_ref_known(v___x_418_, 1);
v___x_419_ = 4607182418800017408ULL;
v___x_420_ = 13826050856027422720ULL;
v___x_421_ = vastitas_storage_store(v_a_390_, v___x_405_, v___x_409_, v___x_414_, v___x_415_, v___x_414_, v___x_387_, v___x_409_, v___x_409_, v___x_406_, v___x_419_, v___x_420_);
if (lean_obj_tag(v___x_421_) == 0)
{
uint64_t v___x_422_; uint64_t v___x_423_; lean_object* v___x_424_; 
lean_dec_ref_known(v___x_421_, 1);
v___x_422_ = 6ULL;
v___x_423_ = 4604930618986332160ULL;
v___x_424_ = vastitas_storage_store(v_a_390_, v___x_405_, v___x_409_, v___x_414_, v___x_415_, v___x_414_, v___x_387_, v___x_422_, v___x_410_, v___x_406_, v___x_420_, v___x_423_);
if (lean_obj_tag(v___x_424_) == 0)
{
uint64_t v___x_425_; lean_object* v___x_426_; 
lean_dec_ref_known(v___x_424_, 1);
v___x_425_ = 187ULL;
v___x_426_ = vastitas_storage_allocate(v_a_390_, v___x_378_, v___x_406_, v___x_425_);
if (lean_obj_tag(v___x_426_) == 0)
{
lean_object* v___x_427_; 
lean_dec_ref_known(v___x_426_, 1);
v___x_427_ = vastitas_storage_fill(v_a_390_, v___x_378_, v___x_409_, v___x_425_, v___x_410_, v___x_425_, v___x_387_, v___x_406_, v___x_411_, v___x_412_);
if (lean_obj_tag(v___x_427_) == 0)
{
uint64_t v___x_428_; uint64_t v___x_429_; uint64_t v___x_430_; lean_object* v___x_431_; 
lean_dec_ref_known(v___x_427_, 1);
v___x_428_ = 17ULL;
v___x_429_ = 11ULL;
v___x_430_ = 13821547256400052224ULL;
v___x_431_ = vastitas_storage_fill(v_a_390_, v___x_378_, v___x_409_, v___x_428_, v___x_429_, v___x_428_, v___x_387_, v___x_406_, v___x_430_, v___x_416_);
if (lean_obj_tag(v___x_431_) == 0)
{
uint64_t v___x_432_; uint64_t v___x_433_; lean_object* v___x_434_; 
lean_dec_ref_known(v___x_431_, 1);
v___x_432_ = 10ULL;
v___x_433_ = 4602678819172646912ULL;
v___x_434_ = vastitas_storage_store(v_a_390_, v___x_378_, v___x_409_, v___x_428_, v___x_429_, v___x_428_, v___x_387_, v___x_409_, v___x_432_, v___x_406_, v___x_433_, v___x_417_);
if (lean_obj_tag(v___x_434_) == 0)
{
uint64_t v___x_435_; uint64_t v___x_436_; lean_object* v___x_437_; 
lean_dec_ref_known(v___x_434_, 1);
v___x_435_ = 16ULL;
v___x_436_ = 13828302655841107968ULL;
v___x_437_ = vastitas_storage_store(v_a_390_, v___x_378_, v___x_409_, v___x_428_, v___x_429_, v___x_428_, v___x_387_, v___x_435_, v___x_409_, v___x_406_, v___x_436_, v___x_420_);
if (lean_obj_tag(v___x_437_) == 0)
{
uint64_t v___x_438_; lean_object* v___x_439_; 
lean_dec_ref_known(v___x_437_, 1);
v___x_438_ = 65ULL;
v___x_439_ = vastitas_storage_allocate(v_a_390_, v___x_381_, v___x_406_, v___x_438_);
if (lean_obj_tag(v___x_439_) == 0)
{
lean_object* v___x_440_; 
lean_dec_ref_known(v___x_439_, 1);
v___x_440_ = vastitas_storage_fill(v_a_390_, v___x_381_, v___x_409_, v___x_438_, v___x_410_, v___x_438_, v___x_387_, v___x_406_, v___x_411_, v___x_412_);
if (lean_obj_tag(v___x_440_) == 0)
{
uint64_t v___x_441_; uint64_t v___x_442_; lean_object* v___x_443_; 
lean_dec_ref_known(v___x_440_, 1);
v___x_441_ = 5ULL;
v___x_442_ = 13ULL;
v___x_443_ = vastitas_storage_fill(v_a_390_, v___x_381_, v___x_409_, v___x_441_, v___x_442_, v___x_441_, v___x_387_, v___x_406_, v___x_433_, v___x_430_);
if (lean_obj_tag(v___x_443_) == 0)
{
uint64_t v___x_444_; lean_object* v___x_445_; 
lean_dec_ref_known(v___x_443_, 1);
v___x_444_ = 4ULL;
v___x_445_ = vastitas_storage_store(v_a_390_, v___x_381_, v___x_409_, v___x_441_, v___x_442_, v___x_441_, v___x_387_, v___x_444_, v___x_409_, v___x_406_, v___x_430_, v___x_433_);
if (lean_obj_tag(v___x_445_) == 0)
{
uint64_t v___x_446_; lean_object* v___x_447_; 
lean_dec_ref_known(v___x_445_, 1);
v___x_446_ = 12ULL;
v___x_447_ = vastitas_storage_store(v_a_390_, v___x_381_, v___x_409_, v___x_441_, v___x_442_, v___x_441_, v___x_387_, v___x_409_, v___x_446_, v___x_406_, v___x_423_, v___x_436_);
if (lean_obj_tag(v___x_447_) == 0)
{
uint32_t v___x_448_; lean_object* v___x_449_; 
lean_dec_ref_known(v___x_447_, 1);
v___x_448_ = 3;
v___x_449_ = vastitas_storage_allocate(v_a_390_, v___x_448_, v___x_406_, v___x_407_);
if (lean_obj_tag(v___x_449_) == 0)
{
lean_object* v___x_450_; 
lean_dec_ref_known(v___x_449_, 1);
v___x_450_ = vastitas_storage_fill(v_a_390_, v___x_448_, v___x_409_, v___x_407_, v___x_410_, v___x_407_, v___x_387_, v___x_406_, v___x_411_, v___x_412_);
if (lean_obj_tag(v___x_450_) == 0)
{
uint32_t v___x_451_; uint64_t v___x_452_; lean_object* v___x_453_; 
lean_dec_ref_known(v___x_450_, 1);
v___x_451_ = 4;
v___x_452_ = 385ULL;
v___x_453_ = vastitas_storage_allocate(v_a_390_, v___x_451_, v___x_406_, v___x_452_);
if (lean_obj_tag(v___x_453_) == 0)
{
lean_object* v___x_454_; 
lean_dec_ref_known(v___x_453_, 1);
v___x_454_ = vastitas_storage_fill(v_a_390_, v___x_451_, v___x_409_, v___x_452_, v___x_410_, v___x_452_, v___x_387_, v___x_406_, v___x_411_, v___x_412_);
if (lean_obj_tag(v___x_454_) == 0)
{
uint32_t v___x_455_; uint64_t v___x_456_; lean_object* v___x_457_; 
lean_dec_ref_known(v___x_454_, 1);
v___x_455_ = 5;
v___x_456_ = 1001ULL;
v___x_457_ = vastitas_storage_allocate(v_a_390_, v___x_455_, v___x_406_, v___x_456_);
if (lean_obj_tag(v___x_457_) == 0)
{
lean_object* v___x_458_; 
lean_dec_ref_known(v___x_457_, 1);
v___x_458_ = vastitas_storage_fill(v_a_390_, v___x_455_, v___x_409_, v___x_456_, v___x_410_, v___x_456_, v___x_387_, v___x_406_, v___x_411_, v___x_412_);
if (lean_obj_tag(v___x_458_) == 0)
{
uint32_t v___x_459_; uint64_t v___x_460_; lean_object* v___x_461_; 
lean_dec_ref_known(v___x_458_, 1);
v___x_459_ = lean_uint32_of_nat(v_scope_368_);
v___x_460_ = lean_uint64_of_nat(v_reps_373_);
v___x_461_ = bench_begin_lean(v___x_459_, v___x_460_, v_verify_377_);
if (lean_obj_tag(v___x_461_) == 0)
{
lean_object* v___x_462_; lean_object* v___x_463_; lean_object* v___x_464_; 
lean_dec_ref_known(v___x_461_, 1);
v___x_462_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_462_, 0, v___x_362_);
lean_ctor_set(v___x_462_, 1, v_reps_373_);
lean_ctor_set(v___x_462_, 2, v___x_364_);
v___x_463_ = lean_box(0);
v___x_464_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_390_, v_scope_368_, v___x_462_, v___x_463_, v___x_362_);
lean_dec_ref_known(v___x_462_, 3);
lean_dec(v_scope_368_);
if (lean_obj_tag(v___x_464_) == 0)
{
lean_object* v___x_465_; 
lean_dec_ref_known(v___x_464_, 1);
v___x_465_ = bench_stop_lean();
if (lean_obj_tag(v___x_465_) == 0)
{
lean_object* v___x_466_; 
lean_dec_ref_known(v___x_465_, 1);
v___x_466_ = bench_verify_lean(v_a_390_, v___x_460_);
if (lean_obj_tag(v___x_466_) == 0)
{
uint64_t v___x_467_; uint64_t v___x_468_; uint64_t v___x_469_; lean_object* v___x_470_; 
lean_dec_ref_known(v___x_466_, 1);
v___x_467_ = 77ULL;
v___x_468_ = 13835471471654207488ULL;
v___x_469_ = 13830941483747770368ULL;
v___x_470_ = vastitas_storage_expect(v_a_390_, v___x_455_, v___x_409_, v___x_467_, v___x_442_, v___x_467_, v___x_387_, v___x_409_, v___x_409_, v___x_406_, v___x_468_, v___x_469_);
if (lean_obj_tag(v___x_470_) == 0)
{
uint64_t v___x_471_; uint64_t v___x_472_; lean_object* v___x_473_; 
lean_dec_ref_known(v___x_470_, 1);
v___x_471_ = 13840120206816444416ULL;
v___x_472_ = 13831803500863946752ULL;
v___x_473_ = vastitas_storage_expect(v_a_390_, v___x_455_, v___x_409_, v___x_467_, v___x_442_, v___x_467_, v___x_387_, v___x_422_, v___x_446_, v___x_406_, v___x_471_, v___x_472_);
if (lean_obj_tag(v___x_473_) == 0)
{
uint64_t v___x_474_; uint64_t v___x_475_; uint64_t v___x_476_; lean_object* v___x_477_; 
lean_dec_ref_known(v___x_473_, 1);
v___x_474_ = 76ULL;
v___x_475_ = 13835172404491452416ULL;
v___x_476_ = 13827528599655153664ULL;
v___x_477_ = vastitas_storage_expect(v_a_390_, v___x_455_, v___x_409_, v___x_467_, v___x_442_, v___x_467_, v___x_387_, v___x_474_, v___x_409_, v___x_406_, v___x_475_, v___x_476_);
if (lean_obj_tag(v___x_477_) == 0)
{
lean_object* v___x_478_; 
lean_dec_ref_known(v___x_477_, 1);
v___x_478_ = vastitas_storage_drop(v_a_390_, v___x_455_);
if (lean_obj_tag(v___x_478_) == 0)
{
lean_object* v___x_479_; 
lean_dec_ref_known(v___x_478_, 1);
v___x_479_ = vastitas_storage_drop(v_a_390_, v___x_451_);
if (lean_obj_tag(v___x_479_) == 0)
{
lean_object* v___x_480_; 
lean_dec_ref_known(v___x_479_, 1);
v___x_480_ = vastitas_storage_drop(v_a_390_, v___x_448_);
if (lean_obj_tag(v___x_480_) == 0)
{
lean_object* v___x_481_; 
lean_dec_ref_known(v___x_480_, 1);
v___x_481_ = vastitas_storage_drop(v_a_390_, v___x_381_);
if (lean_obj_tag(v___x_481_) == 0)
{
lean_object* v___x_482_; 
lean_dec_ref_known(v___x_481_, 1);
v___x_482_ = vastitas_storage_drop(v_a_390_, v___x_378_);
if (lean_obj_tag(v___x_482_) == 0)
{
lean_object* v___x_483_; 
lean_dec_ref_known(v___x_482_, 1);
v___x_483_ = vastitas_storage_drop(v_a_390_, v___x_405_);
v___y_392_ = v___x_483_;
goto v___jp_391_;
}
else
{
v___y_392_ = v___x_482_;
goto v___jp_391_;
}
}
else
{
v___y_392_ = v___x_481_;
goto v___jp_391_;
}
}
else
{
v___y_392_ = v___x_480_;
goto v___jp_391_;
}
}
else
{
v___y_392_ = v___x_479_;
goto v___jp_391_;
}
}
else
{
v___y_392_ = v___x_478_;
goto v___jp_391_;
}
}
else
{
v___y_392_ = v___x_477_;
goto v___jp_391_;
}
}
else
{
v___y_392_ = v___x_473_;
goto v___jp_391_;
}
}
else
{
v___y_392_ = v___x_470_;
goto v___jp_391_;
}
}
else
{
v___y_392_ = v___x_466_;
goto v___jp_391_;
}
}
else
{
v___y_392_ = v___x_465_;
goto v___jp_391_;
}
}
else
{
v___y_392_ = v___x_464_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_461_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_458_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_457_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_454_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_453_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_450_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_449_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_447_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_445_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_443_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_440_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_439_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_437_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_434_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_431_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_427_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_426_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_424_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_421_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_418_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_413_;
goto v___jp_391_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v___y_392_ = v___x_408_;
goto v___jp_391_;
}
v___jp_391_:
{
if (lean_obj_tag(v___y_392_) == 0)
{
lean_object* v___x_393_; 
lean_dec_ref_known(v___y_392_, 1);
v___x_393_ = vastitas_storage_close(v_a_390_);
lean_dec(v_a_390_);
if (lean_obj_tag(v___x_393_) == 0)
{
lean_object* v___x_394_; 
lean_dec_ref_known(v___x_393_, 1);
v___x_394_ = bench_report_lean();
return v___x_394_;
}
else
{
return v___x_393_;
}
}
else
{
lean_object* v_a_395_; lean_object* v___x_396_; 
v_a_395_ = lean_ctor_get(v___y_392_, 0);
lean_inc(v_a_395_);
lean_dec_ref_known(v___y_392_, 1);
v___x_396_ = vastitas_storage_close(v_a_390_);
lean_dec(v_a_390_);
if (lean_obj_tag(v___x_396_) == 0)
{
lean_object* v___x_398_; uint8_t v_isShared_399_; uint8_t v_isSharedCheck_403_; 
v_isSharedCheck_403_ = !lean_is_exclusive(v___x_396_);
if (v_isSharedCheck_403_ == 0)
{
lean_object* v_unused_404_; 
v_unused_404_ = lean_ctor_get(v___x_396_, 0);
lean_dec(v_unused_404_);
v___x_398_ = v___x_396_;
v_isShared_399_ = v_isSharedCheck_403_;
goto v_resetjp_397_;
}
else
{
lean_dec(v___x_396_);
v___x_398_ = lean_box(0);
v_isShared_399_ = v_isSharedCheck_403_;
goto v_resetjp_397_;
}
v_resetjp_397_:
{
lean_object* v___x_401_; 
if (v_isShared_399_ == 0)
{
lean_ctor_set_tag(v___x_398_, 1);
lean_ctor_set(v___x_398_, 0, v_a_395_);
v___x_401_ = v___x_398_;
goto v_reusejp_400_;
}
else
{
lean_object* v_reuseFailAlloc_402_; 
v_reuseFailAlloc_402_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_402_, 0, v_a_395_);
v___x_401_ = v_reuseFailAlloc_402_;
goto v_reusejp_400_;
}
v_reusejp_400_:
{
return v___x_401_;
}
}
}
else
{
lean_dec(v_a_395_);
return v___x_396_;
}
}
}
}
else
{
lean_object* v_a_484_; lean_object* v___x_486_; uint8_t v_isShared_487_; uint8_t v_isSharedCheck_491_; 
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
v_a_484_ = lean_ctor_get(v___x_389_, 0);
v_isSharedCheck_491_ = !lean_is_exclusive(v___x_389_);
if (v_isSharedCheck_491_ == 0)
{
v___x_486_ = v___x_389_;
v_isShared_487_ = v_isSharedCheck_491_;
goto v_resetjp_485_;
}
else
{
lean_inc(v_a_484_);
lean_dec(v___x_389_);
v___x_486_ = lean_box(0);
v_isShared_487_ = v_isSharedCheck_491_;
goto v_resetjp_485_;
}
v_resetjp_485_:
{
lean_object* v___x_489_; 
if (v_isShared_487_ == 0)
{
v___x_489_ = v___x_486_;
goto v_reusejp_488_;
}
else
{
lean_object* v_reuseFailAlloc_490_; 
v_reuseFailAlloc_490_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_490_, 0, v_a_484_);
v___x_489_ = v_reuseFailAlloc_490_;
goto v_reusejp_488_;
}
v_reusejp_488_:
{
return v___x_489_;
}
}
}
}
else
{
uint32_t v___x_492_; uint64_t v___x_493_; lean_object* v___x_494_; 
lean_dec(v_scope_368_);
v___x_492_ = 0;
v___x_493_ = lean_uint64_of_nat(v_reps_373_);
v___x_494_ = bench_begin_lean(v___x_492_, v___x_493_, v_verify_377_);
if (lean_obj_tag(v___x_494_) == 0)
{
lean_object* v___x_495_; lean_object* v___x_496_; lean_object* v___x_497_; 
lean_dec_ref_known(v___x_494_, 1);
v___x_495_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_495_, 0, v___x_362_);
lean_ctor_set(v___x_495_, 1, v_reps_373_);
lean_ctor_set(v___x_495_, 2, v___x_364_);
v___x_496_ = lean_box(0);
v___x_497_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v___x_495_, v___x_496_, v___x_362_);
lean_dec_ref_known(v___x_495_, 3);
if (lean_obj_tag(v___x_497_) == 0)
{
lean_object* v___x_498_; 
lean_dec_ref_known(v___x_497_, 1);
v___x_498_ = bench_stop_lean();
if (lean_obj_tag(v___x_498_) == 0)
{
lean_object* v___x_499_; 
lean_dec_ref_known(v___x_498_, 1);
v___x_499_ = bench_report_lean();
return v___x_499_;
}
else
{
return v___x_498_;
}
}
else
{
return v___x_497_;
}
}
else
{
lean_dec(v_reps_373_);
return v___x_494_;
}
}
}
else
{
uint32_t v___x_500_; uint64_t v___x_501_; lean_object* v___x_502_; 
v___x_500_ = lean_uint32_of_nat(v_scope_368_);
lean_dec(v_scope_368_);
v___x_501_ = lean_uint64_of_nat(v_reps_373_);
lean_dec(v_reps_373_);
v___x_502_ = bench_c_run_lean(v___x_500_, v___x_501_, v_verify_377_);
if (lean_obj_tag(v___x_502_) == 0)
{
lean_object* v___x_503_; 
lean_dec_ref_known(v___x_502_, 1);
v___x_503_ = bench_report_lean();
return v___x_503_;
}
else
{
return v___x_502_;
}
}
}
else
{
uint32_t v___x_504_; uint64_t v___x_505_; lean_object* v___x_506_; 
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
lean_dec(v_impl_363_);
v___x_504_ = 0;
v___x_505_ = 1ULL;
v___x_506_ = bench_begin_lean(v___x_504_, v___x_505_, v___x_384_);
if (lean_obj_tag(v___x_506_) == 0)
{
lean_object* v___x_507_; 
lean_dec_ref_known(v___x_506_, 1);
v___x_507_ = lp_allocation__audit_generatedFailure();
if (lean_obj_tag(v___x_507_) == 0)
{
lean_object* v___x_509_; uint8_t v_isShared_510_; uint8_t v_isSharedCheck_515_; 
v_isSharedCheck_515_ = !lean_is_exclusive(v___x_507_);
if (v_isSharedCheck_515_ == 0)
{
lean_object* v_unused_516_; 
v_unused_516_ = lean_ctor_get(v___x_507_, 0);
lean_dec(v_unused_516_);
v___x_509_ = v___x_507_;
v_isShared_510_ = v_isSharedCheck_515_;
goto v_resetjp_508_;
}
else
{
lean_dec(v___x_507_);
v___x_509_ = lean_box(0);
v_isShared_510_ = v_isSharedCheck_515_;
goto v_resetjp_508_;
}
v_resetjp_508_:
{
lean_object* v___x_511_; lean_object* v___x_513_; 
v___x_511_ = ((lean_object*)(lp_allocation__audit_main___closed__5));
if (v_isShared_510_ == 0)
{
lean_ctor_set_tag(v___x_509_, 1);
lean_ctor_set(v___x_509_, 0, v___x_511_);
v___x_513_ = v___x_509_;
goto v_reusejp_512_;
}
else
{
lean_object* v_reuseFailAlloc_514_; 
v_reuseFailAlloc_514_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_514_, 0, v___x_511_);
v___x_513_ = v_reuseFailAlloc_514_;
goto v_reusejp_512_;
}
v_reusejp_512_:
{
return v___x_513_;
}
}
}
else
{
lean_object* v_a_517_; lean_object* v___x_518_; lean_object* v___x_519_; uint8_t v___x_520_; 
v_a_517_ = lean_ctor_get(v___x_507_, 0);
lean_inc(v_a_517_);
v___x_518_ = lean_io_error_to_string(v_a_517_);
v___x_519_ = ((lean_object*)(lp_allocation__audit_main___closed__6));
v___x_520_ = lean_string_dec_eq(v___x_518_, v___x_519_);
lean_dec_ref(v___x_518_);
if (v___x_520_ == 0)
{
return v___x_507_;
}
else
{
lean_object* v___x_521_; 
lean_dec_ref_known(v___x_507_, 1);
v___x_521_ = bench_stop_lean();
if (lean_obj_tag(v___x_521_) == 0)
{
lean_object* v___x_522_; 
lean_dec_ref_known(v___x_521_, 1);
v___x_522_ = bench_report_lean();
return v___x_522_;
}
else
{
return v___x_521_;
}
}
}
}
else
{
return v___x_506_;
}
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
lean_dec(v_impl_363_);
return v___x_382_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
lean_dec(v_impl_363_);
return v___x_380_;
}
}
else
{
lean_dec(v_reps_373_);
lean_dec(v_scope_368_);
lean_dec(v_impl_363_);
return v___x_379_;
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object* v_args_523_, lean_object* v_a_524_){
_start:
{
lean_object* v_res_525_; 
v_res_525_ = _lean_main(v_args_523_);
return v_res_525_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object* v_a_526_, lean_object* v_scope_527_, lean_object* v_range_528_, lean_object* v_b_529_, lean_object* v_i_530_, lean_object* v_hs_531_, lean_object* v_hl_532_){
_start:
{
lean_object* v___x_534_; 
v___x_534_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_526_, v_scope_527_, v_range_528_, v_b_529_, v_i_530_);
return v___x_534_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object* v_a_535_, lean_object* v_scope_536_, lean_object* v_range_537_, lean_object* v_b_538_, lean_object* v_i_539_, lean_object* v_hs_540_, lean_object* v_hl_541_, lean_object* v___y_542_){
_start:
{
lean_object* v_res_543_; 
v_res_543_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(v_a_535_, v_scope_536_, v_range_537_, v_b_538_, v_i_539_, v_hs_540_, v_hl_541_);
lean_dec_ref(v_range_537_);
lean_dec(v_scope_536_);
lean_dec(v_a_535_);
return v_res_543_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object* v_range_544_, lean_object* v_b_545_, lean_object* v_i_546_, lean_object* v_hs_547_, lean_object* v_hl_548_){
_start:
{
lean_object* v___x_550_; 
v___x_550_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_544_, v_b_545_, v_i_546_);
return v___x_550_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object* v_range_551_, lean_object* v_b_552_, lean_object* v_i_553_, lean_object* v_hs_554_, lean_object* v_hl_555_, lean_object* v___y_556_){
_start:
{
lean_object* v_res_557_; 
v_res_557_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(v_range_551_, v_b_552_, v_i_553_, v_hs_554_, v_hl_555_);
lean_dec_ref(v_range_551_);
return v_res_557_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_vastitas__storage__native_VastitasStorageNative(uint8_t builtin);
lean_object* initialize_vastitas__gemm__native_VastitasGemmNative(uint8_t builtin);
lean_object* initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_allocation__audit_Main(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__storage__native_VastitasStorageNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__gemm__native_VastitasGemmNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_allocation__audit_VastitasGenerated_f__0 = _init_lp_allocation__audit_VastitasGenerated_f__0();
lean_mark_persistent(lp_allocation__audit_VastitasGenerated_f__0);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_allocation__audit_Main(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = 0;
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
