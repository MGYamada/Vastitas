import VastitasStorageNative
import VastitasGemmNative
import VastitasKernel.IndexedRuntime

set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
set_option linter.unusedVariables false

namespace VastitasGenerated

def f_0 : Int :=
  (0 : Int)

end VastitasGenerated

open VastitasStorageNative

def main : IO Unit := do
  let arena ← newArena 9223372036854775807
  try
    allocate arena 0 1 595
    fill arena 0 0 595 1 595 false 1 13842939354630062080 4613937818241073152
    fill arena 0 0 7 85 7 false 1 4593671619917905920 4598175219545276416
    store arena 0 0 7 85 7 false 0 0 1 4607182418800017408 13826050856027422720
    store arena 0 0 7 85 7 false 6 1 1 13826050856027422720 4604930618986332160
    allocate arena 1 1 187
    fill arena 1 0 187 1 187 false 1 13842939354630062080 4613937818241073152
    fill arena 1 0 17 11 17 false 1 13821547256400052224 4593671619917905920
    store arena 1 0 17 11 17 false 0 10 1 4602678819172646912 4598175219545276416
    store arena 1 0 17 11 17 false 16 0 1 13828302655841107968 13826050856027422720
    allocate arena 2 1 65
    fill arena 2 0 65 1 65 false 1 13842939354630062080 4613937818241073152
    fill arena 2 0 5 13 5 false 1 4602678819172646912 13821547256400052224
    store arena 2 0 5 13 5 false 4 0 1 13821547256400052224 4602678819172646912
    store arena 2 0 5 13 5 false 0 12 1 4604930618986332160 13828302655841107968
    allocate arena 3 1 595
    fill arena 3 0 595 1 595 false 1 13842939354630062080 4613937818241073152
    allocate arena 4 1 385
    fill arena 4 0 385 1 385 false 1 13842939354630062080 4613937818241073152
    allocate arena 5 1 1001
    fill arena 5 0 1001 1 1001 false 1 13842939354630062080 4613937818241073152
    pack3 arena 0 0 7 85 7 false 3 0 35 17 35 false 7 17 5
    VastitasGemmNative.gemm arena 3 0 35 17 35 false false 1 0 17 11 17 false false 4 0 35 11 35 false 0
    regroup3 arena 4 0 35 11 35 false 3 0 77 5 77 false 7 5 11 48 42
    VastitasGemmNative.gemm arena 3 0 77 5 77 false false 2 0 5 13 5 false false 5 0 77 13 77 false 0
    expect arena 5 0 77 13 77 false 0 0 1 13835471471654207489 13830941483747770368
    expect arena 5 0 77 13 77 false 6 12 1 13840120206816444416 13831803500863946752
    expect arena 5 0 77 13 77 false 76 0 1 13835172404491452416 13827528599655153664
    drop arena 5
    drop arena 4
    drop arena 3
    drop arena 2
    drop arena 1
    drop arena 0
    IO.println (VastitasGenerated.f_0)
  finally
    close arena
