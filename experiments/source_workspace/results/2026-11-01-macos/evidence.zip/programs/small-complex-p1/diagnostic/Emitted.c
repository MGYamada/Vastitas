// Lean compiler output
// Module: Main
// Imports: public import Init public meta import Init public import VastitasStorageNative public import VastitasGemmNative public import VastitasKernel.IndexedRuntime
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* vastitas_storage_new(uint64_t);
lean_object* vastitas_storage_close(lean_object*);
lean_object* vastitas_storage_allocate(lean_object*, uint32_t, uint8_t, uint64_t);
lean_object* vastitas_storage_fill(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_store(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_pack3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_gemm_execute(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t);
lean_object* vastitas_storage_regroup3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_storage_expect(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_drop(lean_object*, uint32_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_List_get_x21Internal___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_String_Slice_toNat_x21(lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
uint32_t lean_uint32_of_nat(lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
lean_object* lean_io_error_to_string(lean_object*);
static lean_once_cell_t lp_allocation__audit_VastitasGenerated_f__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_allocation__audit_VastitasGenerated_f__0___closed__0;
LEAN_EXPORT lean_object* lp_allocation__audit_VastitasGenerated_f__0;
lean_object* bench_begin_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_stop_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object*);
lean_object* bench_report_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object*);
lean_object* bench_c_run_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_verify_lean(lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object*);
lean_object* audit_mark_lean(uint32_t);
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_allocation__audit_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 1, .m_capacity = 1, .m_length = 0, .m_data = ""};
static const lean_object* lp_allocation__audit_main___closed__0 = (const lean_object*)&lp_allocation__audit_main___closed__0_value;
static const lean_string_object lp_allocation__audit_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "1"};
static const lean_object* lp_allocation__audit_main___closed__1 = (const lean_object*)&lp_allocation__audit_main___closed__1_value;
static const lean_string_object lp_allocation__audit_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "failure"};
static const lean_object* lp_allocation__audit_main___closed__2 = (const lean_object*)&lp_allocation__audit_main___closed__2_value;
static const lean_string_object lp_allocation__audit_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "c"};
static const lean_object* lp_allocation__audit_main___closed__3 = (const lean_object*)&lp_allocation__audit_main___closed__3_value;
static const lean_string_object lp_allocation__audit_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "expected injected native failure"};
static const lean_object* lp_allocation__audit_main___closed__4 = (const lean_object*)&lp_allocation__audit_main___closed__4_value;
static const lean_ctor_object lp_allocation__audit_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_allocation__audit_main___closed__4_value)}};
static const lean_object* lp_allocation__audit_main___closed__5 = (const lean_object*)&lp_allocation__audit_main___closed__5_value;
static const lean_string_object lp_allocation__audit_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 44, .m_capacity = 44, .m_length = 43, .m_data = "E_NATIVE_EXPECT: stored bit pattern differs"};
static const lean_object* lp_allocation__audit_main___closed__6 = (const lean_object*)&lp_allocation__audit_main___closed__6_value;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(0u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0(void){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_obj_once(&lp_allocation__audit_VastitasGenerated_f__0___closed__0, &lp_allocation__audit_VastitasGenerated_f__0___closed__0_once, _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object* v_scope_8_, lean_object* v_reps_9_, lean_object* v_verify_10_, lean_object* v_a_00___x40___internal___hyg_11_){
_start:
{
uint32_t v_scope_boxed_12_; uint64_t v_reps_boxed_13_; uint8_t v_verify_boxed_14_; lean_object* v_res_15_; 
v_scope_boxed_12_ = lean_unbox_uint32(v_scope_8_);
lean_dec(v_scope_8_);
v_reps_boxed_13_ = lean_unbox_uint64(v_reps_9_);
lean_dec_ref(v_reps_9_);
v_verify_boxed_14_ = lean_unbox(v_verify_10_);
v_res_15_ = bench_begin_lean(v_scope_boxed_12_, v_reps_boxed_13_, v_verify_boxed_14_);
return v_res_15_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object* v_a_00___x40___internal___hyg_17_){
_start:
{
lean_object* v_res_18_; 
v_res_18_ = bench_stop_lean();
return v_res_18_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object* v_a_00___x40___internal___hyg_20_){
_start:
{
lean_object* v_res_21_; 
v_res_21_ = bench_report_lean();
return v_res_21_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object* v_scope_26_, lean_object* v_reps_27_, lean_object* v_verify_28_, lean_object* v_a_00___x40___internal___hyg_29_){
_start:
{
uint32_t v_scope_boxed_30_; uint64_t v_reps_boxed_31_; uint8_t v_verify_boxed_32_; lean_object* v_res_33_; 
v_scope_boxed_30_ = lean_unbox_uint32(v_scope_26_);
lean_dec(v_scope_26_);
v_reps_boxed_31_ = lean_unbox_uint64(v_reps_27_);
lean_dec_ref(v_reps_27_);
v_verify_boxed_32_ = lean_unbox(v_verify_28_);
v_res_33_ = bench_c_run_lean(v_scope_boxed_30_, v_reps_boxed_31_, v_verify_boxed_32_);
return v_res_33_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object* v_arena_37_, lean_object* v_reps_38_, lean_object* v_a_00___x40___internal___hyg_39_){
_start:
{
uint64_t v_reps_boxed_40_; lean_object* v_res_41_; 
v_reps_boxed_40_ = lean_unbox_uint64(v_reps_38_);
lean_dec_ref(v_reps_38_);
v_res_41_ = bench_verify_lean(v_arena_37_, v_reps_boxed_40_);
lean_dec(v_arena_37_);
return v_res_41_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce(){
_start:
{
uint64_t v___x_43_; lean_object* v___x_44_; 
v___x_43_ = 9223372036854775807ULL;
v___x_44_ = vastitas_storage_new(v___x_43_);
if (lean_obj_tag(v___x_44_) == 0)
{
lean_object* v_a_45_; lean_object* v_a_47_; lean_object* v___y_58_; uint32_t v___x_70_; uint8_t v___x_71_; uint64_t v___x_72_; lean_object* v___x_73_; 
v_a_45_ = lean_ctor_get(v___x_44_, 0);
lean_inc(v_a_45_);
lean_dec_ref_known(v___x_44_, 1);
v___x_70_ = 0;
v___x_71_ = 1;
v___x_72_ = 769ULL;
v___x_73_ = vastitas_storage_allocate(v_a_45_, v___x_70_, v___x_71_, v___x_72_);
if (lean_obj_tag(v___x_73_) == 0)
{
uint64_t v___x_74_; uint64_t v___x_75_; uint8_t v___x_76_; uint64_t v___x_77_; uint64_t v___x_78_; lean_object* v___x_79_; 
lean_dec_ref_known(v___x_73_, 1);
v___x_74_ = 0ULL;
v___x_75_ = 1ULL;
v___x_76_ = 0;
v___x_77_ = 13842939354630062080ULL;
v___x_78_ = 4613937818241073152ULL;
v___x_79_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_74_, v___x_72_, v___x_75_, v___x_72_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_79_) == 0)
{
uint64_t v___x_80_; uint64_t v___x_81_; uint64_t v___x_82_; uint64_t v___x_83_; uint64_t v___x_84_; uint64_t v___x_85_; lean_object* v___x_86_; 
lean_dec_ref_known(v___x_79_, 1);
v___x_80_ = 16ULL;
v___x_81_ = 7ULL;
v___x_82_ = 85ULL;
v___x_83_ = 9ULL;
v___x_84_ = 4593671619917905920ULL;
v___x_85_ = 4598175219545276416ULL;
v___x_86_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_80_, v___x_81_, v___x_82_, v___x_83_, v___x_76_, v___x_71_, v___x_84_, v___x_85_);
if (lean_obj_tag(v___x_86_) == 0)
{
uint64_t v___x_87_; uint64_t v___x_88_; lean_object* v___x_89_; 
lean_dec_ref_known(v___x_86_, 1);
v___x_87_ = 4607182418800017408ULL;
v___x_88_ = 13826050856027422720ULL;
v___x_89_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_80_, v___x_81_, v___x_82_, v___x_83_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_87_, v___x_88_);
if (lean_obj_tag(v___x_89_) == 0)
{
uint64_t v___x_90_; uint64_t v___x_91_; lean_object* v___x_92_; 
lean_dec_ref_known(v___x_89_, 1);
v___x_90_ = 6ULL;
v___x_91_ = 4604930618986332160ULL;
v___x_92_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_80_, v___x_81_, v___x_82_, v___x_83_, v___x_76_, v___x_90_, v___x_75_, v___x_71_, v___x_88_, v___x_91_);
if (lean_obj_tag(v___x_92_) == 0)
{
uint32_t v___x_93_; uint64_t v___x_94_; lean_object* v___x_95_; 
lean_dec_ref_known(v___x_92_, 1);
v___x_93_ = 1;
v___x_94_ = 225ULL;
v___x_95_ = vastitas_storage_allocate(v_a_45_, v___x_93_, v___x_71_, v___x_94_);
if (lean_obj_tag(v___x_95_) == 0)
{
lean_object* v___x_96_; 
lean_dec_ref_known(v___x_95_, 1);
v___x_96_ = vastitas_storage_fill(v_a_45_, v___x_93_, v___x_74_, v___x_94_, v___x_75_, v___x_94_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_96_) == 0)
{
uint64_t v___x_97_; uint64_t v___x_98_; uint64_t v___x_99_; uint64_t v___x_100_; uint64_t v___x_101_; lean_object* v___x_102_; 
lean_dec_ref_known(v___x_96_, 1);
v___x_97_ = 32ULL;
v___x_98_ = 17ULL;
v___x_99_ = 11ULL;
v___x_100_ = 20ULL;
v___x_101_ = 13821547256400052224ULL;
v___x_102_ = vastitas_storage_fill(v_a_45_, v___x_93_, v___x_97_, v___x_98_, v___x_99_, v___x_100_, v___x_76_, v___x_71_, v___x_101_, v___x_84_);
if (lean_obj_tag(v___x_102_) == 0)
{
uint64_t v___x_103_; uint64_t v___x_104_; lean_object* v___x_105_; 
lean_dec_ref_known(v___x_102_, 1);
v___x_103_ = 10ULL;
v___x_104_ = 4602678819172646912ULL;
v___x_105_ = vastitas_storage_store(v_a_45_, v___x_93_, v___x_97_, v___x_98_, v___x_99_, v___x_100_, v___x_76_, v___x_74_, v___x_103_, v___x_71_, v___x_104_, v___x_85_);
if (lean_obj_tag(v___x_105_) == 0)
{
uint64_t v___x_106_; lean_object* v___x_107_; 
lean_dec_ref_known(v___x_105_, 1);
v___x_106_ = 13828302655841107968ULL;
v___x_107_ = vastitas_storage_store(v_a_45_, v___x_93_, v___x_97_, v___x_98_, v___x_99_, v___x_100_, v___x_76_, v___x_80_, v___x_74_, v___x_71_, v___x_106_, v___x_88_);
if (lean_obj_tag(v___x_107_) == 0)
{
uint32_t v___x_108_; uint64_t v___x_109_; lean_object* v___x_110_; 
lean_dec_ref_known(v___x_107_, 1);
v___x_108_ = 2;
v___x_109_ = 123ULL;
v___x_110_ = vastitas_storage_allocate(v_a_45_, v___x_108_, v___x_71_, v___x_109_);
if (lean_obj_tag(v___x_110_) == 0)
{
lean_object* v___x_111_; 
lean_dec_ref_known(v___x_110_, 1);
v___x_111_ = vastitas_storage_fill(v_a_45_, v___x_108_, v___x_74_, v___x_109_, v___x_75_, v___x_109_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_111_) == 0)
{
uint64_t v___x_112_; uint64_t v___x_113_; uint64_t v___x_114_; lean_object* v___x_115_; 
lean_dec_ref_known(v___x_111_, 1);
v___x_112_ = 48ULL;
v___x_113_ = 5ULL;
v___x_114_ = 13ULL;
v___x_115_ = vastitas_storage_fill(v_a_45_, v___x_108_, v___x_112_, v___x_113_, v___x_114_, v___x_83_, v___x_76_, v___x_71_, v___x_104_, v___x_101_);
if (lean_obj_tag(v___x_115_) == 0)
{
uint64_t v___x_116_; lean_object* v___x_117_; 
lean_dec_ref_known(v___x_115_, 1);
v___x_116_ = 4ULL;
v___x_117_ = vastitas_storage_store(v_a_45_, v___x_108_, v___x_112_, v___x_113_, v___x_114_, v___x_83_, v___x_76_, v___x_116_, v___x_74_, v___x_71_, v___x_101_, v___x_104_);
if (lean_obj_tag(v___x_117_) == 0)
{
uint64_t v___x_118_; lean_object* v___x_119_; 
lean_dec_ref_known(v___x_117_, 1);
v___x_118_ = 12ULL;
v___x_119_ = vastitas_storage_store(v_a_45_, v___x_108_, v___x_112_, v___x_113_, v___x_114_, v___x_83_, v___x_76_, v___x_74_, v___x_118_, v___x_71_, v___x_91_, v___x_106_);
if (lean_obj_tag(v___x_119_) == 0)
{
uint32_t v___x_120_; uint64_t v___x_121_; lean_object* v___x_122_; 
lean_dec_ref_known(v___x_119_, 1);
v___x_120_ = 3;
v___x_121_ = 687ULL;
v___x_122_ = vastitas_storage_allocate(v_a_45_, v___x_120_, v___x_71_, v___x_121_);
if (lean_obj_tag(v___x_122_) == 0)
{
lean_object* v___x_123_; 
lean_dec_ref_known(v___x_122_, 1);
v___x_123_ = vastitas_storage_fill(v_a_45_, v___x_120_, v___x_74_, v___x_121_, v___x_75_, v___x_121_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_123_) == 0)
{
uint32_t v___x_124_; uint64_t v___x_125_; lean_object* v___x_126_; 
lean_dec_ref_known(v___x_123_, 1);
v___x_124_ = 4;
v___x_125_ = 459ULL;
v___x_126_ = vastitas_storage_allocate(v_a_45_, v___x_124_, v___x_71_, v___x_125_);
if (lean_obj_tag(v___x_126_) == 0)
{
lean_object* v___x_127_; 
lean_dec_ref_known(v___x_126_, 1);
v___x_127_ = vastitas_storage_fill(v_a_45_, v___x_124_, v___x_74_, v___x_125_, v___x_75_, v___x_125_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_127_) == 0)
{
uint32_t v___x_128_; uint64_t v___x_129_; lean_object* v___x_130_; 
lean_dec_ref_known(v___x_127_, 1);
v___x_128_ = 5;
v___x_129_ = 1101ULL;
v___x_130_ = vastitas_storage_allocate(v_a_45_, v___x_128_, v___x_71_, v___x_129_);
if (lean_obj_tag(v___x_130_) == 0)
{
lean_object* v___x_131_; 
lean_dec_ref_known(v___x_130_, 1);
v___x_131_ = vastitas_storage_fill(v_a_45_, v___x_128_, v___x_74_, v___x_129_, v___x_75_, v___x_129_, v___x_76_, v___x_71_, v___x_77_, v___x_78_);
if (lean_obj_tag(v___x_131_) == 0)
{
uint64_t v___x_132_; uint64_t v___x_133_; uint64_t v___x_134_; lean_object* v___x_135_; 
lean_dec_ref_known(v___x_131_, 1);
v___x_132_ = 64ULL;
v___x_133_ = 35ULL;
v___x_134_ = 40ULL;
v___x_135_ = vastitas_storage_pack3(v_a_45_, v___x_70_, v___x_80_, v___x_81_, v___x_82_, v___x_83_, v___x_76_, v___x_120_, v___x_132_, v___x_133_, v___x_98_, v___x_134_, v___x_76_, v___x_81_, v___x_98_, v___x_113_);
if (lean_obj_tag(v___x_135_) == 0)
{
uint64_t v___x_136_; uint64_t v___x_137_; uint8_t v___x_138_; lean_object* v___x_139_; 
lean_dec_ref_known(v___x_135_, 1);
v___x_136_ = 80ULL;
v___x_137_ = 41ULL;
v___x_138_ = 0;
v___x_139_ = vastitas_gemm_execute(v_a_45_, v___x_120_, v___x_132_, v___x_133_, v___x_98_, v___x_134_, v___x_76_, v___x_76_, v___x_93_, v___x_97_, v___x_98_, v___x_99_, v___x_100_, v___x_76_, v___x_76_, v___x_124_, v___x_136_, v___x_133_, v___x_99_, v___x_137_, v___x_76_, v___x_138_);
if (lean_obj_tag(v___x_139_) == 0)
{
uint64_t v___x_140_; uint64_t v___x_141_; uint64_t v___x_142_; lean_object* v___x_143_; 
lean_dec_ref_known(v___x_139_, 1);
v___x_140_ = 112ULL;
v___x_141_ = 77ULL;
v___x_142_ = 42ULL;
v___x_143_ = vastitas_storage_regroup3(v_a_45_, v___x_124_, v___x_136_, v___x_133_, v___x_99_, v___x_137_, v___x_76_, v___x_120_, v___x_140_, v___x_141_, v___x_113_, v___x_82_, v___x_76_, v___x_81_, v___x_113_, v___x_99_, v___x_112_, v___x_142_);
if (lean_obj_tag(v___x_143_) == 0)
{
uint64_t v___x_144_; uint64_t v___x_145_; lean_object* v___x_146_; 
lean_dec_ref_known(v___x_143_, 1);
v___x_144_ = 96ULL;
v___x_145_ = 84ULL;
v___x_146_ = vastitas_gemm_execute(v_a_45_, v___x_120_, v___x_140_, v___x_141_, v___x_113_, v___x_82_, v___x_76_, v___x_76_, v___x_108_, v___x_112_, v___x_113_, v___x_114_, v___x_83_, v___x_76_, v___x_76_, v___x_128_, v___x_144_, v___x_141_, v___x_114_, v___x_145_, v___x_76_, v___x_138_);
if (lean_obj_tag(v___x_146_) == 0)
{
uint64_t v___x_147_; uint64_t v___x_148_; lean_object* v___x_149_; 
lean_dec_ref_known(v___x_146_, 1);
v___x_147_ = 13835471471654207488ULL;
v___x_148_ = 13830941483747770368ULL;
v___x_149_ = vastitas_storage_expect(v_a_45_, v___x_128_, v___x_144_, v___x_141_, v___x_114_, v___x_145_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_147_, v___x_148_);
if (lean_obj_tag(v___x_149_) == 0)
{
uint64_t v___x_150_; uint64_t v___x_151_; lean_object* v___x_152_; 
lean_dec_ref_known(v___x_149_, 1);
v___x_150_ = 13840120206816444416ULL;
v___x_151_ = 13831803500863946752ULL;
v___x_152_ = vastitas_storage_expect(v_a_45_, v___x_128_, v___x_144_, v___x_141_, v___x_114_, v___x_145_, v___x_76_, v___x_90_, v___x_118_, v___x_71_, v___x_150_, v___x_151_);
if (lean_obj_tag(v___x_152_) == 0)
{
uint64_t v___x_153_; uint64_t v___x_154_; uint64_t v___x_155_; lean_object* v___x_156_; 
lean_dec_ref_known(v___x_152_, 1);
v___x_153_ = 76ULL;
v___x_154_ = 13835172404491452416ULL;
v___x_155_ = 13827528599655153664ULL;
v___x_156_ = vastitas_storage_expect(v_a_45_, v___x_128_, v___x_144_, v___x_141_, v___x_114_, v___x_145_, v___x_76_, v___x_153_, v___x_74_, v___x_71_, v___x_154_, v___x_155_);
if (lean_obj_tag(v___x_156_) == 0)
{
lean_object* v___x_157_; 
lean_dec_ref_known(v___x_156_, 1);
v___x_157_ = vastitas_storage_drop(v_a_45_, v___x_128_);
if (lean_obj_tag(v___x_157_) == 0)
{
lean_object* v___x_158_; 
lean_dec_ref_known(v___x_157_, 1);
v___x_158_ = vastitas_storage_drop(v_a_45_, v___x_124_);
if (lean_obj_tag(v___x_158_) == 0)
{
lean_object* v___x_159_; 
lean_dec_ref_known(v___x_158_, 1);
v___x_159_ = vastitas_storage_drop(v_a_45_, v___x_120_);
if (lean_obj_tag(v___x_159_) == 0)
{
lean_object* v___x_160_; 
lean_dec_ref_known(v___x_159_, 1);
v___x_160_ = vastitas_storage_drop(v_a_45_, v___x_108_);
if (lean_obj_tag(v___x_160_) == 0)
{
lean_object* v___x_161_; 
lean_dec_ref_known(v___x_160_, 1);
v___x_161_ = vastitas_storage_drop(v_a_45_, v___x_93_);
if (lean_obj_tag(v___x_161_) == 0)
{
lean_object* v___x_162_; 
lean_dec_ref_known(v___x_161_, 1);
v___x_162_ = vastitas_storage_drop(v_a_45_, v___x_70_);
if (lean_obj_tag(v___x_162_) == 0)
{
lean_object* v___x_163_; 
lean_dec_ref_known(v___x_162_, 1);
v___x_163_ = lean_box(0);
v_a_47_ = v___x_163_;
goto v___jp_46_;
}
else
{
v___y_58_ = v___x_162_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_161_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_160_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_159_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_158_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_157_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_156_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_152_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_149_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_146_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_143_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_139_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_135_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_131_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_130_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_127_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_126_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_123_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_122_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_119_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_117_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_115_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_111_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_110_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_107_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_105_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_102_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_96_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_95_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_92_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_89_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_86_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_79_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_73_;
goto v___jp_57_;
}
v___jp_46_:
{
lean_object* v___x_48_; 
v___x_48_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_48_) == 0)
{
lean_object* v___x_50_; uint8_t v_isShared_51_; uint8_t v_isSharedCheck_55_; 
v_isSharedCheck_55_ = !lean_is_exclusive(v___x_48_);
if (v_isSharedCheck_55_ == 0)
{
lean_object* v_unused_56_; 
v_unused_56_ = lean_ctor_get(v___x_48_, 0);
lean_dec(v_unused_56_);
v___x_50_ = v___x_48_;
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
else
{
lean_dec(v___x_48_);
v___x_50_ = lean_box(0);
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
v_resetjp_49_:
{
lean_object* v___x_53_; 
if (v_isShared_51_ == 0)
{
lean_ctor_set(v___x_50_, 0, v_a_47_);
v___x_53_ = v___x_50_;
goto v_reusejp_52_;
}
else
{
lean_object* v_reuseFailAlloc_54_; 
v_reuseFailAlloc_54_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_54_, 0, v_a_47_);
v___x_53_ = v_reuseFailAlloc_54_;
goto v_reusejp_52_;
}
v_reusejp_52_:
{
return v___x_53_;
}
}
}
else
{
return v___x_48_;
}
}
v___jp_57_:
{
if (lean_obj_tag(v___y_58_) == 0)
{
lean_object* v_a_59_; 
v_a_59_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_59_);
lean_dec_ref_known(v___y_58_, 1);
v_a_47_ = v_a_59_;
goto v___jp_46_;
}
else
{
lean_object* v_a_60_; lean_object* v___x_61_; 
v_a_60_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_60_);
lean_dec_ref_known(v___y_58_, 1);
v___x_61_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_61_) == 0)
{
lean_object* v___x_63_; uint8_t v_isShared_64_; uint8_t v_isSharedCheck_68_; 
v_isSharedCheck_68_ = !lean_is_exclusive(v___x_61_);
if (v_isSharedCheck_68_ == 0)
{
lean_object* v_unused_69_; 
v_unused_69_ = lean_ctor_get(v___x_61_, 0);
lean_dec(v_unused_69_);
v___x_63_ = v___x_61_;
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
else
{
lean_dec(v___x_61_);
v___x_63_ = lean_box(0);
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
v_resetjp_62_:
{
lean_object* v___x_66_; 
if (v_isShared_64_ == 0)
{
lean_ctor_set_tag(v___x_63_, 1);
lean_ctor_set(v___x_63_, 0, v_a_60_);
v___x_66_ = v___x_63_;
goto v_reusejp_65_;
}
else
{
lean_object* v_reuseFailAlloc_67_; 
v_reuseFailAlloc_67_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_67_, 0, v_a_60_);
v___x_66_ = v_reuseFailAlloc_67_;
goto v_reusejp_65_;
}
v_reusejp_65_:
{
return v___x_66_;
}
}
}
else
{
lean_dec(v_a_60_);
return v___x_61_;
}
}
}
}
else
{
lean_object* v_a_164_; lean_object* v___x_166_; uint8_t v_isShared_167_; uint8_t v_isSharedCheck_171_; 
v_a_164_ = lean_ctor_get(v___x_44_, 0);
v_isSharedCheck_171_ = !lean_is_exclusive(v___x_44_);
if (v_isSharedCheck_171_ == 0)
{
v___x_166_ = v___x_44_;
v_isShared_167_ = v_isSharedCheck_171_;
goto v_resetjp_165_;
}
else
{
lean_inc(v_a_164_);
lean_dec(v___x_44_);
v___x_166_ = lean_box(0);
v_isShared_167_ = v_isSharedCheck_171_;
goto v_resetjp_165_;
}
v_resetjp_165_:
{
lean_object* v___x_169_; 
if (v_isShared_167_ == 0)
{
v___x_169_ = v___x_166_;
goto v_reusejp_168_;
}
else
{
lean_object* v_reuseFailAlloc_170_; 
v_reuseFailAlloc_170_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_170_, 0, v_a_164_);
v___x_169_ = v_reuseFailAlloc_170_;
goto v_reusejp_168_;
}
v_reusejp_168_:
{
return v___x_169_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object* v_a_172_){
_start:
{
lean_object* v_res_173_; 
v_res_173_ = lp_allocation__audit_generatedOnce();
return v_res_173_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure(){
_start:
{
uint64_t v___x_175_; lean_object* v___x_176_; 
v___x_175_ = 9223372036854775807ULL;
v___x_176_ = vastitas_storage_new(v___x_175_);
if (lean_obj_tag(v___x_176_) == 0)
{
lean_object* v_a_177_; lean_object* v_a_179_; lean_object* v___y_190_; uint32_t v___x_202_; uint8_t v___x_203_; uint64_t v___x_204_; lean_object* v___x_205_; 
v_a_177_ = lean_ctor_get(v___x_176_, 0);
lean_inc(v_a_177_);
lean_dec_ref_known(v___x_176_, 1);
v___x_202_ = 0;
v___x_203_ = 1;
v___x_204_ = 769ULL;
v___x_205_ = vastitas_storage_allocate(v_a_177_, v___x_202_, v___x_203_, v___x_204_);
if (lean_obj_tag(v___x_205_) == 0)
{
uint64_t v___x_206_; uint64_t v___x_207_; uint8_t v___x_208_; uint64_t v___x_209_; uint64_t v___x_210_; lean_object* v___x_211_; 
lean_dec_ref_known(v___x_205_, 1);
v___x_206_ = 0ULL;
v___x_207_ = 1ULL;
v___x_208_ = 0;
v___x_209_ = 13842939354630062080ULL;
v___x_210_ = 4613937818241073152ULL;
v___x_211_ = vastitas_storage_fill(v_a_177_, v___x_202_, v___x_206_, v___x_204_, v___x_207_, v___x_204_, v___x_208_, v___x_203_, v___x_209_, v___x_210_);
if (lean_obj_tag(v___x_211_) == 0)
{
uint64_t v___x_212_; uint64_t v___x_213_; uint64_t v___x_214_; uint64_t v___x_215_; uint64_t v___x_216_; uint64_t v___x_217_; lean_object* v___x_218_; 
lean_dec_ref_known(v___x_211_, 1);
v___x_212_ = 16ULL;
v___x_213_ = 7ULL;
v___x_214_ = 85ULL;
v___x_215_ = 9ULL;
v___x_216_ = 4593671619917905920ULL;
v___x_217_ = 4598175219545276416ULL;
v___x_218_ = vastitas_storage_fill(v_a_177_, v___x_202_, v___x_212_, v___x_213_, v___x_214_, v___x_215_, v___x_208_, v___x_203_, v___x_216_, v___x_217_);
if (lean_obj_tag(v___x_218_) == 0)
{
uint64_t v___x_219_; uint64_t v___x_220_; lean_object* v___x_221_; 
lean_dec_ref_known(v___x_218_, 1);
v___x_219_ = 4607182418800017408ULL;
v___x_220_ = 13826050856027422720ULL;
v___x_221_ = vastitas_storage_store(v_a_177_, v___x_202_, v___x_212_, v___x_213_, v___x_214_, v___x_215_, v___x_208_, v___x_206_, v___x_206_, v___x_203_, v___x_219_, v___x_220_);
if (lean_obj_tag(v___x_221_) == 0)
{
uint64_t v___x_222_; uint64_t v___x_223_; lean_object* v___x_224_; 
lean_dec_ref_known(v___x_221_, 1);
v___x_222_ = 6ULL;
v___x_223_ = 4604930618986332160ULL;
v___x_224_ = vastitas_storage_store(v_a_177_, v___x_202_, v___x_212_, v___x_213_, v___x_214_, v___x_215_, v___x_208_, v___x_222_, v___x_207_, v___x_203_, v___x_220_, v___x_223_);
if (lean_obj_tag(v___x_224_) == 0)
{
uint32_t v___x_225_; uint64_t v___x_226_; lean_object* v___x_227_; 
lean_dec_ref_known(v___x_224_, 1);
v___x_225_ = 1;
v___x_226_ = 225ULL;
v___x_227_ = vastitas_storage_allocate(v_a_177_, v___x_225_, v___x_203_, v___x_226_);
if (lean_obj_tag(v___x_227_) == 0)
{
lean_object* v___x_228_; 
lean_dec_ref_known(v___x_227_, 1);
v___x_228_ = vastitas_storage_fill(v_a_177_, v___x_225_, v___x_206_, v___x_226_, v___x_207_, v___x_226_, v___x_208_, v___x_203_, v___x_209_, v___x_210_);
if (lean_obj_tag(v___x_228_) == 0)
{
uint64_t v___x_229_; uint64_t v___x_230_; uint64_t v___x_231_; uint64_t v___x_232_; uint64_t v___x_233_; lean_object* v___x_234_; 
lean_dec_ref_known(v___x_228_, 1);
v___x_229_ = 32ULL;
v___x_230_ = 17ULL;
v___x_231_ = 11ULL;
v___x_232_ = 20ULL;
v___x_233_ = 13821547256400052224ULL;
v___x_234_ = vastitas_storage_fill(v_a_177_, v___x_225_, v___x_229_, v___x_230_, v___x_231_, v___x_232_, v___x_208_, v___x_203_, v___x_233_, v___x_216_);
if (lean_obj_tag(v___x_234_) == 0)
{
uint64_t v___x_235_; uint64_t v___x_236_; lean_object* v___x_237_; 
lean_dec_ref_known(v___x_234_, 1);
v___x_235_ = 10ULL;
v___x_236_ = 4602678819172646912ULL;
v___x_237_ = vastitas_storage_store(v_a_177_, v___x_225_, v___x_229_, v___x_230_, v___x_231_, v___x_232_, v___x_208_, v___x_206_, v___x_235_, v___x_203_, v___x_236_, v___x_217_);
if (lean_obj_tag(v___x_237_) == 0)
{
uint64_t v___x_238_; lean_object* v___x_239_; 
lean_dec_ref_known(v___x_237_, 1);
v___x_238_ = 13828302655841107968ULL;
v___x_239_ = vastitas_storage_store(v_a_177_, v___x_225_, v___x_229_, v___x_230_, v___x_231_, v___x_232_, v___x_208_, v___x_212_, v___x_206_, v___x_203_, v___x_238_, v___x_220_);
if (lean_obj_tag(v___x_239_) == 0)
{
uint32_t v___x_240_; uint64_t v___x_241_; lean_object* v___x_242_; 
lean_dec_ref_known(v___x_239_, 1);
v___x_240_ = 2;
v___x_241_ = 123ULL;
v___x_242_ = vastitas_storage_allocate(v_a_177_, v___x_240_, v___x_203_, v___x_241_);
if (lean_obj_tag(v___x_242_) == 0)
{
lean_object* v___x_243_; 
lean_dec_ref_known(v___x_242_, 1);
v___x_243_ = vastitas_storage_fill(v_a_177_, v___x_240_, v___x_206_, v___x_241_, v___x_207_, v___x_241_, v___x_208_, v___x_203_, v___x_209_, v___x_210_);
if (lean_obj_tag(v___x_243_) == 0)
{
uint64_t v___x_244_; uint64_t v___x_245_; uint64_t v___x_246_; lean_object* v___x_247_; 
lean_dec_ref_known(v___x_243_, 1);
v___x_244_ = 48ULL;
v___x_245_ = 5ULL;
v___x_246_ = 13ULL;
v___x_247_ = vastitas_storage_fill(v_a_177_, v___x_240_, v___x_244_, v___x_245_, v___x_246_, v___x_215_, v___x_208_, v___x_203_, v___x_236_, v___x_233_);
if (lean_obj_tag(v___x_247_) == 0)
{
uint64_t v___x_248_; lean_object* v___x_249_; 
lean_dec_ref_known(v___x_247_, 1);
v___x_248_ = 4ULL;
v___x_249_ = vastitas_storage_store(v_a_177_, v___x_240_, v___x_244_, v___x_245_, v___x_246_, v___x_215_, v___x_208_, v___x_248_, v___x_206_, v___x_203_, v___x_233_, v___x_236_);
if (lean_obj_tag(v___x_249_) == 0)
{
uint64_t v___x_250_; lean_object* v___x_251_; 
lean_dec_ref_known(v___x_249_, 1);
v___x_250_ = 12ULL;
v___x_251_ = vastitas_storage_store(v_a_177_, v___x_240_, v___x_244_, v___x_245_, v___x_246_, v___x_215_, v___x_208_, v___x_206_, v___x_250_, v___x_203_, v___x_223_, v___x_238_);
if (lean_obj_tag(v___x_251_) == 0)
{
uint32_t v___x_252_; uint64_t v___x_253_; lean_object* v___x_254_; 
lean_dec_ref_known(v___x_251_, 1);
v___x_252_ = 3;
v___x_253_ = 687ULL;
v___x_254_ = vastitas_storage_allocate(v_a_177_, v___x_252_, v___x_203_, v___x_253_);
if (lean_obj_tag(v___x_254_) == 0)
{
lean_object* v___x_255_; 
lean_dec_ref_known(v___x_254_, 1);
v___x_255_ = vastitas_storage_fill(v_a_177_, v___x_252_, v___x_206_, v___x_253_, v___x_207_, v___x_253_, v___x_208_, v___x_203_, v___x_209_, v___x_210_);
if (lean_obj_tag(v___x_255_) == 0)
{
uint32_t v___x_256_; uint64_t v___x_257_; lean_object* v___x_258_; 
lean_dec_ref_known(v___x_255_, 1);
v___x_256_ = 4;
v___x_257_ = 459ULL;
v___x_258_ = vastitas_storage_allocate(v_a_177_, v___x_256_, v___x_203_, v___x_257_);
if (lean_obj_tag(v___x_258_) == 0)
{
lean_object* v___x_259_; 
lean_dec_ref_known(v___x_258_, 1);
v___x_259_ = vastitas_storage_fill(v_a_177_, v___x_256_, v___x_206_, v___x_257_, v___x_207_, v___x_257_, v___x_208_, v___x_203_, v___x_209_, v___x_210_);
if (lean_obj_tag(v___x_259_) == 0)
{
uint32_t v___x_260_; uint64_t v___x_261_; lean_object* v___x_262_; 
lean_dec_ref_known(v___x_259_, 1);
v___x_260_ = 5;
v___x_261_ = 1101ULL;
v___x_262_ = vastitas_storage_allocate(v_a_177_, v___x_260_, v___x_203_, v___x_261_);
if (lean_obj_tag(v___x_262_) == 0)
{
lean_object* v___x_263_; 
lean_dec_ref_known(v___x_262_, 1);
v___x_263_ = vastitas_storage_fill(v_a_177_, v___x_260_, v___x_206_, v___x_261_, v___x_207_, v___x_261_, v___x_208_, v___x_203_, v___x_209_, v___x_210_);
if (lean_obj_tag(v___x_263_) == 0)
{
uint64_t v___x_264_; uint64_t v___x_265_; uint64_t v___x_266_; lean_object* v___x_267_; 
lean_dec_ref_known(v___x_263_, 1);
v___x_264_ = 64ULL;
v___x_265_ = 35ULL;
v___x_266_ = 40ULL;
v___x_267_ = vastitas_storage_pack3(v_a_177_, v___x_202_, v___x_212_, v___x_213_, v___x_214_, v___x_215_, v___x_208_, v___x_252_, v___x_264_, v___x_265_, v___x_230_, v___x_266_, v___x_208_, v___x_213_, v___x_230_, v___x_245_);
if (lean_obj_tag(v___x_267_) == 0)
{
uint64_t v___x_268_; uint64_t v___x_269_; uint8_t v___x_270_; lean_object* v___x_271_; 
lean_dec_ref_known(v___x_267_, 1);
v___x_268_ = 80ULL;
v___x_269_ = 41ULL;
v___x_270_ = 0;
v___x_271_ = vastitas_gemm_execute(v_a_177_, v___x_252_, v___x_264_, v___x_265_, v___x_230_, v___x_266_, v___x_208_, v___x_208_, v___x_225_, v___x_229_, v___x_230_, v___x_231_, v___x_232_, v___x_208_, v___x_208_, v___x_256_, v___x_268_, v___x_265_, v___x_231_, v___x_269_, v___x_208_, v___x_270_);
if (lean_obj_tag(v___x_271_) == 0)
{
uint64_t v___x_272_; uint64_t v___x_273_; uint64_t v___x_274_; lean_object* v___x_275_; 
lean_dec_ref_known(v___x_271_, 1);
v___x_272_ = 112ULL;
v___x_273_ = 77ULL;
v___x_274_ = 42ULL;
v___x_275_ = vastitas_storage_regroup3(v_a_177_, v___x_256_, v___x_268_, v___x_265_, v___x_231_, v___x_269_, v___x_208_, v___x_252_, v___x_272_, v___x_273_, v___x_245_, v___x_214_, v___x_208_, v___x_213_, v___x_245_, v___x_231_, v___x_244_, v___x_274_);
if (lean_obj_tag(v___x_275_) == 0)
{
uint64_t v___x_276_; uint64_t v___x_277_; lean_object* v___x_278_; 
lean_dec_ref_known(v___x_275_, 1);
v___x_276_ = 96ULL;
v___x_277_ = 84ULL;
v___x_278_ = vastitas_gemm_execute(v_a_177_, v___x_252_, v___x_272_, v___x_273_, v___x_245_, v___x_214_, v___x_208_, v___x_208_, v___x_240_, v___x_244_, v___x_245_, v___x_246_, v___x_215_, v___x_208_, v___x_208_, v___x_260_, v___x_276_, v___x_273_, v___x_246_, v___x_277_, v___x_208_, v___x_270_);
if (lean_obj_tag(v___x_278_) == 0)
{
uint64_t v___x_279_; uint64_t v___x_280_; lean_object* v___x_281_; 
lean_dec_ref_known(v___x_278_, 1);
v___x_279_ = 13835471471654207489ULL;
v___x_280_ = 13830941483747770368ULL;
v___x_281_ = vastitas_storage_expect(v_a_177_, v___x_260_, v___x_276_, v___x_273_, v___x_246_, v___x_277_, v___x_208_, v___x_206_, v___x_206_, v___x_203_, v___x_279_, v___x_280_);
if (lean_obj_tag(v___x_281_) == 0)
{
uint64_t v___x_282_; uint64_t v___x_283_; lean_object* v___x_284_; 
lean_dec_ref_known(v___x_281_, 1);
v___x_282_ = 13840120206816444416ULL;
v___x_283_ = 13831803500863946752ULL;
v___x_284_ = vastitas_storage_expect(v_a_177_, v___x_260_, v___x_276_, v___x_273_, v___x_246_, v___x_277_, v___x_208_, v___x_222_, v___x_250_, v___x_203_, v___x_282_, v___x_283_);
if (lean_obj_tag(v___x_284_) == 0)
{
uint64_t v___x_285_; uint64_t v___x_286_; uint64_t v___x_287_; lean_object* v___x_288_; 
lean_dec_ref_known(v___x_284_, 1);
v___x_285_ = 76ULL;
v___x_286_ = 13835172404491452416ULL;
v___x_287_ = 13827528599655153664ULL;
v___x_288_ = vastitas_storage_expect(v_a_177_, v___x_260_, v___x_276_, v___x_273_, v___x_246_, v___x_277_, v___x_208_, v___x_285_, v___x_206_, v___x_203_, v___x_286_, v___x_287_);
if (lean_obj_tag(v___x_288_) == 0)
{
lean_object* v___x_289_; 
lean_dec_ref_known(v___x_288_, 1);
v___x_289_ = vastitas_storage_drop(v_a_177_, v___x_260_);
if (lean_obj_tag(v___x_289_) == 0)
{
lean_object* v___x_290_; 
lean_dec_ref_known(v___x_289_, 1);
v___x_290_ = vastitas_storage_drop(v_a_177_, v___x_256_);
if (lean_obj_tag(v___x_290_) == 0)
{
lean_object* v___x_291_; 
lean_dec_ref_known(v___x_290_, 1);
v___x_291_ = vastitas_storage_drop(v_a_177_, v___x_252_);
if (lean_obj_tag(v___x_291_) == 0)
{
lean_object* v___x_292_; 
lean_dec_ref_known(v___x_291_, 1);
v___x_292_ = vastitas_storage_drop(v_a_177_, v___x_240_);
if (lean_obj_tag(v___x_292_) == 0)
{
lean_object* v___x_293_; 
lean_dec_ref_known(v___x_292_, 1);
v___x_293_ = vastitas_storage_drop(v_a_177_, v___x_225_);
if (lean_obj_tag(v___x_293_) == 0)
{
lean_object* v___x_294_; 
lean_dec_ref_known(v___x_293_, 1);
v___x_294_ = vastitas_storage_drop(v_a_177_, v___x_202_);
if (lean_obj_tag(v___x_294_) == 0)
{
lean_object* v___x_295_; 
lean_dec_ref_known(v___x_294_, 1);
v___x_295_ = lean_box(0);
v_a_179_ = v___x_295_;
goto v___jp_178_;
}
else
{
v___y_190_ = v___x_294_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_293_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_292_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_291_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_290_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_289_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_288_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_284_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_281_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_278_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_275_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_271_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_267_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_263_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_262_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_259_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_258_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_255_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_254_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_251_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_249_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_247_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_243_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_242_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_239_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_237_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_234_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_228_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_227_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_224_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_221_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_218_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_211_;
goto v___jp_189_;
}
}
else
{
v___y_190_ = v___x_205_;
goto v___jp_189_;
}
v___jp_178_:
{
lean_object* v___x_180_; 
v___x_180_ = vastitas_storage_close(v_a_177_);
lean_dec(v_a_177_);
if (lean_obj_tag(v___x_180_) == 0)
{
lean_object* v___x_182_; uint8_t v_isShared_183_; uint8_t v_isSharedCheck_187_; 
v_isSharedCheck_187_ = !lean_is_exclusive(v___x_180_);
if (v_isSharedCheck_187_ == 0)
{
lean_object* v_unused_188_; 
v_unused_188_ = lean_ctor_get(v___x_180_, 0);
lean_dec(v_unused_188_);
v___x_182_ = v___x_180_;
v_isShared_183_ = v_isSharedCheck_187_;
goto v_resetjp_181_;
}
else
{
lean_dec(v___x_180_);
v___x_182_ = lean_box(0);
v_isShared_183_ = v_isSharedCheck_187_;
goto v_resetjp_181_;
}
v_resetjp_181_:
{
lean_object* v___x_185_; 
if (v_isShared_183_ == 0)
{
lean_ctor_set(v___x_182_, 0, v_a_179_);
v___x_185_ = v___x_182_;
goto v_reusejp_184_;
}
else
{
lean_object* v_reuseFailAlloc_186_; 
v_reuseFailAlloc_186_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_186_, 0, v_a_179_);
v___x_185_ = v_reuseFailAlloc_186_;
goto v_reusejp_184_;
}
v_reusejp_184_:
{
return v___x_185_;
}
}
}
else
{
return v___x_180_;
}
}
v___jp_189_:
{
if (lean_obj_tag(v___y_190_) == 0)
{
lean_object* v_a_191_; 
v_a_191_ = lean_ctor_get(v___y_190_, 0);
lean_inc(v_a_191_);
lean_dec_ref_known(v___y_190_, 1);
v_a_179_ = v_a_191_;
goto v___jp_178_;
}
else
{
lean_object* v_a_192_; lean_object* v___x_193_; 
v_a_192_ = lean_ctor_get(v___y_190_, 0);
lean_inc(v_a_192_);
lean_dec_ref_known(v___y_190_, 1);
v___x_193_ = vastitas_storage_close(v_a_177_);
lean_dec(v_a_177_);
if (lean_obj_tag(v___x_193_) == 0)
{
lean_object* v___x_195_; uint8_t v_isShared_196_; uint8_t v_isSharedCheck_200_; 
v_isSharedCheck_200_ = !lean_is_exclusive(v___x_193_);
if (v_isSharedCheck_200_ == 0)
{
lean_object* v_unused_201_; 
v_unused_201_ = lean_ctor_get(v___x_193_, 0);
lean_dec(v_unused_201_);
v___x_195_ = v___x_193_;
v_isShared_196_ = v_isSharedCheck_200_;
goto v_resetjp_194_;
}
else
{
lean_dec(v___x_193_);
v___x_195_ = lean_box(0);
v_isShared_196_ = v_isSharedCheck_200_;
goto v_resetjp_194_;
}
v_resetjp_194_:
{
lean_object* v___x_198_; 
if (v_isShared_196_ == 0)
{
lean_ctor_set_tag(v___x_195_, 1);
lean_ctor_set(v___x_195_, 0, v_a_192_);
v___x_198_ = v___x_195_;
goto v_reusejp_197_;
}
else
{
lean_object* v_reuseFailAlloc_199_; 
v_reuseFailAlloc_199_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_199_, 0, v_a_192_);
v___x_198_ = v_reuseFailAlloc_199_;
goto v_reusejp_197_;
}
v_reusejp_197_:
{
return v___x_198_;
}
}
}
else
{
lean_dec(v_a_192_);
return v___x_193_;
}
}
}
}
else
{
lean_object* v_a_296_; lean_object* v___x_298_; uint8_t v_isShared_299_; uint8_t v_isSharedCheck_303_; 
v_a_296_ = lean_ctor_get(v___x_176_, 0);
v_isSharedCheck_303_ = !lean_is_exclusive(v___x_176_);
if (v_isSharedCheck_303_ == 0)
{
v___x_298_ = v___x_176_;
v_isShared_299_ = v_isSharedCheck_303_;
goto v_resetjp_297_;
}
else
{
lean_inc(v_a_296_);
lean_dec(v___x_176_);
v___x_298_ = lean_box(0);
v_isShared_299_ = v_isSharedCheck_303_;
goto v_resetjp_297_;
}
v_resetjp_297_:
{
lean_object* v___x_301_; 
if (v_isShared_299_ == 0)
{
v___x_301_ = v___x_298_;
goto v_reusejp_300_;
}
else
{
lean_object* v_reuseFailAlloc_302_; 
v_reuseFailAlloc_302_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_302_, 0, v_a_296_);
v___x_301_ = v_reuseFailAlloc_302_;
goto v_reusejp_300_;
}
v_reusejp_300_:
{
return v___x_301_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object* v_a_304_){
_start:
{
lean_object* v_res_305_; 
v_res_305_ = lp_allocation__audit_generatedFailure();
return v_res_305_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object* v_phase_308_, lean_object* v_a_00___x40___internal___hyg_309_){
_start:
{
uint32_t v_phase_boxed_310_; lean_object* v_res_311_; 
v_phase_boxed_310_ = lean_unbox_uint32(v_phase_308_);
lean_dec(v_phase_308_);
v_res_311_ = audit_mark_lean(v_phase_boxed_310_);
return v_res_311_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object* v_a_312_, lean_object* v_scope_313_, lean_object* v_range_314_, lean_object* v_b_315_, lean_object* v_i_316_){
_start:
{
lean_object* v_stop_318_; lean_object* v_step_319_; uint8_t v___x_320_; 
v_stop_318_ = lean_ctor_get(v_range_314_, 1);
v_step_319_ = lean_ctor_get(v_range_314_, 2);
v___x_320_ = lean_nat_dec_lt(v_i_316_, v_stop_318_);
if (v___x_320_ == 0)
{
lean_object* v___x_321_; 
lean_dec(v_i_316_);
v___x_321_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_321_, 0, v_b_315_);
return v___x_321_;
}
else
{
uint32_t v___x_322_; uint64_t v___x_323_; uint64_t v___x_324_; uint64_t v___x_325_; uint64_t v___x_326_; lean_object* v___x_327_; uint8_t v___x_328_; uint32_t v___x_329_; uint64_t v___x_330_; uint64_t v___x_331_; uint32_t v___x_332_; uint64_t v___x_333_; uint64_t v___x_334_; uint64_t v___x_335_; uint32_t v___x_336_; uint64_t v___x_337_; uint32_t v___x_338_; uint64_t v___x_339_; uint32_t v___x_340_; lean_object* v___x_341_; uint64_t v___x_342_; uint64_t v___x_343_; uint64_t v___x_344_; lean_object* v___x_345_; 
v___x_322_ = 0;
v___x_323_ = 16ULL;
v___x_324_ = 7ULL;
v___x_325_ = 85ULL;
v___x_326_ = 9ULL;
v___x_327_ = lean_unsigned_to_nat(0u);
v___x_328_ = lean_nat_dec_eq(v_scope_313_, v___x_327_);
v___x_329_ = 3;
v___x_330_ = 17ULL;
v___x_331_ = 5ULL;
v___x_332_ = 1;
v___x_333_ = 32ULL;
v___x_334_ = 11ULL;
v___x_335_ = 20ULL;
v___x_336_ = 4;
v___x_337_ = 48ULL;
v___x_338_ = 2;
v___x_339_ = 13ULL;
v___x_340_ = 5;
v___x_341_ = lean_box(0);
v___x_342_ = 64ULL;
v___x_343_ = 35ULL;
v___x_344_ = 40ULL;
v___x_345_ = vastitas_storage_pack3(v_a_312_, v___x_322_, v___x_323_, v___x_324_, v___x_325_, v___x_326_, v___x_328_, v___x_329_, v___x_342_, v___x_343_, v___x_330_, v___x_344_, v___x_328_, v___x_324_, v___x_330_, v___x_331_);
if (lean_obj_tag(v___x_345_) == 0)
{
uint64_t v___x_346_; uint64_t v___x_347_; uint8_t v___x_348_; lean_object* v___x_349_; 
lean_dec_ref_known(v___x_345_, 1);
v___x_346_ = 80ULL;
v___x_347_ = 41ULL;
v___x_348_ = 0;
v___x_349_ = vastitas_gemm_execute(v_a_312_, v___x_329_, v___x_342_, v___x_343_, v___x_330_, v___x_344_, v___x_328_, v___x_328_, v___x_332_, v___x_333_, v___x_330_, v___x_334_, v___x_335_, v___x_328_, v___x_328_, v___x_336_, v___x_346_, v___x_343_, v___x_334_, v___x_347_, v___x_328_, v___x_348_);
if (lean_obj_tag(v___x_349_) == 0)
{
uint64_t v___x_350_; uint64_t v___x_351_; uint64_t v___x_352_; lean_object* v___x_353_; 
lean_dec_ref_known(v___x_349_, 1);
v___x_350_ = 112ULL;
v___x_351_ = 77ULL;
v___x_352_ = 42ULL;
v___x_353_ = vastitas_storage_regroup3(v_a_312_, v___x_336_, v___x_346_, v___x_343_, v___x_334_, v___x_347_, v___x_328_, v___x_329_, v___x_350_, v___x_351_, v___x_331_, v___x_325_, v___x_328_, v___x_324_, v___x_331_, v___x_334_, v___x_337_, v___x_352_);
if (lean_obj_tag(v___x_353_) == 0)
{
uint64_t v___x_354_; uint64_t v___x_355_; lean_object* v___x_356_; 
lean_dec_ref_known(v___x_353_, 1);
v___x_354_ = 96ULL;
v___x_355_ = 84ULL;
v___x_356_ = vastitas_gemm_execute(v_a_312_, v___x_329_, v___x_350_, v___x_351_, v___x_331_, v___x_325_, v___x_328_, v___x_328_, v___x_338_, v___x_337_, v___x_331_, v___x_339_, v___x_326_, v___x_328_, v___x_328_, v___x_340_, v___x_354_, v___x_351_, v___x_339_, v___x_355_, v___x_328_, v___x_348_);
if (lean_obj_tag(v___x_356_) == 0)
{
lean_object* v___x_357_; 
lean_dec_ref_known(v___x_356_, 1);
v___x_357_ = lean_nat_add(v_i_316_, v_step_319_);
lean_dec(v_i_316_);
v_b_315_ = v___x_341_;
v_i_316_ = v___x_357_;
goto _start;
}
else
{
lean_dec(v_i_316_);
return v___x_356_;
}
}
else
{
lean_dec(v_i_316_);
return v___x_353_;
}
}
else
{
lean_dec(v_i_316_);
return v___x_349_;
}
}
else
{
lean_dec(v_i_316_);
return v___x_345_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object* v_a_359_, lean_object* v_scope_360_, lean_object* v_range_361_, lean_object* v_b_362_, lean_object* v_i_363_, lean_object* v___y_364_){
_start:
{
lean_object* v_res_365_; 
v_res_365_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_359_, v_scope_360_, v_range_361_, v_b_362_, v_i_363_);
lean_dec_ref(v_range_361_);
lean_dec(v_scope_360_);
lean_dec(v_a_359_);
return v_res_365_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object* v_range_366_, lean_object* v_b_367_, lean_object* v_i_368_){
_start:
{
lean_object* v_stop_370_; lean_object* v_step_371_; uint8_t v___x_372_; 
v_stop_370_ = lean_ctor_get(v_range_366_, 1);
v_step_371_ = lean_ctor_get(v_range_366_, 2);
v___x_372_ = lean_nat_dec_lt(v_i_368_, v_stop_370_);
if (v___x_372_ == 0)
{
lean_object* v___x_373_; 
lean_dec(v_i_368_);
v___x_373_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_373_, 0, v_b_367_);
return v___x_373_;
}
else
{
lean_object* v___x_374_; lean_object* v___x_375_; 
v___x_374_ = lean_box(0);
v___x_375_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_375_) == 0)
{
lean_object* v___x_376_; 
lean_dec_ref_known(v___x_375_, 1);
v___x_376_ = lean_nat_add(v_i_368_, v_step_371_);
lean_dec(v_i_368_);
v_b_367_ = v___x_374_;
v_i_368_ = v___x_376_;
goto _start;
}
else
{
lean_dec(v_i_368_);
return v___x_375_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object* v_range_378_, lean_object* v_b_379_, lean_object* v_i_380_, lean_object* v___y_381_){
_start:
{
lean_object* v_res_382_; 
v_res_382_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_378_, v_b_379_, v_i_380_);
lean_dec_ref(v_range_378_);
return v_res_382_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_391_){
_start:
{
lean_object* v___x_393_; lean_object* v___x_394_; lean_object* v_impl_395_; lean_object* v___x_396_; lean_object* v___x_397_; lean_object* v___x_398_; lean_object* v___x_399_; lean_object* v_scope_400_; lean_object* v___x_401_; lean_object* v___x_402_; lean_object* v___x_403_; lean_object* v___x_404_; lean_object* v_reps_405_; lean_object* v___x_406_; lean_object* v___x_407_; lean_object* v___x_408_; uint8_t v_verify_409_; uint32_t v___x_410_; lean_object* v___x_411_; 
v___x_393_ = ((lean_object*)(lp_allocation__audit_main___closed__0));
v___x_394_ = lean_unsigned_to_nat(0u);
v_impl_395_ = l_List_get_x21Internal___redArg(v___x_393_, v_args_391_, v___x_394_);
v___x_396_ = lean_unsigned_to_nat(1u);
v___x_397_ = l_List_get_x21Internal___redArg(v___x_393_, v_args_391_, v___x_396_);
v___x_398_ = lean_string_utf8_byte_size(v___x_397_);
v___x_399_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_399_, 0, v___x_397_);
lean_ctor_set(v___x_399_, 1, v___x_394_);
lean_ctor_set(v___x_399_, 2, v___x_398_);
v_scope_400_ = l_String_Slice_toNat_x21(v___x_399_);
lean_dec_ref_known(v___x_399_, 3);
v___x_401_ = lean_unsigned_to_nat(2u);
v___x_402_ = l_List_get_x21Internal___redArg(v___x_393_, v_args_391_, v___x_401_);
v___x_403_ = lean_string_utf8_byte_size(v___x_402_);
v___x_404_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_404_, 0, v___x_402_);
lean_ctor_set(v___x_404_, 1, v___x_394_);
lean_ctor_set(v___x_404_, 2, v___x_403_);
v_reps_405_ = l_String_Slice_toNat_x21(v___x_404_);
lean_dec_ref_known(v___x_404_, 3);
v___x_406_ = lean_unsigned_to_nat(3u);
v___x_407_ = l_List_get_x21Internal___redArg(v___x_393_, v_args_391_, v___x_406_);
lean_dec(v_args_391_);
v___x_408_ = ((lean_object*)(lp_allocation__audit_main___closed__1));
v_verify_409_ = lean_string_dec_eq(v___x_407_, v___x_408_);
lean_dec(v___x_407_);
v___x_410_ = 1;
v___x_411_ = audit_mark_lean(v___x_410_);
if (lean_obj_tag(v___x_411_) == 0)
{
lean_object* v___x_412_; 
lean_dec_ref_known(v___x_411_, 1);
v___x_412_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_412_) == 0)
{
uint32_t v___x_413_; lean_object* v___x_414_; 
lean_dec_ref_known(v___x_412_, 1);
v___x_413_ = 2;
v___x_414_ = audit_mark_lean(v___x_413_);
if (lean_obj_tag(v___x_414_) == 0)
{
lean_object* v___x_415_; uint8_t v___x_416_; 
lean_dec_ref_known(v___x_414_, 1);
v___x_415_ = ((lean_object*)(lp_allocation__audit_main___closed__2));
v___x_416_ = lean_string_dec_eq(v_impl_395_, v___x_415_);
if (v___x_416_ == 0)
{
lean_object* v___x_417_; uint8_t v___x_418_; 
v___x_417_ = ((lean_object*)(lp_allocation__audit_main___closed__3));
v___x_418_ = lean_string_dec_eq(v_impl_395_, v___x_417_);
lean_dec(v_impl_395_);
if (v___x_418_ == 0)
{
uint8_t v___x_419_; 
v___x_419_ = lean_nat_dec_eq(v_scope_400_, v___x_394_);
if (v___x_419_ == 0)
{
uint64_t v___x_420_; lean_object* v___x_421_; 
v___x_420_ = 9223372036854775807ULL;
v___x_421_ = vastitas_storage_new(v___x_420_);
if (lean_obj_tag(v___x_421_) == 0)
{
lean_object* v_a_422_; lean_object* v___y_424_; uint32_t v___x_437_; uint8_t v___x_438_; uint64_t v___x_439_; lean_object* v___x_440_; 
v_a_422_ = lean_ctor_get(v___x_421_, 0);
lean_inc(v_a_422_);
lean_dec_ref_known(v___x_421_, 1);
v___x_437_ = 0;
v___x_438_ = 1;
v___x_439_ = 769ULL;
v___x_440_ = vastitas_storage_allocate(v_a_422_, v___x_437_, v___x_438_, v___x_439_);
if (lean_obj_tag(v___x_440_) == 0)
{
uint64_t v___x_441_; uint64_t v___x_442_; uint64_t v___x_443_; uint64_t v___x_444_; lean_object* v___x_445_; 
lean_dec_ref_known(v___x_440_, 1);
v___x_441_ = 0ULL;
v___x_442_ = 1ULL;
v___x_443_ = 13842939354630062080ULL;
v___x_444_ = 4613937818241073152ULL;
v___x_445_ = vastitas_storage_fill(v_a_422_, v___x_437_, v___x_441_, v___x_439_, v___x_442_, v___x_439_, v___x_419_, v___x_438_, v___x_443_, v___x_444_);
if (lean_obj_tag(v___x_445_) == 0)
{
uint64_t v___x_446_; uint64_t v___x_447_; uint64_t v___x_448_; uint64_t v___x_449_; uint64_t v___x_450_; uint64_t v___x_451_; lean_object* v___x_452_; 
lean_dec_ref_known(v___x_445_, 1);
v___x_446_ = 16ULL;
v___x_447_ = 7ULL;
v___x_448_ = 85ULL;
v___x_449_ = 9ULL;
v___x_450_ = 4593671619917905920ULL;
v___x_451_ = 4598175219545276416ULL;
v___x_452_ = vastitas_storage_fill(v_a_422_, v___x_437_, v___x_446_, v___x_447_, v___x_448_, v___x_449_, v___x_419_, v___x_438_, v___x_450_, v___x_451_);
if (lean_obj_tag(v___x_452_) == 0)
{
uint64_t v___x_453_; uint64_t v___x_454_; lean_object* v___x_455_; 
lean_dec_ref_known(v___x_452_, 1);
v___x_453_ = 4607182418800017408ULL;
v___x_454_ = 13826050856027422720ULL;
v___x_455_ = vastitas_storage_store(v_a_422_, v___x_437_, v___x_446_, v___x_447_, v___x_448_, v___x_449_, v___x_419_, v___x_441_, v___x_441_, v___x_438_, v___x_453_, v___x_454_);
if (lean_obj_tag(v___x_455_) == 0)
{
uint64_t v___x_456_; uint64_t v___x_457_; lean_object* v___x_458_; 
lean_dec_ref_known(v___x_455_, 1);
v___x_456_ = 6ULL;
v___x_457_ = 4604930618986332160ULL;
v___x_458_ = vastitas_storage_store(v_a_422_, v___x_437_, v___x_446_, v___x_447_, v___x_448_, v___x_449_, v___x_419_, v___x_456_, v___x_442_, v___x_438_, v___x_454_, v___x_457_);
if (lean_obj_tag(v___x_458_) == 0)
{
uint64_t v___x_459_; lean_object* v___x_460_; 
lean_dec_ref_known(v___x_458_, 1);
v___x_459_ = 225ULL;
v___x_460_ = vastitas_storage_allocate(v_a_422_, v___x_410_, v___x_438_, v___x_459_);
if (lean_obj_tag(v___x_460_) == 0)
{
lean_object* v___x_461_; 
lean_dec_ref_known(v___x_460_, 1);
v___x_461_ = vastitas_storage_fill(v_a_422_, v___x_410_, v___x_441_, v___x_459_, v___x_442_, v___x_459_, v___x_419_, v___x_438_, v___x_443_, v___x_444_);
if (lean_obj_tag(v___x_461_) == 0)
{
uint64_t v___x_462_; uint64_t v___x_463_; uint64_t v___x_464_; uint64_t v___x_465_; uint64_t v___x_466_; lean_object* v___x_467_; 
lean_dec_ref_known(v___x_461_, 1);
v___x_462_ = 32ULL;
v___x_463_ = 17ULL;
v___x_464_ = 11ULL;
v___x_465_ = 20ULL;
v___x_466_ = 13821547256400052224ULL;
v___x_467_ = vastitas_storage_fill(v_a_422_, v___x_410_, v___x_462_, v___x_463_, v___x_464_, v___x_465_, v___x_419_, v___x_438_, v___x_466_, v___x_450_);
if (lean_obj_tag(v___x_467_) == 0)
{
uint64_t v___x_468_; uint64_t v___x_469_; lean_object* v___x_470_; 
lean_dec_ref_known(v___x_467_, 1);
v___x_468_ = 10ULL;
v___x_469_ = 4602678819172646912ULL;
v___x_470_ = vastitas_storage_store(v_a_422_, v___x_410_, v___x_462_, v___x_463_, v___x_464_, v___x_465_, v___x_419_, v___x_441_, v___x_468_, v___x_438_, v___x_469_, v___x_451_);
if (lean_obj_tag(v___x_470_) == 0)
{
uint64_t v___x_471_; lean_object* v___x_472_; 
lean_dec_ref_known(v___x_470_, 1);
v___x_471_ = 13828302655841107968ULL;
v___x_472_ = vastitas_storage_store(v_a_422_, v___x_410_, v___x_462_, v___x_463_, v___x_464_, v___x_465_, v___x_419_, v___x_446_, v___x_441_, v___x_438_, v___x_471_, v___x_454_);
if (lean_obj_tag(v___x_472_) == 0)
{
uint64_t v___x_473_; lean_object* v___x_474_; 
lean_dec_ref_known(v___x_472_, 1);
v___x_473_ = 123ULL;
v___x_474_ = vastitas_storage_allocate(v_a_422_, v___x_413_, v___x_438_, v___x_473_);
if (lean_obj_tag(v___x_474_) == 0)
{
lean_object* v___x_475_; 
lean_dec_ref_known(v___x_474_, 1);
v___x_475_ = vastitas_storage_fill(v_a_422_, v___x_413_, v___x_441_, v___x_473_, v___x_442_, v___x_473_, v___x_419_, v___x_438_, v___x_443_, v___x_444_);
if (lean_obj_tag(v___x_475_) == 0)
{
uint64_t v___x_476_; uint64_t v___x_477_; uint64_t v___x_478_; lean_object* v___x_479_; 
lean_dec_ref_known(v___x_475_, 1);
v___x_476_ = 48ULL;
v___x_477_ = 5ULL;
v___x_478_ = 13ULL;
v___x_479_ = vastitas_storage_fill(v_a_422_, v___x_413_, v___x_476_, v___x_477_, v___x_478_, v___x_449_, v___x_419_, v___x_438_, v___x_469_, v___x_466_);
if (lean_obj_tag(v___x_479_) == 0)
{
uint64_t v___x_480_; lean_object* v___x_481_; 
lean_dec_ref_known(v___x_479_, 1);
v___x_480_ = 4ULL;
v___x_481_ = vastitas_storage_store(v_a_422_, v___x_413_, v___x_476_, v___x_477_, v___x_478_, v___x_449_, v___x_419_, v___x_480_, v___x_441_, v___x_438_, v___x_466_, v___x_469_);
if (lean_obj_tag(v___x_481_) == 0)
{
uint64_t v___x_482_; lean_object* v___x_483_; 
lean_dec_ref_known(v___x_481_, 1);
v___x_482_ = 12ULL;
v___x_483_ = vastitas_storage_store(v_a_422_, v___x_413_, v___x_476_, v___x_477_, v___x_478_, v___x_449_, v___x_419_, v___x_441_, v___x_482_, v___x_438_, v___x_457_, v___x_471_);
if (lean_obj_tag(v___x_483_) == 0)
{
uint32_t v___x_484_; uint64_t v___x_485_; lean_object* v___x_486_; 
lean_dec_ref_known(v___x_483_, 1);
v___x_484_ = 3;
v___x_485_ = 687ULL;
v___x_486_ = vastitas_storage_allocate(v_a_422_, v___x_484_, v___x_438_, v___x_485_);
if (lean_obj_tag(v___x_486_) == 0)
{
lean_object* v___x_487_; 
lean_dec_ref_known(v___x_486_, 1);
v___x_487_ = vastitas_storage_fill(v_a_422_, v___x_484_, v___x_441_, v___x_485_, v___x_442_, v___x_485_, v___x_419_, v___x_438_, v___x_443_, v___x_444_);
if (lean_obj_tag(v___x_487_) == 0)
{
uint32_t v___x_488_; uint64_t v___x_489_; lean_object* v___x_490_; 
lean_dec_ref_known(v___x_487_, 1);
v___x_488_ = 4;
v___x_489_ = 459ULL;
v___x_490_ = vastitas_storage_allocate(v_a_422_, v___x_488_, v___x_438_, v___x_489_);
if (lean_obj_tag(v___x_490_) == 0)
{
lean_object* v___x_491_; 
lean_dec_ref_known(v___x_490_, 1);
v___x_491_ = vastitas_storage_fill(v_a_422_, v___x_488_, v___x_441_, v___x_489_, v___x_442_, v___x_489_, v___x_419_, v___x_438_, v___x_443_, v___x_444_);
if (lean_obj_tag(v___x_491_) == 0)
{
uint32_t v___x_492_; uint64_t v___x_493_; lean_object* v___x_494_; 
lean_dec_ref_known(v___x_491_, 1);
v___x_492_ = 5;
v___x_493_ = 1101ULL;
v___x_494_ = vastitas_storage_allocate(v_a_422_, v___x_492_, v___x_438_, v___x_493_);
if (lean_obj_tag(v___x_494_) == 0)
{
lean_object* v___x_495_; 
lean_dec_ref_known(v___x_494_, 1);
v___x_495_ = vastitas_storage_fill(v_a_422_, v___x_492_, v___x_441_, v___x_493_, v___x_442_, v___x_493_, v___x_419_, v___x_438_, v___x_443_, v___x_444_);
if (lean_obj_tag(v___x_495_) == 0)
{
uint32_t v___x_496_; uint64_t v___x_497_; lean_object* v___x_498_; 
lean_dec_ref_known(v___x_495_, 1);
v___x_496_ = lean_uint32_of_nat(v_scope_400_);
v___x_497_ = lean_uint64_of_nat(v_reps_405_);
v___x_498_ = bench_begin_lean(v___x_496_, v___x_497_, v_verify_409_);
if (lean_obj_tag(v___x_498_) == 0)
{
lean_object* v___x_499_; lean_object* v___x_500_; lean_object* v___x_501_; 
lean_dec_ref_known(v___x_498_, 1);
v___x_499_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_499_, 0, v___x_394_);
lean_ctor_set(v___x_499_, 1, v_reps_405_);
lean_ctor_set(v___x_499_, 2, v___x_396_);
v___x_500_ = lean_box(0);
v___x_501_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_422_, v_scope_400_, v___x_499_, v___x_500_, v___x_394_);
lean_dec_ref_known(v___x_499_, 3);
lean_dec(v_scope_400_);
if (lean_obj_tag(v___x_501_) == 0)
{
lean_object* v___x_502_; 
lean_dec_ref_known(v___x_501_, 1);
v___x_502_ = bench_stop_lean();
if (lean_obj_tag(v___x_502_) == 0)
{
lean_object* v___x_503_; 
lean_dec_ref_known(v___x_502_, 1);
v___x_503_ = bench_verify_lean(v_a_422_, v___x_497_);
if (lean_obj_tag(v___x_503_) == 0)
{
uint64_t v___x_504_; uint64_t v___x_505_; uint64_t v___x_506_; uint64_t v___x_507_; uint64_t v___x_508_; lean_object* v___x_509_; 
lean_dec_ref_known(v___x_503_, 1);
v___x_504_ = 96ULL;
v___x_505_ = 77ULL;
v___x_506_ = 84ULL;
v___x_507_ = 13835471471654207488ULL;
v___x_508_ = 13830941483747770368ULL;
v___x_509_ = vastitas_storage_expect(v_a_422_, v___x_492_, v___x_504_, v___x_505_, v___x_478_, v___x_506_, v___x_419_, v___x_441_, v___x_441_, v___x_438_, v___x_507_, v___x_508_);
if (lean_obj_tag(v___x_509_) == 0)
{
uint64_t v___x_510_; uint64_t v___x_511_; lean_object* v___x_512_; 
lean_dec_ref_known(v___x_509_, 1);
v___x_510_ = 13840120206816444416ULL;
v___x_511_ = 13831803500863946752ULL;
v___x_512_ = vastitas_storage_expect(v_a_422_, v___x_492_, v___x_504_, v___x_505_, v___x_478_, v___x_506_, v___x_419_, v___x_456_, v___x_482_, v___x_438_, v___x_510_, v___x_511_);
if (lean_obj_tag(v___x_512_) == 0)
{
uint64_t v___x_513_; uint64_t v___x_514_; uint64_t v___x_515_; lean_object* v___x_516_; 
lean_dec_ref_known(v___x_512_, 1);
v___x_513_ = 76ULL;
v___x_514_ = 13835172404491452416ULL;
v___x_515_ = 13827528599655153664ULL;
v___x_516_ = vastitas_storage_expect(v_a_422_, v___x_492_, v___x_504_, v___x_505_, v___x_478_, v___x_506_, v___x_419_, v___x_513_, v___x_441_, v___x_438_, v___x_514_, v___x_515_);
if (lean_obj_tag(v___x_516_) == 0)
{
lean_object* v___x_517_; 
lean_dec_ref_known(v___x_516_, 1);
v___x_517_ = vastitas_storage_drop(v_a_422_, v___x_492_);
if (lean_obj_tag(v___x_517_) == 0)
{
lean_object* v___x_518_; 
lean_dec_ref_known(v___x_517_, 1);
v___x_518_ = vastitas_storage_drop(v_a_422_, v___x_488_);
if (lean_obj_tag(v___x_518_) == 0)
{
lean_object* v___x_519_; 
lean_dec_ref_known(v___x_518_, 1);
v___x_519_ = vastitas_storage_drop(v_a_422_, v___x_484_);
if (lean_obj_tag(v___x_519_) == 0)
{
lean_object* v___x_520_; 
lean_dec_ref_known(v___x_519_, 1);
v___x_520_ = vastitas_storage_drop(v_a_422_, v___x_413_);
if (lean_obj_tag(v___x_520_) == 0)
{
lean_object* v___x_521_; 
lean_dec_ref_known(v___x_520_, 1);
v___x_521_ = vastitas_storage_drop(v_a_422_, v___x_410_);
if (lean_obj_tag(v___x_521_) == 0)
{
lean_object* v___x_522_; 
lean_dec_ref_known(v___x_521_, 1);
v___x_522_ = vastitas_storage_drop(v_a_422_, v___x_437_);
v___y_424_ = v___x_522_;
goto v___jp_423_;
}
else
{
v___y_424_ = v___x_521_;
goto v___jp_423_;
}
}
else
{
v___y_424_ = v___x_520_;
goto v___jp_423_;
}
}
else
{
v___y_424_ = v___x_519_;
goto v___jp_423_;
}
}
else
{
v___y_424_ = v___x_518_;
goto v___jp_423_;
}
}
else
{
v___y_424_ = v___x_517_;
goto v___jp_423_;
}
}
else
{
v___y_424_ = v___x_516_;
goto v___jp_423_;
}
}
else
{
v___y_424_ = v___x_512_;
goto v___jp_423_;
}
}
else
{
v___y_424_ = v___x_509_;
goto v___jp_423_;
}
}
else
{
v___y_424_ = v___x_503_;
goto v___jp_423_;
}
}
else
{
v___y_424_ = v___x_502_;
goto v___jp_423_;
}
}
else
{
v___y_424_ = v___x_501_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_498_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_495_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_494_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_491_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_490_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_487_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_486_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_483_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_481_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_479_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_475_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_474_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_472_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_470_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_467_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_461_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_460_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_458_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_455_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_452_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_445_;
goto v___jp_423_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v___y_424_ = v___x_440_;
goto v___jp_423_;
}
v___jp_423_:
{
if (lean_obj_tag(v___y_424_) == 0)
{
lean_object* v___x_425_; 
lean_dec_ref_known(v___y_424_, 1);
v___x_425_ = vastitas_storage_close(v_a_422_);
lean_dec(v_a_422_);
if (lean_obj_tag(v___x_425_) == 0)
{
lean_object* v___x_426_; 
lean_dec_ref_known(v___x_425_, 1);
v___x_426_ = bench_report_lean();
return v___x_426_;
}
else
{
return v___x_425_;
}
}
else
{
lean_object* v_a_427_; lean_object* v___x_428_; 
v_a_427_ = lean_ctor_get(v___y_424_, 0);
lean_inc(v_a_427_);
lean_dec_ref_known(v___y_424_, 1);
v___x_428_ = vastitas_storage_close(v_a_422_);
lean_dec(v_a_422_);
if (lean_obj_tag(v___x_428_) == 0)
{
lean_object* v___x_430_; uint8_t v_isShared_431_; uint8_t v_isSharedCheck_435_; 
v_isSharedCheck_435_ = !lean_is_exclusive(v___x_428_);
if (v_isSharedCheck_435_ == 0)
{
lean_object* v_unused_436_; 
v_unused_436_ = lean_ctor_get(v___x_428_, 0);
lean_dec(v_unused_436_);
v___x_430_ = v___x_428_;
v_isShared_431_ = v_isSharedCheck_435_;
goto v_resetjp_429_;
}
else
{
lean_dec(v___x_428_);
v___x_430_ = lean_box(0);
v_isShared_431_ = v_isSharedCheck_435_;
goto v_resetjp_429_;
}
v_resetjp_429_:
{
lean_object* v___x_433_; 
if (v_isShared_431_ == 0)
{
lean_ctor_set_tag(v___x_430_, 1);
lean_ctor_set(v___x_430_, 0, v_a_427_);
v___x_433_ = v___x_430_;
goto v_reusejp_432_;
}
else
{
lean_object* v_reuseFailAlloc_434_; 
v_reuseFailAlloc_434_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_434_, 0, v_a_427_);
v___x_433_ = v_reuseFailAlloc_434_;
goto v_reusejp_432_;
}
v_reusejp_432_:
{
return v___x_433_;
}
}
}
else
{
lean_dec(v_a_427_);
return v___x_428_;
}
}
}
}
else
{
lean_object* v_a_523_; lean_object* v___x_525_; uint8_t v_isShared_526_; uint8_t v_isSharedCheck_530_; 
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
v_a_523_ = lean_ctor_get(v___x_421_, 0);
v_isSharedCheck_530_ = !lean_is_exclusive(v___x_421_);
if (v_isSharedCheck_530_ == 0)
{
v___x_525_ = v___x_421_;
v_isShared_526_ = v_isSharedCheck_530_;
goto v_resetjp_524_;
}
else
{
lean_inc(v_a_523_);
lean_dec(v___x_421_);
v___x_525_ = lean_box(0);
v_isShared_526_ = v_isSharedCheck_530_;
goto v_resetjp_524_;
}
v_resetjp_524_:
{
lean_object* v___x_528_; 
if (v_isShared_526_ == 0)
{
v___x_528_ = v___x_525_;
goto v_reusejp_527_;
}
else
{
lean_object* v_reuseFailAlloc_529_; 
v_reuseFailAlloc_529_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_529_, 0, v_a_523_);
v___x_528_ = v_reuseFailAlloc_529_;
goto v_reusejp_527_;
}
v_reusejp_527_:
{
return v___x_528_;
}
}
}
}
else
{
uint32_t v___x_531_; uint64_t v___x_532_; lean_object* v___x_533_; 
lean_dec(v_scope_400_);
v___x_531_ = 0;
v___x_532_ = lean_uint64_of_nat(v_reps_405_);
v___x_533_ = bench_begin_lean(v___x_531_, v___x_532_, v_verify_409_);
if (lean_obj_tag(v___x_533_) == 0)
{
lean_object* v___x_534_; lean_object* v___x_535_; lean_object* v___x_536_; 
lean_dec_ref_known(v___x_533_, 1);
v___x_534_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_534_, 0, v___x_394_);
lean_ctor_set(v___x_534_, 1, v_reps_405_);
lean_ctor_set(v___x_534_, 2, v___x_396_);
v___x_535_ = lean_box(0);
v___x_536_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v___x_534_, v___x_535_, v___x_394_);
lean_dec_ref_known(v___x_534_, 3);
if (lean_obj_tag(v___x_536_) == 0)
{
lean_object* v___x_537_; 
lean_dec_ref_known(v___x_536_, 1);
v___x_537_ = bench_stop_lean();
if (lean_obj_tag(v___x_537_) == 0)
{
lean_object* v___x_538_; 
lean_dec_ref_known(v___x_537_, 1);
v___x_538_ = bench_report_lean();
return v___x_538_;
}
else
{
return v___x_537_;
}
}
else
{
return v___x_536_;
}
}
else
{
lean_dec(v_reps_405_);
return v___x_533_;
}
}
}
else
{
uint32_t v___x_539_; uint64_t v___x_540_; lean_object* v___x_541_; 
v___x_539_ = lean_uint32_of_nat(v_scope_400_);
lean_dec(v_scope_400_);
v___x_540_ = lean_uint64_of_nat(v_reps_405_);
lean_dec(v_reps_405_);
v___x_541_ = bench_c_run_lean(v___x_539_, v___x_540_, v_verify_409_);
if (lean_obj_tag(v___x_541_) == 0)
{
lean_object* v___x_542_; 
lean_dec_ref_known(v___x_541_, 1);
v___x_542_ = bench_report_lean();
return v___x_542_;
}
else
{
return v___x_541_;
}
}
}
else
{
uint32_t v___x_543_; uint64_t v___x_544_; lean_object* v___x_545_; 
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
lean_dec(v_impl_395_);
v___x_543_ = 0;
v___x_544_ = 1ULL;
v___x_545_ = bench_begin_lean(v___x_543_, v___x_544_, v___x_416_);
if (lean_obj_tag(v___x_545_) == 0)
{
lean_object* v___x_546_; 
lean_dec_ref_known(v___x_545_, 1);
v___x_546_ = lp_allocation__audit_generatedFailure();
if (lean_obj_tag(v___x_546_) == 0)
{
lean_object* v___x_548_; uint8_t v_isShared_549_; uint8_t v_isSharedCheck_554_; 
v_isSharedCheck_554_ = !lean_is_exclusive(v___x_546_);
if (v_isSharedCheck_554_ == 0)
{
lean_object* v_unused_555_; 
v_unused_555_ = lean_ctor_get(v___x_546_, 0);
lean_dec(v_unused_555_);
v___x_548_ = v___x_546_;
v_isShared_549_ = v_isSharedCheck_554_;
goto v_resetjp_547_;
}
else
{
lean_dec(v___x_546_);
v___x_548_ = lean_box(0);
v_isShared_549_ = v_isSharedCheck_554_;
goto v_resetjp_547_;
}
v_resetjp_547_:
{
lean_object* v___x_550_; lean_object* v___x_552_; 
v___x_550_ = ((lean_object*)(lp_allocation__audit_main___closed__5));
if (v_isShared_549_ == 0)
{
lean_ctor_set_tag(v___x_548_, 1);
lean_ctor_set(v___x_548_, 0, v___x_550_);
v___x_552_ = v___x_548_;
goto v_reusejp_551_;
}
else
{
lean_object* v_reuseFailAlloc_553_; 
v_reuseFailAlloc_553_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_553_, 0, v___x_550_);
v___x_552_ = v_reuseFailAlloc_553_;
goto v_reusejp_551_;
}
v_reusejp_551_:
{
return v___x_552_;
}
}
}
else
{
lean_object* v_a_556_; lean_object* v___x_557_; lean_object* v___x_558_; uint8_t v___x_559_; 
v_a_556_ = lean_ctor_get(v___x_546_, 0);
lean_inc(v_a_556_);
v___x_557_ = lean_io_error_to_string(v_a_556_);
v___x_558_ = ((lean_object*)(lp_allocation__audit_main___closed__6));
v___x_559_ = lean_string_dec_eq(v___x_557_, v___x_558_);
lean_dec_ref(v___x_557_);
if (v___x_559_ == 0)
{
return v___x_546_;
}
else
{
lean_object* v___x_560_; 
lean_dec_ref_known(v___x_546_, 1);
v___x_560_ = bench_stop_lean();
if (lean_obj_tag(v___x_560_) == 0)
{
lean_object* v___x_561_; 
lean_dec_ref_known(v___x_560_, 1);
v___x_561_ = bench_report_lean();
return v___x_561_;
}
else
{
return v___x_560_;
}
}
}
}
else
{
return v___x_545_;
}
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
lean_dec(v_impl_395_);
return v___x_414_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
lean_dec(v_impl_395_);
return v___x_412_;
}
}
else
{
lean_dec(v_reps_405_);
lean_dec(v_scope_400_);
lean_dec(v_impl_395_);
return v___x_411_;
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object* v_args_562_, lean_object* v_a_563_){
_start:
{
lean_object* v_res_564_; 
v_res_564_ = _lean_main(v_args_562_);
return v_res_564_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object* v_a_565_, lean_object* v_scope_566_, lean_object* v_range_567_, lean_object* v_b_568_, lean_object* v_i_569_, lean_object* v_hs_570_, lean_object* v_hl_571_){
_start:
{
lean_object* v___x_573_; 
v___x_573_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_565_, v_scope_566_, v_range_567_, v_b_568_, v_i_569_);
return v___x_573_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object* v_a_574_, lean_object* v_scope_575_, lean_object* v_range_576_, lean_object* v_b_577_, lean_object* v_i_578_, lean_object* v_hs_579_, lean_object* v_hl_580_, lean_object* v___y_581_){
_start:
{
lean_object* v_res_582_; 
v_res_582_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(v_a_574_, v_scope_575_, v_range_576_, v_b_577_, v_i_578_, v_hs_579_, v_hl_580_);
lean_dec_ref(v_range_576_);
lean_dec(v_scope_575_);
lean_dec(v_a_574_);
return v_res_582_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object* v_range_583_, lean_object* v_b_584_, lean_object* v_i_585_, lean_object* v_hs_586_, lean_object* v_hl_587_){
_start:
{
lean_object* v___x_589_; 
v___x_589_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_583_, v_b_584_, v_i_585_);
return v___x_589_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object* v_range_590_, lean_object* v_b_591_, lean_object* v_i_592_, lean_object* v_hs_593_, lean_object* v_hl_594_, lean_object* v___y_595_){
_start:
{
lean_object* v_res_596_; 
v_res_596_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(v_range_590_, v_b_591_, v_i_592_, v_hs_593_, v_hl_594_);
lean_dec_ref(v_range_590_);
return v_res_596_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_vastitas__storage__native_VastitasStorageNative(uint8_t builtin);
lean_object* initialize_vastitas__gemm__native_VastitasGemmNative(uint8_t builtin);
lean_object* initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_allocation__audit_Main(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__storage__native_VastitasStorageNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__gemm__native_VastitasGemmNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_allocation__audit_VastitasGenerated_f__0 = _init_lp_allocation__audit_VastitasGenerated_f__0();
lean_mark_persistent(lp_allocation__audit_VastitasGenerated_f__0);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_allocation__audit_Main(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = 0;
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
