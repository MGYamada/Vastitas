// Lean compiler output
// Module: Main
// Imports: public import Init public meta import Init public import VastitasStorageNative public import VastitasGemmNative public import VastitasKernel.IndexedRuntime
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* vastitas_storage_new(uint64_t);
lean_object* vastitas_storage_close(lean_object*);
lean_object* vastitas_storage_allocate(lean_object*, uint32_t, uint8_t, uint64_t);
lean_object* vastitas_storage_fill(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_store(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_pack3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_gemm_execute(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint8_t);
lean_object* vastitas_storage_regroup3(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
lean_object* vastitas_storage_expect(lean_object*, uint32_t, uint64_t, uint64_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t, uint8_t, uint64_t, uint64_t);
lean_object* vastitas_storage_drop(lean_object*, uint32_t);
lean_object* lean_nat_add(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_List_get_x21Internal___redArg(lean_object*, lean_object*, lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_String_Slice_toNat_x21(lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
uint32_t lean_uint32_of_nat(lean_object*);
uint64_t lean_uint64_of_nat(lean_object*);
lean_object* lean_io_error_to_string(lean_object*);
static lean_once_cell_t lp_allocation__audit_VastitasGenerated_f__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_allocation__audit_VastitasGenerated_f__0___closed__0;
LEAN_EXPORT lean_object* lp_allocation__audit_VastitasGenerated_f__0;
lean_object* bench_begin_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_stop_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object*);
lean_object* bench_report_lean();
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object*);
lean_object* bench_c_run_lean(uint32_t, uint64_t, uint8_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* bench_verify_lean(lean_object*, uint64_t);
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure();
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object*);
lean_object* audit_mark_lean(uint32_t);
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_allocation__audit_main___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 1, .m_capacity = 1, .m_length = 0, .m_data = ""};
static const lean_object* lp_allocation__audit_main___closed__0 = (const lean_object*)&lp_allocation__audit_main___closed__0_value;
static const lean_string_object lp_allocation__audit_main___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "1"};
static const lean_object* lp_allocation__audit_main___closed__1 = (const lean_object*)&lp_allocation__audit_main___closed__1_value;
static const lean_string_object lp_allocation__audit_main___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 8, .m_capacity = 8, .m_length = 7, .m_data = "failure"};
static const lean_object* lp_allocation__audit_main___closed__2 = (const lean_object*)&lp_allocation__audit_main___closed__2_value;
static const lean_string_object lp_allocation__audit_main___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "c"};
static const lean_object* lp_allocation__audit_main___closed__3 = (const lean_object*)&lp_allocation__audit_main___closed__3_value;
static const lean_string_object lp_allocation__audit_main___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 33, .m_capacity = 33, .m_length = 32, .m_data = "expected injected native failure"};
static const lean_object* lp_allocation__audit_main___closed__4 = (const lean_object*)&lp_allocation__audit_main___closed__4_value;
static const lean_ctor_object lp_allocation__audit_main___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*1 + 0, .m_other = 1, .m_tag = 18}, .m_objs = {((lean_object*)&lp_allocation__audit_main___closed__4_value)}};
static const lean_object* lp_allocation__audit_main___closed__5 = (const lean_object*)&lp_allocation__audit_main___closed__5_value;
static const lean_string_object lp_allocation__audit_main___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 44, .m_capacity = 44, .m_length = 43, .m_data = "E_NATIVE_EXPECT: stored bit pattern differs"};
static const lean_object* lp_allocation__audit_main___closed__6 = (const lean_object*)&lp_allocation__audit_main___closed__6_value;
LEAN_EXPORT lean_object* _lean_main(lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0(void){
_start:
{
lean_object* v___x_1_; lean_object* v___x_2_; 
v___x_1_ = lean_unsigned_to_nat(0u);
v___x_2_ = lean_nat_to_int(v___x_1_);
return v___x_2_;
}
}
static lean_object* _init_lp_allocation__audit_VastitasGenerated_f__0(void){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_obj_once(&lp_allocation__audit_VastitasGenerated_f__0___closed__0, &lp_allocation__audit_VastitasGenerated_f__0___closed__0_once, _init_lp_allocation__audit_VastitasGenerated_f__0___closed__0);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchBegin___boxed(lean_object* v_scope_8_, lean_object* v_reps_9_, lean_object* v_verify_10_, lean_object* v_a_00___x40___internal___hyg_11_){
_start:
{
uint32_t v_scope_boxed_12_; uint64_t v_reps_boxed_13_; uint8_t v_verify_boxed_14_; lean_object* v_res_15_; 
v_scope_boxed_12_ = lean_unbox_uint32(v_scope_8_);
lean_dec(v_scope_8_);
v_reps_boxed_13_ = lean_unbox_uint64(v_reps_9_);
lean_dec_ref(v_reps_9_);
v_verify_boxed_14_ = lean_unbox(v_verify_10_);
v_res_15_ = bench_begin_lean(v_scope_boxed_12_, v_reps_boxed_13_, v_verify_boxed_14_);
return v_res_15_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchStop___boxed(lean_object* v_a_00___x40___internal___hyg_17_){
_start:
{
lean_object* v_res_18_; 
v_res_18_ = bench_stop_lean();
return v_res_18_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchReport___boxed(lean_object* v_a_00___x40___internal___hyg_20_){
_start:
{
lean_object* v_res_21_; 
v_res_21_ = bench_report_lean();
return v_res_21_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchCRun___boxed(lean_object* v_scope_26_, lean_object* v_reps_27_, lean_object* v_verify_28_, lean_object* v_a_00___x40___internal___hyg_29_){
_start:
{
uint32_t v_scope_boxed_30_; uint64_t v_reps_boxed_31_; uint8_t v_verify_boxed_32_; lean_object* v_res_33_; 
v_scope_boxed_30_ = lean_unbox_uint32(v_scope_26_);
lean_dec(v_scope_26_);
v_reps_boxed_31_ = lean_unbox_uint64(v_reps_27_);
lean_dec_ref(v_reps_27_);
v_verify_boxed_32_ = lean_unbox(v_verify_28_);
v_res_33_ = bench_c_run_lean(v_scope_boxed_30_, v_reps_boxed_31_, v_verify_boxed_32_);
return v_res_33_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_benchVerify___boxed(lean_object* v_arena_37_, lean_object* v_reps_38_, lean_object* v_a_00___x40___internal___hyg_39_){
_start:
{
uint64_t v_reps_boxed_40_; lean_object* v_res_41_; 
v_reps_boxed_40_ = lean_unbox_uint64(v_reps_38_);
lean_dec_ref(v_reps_38_);
v_res_41_ = bench_verify_lean(v_arena_37_, v_reps_boxed_40_);
lean_dec(v_arena_37_);
return v_res_41_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce(){
_start:
{
uint64_t v___x_43_; lean_object* v___x_44_; 
v___x_43_ = 9223372036854775807ULL;
v___x_44_ = vastitas_storage_new(v___x_43_);
if (lean_obj_tag(v___x_44_) == 0)
{
lean_object* v_a_45_; lean_object* v_a_47_; lean_object* v___y_58_; uint32_t v___x_70_; uint8_t v___x_71_; uint64_t v___x_72_; lean_object* v___x_73_; 
v_a_45_ = lean_ctor_get(v___x_44_, 0);
lean_inc(v_a_45_);
lean_dec_ref_known(v___x_44_, 1);
v___x_70_ = 0;
v___x_71_ = 0;
v___x_72_ = 595ULL;
v___x_73_ = vastitas_storage_allocate(v_a_45_, v___x_70_, v___x_71_, v___x_72_);
if (lean_obj_tag(v___x_73_) == 0)
{
uint64_t v___x_74_; uint64_t v___x_75_; uint8_t v___x_76_; uint64_t v___x_77_; lean_object* v___x_78_; 
lean_dec_ref_known(v___x_73_, 1);
v___x_74_ = 0ULL;
v___x_75_ = 1ULL;
v___x_76_ = 0;
v___x_77_ = 13842939354630062080ULL;
v___x_78_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_74_, v___x_72_, v___x_75_, v___x_72_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_78_) == 0)
{
uint64_t v___x_79_; uint64_t v___x_80_; uint64_t v___x_81_; lean_object* v___x_82_; 
lean_dec_ref_known(v___x_78_, 1);
v___x_79_ = 7ULL;
v___x_80_ = 85ULL;
v___x_81_ = 4593671619917905920ULL;
v___x_82_ = vastitas_storage_fill(v_a_45_, v___x_70_, v___x_74_, v___x_79_, v___x_80_, v___x_79_, v___x_76_, v___x_71_, v___x_81_, v___x_74_);
if (lean_obj_tag(v___x_82_) == 0)
{
uint64_t v___x_83_; lean_object* v___x_84_; 
lean_dec_ref_known(v___x_82_, 1);
v___x_83_ = 4607182418800017408ULL;
v___x_84_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_74_, v___x_79_, v___x_80_, v___x_79_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_83_, v___x_74_);
if (lean_obj_tag(v___x_84_) == 0)
{
uint64_t v___x_85_; uint64_t v___x_86_; lean_object* v___x_87_; 
lean_dec_ref_known(v___x_84_, 1);
v___x_85_ = 6ULL;
v___x_86_ = 13826050856027422720ULL;
v___x_87_ = vastitas_storage_store(v_a_45_, v___x_70_, v___x_74_, v___x_79_, v___x_80_, v___x_79_, v___x_76_, v___x_85_, v___x_75_, v___x_71_, v___x_86_, v___x_74_);
if (lean_obj_tag(v___x_87_) == 0)
{
uint32_t v___x_88_; uint64_t v___x_89_; lean_object* v___x_90_; 
lean_dec_ref_known(v___x_87_, 1);
v___x_88_ = 1;
v___x_89_ = 187ULL;
v___x_90_ = vastitas_storage_allocate(v_a_45_, v___x_88_, v___x_71_, v___x_89_);
if (lean_obj_tag(v___x_90_) == 0)
{
lean_object* v___x_91_; 
lean_dec_ref_known(v___x_90_, 1);
v___x_91_ = vastitas_storage_fill(v_a_45_, v___x_88_, v___x_74_, v___x_89_, v___x_75_, v___x_89_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_91_) == 0)
{
uint64_t v___x_92_; uint64_t v___x_93_; uint64_t v___x_94_; lean_object* v___x_95_; 
lean_dec_ref_known(v___x_91_, 1);
v___x_92_ = 17ULL;
v___x_93_ = 11ULL;
v___x_94_ = 13821547256400052224ULL;
v___x_95_ = vastitas_storage_fill(v_a_45_, v___x_88_, v___x_74_, v___x_92_, v___x_93_, v___x_92_, v___x_76_, v___x_71_, v___x_94_, v___x_74_);
if (lean_obj_tag(v___x_95_) == 0)
{
uint64_t v___x_96_; uint64_t v___x_97_; lean_object* v___x_98_; 
lean_dec_ref_known(v___x_95_, 1);
v___x_96_ = 10ULL;
v___x_97_ = 4602678819172646912ULL;
v___x_98_ = vastitas_storage_store(v_a_45_, v___x_88_, v___x_74_, v___x_92_, v___x_93_, v___x_92_, v___x_76_, v___x_74_, v___x_96_, v___x_71_, v___x_97_, v___x_74_);
if (lean_obj_tag(v___x_98_) == 0)
{
uint64_t v___x_99_; uint64_t v___x_100_; lean_object* v___x_101_; 
lean_dec_ref_known(v___x_98_, 1);
v___x_99_ = 16ULL;
v___x_100_ = 13828302655841107968ULL;
v___x_101_ = vastitas_storage_store(v_a_45_, v___x_88_, v___x_74_, v___x_92_, v___x_93_, v___x_92_, v___x_76_, v___x_99_, v___x_74_, v___x_71_, v___x_100_, v___x_74_);
if (lean_obj_tag(v___x_101_) == 0)
{
uint32_t v___x_102_; uint64_t v___x_103_; lean_object* v___x_104_; 
lean_dec_ref_known(v___x_101_, 1);
v___x_102_ = 2;
v___x_103_ = 65ULL;
v___x_104_ = vastitas_storage_allocate(v_a_45_, v___x_102_, v___x_71_, v___x_103_);
if (lean_obj_tag(v___x_104_) == 0)
{
lean_object* v___x_105_; 
lean_dec_ref_known(v___x_104_, 1);
v___x_105_ = vastitas_storage_fill(v_a_45_, v___x_102_, v___x_74_, v___x_103_, v___x_75_, v___x_103_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_105_) == 0)
{
uint64_t v___x_106_; uint64_t v___x_107_; lean_object* v___x_108_; 
lean_dec_ref_known(v___x_105_, 1);
v___x_106_ = 5ULL;
v___x_107_ = 13ULL;
v___x_108_ = vastitas_storage_fill(v_a_45_, v___x_102_, v___x_74_, v___x_106_, v___x_107_, v___x_106_, v___x_76_, v___x_71_, v___x_97_, v___x_74_);
if (lean_obj_tag(v___x_108_) == 0)
{
uint64_t v___x_109_; lean_object* v___x_110_; 
lean_dec_ref_known(v___x_108_, 1);
v___x_109_ = 4ULL;
v___x_110_ = vastitas_storage_store(v_a_45_, v___x_102_, v___x_74_, v___x_106_, v___x_107_, v___x_106_, v___x_76_, v___x_109_, v___x_74_, v___x_71_, v___x_94_, v___x_74_);
if (lean_obj_tag(v___x_110_) == 0)
{
uint64_t v___x_111_; uint64_t v___x_112_; lean_object* v___x_113_; 
lean_dec_ref_known(v___x_110_, 1);
v___x_111_ = 12ULL;
v___x_112_ = 4604930618986332160ULL;
v___x_113_ = vastitas_storage_store(v_a_45_, v___x_102_, v___x_74_, v___x_106_, v___x_107_, v___x_106_, v___x_76_, v___x_74_, v___x_111_, v___x_71_, v___x_112_, v___x_74_);
if (lean_obj_tag(v___x_113_) == 0)
{
uint32_t v___x_114_; lean_object* v___x_115_; 
lean_dec_ref_known(v___x_113_, 1);
v___x_114_ = 3;
v___x_115_ = vastitas_storage_allocate(v_a_45_, v___x_114_, v___x_71_, v___x_72_);
if (lean_obj_tag(v___x_115_) == 0)
{
lean_object* v___x_116_; 
lean_dec_ref_known(v___x_115_, 1);
v___x_116_ = vastitas_storage_fill(v_a_45_, v___x_114_, v___x_74_, v___x_72_, v___x_75_, v___x_72_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_116_) == 0)
{
uint32_t v___x_117_; uint64_t v___x_118_; lean_object* v___x_119_; 
lean_dec_ref_known(v___x_116_, 1);
v___x_117_ = 4;
v___x_118_ = 385ULL;
v___x_119_ = vastitas_storage_allocate(v_a_45_, v___x_117_, v___x_71_, v___x_118_);
if (lean_obj_tag(v___x_119_) == 0)
{
lean_object* v___x_120_; 
lean_dec_ref_known(v___x_119_, 1);
v___x_120_ = vastitas_storage_fill(v_a_45_, v___x_117_, v___x_74_, v___x_118_, v___x_75_, v___x_118_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_120_) == 0)
{
uint32_t v___x_121_; uint64_t v___x_122_; lean_object* v___x_123_; 
lean_dec_ref_known(v___x_120_, 1);
v___x_121_ = 5;
v___x_122_ = 1001ULL;
v___x_123_ = vastitas_storage_allocate(v_a_45_, v___x_121_, v___x_71_, v___x_122_);
if (lean_obj_tag(v___x_123_) == 0)
{
lean_object* v___x_124_; 
lean_dec_ref_known(v___x_123_, 1);
v___x_124_ = vastitas_storage_fill(v_a_45_, v___x_121_, v___x_74_, v___x_122_, v___x_75_, v___x_122_, v___x_76_, v___x_71_, v___x_77_, v___x_74_);
if (lean_obj_tag(v___x_124_) == 0)
{
uint64_t v___x_125_; lean_object* v___x_126_; 
lean_dec_ref_known(v___x_124_, 1);
v___x_125_ = 35ULL;
v___x_126_ = vastitas_storage_pack3(v_a_45_, v___x_70_, v___x_74_, v___x_79_, v___x_80_, v___x_79_, v___x_76_, v___x_114_, v___x_74_, v___x_125_, v___x_92_, v___x_125_, v___x_76_, v___x_79_, v___x_92_, v___x_106_);
if (lean_obj_tag(v___x_126_) == 0)
{
lean_object* v___x_127_; 
lean_dec_ref_known(v___x_126_, 1);
v___x_127_ = vastitas_gemm_execute(v_a_45_, v___x_114_, v___x_74_, v___x_125_, v___x_92_, v___x_125_, v___x_76_, v___x_76_, v___x_88_, v___x_74_, v___x_92_, v___x_93_, v___x_92_, v___x_76_, v___x_76_, v___x_117_, v___x_74_, v___x_125_, v___x_93_, v___x_125_, v___x_76_, v___x_71_);
if (lean_obj_tag(v___x_127_) == 0)
{
uint64_t v___x_128_; uint64_t v___x_129_; uint64_t v___x_130_; lean_object* v___x_131_; 
lean_dec_ref_known(v___x_127_, 1);
v___x_128_ = 77ULL;
v___x_129_ = 48ULL;
v___x_130_ = 42ULL;
v___x_131_ = vastitas_storage_regroup3(v_a_45_, v___x_117_, v___x_74_, v___x_125_, v___x_93_, v___x_125_, v___x_76_, v___x_114_, v___x_74_, v___x_128_, v___x_106_, v___x_128_, v___x_76_, v___x_79_, v___x_106_, v___x_93_, v___x_129_, v___x_130_);
if (lean_obj_tag(v___x_131_) == 0)
{
lean_object* v___x_132_; 
lean_dec_ref_known(v___x_131_, 1);
v___x_132_ = vastitas_gemm_execute(v_a_45_, v___x_114_, v___x_74_, v___x_128_, v___x_106_, v___x_128_, v___x_76_, v___x_76_, v___x_102_, v___x_74_, v___x_106_, v___x_107_, v___x_106_, v___x_76_, v___x_76_, v___x_121_, v___x_74_, v___x_128_, v___x_107_, v___x_128_, v___x_76_, v___x_71_);
if (lean_obj_tag(v___x_132_) == 0)
{
uint64_t v___x_133_; lean_object* v___x_134_; 
lean_dec_ref_known(v___x_132_, 1);
v___x_133_ = 13831222958724481024ULL;
v___x_134_ = vastitas_storage_expect(v_a_45_, v___x_121_, v___x_74_, v___x_128_, v___x_107_, v___x_128_, v___x_76_, v___x_74_, v___x_74_, v___x_71_, v___x_133_, v___x_74_);
if (lean_obj_tag(v___x_134_) == 0)
{
uint64_t v___x_135_; lean_object* v___x_136_; 
lean_dec_ref_known(v___x_134_, 1);
v___x_135_ = 13832876624212656128ULL;
v___x_136_ = vastitas_storage_expect(v_a_45_, v___x_121_, v___x_74_, v___x_128_, v___x_107_, v___x_128_, v___x_76_, v___x_85_, v___x_111_, v___x_71_, v___x_135_, v___x_74_);
if (lean_obj_tag(v___x_136_) == 0)
{
uint64_t v___x_137_; uint64_t v___x_138_; lean_object* v___x_139_; 
lean_dec_ref_known(v___x_136_, 1);
v___x_137_ = 76ULL;
v___x_138_ = 13827739705887686656ULL;
v___x_139_ = vastitas_storage_expect(v_a_45_, v___x_121_, v___x_74_, v___x_128_, v___x_107_, v___x_128_, v___x_76_, v___x_137_, v___x_74_, v___x_71_, v___x_138_, v___x_74_);
if (lean_obj_tag(v___x_139_) == 0)
{
lean_object* v___x_140_; 
lean_dec_ref_known(v___x_139_, 1);
v___x_140_ = vastitas_storage_drop(v_a_45_, v___x_121_);
if (lean_obj_tag(v___x_140_) == 0)
{
lean_object* v___x_141_; 
lean_dec_ref_known(v___x_140_, 1);
v___x_141_ = vastitas_storage_drop(v_a_45_, v___x_117_);
if (lean_obj_tag(v___x_141_) == 0)
{
lean_object* v___x_142_; 
lean_dec_ref_known(v___x_141_, 1);
v___x_142_ = vastitas_storage_drop(v_a_45_, v___x_114_);
if (lean_obj_tag(v___x_142_) == 0)
{
lean_object* v___x_143_; 
lean_dec_ref_known(v___x_142_, 1);
v___x_143_ = vastitas_storage_drop(v_a_45_, v___x_102_);
if (lean_obj_tag(v___x_143_) == 0)
{
lean_object* v___x_144_; 
lean_dec_ref_known(v___x_143_, 1);
v___x_144_ = vastitas_storage_drop(v_a_45_, v___x_88_);
if (lean_obj_tag(v___x_144_) == 0)
{
lean_object* v___x_145_; 
lean_dec_ref_known(v___x_144_, 1);
v___x_145_ = vastitas_storage_drop(v_a_45_, v___x_70_);
if (lean_obj_tag(v___x_145_) == 0)
{
lean_object* v___x_146_; 
lean_dec_ref_known(v___x_145_, 1);
v___x_146_ = lean_box(0);
v_a_47_ = v___x_146_;
goto v___jp_46_;
}
else
{
v___y_58_ = v___x_145_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_144_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_143_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_142_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_141_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_140_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_139_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_136_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_134_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_132_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_131_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_127_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_126_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_124_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_123_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_120_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_119_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_116_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_115_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_113_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_110_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_108_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_105_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_104_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_101_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_98_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_95_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_91_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_90_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_87_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_84_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_82_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_78_;
goto v___jp_57_;
}
}
else
{
v___y_58_ = v___x_73_;
goto v___jp_57_;
}
v___jp_46_:
{
lean_object* v___x_48_; 
v___x_48_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_48_) == 0)
{
lean_object* v___x_50_; uint8_t v_isShared_51_; uint8_t v_isSharedCheck_55_; 
v_isSharedCheck_55_ = !lean_is_exclusive(v___x_48_);
if (v_isSharedCheck_55_ == 0)
{
lean_object* v_unused_56_; 
v_unused_56_ = lean_ctor_get(v___x_48_, 0);
lean_dec(v_unused_56_);
v___x_50_ = v___x_48_;
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
else
{
lean_dec(v___x_48_);
v___x_50_ = lean_box(0);
v_isShared_51_ = v_isSharedCheck_55_;
goto v_resetjp_49_;
}
v_resetjp_49_:
{
lean_object* v___x_53_; 
if (v_isShared_51_ == 0)
{
lean_ctor_set(v___x_50_, 0, v_a_47_);
v___x_53_ = v___x_50_;
goto v_reusejp_52_;
}
else
{
lean_object* v_reuseFailAlloc_54_; 
v_reuseFailAlloc_54_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_54_, 0, v_a_47_);
v___x_53_ = v_reuseFailAlloc_54_;
goto v_reusejp_52_;
}
v_reusejp_52_:
{
return v___x_53_;
}
}
}
else
{
return v___x_48_;
}
}
v___jp_57_:
{
if (lean_obj_tag(v___y_58_) == 0)
{
lean_object* v_a_59_; 
v_a_59_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_59_);
lean_dec_ref_known(v___y_58_, 1);
v_a_47_ = v_a_59_;
goto v___jp_46_;
}
else
{
lean_object* v_a_60_; lean_object* v___x_61_; 
v_a_60_ = lean_ctor_get(v___y_58_, 0);
lean_inc(v_a_60_);
lean_dec_ref_known(v___y_58_, 1);
v___x_61_ = vastitas_storage_close(v_a_45_);
lean_dec(v_a_45_);
if (lean_obj_tag(v___x_61_) == 0)
{
lean_object* v___x_63_; uint8_t v_isShared_64_; uint8_t v_isSharedCheck_68_; 
v_isSharedCheck_68_ = !lean_is_exclusive(v___x_61_);
if (v_isSharedCheck_68_ == 0)
{
lean_object* v_unused_69_; 
v_unused_69_ = lean_ctor_get(v___x_61_, 0);
lean_dec(v_unused_69_);
v___x_63_ = v___x_61_;
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
else
{
lean_dec(v___x_61_);
v___x_63_ = lean_box(0);
v_isShared_64_ = v_isSharedCheck_68_;
goto v_resetjp_62_;
}
v_resetjp_62_:
{
lean_object* v___x_66_; 
if (v_isShared_64_ == 0)
{
lean_ctor_set_tag(v___x_63_, 1);
lean_ctor_set(v___x_63_, 0, v_a_60_);
v___x_66_ = v___x_63_;
goto v_reusejp_65_;
}
else
{
lean_object* v_reuseFailAlloc_67_; 
v_reuseFailAlloc_67_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_67_, 0, v_a_60_);
v___x_66_ = v_reuseFailAlloc_67_;
goto v_reusejp_65_;
}
v_reusejp_65_:
{
return v___x_66_;
}
}
}
else
{
lean_dec(v_a_60_);
return v___x_61_;
}
}
}
}
else
{
lean_object* v_a_147_; lean_object* v___x_149_; uint8_t v_isShared_150_; uint8_t v_isSharedCheck_154_; 
v_a_147_ = lean_ctor_get(v___x_44_, 0);
v_isSharedCheck_154_ = !lean_is_exclusive(v___x_44_);
if (v_isSharedCheck_154_ == 0)
{
v___x_149_ = v___x_44_;
v_isShared_150_ = v_isSharedCheck_154_;
goto v_resetjp_148_;
}
else
{
lean_inc(v_a_147_);
lean_dec(v___x_44_);
v___x_149_ = lean_box(0);
v_isShared_150_ = v_isSharedCheck_154_;
goto v_resetjp_148_;
}
v_resetjp_148_:
{
lean_object* v___x_152_; 
if (v_isShared_150_ == 0)
{
v___x_152_ = v___x_149_;
goto v_reusejp_151_;
}
else
{
lean_object* v_reuseFailAlloc_153_; 
v_reuseFailAlloc_153_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_153_, 0, v_a_147_);
v___x_152_ = v_reuseFailAlloc_153_;
goto v_reusejp_151_;
}
v_reusejp_151_:
{
return v___x_152_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedOnce___boxed(lean_object* v_a_155_){
_start:
{
lean_object* v_res_156_; 
v_res_156_ = lp_allocation__audit_generatedOnce();
return v_res_156_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure(){
_start:
{
uint64_t v___x_158_; lean_object* v___x_159_; 
v___x_158_ = 9223372036854775807ULL;
v___x_159_ = vastitas_storage_new(v___x_158_);
if (lean_obj_tag(v___x_159_) == 0)
{
lean_object* v_a_160_; lean_object* v_a_162_; lean_object* v___y_173_; uint32_t v___x_185_; uint8_t v___x_186_; uint64_t v___x_187_; lean_object* v___x_188_; 
v_a_160_ = lean_ctor_get(v___x_159_, 0);
lean_inc(v_a_160_);
lean_dec_ref_known(v___x_159_, 1);
v___x_185_ = 0;
v___x_186_ = 0;
v___x_187_ = 595ULL;
v___x_188_ = vastitas_storage_allocate(v_a_160_, v___x_185_, v___x_186_, v___x_187_);
if (lean_obj_tag(v___x_188_) == 0)
{
uint64_t v___x_189_; uint64_t v___x_190_; uint8_t v___x_191_; uint64_t v___x_192_; lean_object* v___x_193_; 
lean_dec_ref_known(v___x_188_, 1);
v___x_189_ = 0ULL;
v___x_190_ = 1ULL;
v___x_191_ = 0;
v___x_192_ = 13842939354630062080ULL;
v___x_193_ = vastitas_storage_fill(v_a_160_, v___x_185_, v___x_189_, v___x_187_, v___x_190_, v___x_187_, v___x_191_, v___x_186_, v___x_192_, v___x_189_);
if (lean_obj_tag(v___x_193_) == 0)
{
uint64_t v___x_194_; uint64_t v___x_195_; uint64_t v___x_196_; lean_object* v___x_197_; 
lean_dec_ref_known(v___x_193_, 1);
v___x_194_ = 7ULL;
v___x_195_ = 85ULL;
v___x_196_ = 4593671619917905920ULL;
v___x_197_ = vastitas_storage_fill(v_a_160_, v___x_185_, v___x_189_, v___x_194_, v___x_195_, v___x_194_, v___x_191_, v___x_186_, v___x_196_, v___x_189_);
if (lean_obj_tag(v___x_197_) == 0)
{
uint64_t v___x_198_; lean_object* v___x_199_; 
lean_dec_ref_known(v___x_197_, 1);
v___x_198_ = 4607182418800017408ULL;
v___x_199_ = vastitas_storage_store(v_a_160_, v___x_185_, v___x_189_, v___x_194_, v___x_195_, v___x_194_, v___x_191_, v___x_189_, v___x_189_, v___x_186_, v___x_198_, v___x_189_);
if (lean_obj_tag(v___x_199_) == 0)
{
uint64_t v___x_200_; uint64_t v___x_201_; lean_object* v___x_202_; 
lean_dec_ref_known(v___x_199_, 1);
v___x_200_ = 6ULL;
v___x_201_ = 13826050856027422720ULL;
v___x_202_ = vastitas_storage_store(v_a_160_, v___x_185_, v___x_189_, v___x_194_, v___x_195_, v___x_194_, v___x_191_, v___x_200_, v___x_190_, v___x_186_, v___x_201_, v___x_189_);
if (lean_obj_tag(v___x_202_) == 0)
{
uint32_t v___x_203_; uint64_t v___x_204_; lean_object* v___x_205_; 
lean_dec_ref_known(v___x_202_, 1);
v___x_203_ = 1;
v___x_204_ = 187ULL;
v___x_205_ = vastitas_storage_allocate(v_a_160_, v___x_203_, v___x_186_, v___x_204_);
if (lean_obj_tag(v___x_205_) == 0)
{
lean_object* v___x_206_; 
lean_dec_ref_known(v___x_205_, 1);
v___x_206_ = vastitas_storage_fill(v_a_160_, v___x_203_, v___x_189_, v___x_204_, v___x_190_, v___x_204_, v___x_191_, v___x_186_, v___x_192_, v___x_189_);
if (lean_obj_tag(v___x_206_) == 0)
{
uint64_t v___x_207_; uint64_t v___x_208_; uint64_t v___x_209_; lean_object* v___x_210_; 
lean_dec_ref_known(v___x_206_, 1);
v___x_207_ = 17ULL;
v___x_208_ = 11ULL;
v___x_209_ = 13821547256400052224ULL;
v___x_210_ = vastitas_storage_fill(v_a_160_, v___x_203_, v___x_189_, v___x_207_, v___x_208_, v___x_207_, v___x_191_, v___x_186_, v___x_209_, v___x_189_);
if (lean_obj_tag(v___x_210_) == 0)
{
uint64_t v___x_211_; uint64_t v___x_212_; lean_object* v___x_213_; 
lean_dec_ref_known(v___x_210_, 1);
v___x_211_ = 10ULL;
v___x_212_ = 4602678819172646912ULL;
v___x_213_ = vastitas_storage_store(v_a_160_, v___x_203_, v___x_189_, v___x_207_, v___x_208_, v___x_207_, v___x_191_, v___x_189_, v___x_211_, v___x_186_, v___x_212_, v___x_189_);
if (lean_obj_tag(v___x_213_) == 0)
{
uint64_t v___x_214_; uint64_t v___x_215_; lean_object* v___x_216_; 
lean_dec_ref_known(v___x_213_, 1);
v___x_214_ = 16ULL;
v___x_215_ = 13828302655841107968ULL;
v___x_216_ = vastitas_storage_store(v_a_160_, v___x_203_, v___x_189_, v___x_207_, v___x_208_, v___x_207_, v___x_191_, v___x_214_, v___x_189_, v___x_186_, v___x_215_, v___x_189_);
if (lean_obj_tag(v___x_216_) == 0)
{
uint32_t v___x_217_; uint64_t v___x_218_; lean_object* v___x_219_; 
lean_dec_ref_known(v___x_216_, 1);
v___x_217_ = 2;
v___x_218_ = 65ULL;
v___x_219_ = vastitas_storage_allocate(v_a_160_, v___x_217_, v___x_186_, v___x_218_);
if (lean_obj_tag(v___x_219_) == 0)
{
lean_object* v___x_220_; 
lean_dec_ref_known(v___x_219_, 1);
v___x_220_ = vastitas_storage_fill(v_a_160_, v___x_217_, v___x_189_, v___x_218_, v___x_190_, v___x_218_, v___x_191_, v___x_186_, v___x_192_, v___x_189_);
if (lean_obj_tag(v___x_220_) == 0)
{
uint64_t v___x_221_; uint64_t v___x_222_; lean_object* v___x_223_; 
lean_dec_ref_known(v___x_220_, 1);
v___x_221_ = 5ULL;
v___x_222_ = 13ULL;
v___x_223_ = vastitas_storage_fill(v_a_160_, v___x_217_, v___x_189_, v___x_221_, v___x_222_, v___x_221_, v___x_191_, v___x_186_, v___x_212_, v___x_189_);
if (lean_obj_tag(v___x_223_) == 0)
{
uint64_t v___x_224_; lean_object* v___x_225_; 
lean_dec_ref_known(v___x_223_, 1);
v___x_224_ = 4ULL;
v___x_225_ = vastitas_storage_store(v_a_160_, v___x_217_, v___x_189_, v___x_221_, v___x_222_, v___x_221_, v___x_191_, v___x_224_, v___x_189_, v___x_186_, v___x_209_, v___x_189_);
if (lean_obj_tag(v___x_225_) == 0)
{
uint64_t v___x_226_; uint64_t v___x_227_; lean_object* v___x_228_; 
lean_dec_ref_known(v___x_225_, 1);
v___x_226_ = 12ULL;
v___x_227_ = 4604930618986332160ULL;
v___x_228_ = vastitas_storage_store(v_a_160_, v___x_217_, v___x_189_, v___x_221_, v___x_222_, v___x_221_, v___x_191_, v___x_189_, v___x_226_, v___x_186_, v___x_227_, v___x_189_);
if (lean_obj_tag(v___x_228_) == 0)
{
uint32_t v___x_229_; lean_object* v___x_230_; 
lean_dec_ref_known(v___x_228_, 1);
v___x_229_ = 3;
v___x_230_ = vastitas_storage_allocate(v_a_160_, v___x_229_, v___x_186_, v___x_187_);
if (lean_obj_tag(v___x_230_) == 0)
{
lean_object* v___x_231_; 
lean_dec_ref_known(v___x_230_, 1);
v___x_231_ = vastitas_storage_fill(v_a_160_, v___x_229_, v___x_189_, v___x_187_, v___x_190_, v___x_187_, v___x_191_, v___x_186_, v___x_192_, v___x_189_);
if (lean_obj_tag(v___x_231_) == 0)
{
uint32_t v___x_232_; uint64_t v___x_233_; lean_object* v___x_234_; 
lean_dec_ref_known(v___x_231_, 1);
v___x_232_ = 4;
v___x_233_ = 385ULL;
v___x_234_ = vastitas_storage_allocate(v_a_160_, v___x_232_, v___x_186_, v___x_233_);
if (lean_obj_tag(v___x_234_) == 0)
{
lean_object* v___x_235_; 
lean_dec_ref_known(v___x_234_, 1);
v___x_235_ = vastitas_storage_fill(v_a_160_, v___x_232_, v___x_189_, v___x_233_, v___x_190_, v___x_233_, v___x_191_, v___x_186_, v___x_192_, v___x_189_);
if (lean_obj_tag(v___x_235_) == 0)
{
uint32_t v___x_236_; uint64_t v___x_237_; lean_object* v___x_238_; 
lean_dec_ref_known(v___x_235_, 1);
v___x_236_ = 5;
v___x_237_ = 1001ULL;
v___x_238_ = vastitas_storage_allocate(v_a_160_, v___x_236_, v___x_186_, v___x_237_);
if (lean_obj_tag(v___x_238_) == 0)
{
lean_object* v___x_239_; 
lean_dec_ref_known(v___x_238_, 1);
v___x_239_ = vastitas_storage_fill(v_a_160_, v___x_236_, v___x_189_, v___x_237_, v___x_190_, v___x_237_, v___x_191_, v___x_186_, v___x_192_, v___x_189_);
if (lean_obj_tag(v___x_239_) == 0)
{
uint64_t v___x_240_; lean_object* v___x_241_; 
lean_dec_ref_known(v___x_239_, 1);
v___x_240_ = 35ULL;
v___x_241_ = vastitas_storage_pack3(v_a_160_, v___x_185_, v___x_189_, v___x_194_, v___x_195_, v___x_194_, v___x_191_, v___x_229_, v___x_189_, v___x_240_, v___x_207_, v___x_240_, v___x_191_, v___x_194_, v___x_207_, v___x_221_);
if (lean_obj_tag(v___x_241_) == 0)
{
lean_object* v___x_242_; 
lean_dec_ref_known(v___x_241_, 1);
v___x_242_ = vastitas_gemm_execute(v_a_160_, v___x_229_, v___x_189_, v___x_240_, v___x_207_, v___x_240_, v___x_191_, v___x_191_, v___x_203_, v___x_189_, v___x_207_, v___x_208_, v___x_207_, v___x_191_, v___x_191_, v___x_232_, v___x_189_, v___x_240_, v___x_208_, v___x_240_, v___x_191_, v___x_186_);
if (lean_obj_tag(v___x_242_) == 0)
{
uint64_t v___x_243_; uint64_t v___x_244_; uint64_t v___x_245_; lean_object* v___x_246_; 
lean_dec_ref_known(v___x_242_, 1);
v___x_243_ = 77ULL;
v___x_244_ = 48ULL;
v___x_245_ = 42ULL;
v___x_246_ = vastitas_storage_regroup3(v_a_160_, v___x_232_, v___x_189_, v___x_240_, v___x_208_, v___x_240_, v___x_191_, v___x_229_, v___x_189_, v___x_243_, v___x_221_, v___x_243_, v___x_191_, v___x_194_, v___x_221_, v___x_208_, v___x_244_, v___x_245_);
if (lean_obj_tag(v___x_246_) == 0)
{
lean_object* v___x_247_; 
lean_dec_ref_known(v___x_246_, 1);
v___x_247_ = vastitas_gemm_execute(v_a_160_, v___x_229_, v___x_189_, v___x_243_, v___x_221_, v___x_243_, v___x_191_, v___x_191_, v___x_217_, v___x_189_, v___x_221_, v___x_222_, v___x_221_, v___x_191_, v___x_191_, v___x_236_, v___x_189_, v___x_243_, v___x_222_, v___x_243_, v___x_191_, v___x_186_);
if (lean_obj_tag(v___x_247_) == 0)
{
uint64_t v___x_248_; lean_object* v___x_249_; 
lean_dec_ref_known(v___x_247_, 1);
v___x_248_ = 13831222958724481025ULL;
v___x_249_ = vastitas_storage_expect(v_a_160_, v___x_236_, v___x_189_, v___x_243_, v___x_222_, v___x_243_, v___x_191_, v___x_189_, v___x_189_, v___x_186_, v___x_248_, v___x_189_);
if (lean_obj_tag(v___x_249_) == 0)
{
uint64_t v___x_250_; lean_object* v___x_251_; 
lean_dec_ref_known(v___x_249_, 1);
v___x_250_ = 13832876624212656128ULL;
v___x_251_ = vastitas_storage_expect(v_a_160_, v___x_236_, v___x_189_, v___x_243_, v___x_222_, v___x_243_, v___x_191_, v___x_200_, v___x_226_, v___x_186_, v___x_250_, v___x_189_);
if (lean_obj_tag(v___x_251_) == 0)
{
uint64_t v___x_252_; uint64_t v___x_253_; lean_object* v___x_254_; 
lean_dec_ref_known(v___x_251_, 1);
v___x_252_ = 76ULL;
v___x_253_ = 13827739705887686656ULL;
v___x_254_ = vastitas_storage_expect(v_a_160_, v___x_236_, v___x_189_, v___x_243_, v___x_222_, v___x_243_, v___x_191_, v___x_252_, v___x_189_, v___x_186_, v___x_253_, v___x_189_);
if (lean_obj_tag(v___x_254_) == 0)
{
lean_object* v___x_255_; 
lean_dec_ref_known(v___x_254_, 1);
v___x_255_ = vastitas_storage_drop(v_a_160_, v___x_236_);
if (lean_obj_tag(v___x_255_) == 0)
{
lean_object* v___x_256_; 
lean_dec_ref_known(v___x_255_, 1);
v___x_256_ = vastitas_storage_drop(v_a_160_, v___x_232_);
if (lean_obj_tag(v___x_256_) == 0)
{
lean_object* v___x_257_; 
lean_dec_ref_known(v___x_256_, 1);
v___x_257_ = vastitas_storage_drop(v_a_160_, v___x_229_);
if (lean_obj_tag(v___x_257_) == 0)
{
lean_object* v___x_258_; 
lean_dec_ref_known(v___x_257_, 1);
v___x_258_ = vastitas_storage_drop(v_a_160_, v___x_217_);
if (lean_obj_tag(v___x_258_) == 0)
{
lean_object* v___x_259_; 
lean_dec_ref_known(v___x_258_, 1);
v___x_259_ = vastitas_storage_drop(v_a_160_, v___x_203_);
if (lean_obj_tag(v___x_259_) == 0)
{
lean_object* v___x_260_; 
lean_dec_ref_known(v___x_259_, 1);
v___x_260_ = vastitas_storage_drop(v_a_160_, v___x_185_);
if (lean_obj_tag(v___x_260_) == 0)
{
lean_object* v___x_261_; 
lean_dec_ref_known(v___x_260_, 1);
v___x_261_ = lean_box(0);
v_a_162_ = v___x_261_;
goto v___jp_161_;
}
else
{
v___y_173_ = v___x_260_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_259_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_258_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_257_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_256_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_255_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_254_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_251_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_249_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_247_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_246_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_242_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_241_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_239_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_238_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_235_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_234_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_231_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_230_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_228_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_225_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_223_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_220_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_219_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_216_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_213_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_210_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_206_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_205_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_202_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_199_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_197_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_193_;
goto v___jp_172_;
}
}
else
{
v___y_173_ = v___x_188_;
goto v___jp_172_;
}
v___jp_161_:
{
lean_object* v___x_163_; 
v___x_163_ = vastitas_storage_close(v_a_160_);
lean_dec(v_a_160_);
if (lean_obj_tag(v___x_163_) == 0)
{
lean_object* v___x_165_; uint8_t v_isShared_166_; uint8_t v_isSharedCheck_170_; 
v_isSharedCheck_170_ = !lean_is_exclusive(v___x_163_);
if (v_isSharedCheck_170_ == 0)
{
lean_object* v_unused_171_; 
v_unused_171_ = lean_ctor_get(v___x_163_, 0);
lean_dec(v_unused_171_);
v___x_165_ = v___x_163_;
v_isShared_166_ = v_isSharedCheck_170_;
goto v_resetjp_164_;
}
else
{
lean_dec(v___x_163_);
v___x_165_ = lean_box(0);
v_isShared_166_ = v_isSharedCheck_170_;
goto v_resetjp_164_;
}
v_resetjp_164_:
{
lean_object* v___x_168_; 
if (v_isShared_166_ == 0)
{
lean_ctor_set(v___x_165_, 0, v_a_162_);
v___x_168_ = v___x_165_;
goto v_reusejp_167_;
}
else
{
lean_object* v_reuseFailAlloc_169_; 
v_reuseFailAlloc_169_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v_reuseFailAlloc_169_, 0, v_a_162_);
v___x_168_ = v_reuseFailAlloc_169_;
goto v_reusejp_167_;
}
v_reusejp_167_:
{
return v___x_168_;
}
}
}
else
{
return v___x_163_;
}
}
v___jp_172_:
{
if (lean_obj_tag(v___y_173_) == 0)
{
lean_object* v_a_174_; 
v_a_174_ = lean_ctor_get(v___y_173_, 0);
lean_inc(v_a_174_);
lean_dec_ref_known(v___y_173_, 1);
v_a_162_ = v_a_174_;
goto v___jp_161_;
}
else
{
lean_object* v_a_175_; lean_object* v___x_176_; 
v_a_175_ = lean_ctor_get(v___y_173_, 0);
lean_inc(v_a_175_);
lean_dec_ref_known(v___y_173_, 1);
v___x_176_ = vastitas_storage_close(v_a_160_);
lean_dec(v_a_160_);
if (lean_obj_tag(v___x_176_) == 0)
{
lean_object* v___x_178_; uint8_t v_isShared_179_; uint8_t v_isSharedCheck_183_; 
v_isSharedCheck_183_ = !lean_is_exclusive(v___x_176_);
if (v_isSharedCheck_183_ == 0)
{
lean_object* v_unused_184_; 
v_unused_184_ = lean_ctor_get(v___x_176_, 0);
lean_dec(v_unused_184_);
v___x_178_ = v___x_176_;
v_isShared_179_ = v_isSharedCheck_183_;
goto v_resetjp_177_;
}
else
{
lean_dec(v___x_176_);
v___x_178_ = lean_box(0);
v_isShared_179_ = v_isSharedCheck_183_;
goto v_resetjp_177_;
}
v_resetjp_177_:
{
lean_object* v___x_181_; 
if (v_isShared_179_ == 0)
{
lean_ctor_set_tag(v___x_178_, 1);
lean_ctor_set(v___x_178_, 0, v_a_175_);
v___x_181_ = v___x_178_;
goto v_reusejp_180_;
}
else
{
lean_object* v_reuseFailAlloc_182_; 
v_reuseFailAlloc_182_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_182_, 0, v_a_175_);
v___x_181_ = v_reuseFailAlloc_182_;
goto v_reusejp_180_;
}
v_reusejp_180_:
{
return v___x_181_;
}
}
}
else
{
lean_dec(v_a_175_);
return v___x_176_;
}
}
}
}
else
{
lean_object* v_a_262_; lean_object* v___x_264_; uint8_t v_isShared_265_; uint8_t v_isSharedCheck_269_; 
v_a_262_ = lean_ctor_get(v___x_159_, 0);
v_isSharedCheck_269_ = !lean_is_exclusive(v___x_159_);
if (v_isSharedCheck_269_ == 0)
{
v___x_264_ = v___x_159_;
v_isShared_265_ = v_isSharedCheck_269_;
goto v_resetjp_263_;
}
else
{
lean_inc(v_a_262_);
lean_dec(v___x_159_);
v___x_264_ = lean_box(0);
v_isShared_265_ = v_isSharedCheck_269_;
goto v_resetjp_263_;
}
v_resetjp_263_:
{
lean_object* v___x_267_; 
if (v_isShared_265_ == 0)
{
v___x_267_ = v___x_264_;
goto v_reusejp_266_;
}
else
{
lean_object* v_reuseFailAlloc_268_; 
v_reuseFailAlloc_268_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_268_, 0, v_a_262_);
v___x_267_ = v_reuseFailAlloc_268_;
goto v_reusejp_266_;
}
v_reusejp_266_:
{
return v___x_267_;
}
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_generatedFailure___boxed(lean_object* v_a_270_){
_start:
{
lean_object* v_res_271_; 
v_res_271_ = lp_allocation__audit_generatedFailure();
return v_res_271_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_auditMark___boxed(lean_object* v_phase_274_, lean_object* v_a_00___x40___internal___hyg_275_){
_start:
{
uint32_t v_phase_boxed_276_; lean_object* v_res_277_; 
v_phase_boxed_276_ = lean_unbox_uint32(v_phase_274_);
lean_dec(v_phase_274_);
v_res_277_ = audit_mark_lean(v_phase_boxed_276_);
return v_res_277_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(lean_object* v_a_278_, lean_object* v_scope_279_, lean_object* v_range_280_, lean_object* v_b_281_, lean_object* v_i_282_){
_start:
{
lean_object* v_stop_284_; lean_object* v_step_285_; uint8_t v___x_286_; 
v_stop_284_ = lean_ctor_get(v_range_280_, 1);
v_step_285_ = lean_ctor_get(v_range_280_, 2);
v___x_286_ = lean_nat_dec_lt(v_i_282_, v_stop_284_);
if (v___x_286_ == 0)
{
lean_object* v___x_287_; 
lean_dec(v_i_282_);
v___x_287_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_287_, 0, v_b_281_);
return v___x_287_;
}
else
{
uint32_t v___x_288_; uint64_t v___x_289_; uint64_t v___x_290_; uint64_t v___x_291_; lean_object* v___x_292_; uint8_t v___x_293_; uint32_t v___x_294_; uint64_t v___x_295_; uint64_t v___x_296_; uint32_t v___x_297_; uint64_t v___x_298_; uint32_t v___x_299_; uint8_t v___x_300_; uint32_t v___x_301_; uint64_t v___x_302_; uint32_t v___x_303_; lean_object* v___x_304_; uint64_t v___x_305_; lean_object* v___x_306_; 
v___x_288_ = 0;
v___x_289_ = 0ULL;
v___x_290_ = 7ULL;
v___x_291_ = 85ULL;
v___x_292_ = lean_unsigned_to_nat(0u);
v___x_293_ = lean_nat_dec_eq(v_scope_279_, v___x_292_);
v___x_294_ = 3;
v___x_295_ = 17ULL;
v___x_296_ = 5ULL;
v___x_297_ = 1;
v___x_298_ = 11ULL;
v___x_299_ = 4;
v___x_300_ = 0;
v___x_301_ = 2;
v___x_302_ = 13ULL;
v___x_303_ = 5;
v___x_304_ = lean_box(0);
v___x_305_ = 35ULL;
v___x_306_ = vastitas_storage_pack3(v_a_278_, v___x_288_, v___x_289_, v___x_290_, v___x_291_, v___x_290_, v___x_293_, v___x_294_, v___x_289_, v___x_305_, v___x_295_, v___x_305_, v___x_293_, v___x_290_, v___x_295_, v___x_296_);
if (lean_obj_tag(v___x_306_) == 0)
{
lean_object* v___x_307_; 
lean_dec_ref_known(v___x_306_, 1);
v___x_307_ = vastitas_gemm_execute(v_a_278_, v___x_294_, v___x_289_, v___x_305_, v___x_295_, v___x_305_, v___x_293_, v___x_293_, v___x_297_, v___x_289_, v___x_295_, v___x_298_, v___x_295_, v___x_293_, v___x_293_, v___x_299_, v___x_289_, v___x_305_, v___x_298_, v___x_305_, v___x_293_, v___x_300_);
if (lean_obj_tag(v___x_307_) == 0)
{
uint64_t v___x_308_; uint64_t v___x_309_; uint64_t v___x_310_; lean_object* v___x_311_; 
lean_dec_ref_known(v___x_307_, 1);
v___x_308_ = 77ULL;
v___x_309_ = 48ULL;
v___x_310_ = 42ULL;
v___x_311_ = vastitas_storage_regroup3(v_a_278_, v___x_299_, v___x_289_, v___x_305_, v___x_298_, v___x_305_, v___x_293_, v___x_294_, v___x_289_, v___x_308_, v___x_296_, v___x_308_, v___x_293_, v___x_290_, v___x_296_, v___x_298_, v___x_309_, v___x_310_);
if (lean_obj_tag(v___x_311_) == 0)
{
lean_object* v___x_312_; 
lean_dec_ref_known(v___x_311_, 1);
v___x_312_ = vastitas_gemm_execute(v_a_278_, v___x_294_, v___x_289_, v___x_308_, v___x_296_, v___x_308_, v___x_293_, v___x_293_, v___x_301_, v___x_289_, v___x_296_, v___x_302_, v___x_296_, v___x_293_, v___x_293_, v___x_303_, v___x_289_, v___x_308_, v___x_302_, v___x_308_, v___x_293_, v___x_300_);
if (lean_obj_tag(v___x_312_) == 0)
{
lean_object* v___x_313_; 
lean_dec_ref_known(v___x_312_, 1);
v___x_313_ = lean_nat_add(v_i_282_, v_step_285_);
lean_dec(v_i_282_);
v_b_281_ = v___x_304_;
v_i_282_ = v___x_313_;
goto _start;
}
else
{
lean_dec(v_i_282_);
return v___x_312_;
}
}
else
{
lean_dec(v_i_282_);
return v___x_311_;
}
}
else
{
lean_dec(v_i_282_);
return v___x_307_;
}
}
else
{
lean_dec(v_i_282_);
return v___x_306_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg___boxed(lean_object* v_a_315_, lean_object* v_scope_316_, lean_object* v_range_317_, lean_object* v_b_318_, lean_object* v_i_319_, lean_object* v___y_320_){
_start:
{
lean_object* v_res_321_; 
v_res_321_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_315_, v_scope_316_, v_range_317_, v_b_318_, v_i_319_);
lean_dec_ref(v_range_317_);
lean_dec(v_scope_316_);
lean_dec(v_a_315_);
return v_res_321_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(lean_object* v_range_322_, lean_object* v_b_323_, lean_object* v_i_324_){
_start:
{
lean_object* v_stop_326_; lean_object* v_step_327_; uint8_t v___x_328_; 
v_stop_326_ = lean_ctor_get(v_range_322_, 1);
v_step_327_ = lean_ctor_get(v_range_322_, 2);
v___x_328_ = lean_nat_dec_lt(v_i_324_, v_stop_326_);
if (v___x_328_ == 0)
{
lean_object* v___x_329_; 
lean_dec(v_i_324_);
v___x_329_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_329_, 0, v_b_323_);
return v___x_329_;
}
else
{
lean_object* v___x_330_; lean_object* v___x_331_; 
v___x_330_ = lean_box(0);
v___x_331_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_331_) == 0)
{
lean_object* v___x_332_; 
lean_dec_ref_known(v___x_331_, 1);
v___x_332_ = lean_nat_add(v_i_324_, v_step_327_);
lean_dec(v_i_324_);
v_b_323_ = v___x_330_;
v_i_324_ = v___x_332_;
goto _start;
}
else
{
lean_dec(v_i_324_);
return v___x_331_;
}
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg___boxed(lean_object* v_range_334_, lean_object* v_b_335_, lean_object* v_i_336_, lean_object* v___y_337_){
_start:
{
lean_object* v_res_338_; 
v_res_338_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_334_, v_b_335_, v_i_336_);
lean_dec_ref(v_range_334_);
return v_res_338_;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* v_args_347_){
_start:
{
lean_object* v___x_349_; lean_object* v___x_350_; lean_object* v_impl_351_; lean_object* v___x_352_; lean_object* v___x_353_; lean_object* v___x_354_; lean_object* v___x_355_; lean_object* v_scope_356_; lean_object* v___x_357_; lean_object* v___x_358_; lean_object* v___x_359_; lean_object* v___x_360_; lean_object* v_reps_361_; lean_object* v___x_362_; lean_object* v___x_363_; lean_object* v___x_364_; uint8_t v_verify_365_; uint32_t v___x_366_; lean_object* v___x_367_; 
v___x_349_ = ((lean_object*)(lp_allocation__audit_main___closed__0));
v___x_350_ = lean_unsigned_to_nat(0u);
v_impl_351_ = l_List_get_x21Internal___redArg(v___x_349_, v_args_347_, v___x_350_);
v___x_352_ = lean_unsigned_to_nat(1u);
v___x_353_ = l_List_get_x21Internal___redArg(v___x_349_, v_args_347_, v___x_352_);
v___x_354_ = lean_string_utf8_byte_size(v___x_353_);
v___x_355_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_355_, 0, v___x_353_);
lean_ctor_set(v___x_355_, 1, v___x_350_);
lean_ctor_set(v___x_355_, 2, v___x_354_);
v_scope_356_ = l_String_Slice_toNat_x21(v___x_355_);
lean_dec_ref_known(v___x_355_, 3);
v___x_357_ = lean_unsigned_to_nat(2u);
v___x_358_ = l_List_get_x21Internal___redArg(v___x_349_, v_args_347_, v___x_357_);
v___x_359_ = lean_string_utf8_byte_size(v___x_358_);
v___x_360_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_360_, 0, v___x_358_);
lean_ctor_set(v___x_360_, 1, v___x_350_);
lean_ctor_set(v___x_360_, 2, v___x_359_);
v_reps_361_ = l_String_Slice_toNat_x21(v___x_360_);
lean_dec_ref_known(v___x_360_, 3);
v___x_362_ = lean_unsigned_to_nat(3u);
v___x_363_ = l_List_get_x21Internal___redArg(v___x_349_, v_args_347_, v___x_362_);
lean_dec(v_args_347_);
v___x_364_ = ((lean_object*)(lp_allocation__audit_main___closed__1));
v_verify_365_ = lean_string_dec_eq(v___x_363_, v___x_364_);
lean_dec(v___x_363_);
v___x_366_ = 1;
v___x_367_ = audit_mark_lean(v___x_366_);
if (lean_obj_tag(v___x_367_) == 0)
{
lean_object* v___x_368_; 
lean_dec_ref_known(v___x_367_, 1);
v___x_368_ = lp_allocation__audit_generatedOnce();
if (lean_obj_tag(v___x_368_) == 0)
{
uint32_t v___x_369_; lean_object* v___x_370_; 
lean_dec_ref_known(v___x_368_, 1);
v___x_369_ = 2;
v___x_370_ = audit_mark_lean(v___x_369_);
if (lean_obj_tag(v___x_370_) == 0)
{
lean_object* v___x_371_; uint8_t v___x_372_; 
lean_dec_ref_known(v___x_370_, 1);
v___x_371_ = ((lean_object*)(lp_allocation__audit_main___closed__2));
v___x_372_ = lean_string_dec_eq(v_impl_351_, v___x_371_);
if (v___x_372_ == 0)
{
lean_object* v___x_373_; uint8_t v___x_374_; 
v___x_373_ = ((lean_object*)(lp_allocation__audit_main___closed__3));
v___x_374_ = lean_string_dec_eq(v_impl_351_, v___x_373_);
lean_dec(v_impl_351_);
if (v___x_374_ == 0)
{
uint8_t v___x_375_; 
v___x_375_ = lean_nat_dec_eq(v_scope_356_, v___x_350_);
if (v___x_375_ == 0)
{
uint64_t v___x_376_; lean_object* v___x_377_; 
v___x_376_ = 9223372036854775807ULL;
v___x_377_ = vastitas_storage_new(v___x_376_);
if (lean_obj_tag(v___x_377_) == 0)
{
lean_object* v_a_378_; lean_object* v___y_380_; uint32_t v___x_393_; uint8_t v___x_394_; uint64_t v___x_395_; lean_object* v___x_396_; 
v_a_378_ = lean_ctor_get(v___x_377_, 0);
lean_inc(v_a_378_);
lean_dec_ref_known(v___x_377_, 1);
v___x_393_ = 0;
v___x_394_ = 0;
v___x_395_ = 595ULL;
v___x_396_ = vastitas_storage_allocate(v_a_378_, v___x_393_, v___x_394_, v___x_395_);
if (lean_obj_tag(v___x_396_) == 0)
{
uint64_t v___x_397_; uint64_t v___x_398_; uint64_t v___x_399_; lean_object* v___x_400_; 
lean_dec_ref_known(v___x_396_, 1);
v___x_397_ = 0ULL;
v___x_398_ = 1ULL;
v___x_399_ = 13842939354630062080ULL;
v___x_400_ = vastitas_storage_fill(v_a_378_, v___x_393_, v___x_397_, v___x_395_, v___x_398_, v___x_395_, v___x_375_, v___x_394_, v___x_399_, v___x_397_);
if (lean_obj_tag(v___x_400_) == 0)
{
uint64_t v___x_401_; uint64_t v___x_402_; uint64_t v___x_403_; lean_object* v___x_404_; 
lean_dec_ref_known(v___x_400_, 1);
v___x_401_ = 7ULL;
v___x_402_ = 85ULL;
v___x_403_ = 4593671619917905920ULL;
v___x_404_ = vastitas_storage_fill(v_a_378_, v___x_393_, v___x_397_, v___x_401_, v___x_402_, v___x_401_, v___x_375_, v___x_394_, v___x_403_, v___x_397_);
if (lean_obj_tag(v___x_404_) == 0)
{
uint64_t v___x_405_; lean_object* v___x_406_; 
lean_dec_ref_known(v___x_404_, 1);
v___x_405_ = 4607182418800017408ULL;
v___x_406_ = vastitas_storage_store(v_a_378_, v___x_393_, v___x_397_, v___x_401_, v___x_402_, v___x_401_, v___x_375_, v___x_397_, v___x_397_, v___x_394_, v___x_405_, v___x_397_);
if (lean_obj_tag(v___x_406_) == 0)
{
uint64_t v___x_407_; uint64_t v___x_408_; lean_object* v___x_409_; 
lean_dec_ref_known(v___x_406_, 1);
v___x_407_ = 6ULL;
v___x_408_ = 13826050856027422720ULL;
v___x_409_ = vastitas_storage_store(v_a_378_, v___x_393_, v___x_397_, v___x_401_, v___x_402_, v___x_401_, v___x_375_, v___x_407_, v___x_398_, v___x_394_, v___x_408_, v___x_397_);
if (lean_obj_tag(v___x_409_) == 0)
{
uint64_t v___x_410_; lean_object* v___x_411_; 
lean_dec_ref_known(v___x_409_, 1);
v___x_410_ = 187ULL;
v___x_411_ = vastitas_storage_allocate(v_a_378_, v___x_366_, v___x_394_, v___x_410_);
if (lean_obj_tag(v___x_411_) == 0)
{
lean_object* v___x_412_; 
lean_dec_ref_known(v___x_411_, 1);
v___x_412_ = vastitas_storage_fill(v_a_378_, v___x_366_, v___x_397_, v___x_410_, v___x_398_, v___x_410_, v___x_375_, v___x_394_, v___x_399_, v___x_397_);
if (lean_obj_tag(v___x_412_) == 0)
{
uint64_t v___x_413_; uint64_t v___x_414_; uint64_t v___x_415_; lean_object* v___x_416_; 
lean_dec_ref_known(v___x_412_, 1);
v___x_413_ = 17ULL;
v___x_414_ = 11ULL;
v___x_415_ = 13821547256400052224ULL;
v___x_416_ = vastitas_storage_fill(v_a_378_, v___x_366_, v___x_397_, v___x_413_, v___x_414_, v___x_413_, v___x_375_, v___x_394_, v___x_415_, v___x_397_);
if (lean_obj_tag(v___x_416_) == 0)
{
uint64_t v___x_417_; uint64_t v___x_418_; lean_object* v___x_419_; 
lean_dec_ref_known(v___x_416_, 1);
v___x_417_ = 10ULL;
v___x_418_ = 4602678819172646912ULL;
v___x_419_ = vastitas_storage_store(v_a_378_, v___x_366_, v___x_397_, v___x_413_, v___x_414_, v___x_413_, v___x_375_, v___x_397_, v___x_417_, v___x_394_, v___x_418_, v___x_397_);
if (lean_obj_tag(v___x_419_) == 0)
{
uint64_t v___x_420_; uint64_t v___x_421_; lean_object* v___x_422_; 
lean_dec_ref_known(v___x_419_, 1);
v___x_420_ = 16ULL;
v___x_421_ = 13828302655841107968ULL;
v___x_422_ = vastitas_storage_store(v_a_378_, v___x_366_, v___x_397_, v___x_413_, v___x_414_, v___x_413_, v___x_375_, v___x_420_, v___x_397_, v___x_394_, v___x_421_, v___x_397_);
if (lean_obj_tag(v___x_422_) == 0)
{
uint64_t v___x_423_; lean_object* v___x_424_; 
lean_dec_ref_known(v___x_422_, 1);
v___x_423_ = 65ULL;
v___x_424_ = vastitas_storage_allocate(v_a_378_, v___x_369_, v___x_394_, v___x_423_);
if (lean_obj_tag(v___x_424_) == 0)
{
lean_object* v___x_425_; 
lean_dec_ref_known(v___x_424_, 1);
v___x_425_ = vastitas_storage_fill(v_a_378_, v___x_369_, v___x_397_, v___x_423_, v___x_398_, v___x_423_, v___x_375_, v___x_394_, v___x_399_, v___x_397_);
if (lean_obj_tag(v___x_425_) == 0)
{
uint64_t v___x_426_; uint64_t v___x_427_; lean_object* v___x_428_; 
lean_dec_ref_known(v___x_425_, 1);
v___x_426_ = 5ULL;
v___x_427_ = 13ULL;
v___x_428_ = vastitas_storage_fill(v_a_378_, v___x_369_, v___x_397_, v___x_426_, v___x_427_, v___x_426_, v___x_375_, v___x_394_, v___x_418_, v___x_397_);
if (lean_obj_tag(v___x_428_) == 0)
{
uint64_t v___x_429_; lean_object* v___x_430_; 
lean_dec_ref_known(v___x_428_, 1);
v___x_429_ = 4ULL;
v___x_430_ = vastitas_storage_store(v_a_378_, v___x_369_, v___x_397_, v___x_426_, v___x_427_, v___x_426_, v___x_375_, v___x_429_, v___x_397_, v___x_394_, v___x_415_, v___x_397_);
if (lean_obj_tag(v___x_430_) == 0)
{
uint64_t v___x_431_; uint64_t v___x_432_; lean_object* v___x_433_; 
lean_dec_ref_known(v___x_430_, 1);
v___x_431_ = 12ULL;
v___x_432_ = 4604930618986332160ULL;
v___x_433_ = vastitas_storage_store(v_a_378_, v___x_369_, v___x_397_, v___x_426_, v___x_427_, v___x_426_, v___x_375_, v___x_397_, v___x_431_, v___x_394_, v___x_432_, v___x_397_);
if (lean_obj_tag(v___x_433_) == 0)
{
uint32_t v___x_434_; lean_object* v___x_435_; 
lean_dec_ref_known(v___x_433_, 1);
v___x_434_ = 3;
v___x_435_ = vastitas_storage_allocate(v_a_378_, v___x_434_, v___x_394_, v___x_395_);
if (lean_obj_tag(v___x_435_) == 0)
{
lean_object* v___x_436_; 
lean_dec_ref_known(v___x_435_, 1);
v___x_436_ = vastitas_storage_fill(v_a_378_, v___x_434_, v___x_397_, v___x_395_, v___x_398_, v___x_395_, v___x_375_, v___x_394_, v___x_399_, v___x_397_);
if (lean_obj_tag(v___x_436_) == 0)
{
uint32_t v___x_437_; uint64_t v___x_438_; lean_object* v___x_439_; 
lean_dec_ref_known(v___x_436_, 1);
v___x_437_ = 4;
v___x_438_ = 385ULL;
v___x_439_ = vastitas_storage_allocate(v_a_378_, v___x_437_, v___x_394_, v___x_438_);
if (lean_obj_tag(v___x_439_) == 0)
{
lean_object* v___x_440_; 
lean_dec_ref_known(v___x_439_, 1);
v___x_440_ = vastitas_storage_fill(v_a_378_, v___x_437_, v___x_397_, v___x_438_, v___x_398_, v___x_438_, v___x_375_, v___x_394_, v___x_399_, v___x_397_);
if (lean_obj_tag(v___x_440_) == 0)
{
uint32_t v___x_441_; uint64_t v___x_442_; lean_object* v___x_443_; 
lean_dec_ref_known(v___x_440_, 1);
v___x_441_ = 5;
v___x_442_ = 1001ULL;
v___x_443_ = vastitas_storage_allocate(v_a_378_, v___x_441_, v___x_394_, v___x_442_);
if (lean_obj_tag(v___x_443_) == 0)
{
lean_object* v___x_444_; 
lean_dec_ref_known(v___x_443_, 1);
v___x_444_ = vastitas_storage_fill(v_a_378_, v___x_441_, v___x_397_, v___x_442_, v___x_398_, v___x_442_, v___x_375_, v___x_394_, v___x_399_, v___x_397_);
if (lean_obj_tag(v___x_444_) == 0)
{
uint32_t v___x_445_; uint64_t v___x_446_; lean_object* v___x_447_; 
lean_dec_ref_known(v___x_444_, 1);
v___x_445_ = lean_uint32_of_nat(v_scope_356_);
v___x_446_ = lean_uint64_of_nat(v_reps_361_);
v___x_447_ = bench_begin_lean(v___x_445_, v___x_446_, v_verify_365_);
if (lean_obj_tag(v___x_447_) == 0)
{
lean_object* v___x_448_; lean_object* v___x_449_; lean_object* v___x_450_; 
lean_dec_ref_known(v___x_447_, 1);
v___x_448_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_448_, 0, v___x_350_);
lean_ctor_set(v___x_448_, 1, v_reps_361_);
lean_ctor_set(v___x_448_, 2, v___x_352_);
v___x_449_ = lean_box(0);
v___x_450_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_378_, v_scope_356_, v___x_448_, v___x_449_, v___x_350_);
lean_dec_ref_known(v___x_448_, 3);
lean_dec(v_scope_356_);
if (lean_obj_tag(v___x_450_) == 0)
{
lean_object* v___x_451_; 
lean_dec_ref_known(v___x_450_, 1);
v___x_451_ = bench_stop_lean();
if (lean_obj_tag(v___x_451_) == 0)
{
lean_object* v___x_452_; 
lean_dec_ref_known(v___x_451_, 1);
v___x_452_ = bench_verify_lean(v_a_378_, v___x_446_);
if (lean_obj_tag(v___x_452_) == 0)
{
uint64_t v___x_453_; uint64_t v___x_454_; lean_object* v___x_455_; 
lean_dec_ref_known(v___x_452_, 1);
v___x_453_ = 77ULL;
v___x_454_ = 13831222958724481024ULL;
v___x_455_ = vastitas_storage_expect(v_a_378_, v___x_441_, v___x_397_, v___x_453_, v___x_427_, v___x_453_, v___x_375_, v___x_397_, v___x_397_, v___x_394_, v___x_454_, v___x_397_);
if (lean_obj_tag(v___x_455_) == 0)
{
uint64_t v___x_456_; lean_object* v___x_457_; 
lean_dec_ref_known(v___x_455_, 1);
v___x_456_ = 13832876624212656128ULL;
v___x_457_ = vastitas_storage_expect(v_a_378_, v___x_441_, v___x_397_, v___x_453_, v___x_427_, v___x_453_, v___x_375_, v___x_407_, v___x_431_, v___x_394_, v___x_456_, v___x_397_);
if (lean_obj_tag(v___x_457_) == 0)
{
uint64_t v___x_458_; uint64_t v___x_459_; lean_object* v___x_460_; 
lean_dec_ref_known(v___x_457_, 1);
v___x_458_ = 76ULL;
v___x_459_ = 13827739705887686656ULL;
v___x_460_ = vastitas_storage_expect(v_a_378_, v___x_441_, v___x_397_, v___x_453_, v___x_427_, v___x_453_, v___x_375_, v___x_458_, v___x_397_, v___x_394_, v___x_459_, v___x_397_);
if (lean_obj_tag(v___x_460_) == 0)
{
lean_object* v___x_461_; 
lean_dec_ref_known(v___x_460_, 1);
v___x_461_ = vastitas_storage_drop(v_a_378_, v___x_441_);
if (lean_obj_tag(v___x_461_) == 0)
{
lean_object* v___x_462_; 
lean_dec_ref_known(v___x_461_, 1);
v___x_462_ = vastitas_storage_drop(v_a_378_, v___x_437_);
if (lean_obj_tag(v___x_462_) == 0)
{
lean_object* v___x_463_; 
lean_dec_ref_known(v___x_462_, 1);
v___x_463_ = vastitas_storage_drop(v_a_378_, v___x_434_);
if (lean_obj_tag(v___x_463_) == 0)
{
lean_object* v___x_464_; 
lean_dec_ref_known(v___x_463_, 1);
v___x_464_ = vastitas_storage_drop(v_a_378_, v___x_369_);
if (lean_obj_tag(v___x_464_) == 0)
{
lean_object* v___x_465_; 
lean_dec_ref_known(v___x_464_, 1);
v___x_465_ = vastitas_storage_drop(v_a_378_, v___x_366_);
if (lean_obj_tag(v___x_465_) == 0)
{
lean_object* v___x_466_; 
lean_dec_ref_known(v___x_465_, 1);
v___x_466_ = vastitas_storage_drop(v_a_378_, v___x_393_);
v___y_380_ = v___x_466_;
goto v___jp_379_;
}
else
{
v___y_380_ = v___x_465_;
goto v___jp_379_;
}
}
else
{
v___y_380_ = v___x_464_;
goto v___jp_379_;
}
}
else
{
v___y_380_ = v___x_463_;
goto v___jp_379_;
}
}
else
{
v___y_380_ = v___x_462_;
goto v___jp_379_;
}
}
else
{
v___y_380_ = v___x_461_;
goto v___jp_379_;
}
}
else
{
v___y_380_ = v___x_460_;
goto v___jp_379_;
}
}
else
{
v___y_380_ = v___x_457_;
goto v___jp_379_;
}
}
else
{
v___y_380_ = v___x_455_;
goto v___jp_379_;
}
}
else
{
v___y_380_ = v___x_452_;
goto v___jp_379_;
}
}
else
{
v___y_380_ = v___x_451_;
goto v___jp_379_;
}
}
else
{
v___y_380_ = v___x_450_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_447_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_444_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_443_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_440_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_439_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_436_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_435_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_433_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_430_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_428_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_425_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_424_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_422_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_419_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_416_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_412_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_411_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_409_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_406_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_404_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_400_;
goto v___jp_379_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v___y_380_ = v___x_396_;
goto v___jp_379_;
}
v___jp_379_:
{
if (lean_obj_tag(v___y_380_) == 0)
{
lean_object* v___x_381_; 
lean_dec_ref_known(v___y_380_, 1);
v___x_381_ = vastitas_storage_close(v_a_378_);
lean_dec(v_a_378_);
if (lean_obj_tag(v___x_381_) == 0)
{
lean_object* v___x_382_; 
lean_dec_ref_known(v___x_381_, 1);
v___x_382_ = bench_report_lean();
return v___x_382_;
}
else
{
return v___x_381_;
}
}
else
{
lean_object* v_a_383_; lean_object* v___x_384_; 
v_a_383_ = lean_ctor_get(v___y_380_, 0);
lean_inc(v_a_383_);
lean_dec_ref_known(v___y_380_, 1);
v___x_384_ = vastitas_storage_close(v_a_378_);
lean_dec(v_a_378_);
if (lean_obj_tag(v___x_384_) == 0)
{
lean_object* v___x_386_; uint8_t v_isShared_387_; uint8_t v_isSharedCheck_391_; 
v_isSharedCheck_391_ = !lean_is_exclusive(v___x_384_);
if (v_isSharedCheck_391_ == 0)
{
lean_object* v_unused_392_; 
v_unused_392_ = lean_ctor_get(v___x_384_, 0);
lean_dec(v_unused_392_);
v___x_386_ = v___x_384_;
v_isShared_387_ = v_isSharedCheck_391_;
goto v_resetjp_385_;
}
else
{
lean_dec(v___x_384_);
v___x_386_ = lean_box(0);
v_isShared_387_ = v_isSharedCheck_391_;
goto v_resetjp_385_;
}
v_resetjp_385_:
{
lean_object* v___x_389_; 
if (v_isShared_387_ == 0)
{
lean_ctor_set_tag(v___x_386_, 1);
lean_ctor_set(v___x_386_, 0, v_a_383_);
v___x_389_ = v___x_386_;
goto v_reusejp_388_;
}
else
{
lean_object* v_reuseFailAlloc_390_; 
v_reuseFailAlloc_390_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_390_, 0, v_a_383_);
v___x_389_ = v_reuseFailAlloc_390_;
goto v_reusejp_388_;
}
v_reusejp_388_:
{
return v___x_389_;
}
}
}
else
{
lean_dec(v_a_383_);
return v___x_384_;
}
}
}
}
else
{
lean_object* v_a_467_; lean_object* v___x_469_; uint8_t v_isShared_470_; uint8_t v_isSharedCheck_474_; 
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
v_a_467_ = lean_ctor_get(v___x_377_, 0);
v_isSharedCheck_474_ = !lean_is_exclusive(v___x_377_);
if (v_isSharedCheck_474_ == 0)
{
v___x_469_ = v___x_377_;
v_isShared_470_ = v_isSharedCheck_474_;
goto v_resetjp_468_;
}
else
{
lean_inc(v_a_467_);
lean_dec(v___x_377_);
v___x_469_ = lean_box(0);
v_isShared_470_ = v_isSharedCheck_474_;
goto v_resetjp_468_;
}
v_resetjp_468_:
{
lean_object* v___x_472_; 
if (v_isShared_470_ == 0)
{
v___x_472_ = v___x_469_;
goto v_reusejp_471_;
}
else
{
lean_object* v_reuseFailAlloc_473_; 
v_reuseFailAlloc_473_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_473_, 0, v_a_467_);
v___x_472_ = v_reuseFailAlloc_473_;
goto v_reusejp_471_;
}
v_reusejp_471_:
{
return v___x_472_;
}
}
}
}
else
{
uint32_t v___x_475_; uint64_t v___x_476_; lean_object* v___x_477_; 
lean_dec(v_scope_356_);
v___x_475_ = 0;
v___x_476_ = lean_uint64_of_nat(v_reps_361_);
v___x_477_ = bench_begin_lean(v___x_475_, v___x_476_, v_verify_365_);
if (lean_obj_tag(v___x_477_) == 0)
{
lean_object* v___x_478_; lean_object* v___x_479_; lean_object* v___x_480_; 
lean_dec_ref_known(v___x_477_, 1);
v___x_478_ = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(v___x_478_, 0, v___x_350_);
lean_ctor_set(v___x_478_, 1, v_reps_361_);
lean_ctor_set(v___x_478_, 2, v___x_352_);
v___x_479_ = lean_box(0);
v___x_480_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v___x_478_, v___x_479_, v___x_350_);
lean_dec_ref_known(v___x_478_, 3);
if (lean_obj_tag(v___x_480_) == 0)
{
lean_object* v___x_481_; 
lean_dec_ref_known(v___x_480_, 1);
v___x_481_ = bench_stop_lean();
if (lean_obj_tag(v___x_481_) == 0)
{
lean_object* v___x_482_; 
lean_dec_ref_known(v___x_481_, 1);
v___x_482_ = bench_report_lean();
return v___x_482_;
}
else
{
return v___x_481_;
}
}
else
{
return v___x_480_;
}
}
else
{
lean_dec(v_reps_361_);
return v___x_477_;
}
}
}
else
{
uint32_t v___x_483_; uint64_t v___x_484_; lean_object* v___x_485_; 
v___x_483_ = lean_uint32_of_nat(v_scope_356_);
lean_dec(v_scope_356_);
v___x_484_ = lean_uint64_of_nat(v_reps_361_);
lean_dec(v_reps_361_);
v___x_485_ = bench_c_run_lean(v___x_483_, v___x_484_, v_verify_365_);
if (lean_obj_tag(v___x_485_) == 0)
{
lean_object* v___x_486_; 
lean_dec_ref_known(v___x_485_, 1);
v___x_486_ = bench_report_lean();
return v___x_486_;
}
else
{
return v___x_485_;
}
}
}
else
{
uint32_t v___x_487_; uint64_t v___x_488_; lean_object* v___x_489_; 
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
lean_dec(v_impl_351_);
v___x_487_ = 0;
v___x_488_ = 1ULL;
v___x_489_ = bench_begin_lean(v___x_487_, v___x_488_, v___x_372_);
if (lean_obj_tag(v___x_489_) == 0)
{
lean_object* v___x_490_; 
lean_dec_ref_known(v___x_489_, 1);
v___x_490_ = lp_allocation__audit_generatedFailure();
if (lean_obj_tag(v___x_490_) == 0)
{
lean_object* v___x_492_; uint8_t v_isShared_493_; uint8_t v_isSharedCheck_498_; 
v_isSharedCheck_498_ = !lean_is_exclusive(v___x_490_);
if (v_isSharedCheck_498_ == 0)
{
lean_object* v_unused_499_; 
v_unused_499_ = lean_ctor_get(v___x_490_, 0);
lean_dec(v_unused_499_);
v___x_492_ = v___x_490_;
v_isShared_493_ = v_isSharedCheck_498_;
goto v_resetjp_491_;
}
else
{
lean_dec(v___x_490_);
v___x_492_ = lean_box(0);
v_isShared_493_ = v_isSharedCheck_498_;
goto v_resetjp_491_;
}
v_resetjp_491_:
{
lean_object* v___x_494_; lean_object* v___x_496_; 
v___x_494_ = ((lean_object*)(lp_allocation__audit_main___closed__5));
if (v_isShared_493_ == 0)
{
lean_ctor_set_tag(v___x_492_, 1);
lean_ctor_set(v___x_492_, 0, v___x_494_);
v___x_496_ = v___x_492_;
goto v_reusejp_495_;
}
else
{
lean_object* v_reuseFailAlloc_497_; 
v_reuseFailAlloc_497_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_497_, 0, v___x_494_);
v___x_496_ = v_reuseFailAlloc_497_;
goto v_reusejp_495_;
}
v_reusejp_495_:
{
return v___x_496_;
}
}
}
else
{
lean_object* v_a_500_; lean_object* v___x_501_; lean_object* v___x_502_; uint8_t v___x_503_; 
v_a_500_ = lean_ctor_get(v___x_490_, 0);
lean_inc(v_a_500_);
v___x_501_ = lean_io_error_to_string(v_a_500_);
v___x_502_ = ((lean_object*)(lp_allocation__audit_main___closed__6));
v___x_503_ = lean_string_dec_eq(v___x_501_, v___x_502_);
lean_dec_ref(v___x_501_);
if (v___x_503_ == 0)
{
return v___x_490_;
}
else
{
lean_object* v___x_504_; 
lean_dec_ref_known(v___x_490_, 1);
v___x_504_ = bench_stop_lean();
if (lean_obj_tag(v___x_504_) == 0)
{
lean_object* v___x_505_; 
lean_dec_ref_known(v___x_504_, 1);
v___x_505_ = bench_report_lean();
return v___x_505_;
}
else
{
return v___x_504_;
}
}
}
}
else
{
return v___x_489_;
}
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
lean_dec(v_impl_351_);
return v___x_370_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
lean_dec(v_impl_351_);
return v___x_368_;
}
}
else
{
lean_dec(v_reps_361_);
lean_dec(v_scope_356_);
lean_dec(v_impl_351_);
return v___x_367_;
}
}
}
LEAN_EXPORT lean_object* lp_allocation__audit_main___boxed(lean_object* v_args_506_, lean_object* v_a_507_){
_start:
{
lean_object* v_res_508_; 
v_res_508_ = _lean_main(v_args_506_);
return v_res_508_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(lean_object* v_a_509_, lean_object* v_scope_510_, lean_object* v_range_511_, lean_object* v_b_512_, lean_object* v_i_513_, lean_object* v_hs_514_, lean_object* v_hl_515_){
_start:
{
lean_object* v___x_517_; 
v___x_517_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___redArg(v_a_509_, v_scope_510_, v_range_511_, v_b_512_, v_i_513_);
return v___x_517_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0___boxed(lean_object* v_a_518_, lean_object* v_scope_519_, lean_object* v_range_520_, lean_object* v_b_521_, lean_object* v_i_522_, lean_object* v_hs_523_, lean_object* v_hl_524_, lean_object* v___y_525_){
_start:
{
lean_object* v_res_526_; 
v_res_526_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__0(v_a_518_, v_scope_519_, v_range_520_, v_b_521_, v_i_522_, v_hs_523_, v_hl_524_);
lean_dec_ref(v_range_520_);
lean_dec(v_scope_519_);
lean_dec(v_a_518_);
return v_res_526_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(lean_object* v_range_527_, lean_object* v_b_528_, lean_object* v_i_529_, lean_object* v_hs_530_, lean_object* v_hl_531_){
_start:
{
lean_object* v___x_533_; 
v___x_533_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___redArg(v_range_527_, v_b_528_, v_i_529_);
return v___x_533_;
}
}
LEAN_EXPORT lean_object* lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1___boxed(lean_object* v_range_534_, lean_object* v_b_535_, lean_object* v_i_536_, lean_object* v_hs_537_, lean_object* v_hl_538_, lean_object* v___y_539_){
_start:
{
lean_object* v_res_540_; 
v_res_540_ = lp_allocation__audit___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00main_spec__1(v_range_534_, v_b_535_, v_i_536_, v_hs_537_, v_hl_538_);
lean_dec_ref(v_range_534_);
return v_res_540_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_vastitas__storage__native_VastitasStorageNative(uint8_t builtin);
lean_object* initialize_vastitas__gemm__native_VastitasGemmNative(uint8_t builtin);
lean_object* initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_allocation__audit_Main(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
lean_initialize_runtime_module();
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__storage__native_VastitasStorageNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__gemm__native_VastitasGemmNative(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_vastitas__kernel_VastitasKernel_IndexedRuntime(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
lp_allocation__audit_VastitasGenerated_f__0 = _init_lp_allocation__audit_VastitasGenerated_f__0();
lean_mark_persistent(lp_allocation__audit_VastitasGenerated_f__0);
return lean_io_result_mk_ok(lean_box(0));
}
char ** lean_setup_args(int argc, char ** argv);
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#endif
lean_object* run_main(int argc, char ** argv) {
    lean_object* in = lean_box(0);
    int i = argc;
    while (i > 1) {
      lean_object* n;
      i--;
      n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
      in = n;
    }
    return _lean_main(in);
}
int main(int argc, char ** argv) {
#if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  SetConsoleOutputCP(CP_UTF8);
#endif
  lean_object* res;
  argv = lean_setup_args(argc, argv);
  res = initialize_allocation__audit_Main(1 /* builtin */);
  lean_io_mark_end_initialization();
  if (lean_io_result_is_ok(res)) {
    lean_dec_ref(res);
    lean_init_task_manager();
    res = lean_run_main(&run_main, argc, argv);
  }
  lean_finalize_task_manager();
  if (lean_io_result_is_ok(res)) {
    int ret = 0;
    lean_dec_ref(res);
    return ret;
  } else {
    lean_io_result_show_error(res);
    lean_dec_ref(res);
    return 1;
  }
}
#ifdef __cplusplus
}
#endif
