/* Fixture data independently constructed from cases.json. */
static const unsigned scalar = 0;
static const uint64_t dim_i=7, dim_k=17, dim_j=5, dim_a=11;
static const VStorageLayout views[7] = {{0,7,85,7,0},{0,17,11,17,0},{0,5,13,5,0},{0,35,17,35,0},{0,35,11,35,0},{0,77,13,77,0},{0,77,5,77,0}};
static const uint64_t elements[6] = {595,187,65,595,385,1001};
static const double values[3][2] = {{0x1.0000000000000p-3,0x0.0p+0},{-0x1.0000000000000p-2,0x0.0p+0},{0x1.0000000000000p-1,-0x0.0p+0}};
static const double sentinel[2] = {-0x1.c000000000000p+2,0x0.0p+0};
static const double alpha[2] = {1,0}, beta[2] = {0,0};
typedef struct { uint64_t row, col; double value[2]; } Patch;
static const Patch patches[3][2] = {{{0,0,{0x1.0000000000000p+0,-0x0.0p+0}},{6,1,{-0x1.0000000000000p-1,0x0.0p+0}}},{{0,10,{0x1.0000000000000p-1,0x0.0p+0}},{16,0,{-0x1.8000000000000p-1,-0x0.0p+0}}},{{4,0,{-0x1.0000000000000p-2,0x0.0p+0}},{0,12,{0x1.8000000000000p-1,-0x0.0p+0}}}};
static const Patch expected[3] = {{0,0,{-0x1.2600000000000p+0,0x0.0p+0}},{6,12,{-0x1.8400000000000p+0,0x0.0p+0}},{76,0,{-0x1.6000000000000p-1,0x0.0p+0}}};
