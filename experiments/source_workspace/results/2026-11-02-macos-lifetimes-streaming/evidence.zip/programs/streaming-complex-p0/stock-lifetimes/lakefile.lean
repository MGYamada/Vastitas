import Lake
open Lake DSL
package allocation_audit where
  moreLinkArgs := #["-fno-lto", "-L/private/tmp/vastitas-lean-lifetimes-a6ff4d0-macos/build/runtime", "-Wl,-map,/private/tmp/vastitas-source-lifetimes-8212d7d-macos-streaming/programs/streaming-complex-p0/stock-lifetimes/link.map", "/private/tmp/vastitas-lean-lifetimes-a6ff4d0-macos/build/lifetime.o", "-L", "/Users/masa/.elan/toolchains/leanprover--lean4---v4.35.0/lib"]
require vastitas_kernel from "/Users/masa/.codex/worktrees/review-pr193-iterator/Vastitas/lean-kernel"
require vastitas_gemm_native from "./numerical" with
  NameMap.empty.insert `openblas "/private/tmp/vastitas-packing-build-20261101b/stock"
lean_exe audit where
  root := `Main
  moreLeancArgs := #["-O3", "-fno-lto", "-DAUDIT_GENERATED_MAIN=1", "-include", "/private/tmp/vastitas-source-lifetimes-8212d7d-macos-streaming/programs/streaming-complex-p0/stock-lifetimes/native/audit.h"]
