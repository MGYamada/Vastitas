import Lake
open Lake DSL System

package vastitas_storage_native where
  version := v!"0.1.0"

input_file storageHeader where path := "storage.h"
input_file storageSource where path := "storage.c"
input_file ffiSource where path := "ffi.c"
input_file ffiResultHeader where path := "ffi_result.h"
input_file diagonalSource where path := "diagonal.c"
input_file diagonalHeader where path := "diagonal.h"

target storageObject pkg : FilePath := do
  let source ← storageSource.fetch
  let header ← storageHeader.fetch
  let source ← source.bindM fun path => header.mapM fun _ => pure path
  buildO (pkg.buildDir / "storage.o") source #[] #["-std=c11", "-O3", "-fno-lto", "-I/private/tmp/vastitas-source-lifetimes-8212d7d-macos/programs/bulk-complex-p1/diagnostic-lifetimes/native", "-I/private/tmp/vastitas-source-lifetimes-8212d7d-macos/programs/bulk-complex-p1/diagnostic-lifetimes/numerical", "-I/Users/masa/.codex/worktrees/review-pr193-iterator/Vastitas/experiments/contraction_trees", "-I/private/tmp/vastitas-source-lifetimes-8212d7d-macos/programs/bulk-complex-p1/diagnostic-lifetimes/openblas_include", "-fPIC", "-Wall", "-Wextra", "-Werror"]

target diagonalObject pkg : FilePath := do
  let source ← diagonalSource.fetch
  let headers := #[← storageHeader.fetch, ← diagonalHeader.fetch]
  let source ← source.bindM fun path => (Job.collectArray headers).mapM fun _ => pure path
  buildO (pkg.buildDir / "diagonal.o") source #[] #["-std=c11", "-O3", "-fno-lto", "-I/private/tmp/vastitas-source-lifetimes-8212d7d-macos/programs/bulk-complex-p1/diagnostic-lifetimes/native", "-I/private/tmp/vastitas-source-lifetimes-8212d7d-macos/programs/bulk-complex-p1/diagnostic-lifetimes/numerical", "-I/Users/masa/.codex/worktrees/review-pr193-iterator/Vastitas/experiments/contraction_trees", "-I/private/tmp/vastitas-source-lifetimes-8212d7d-macos/programs/bulk-complex-p1/diagnostic-lifetimes/openblas_include", "-fPIC", "-Wall", "-Wextra", "-Werror"]

target ffiObject pkg : FilePath := do
  let source ← ffiSource.fetch
  let headers := #[← storageHeader.fetch, ← diagonalHeader.fetch, ← ffiResultHeader.fetch]
  let source ← source.bindM fun path => (Job.collectArray headers).mapM fun _ => pure path
  buildLeanO (pkg.buildDir / "ffi.o") source #[] #["-std=c11", "-O3", "-fno-lto", "-I/private/tmp/vastitas-source-lifetimes-8212d7d-macos/programs/bulk-complex-p1/diagnostic-lifetimes/native", "-I/private/tmp/vastitas-source-lifetimes-8212d7d-macos/programs/bulk-complex-p1/diagnostic-lifetimes/numerical", "-I/Users/masa/.codex/worktrees/review-pr193-iterator/Vastitas/experiments/contraction_trees", "-I/private/tmp/vastitas-source-lifetimes-8212d7d-macos/programs/bulk-complex-p1/diagnostic-lifetimes/openblas_include", "-fPIC", "-Wall", "-Wextra", "-Werror"]

input_file auditSource where path := "audit.c"
input_file auditHeader where path := "audit.h"
target auditObject pkg : FilePath := do
  let source ← auditSource.fetch
  let header ← auditHeader.fetch
  let source ← source.bindM fun path => header.mapM fun _ => pure path
  buildLeanO (pkg.buildDir / "audit.o") source #[] #["-std=c11", "-O3", "-fno-lto", "-Wall", "-Wextra", "-Werror", "-DAUDIT_PRODUCTION_SHARED=1"]

input_file bridgeSource where path := "bridge.c"
input_file bridgeHeader where path := "bridge.h"
input_file packingHeader where path := "packing_observer.h"
input_file observerHeader where path := "observer.h"
target bridgeObject pkg : FilePath := do
  let source ← bridgeSource.fetch
  let headers := #[← bridgeHeader.fetch, ← observerHeader.fetch, ← packingHeader.fetch]
  let source ← source.bindM fun path => (Job.collectArray headers).mapM fun _ => pure path
  buildLeanO (pkg.buildDir / "bridge.o") source #[] #["-std=c11", "-O3", "-fno-lto", "-Wall", "-Wextra", "-Werror", "-DSOURCE_WORKSPACE_DIAGNOSTIC=1", "-DSOURCE_WORKSPACE_PACKING=1"]

input_file heapSource where path := "heap.c"
input_file heapHeader where path := "heap.h"
input_file lifetimeHeader where path := "lifetime.h"
input_file allocatorSource where path := "allocator.c"
input_file allocatorHeader where path := "allocator.h"
input_file allocatorStatsHeader where path := "mimalloc-stats.h"
input_file allocatorApiHeader where path := "mimalloc.h"
target allocatorObject pkg : FilePath := do
  let source ← allocatorSource.fetch
  let headers := #[← allocatorHeader.fetch, ← allocatorStatsHeader.fetch, ← allocatorApiHeader.fetch, ← heapHeader.fetch]
  let source ← source.bindM fun path => (Job.collectArray headers).mapM fun _ => pure path
  buildLeanO (pkg.buildDir / "allocator.o") source #[] #["-std=c11", "-O3", "-fno-lto", "-Wall", "-Wextra", "-Werror", "-I", "/private/tmp/vastitas-source-lifetimes-8212d7d-macos/programs/bulk-complex-p1/diagnostic-lifetimes/native", "-DSOURCE_HEAP_LIFETIMES=1"]

target heapObject pkg : FilePath := do
  let source ← heapSource.fetch
  let headers := #[← heapHeader.fetch, ← lifetimeHeader.fetch, ← allocatorApiHeader.fetch]
  let source ← source.bindM fun path => (Job.collectArray headers).mapM fun _ => pure path
  buildLeanO (pkg.buildDir / "heap.o") source #[] #["-std=c11", "-O3", "-fno-lto", "-Wall", "-Wextra", "-Werror", "-I", "/private/tmp/vastitas-source-lifetimes-8212d7d-macos/programs/bulk-complex-p1/diagnostic-lifetimes/native"]

extern_lib storageNative pkg := do
  buildStaticLib (pkg.staticLibDir / nameToStaticLib "vastitas_storage_native")
    #[← storageObject.fetch, ← diagonalObject.fetch, ← ffiObject.fetch, ← auditObject.fetch, ← bridgeObject.fetch, ← allocatorObject.fetch, ← heapObject.fetch]

@[default_target]
lean_lib VastitasStorageNative
