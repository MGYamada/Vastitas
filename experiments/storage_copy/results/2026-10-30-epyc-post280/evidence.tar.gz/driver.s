	.file	"driver.c"
	.text
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC0:
	.string	"/workspace/scratch/6f482abd7151/storage-copy-post280/source/experiments/storage_copy/driver.c"
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC1:
	.string	"bench_open(&f, c)"
	.section	.rodata.str1.8
	.align 8
.LC2:
	.string	"copy(f.arena, 0, f.input, c.self ? 0 : 1, f.output) == VS_OK"
	.section	.rodata.str1.1
.LC3:
	.string	"bench_verify(&f)"
	.section	.rodata.str1.8
	.align 8
.LC4:
	.string	"stats.copied_bytes == expected && stats.written_bytes == expected"
	.text
	.p2align 4
	.type	verify_case, @function
verify_case:
.LFB40:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	xorl	%r12d, %r12d
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$216, %rsp
	.cfi_def_cfa_offset 256
	movq	%fs:40, %rax
	movq	%rax, 200(%rsp)
	xorl	%eax, %eax
	movzbl	277(%rsp), %ebp
	leaq	64(%rsp), %rbx
	movq	%rsp, %r13
.L10:
	movb	%bpl, 277(%rsp)
	subq	$32, %rsp
	.cfi_def_cfa_offset 288
	movq	%rbx, %rdi
	movdqu	288(%rsp), %xmm0
	movq	304(%rsp), %rax
	movups	%xmm0, (%rsp)
	movq	%rax, 16(%rsp)
	call	bench_open@PLT
	addq	$32, %rsp
	.cfi_def_cfa_offset 256
	testl	%eax, %eax
	je	.L18
	testl	%r12d, %r12d
	je	.L12
	movq	bench_c_copy@GOTPCREL(%rip), %rcx
.L3:
	xorl	%edx, %edx
	testb	%bpl, %bpl
	sete	%dl
	subq	$80, %rsp
	.cfi_def_cfa_offset 336
	xorl	%esi, %esi
	movq	224(%rsp), %rax
	movdqa	192(%rsp), %xmm1
	movdqa	208(%rsp), %xmm2
	movq	144(%rsp), %rdi
	movdqu	152(%rsp), %xmm3
	movq	%rax, 72(%rsp)
	movdqu	168(%rsp), %xmm4
	movq	184(%rsp), %rax
	movups	%xmm1, 40(%rsp)
	movups	%xmm2, 56(%rsp)
	movq	%rax, 32(%rsp)
	movups	%xmm3, (%rsp)
	movups	%xmm4, 16(%rsp)
	call	*%rcx
	addq	$80, %rsp
	.cfi_def_cfa_offset 256
	testl	%eax, %eax
	jne	.L19
	movq	%rbx, %rdi
	call	bench_verify@PLT
	testl	%eax, %eax
	je	.L20
	movq	%rbx, %rsi
	movq	%r13, %rdi
	call	bench_close@PLT
	xorl	%eax, %eax
	testb	%bpl, %bpl
	jne	.L6
	movq	256(%rsp), %rax
	imulq	264(%rsp), %rax
	cmpb	$1, 272(%rsp)
	sbbq	%rdx, %rdx
	andq	$-8, %rdx
	addq	$16, %rdx
	imulq	%rdx, %rax
.L6:
	cmpq	%rax, 40(%rsp)
	jne	.L9
	cmpq	%rax, 32(%rsp)
	jne	.L9
	testl	%r12d, %r12d
	jne	.L21
	movl	$1, %r12d
	jmp	.L10
	.p2align 4,,10
	.p2align 3
.L21:
	movq	200(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L22
	addq	$216, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L12:
	.cfi_restore_state
	movq	vstorage_copy@GOTPCREL(%rip), %rcx
	jmp	.L3
.L9:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$81, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC4(%rip), %rdi
	call	__assert_fail@PLT
.L20:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$78, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC3(%rip), %rdi
	call	__assert_fail@PLT
.L19:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$77, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC2(%rip), %rdi
	call	__assert_fail@PLT
.L18:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$75, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC1(%rip), %rdi
	call	__assert_fail@PLT
.L22:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE40:
	.size	verify_case, .-verify_case
	.section	.rodata.str1.8
	.align 8
.LC5:
	.string	"*s && !*end && s[0] != '-' && n <= maximum"
	.text
	.p2align 4
	.type	number, @function
number:
.LFB42:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movl	$10, %edx
	movq	%rsi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbx
	subq	$24, %rsp
	.cfi_def_cfa_offset 48
	movq	%fs:40, %rax
	movq	%rax, 8(%rsp)
	xorl	%eax, %eax
	movq	%rsp, %rsi
	call	strtoull@PLT
	movzbl	(%rbx), %edx
	testb	%dl, %dl
	je	.L24
	movq	(%rsp), %rcx
	cmpb	$0, (%rcx)
	setne	%cl
	cmpb	$45, %dl
	sete	%dl
	orb	%dl, %cl
	jne	.L24
	cmpq	%rax, %rbp
	jb	.L24
	movq	8(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L32
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
.L24:
	.cfi_restore_state
	leaq	__PRETTY_FUNCTION__.3(%rip), %rcx
	movl	$99, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC5(%rip), %rdi
	call	__assert_fail@PLT
.L32:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE42:
	.size	number, .-number
	.section	.rodata.str1.8
	.align 8
.LC6:
	.string	"clock_gettime(CLOCK_MONOTONIC, &t) == 0"
	.text
	.p2align 4
	.type	now.part.0, @function
now.part.0:
.LFB45:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	popq	%rax
	.cfi_def_cfa_offset 8
	leaq	__PRETTY_FUNCTION__.1(%rip), %rcx
	movl	$12, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC6(%rip), %rdi
	subq	$8, %rsp
	.cfi_def_cfa_offset 16
	call	__assert_fail@PLT
	.cfi_endproc
.LFE45:
	.size	now.part.0, .-now.part.0
	.section	.rodata.str1.8
	.align 8
.LC7:
	.string	"stats.copied_bytes == copied && stats.written_bytes == copied"
	.section	.rodata.str1.1
.LC8:
	.string	"mode != 2 || p"
	.section	.rodata.str1.8
	.align 8
.LC9:
	.string	"after.data_allocations == before.data_allocations && after.data_frees == before.data_frees"
	.align 8
.LC10:
	.string	"after.metadata_allocations == before.metadata_allocations"
	.align 8
.LC11:
	.string	"s.timed.copied_bytes == (mode == 1 ? copied * reps : 0)"
	.align 8
.LC12:
	.string	"s.timed.written_bytes == s.timed.copied_bytes"
	.text
	.p2align 4
	.type	sample, @function
sample:
.LFB39:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rdi, %r8
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	movl	%esi, %r12d
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$584, %rsp
	.cfi_def_cfa_offset 640
	movq	%rcx, 40(%rsp)
	movzbl	661(%rsp), %ebp
	movq	%fs:40, %rax
	movq	%rax, 568(%rsp)
	xorl	%eax, %eax
	testl	%edx, %edx
	je	.L71
	movq	bench_c_copy@GOTPCREL(%rip), %rax
	movq	bench_c_loop@GOTPCREL(%rip), %r13
	movq	%rax, 72(%rsp)
.L36:
	movq	$0, 64(%rsp)
	testb	%bpl, %bpl
	jne	.L37
	movq	640(%rsp), %rdx
	imulq	648(%rsp), %rdx
	cmpb	$1, 656(%rsp)
	sbbq	%rax, %rax
	andq	$-8, %rax
	addq	$16, %rax
	imulq	%rax, %rdx
	movq	%rdx, 64(%rsp)
.L37:
	movq	%r8, 8(%rsp)
	testl	%r12d, %r12d
	jne	.L39
	leaq	112(%rsp), %rsi
	movl	$1, %edi
	call	clock_gettime@PLT
	movq	8(%rsp), %r8
	testl	%eax, %eax
	jne	.L47
	imulq	$1000000000, 112(%rsp), %rax
	xorl	%r15d, %r15d
	xorl	%r12d, %r12d
	cmpq	$0, 40(%rsp)
	movq	$0, 16(%rsp)
	movl	$0, %r13d
	movq	$0, 24(%rsp)
	movq	%rax, 88(%rsp)
	movq	120(%rsp), %rax
	movq	%rax, 96(%rsp)
	je	.L74
	leaq	416(%rsp), %rax
	xorl	%r10d, %r10d
	xorl	%r14d, %r14d
	movq	$0, 32(%rsp)
	movq	%rax, 80(%rsp)
	leaq	272(%rsp), %rbx
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	%r8, 104(%rsp)
	movq	%rbx, 8(%rsp)
	movq	%r10, %rbx
	.p2align 4,,10
	.p2align 3
.L46:
	movb	%bpl, 661(%rsp)
	subq	$32, %rsp
	.cfi_def_cfa_offset 672
	movdqu	672(%rsp), %xmm0
	movq	688(%rsp), %rax
	movq	40(%rsp), %rdi
	movq	%rax, 16(%rsp)
	movups	%xmm0, (%rsp)
	call	bench_open@PLT
	addq	$32, %rsp
	.cfi_def_cfa_offset 640
	testl	%eax, %eax
	je	.L89
	xorl	%edx, %edx
	testb	%bpl, %bpl
	sete	%dl
	subq	$80, %rsp
	.cfi_def_cfa_offset 720
	xorl	%esi, %esi
	movq	432(%rsp), %rax
	movdqa	400(%rsp), %xmm1
	movdqa	416(%rsp), %xmm2
	movq	352(%rsp), %rdi
	movdqu	360(%rsp), %xmm3
	movq	%rax, 72(%rsp)
	movdqu	376(%rsp), %xmm4
	movq	392(%rsp), %rax
	movups	%xmm1, 40(%rsp)
	movups	%xmm2, 56(%rsp)
	movq	%rax, 32(%rsp)
	movq	152(%rsp), %rax
	movups	%xmm3, (%rsp)
	movups	%xmm4, 16(%rsp)
	call	*%rax
	addq	$80, %rsp
	.cfi_def_cfa_offset 640
	testl	%eax, %eax
	jne	.L90
	movq	8(%rsp), %rdi
	call	bench_observe@PLT
	movq	8(%rsp), %rsi
	movq	80(%rsp), %rdi
	movq	392(%rsp), %rdx
	addq	%rax, 48(%rsp)
	addq	%rdx, 56(%rsp)
	call	bench_close@PLT
	movq	448(%rsp), %rax
	movq	64(%rsp), %rsi
	movq	456(%rsp), %rdx
	cmpq	%rax, %rsi
	jne	.L77
	cmpq	%rdx, %rsi
	jne	.L77
	movq	424(%rsp), %rcx
	addq	%rcx, 32(%rsp)
	movq	440(%rsp), %rcx
	addq	416(%rsp), %rbx
	movq	432(%rsp), %r11
	cmpq	%rcx, %r13
	cmovb	%rcx, %r13
	addq	%rax, 24(%rsp)
	movq	472(%rsp), %rax
	addq	%rdx, 16(%rsp)
	addq	464(%rsp), %r12
	cmpq	%rax, %r15
	cmovb	%rax, %r15
	addq	$1, %r14
	cmpq	%r14, 40(%rsp)
	jne	.L46
	movq	104(%rsp), %r8
	movq	%rbx, %r10
.L41:
	leaq	128(%rsp), %rsi
	movl	$1, %edi
	movq	%r8, 80(%rsp)
	movq	%r10, 72(%rsp)
	movq	%r11, 64(%rsp)
	call	clock_gettime@PLT
	testl	%eax, %eax
	jne	.L47
	movq	96(%rsp), %rbx
	movq	64(%rsp), %r11
	movq	%r15, %rcx
	movq	%r13, %rbp
	movq	72(%rsp), %r10
	movq	16(%rsp), %r9
	movq	%r12, 40(%rsp)
	movq	24(%rsp), %r14
	movq	32(%rsp), %rsi
	imulq	$1000000000, 128(%rsp), %rax
	movq	80(%rsp), %r8
	movq	%r10, %rdi
	subq	%rbx, %rax
	movq	88(%rsp), %rbx
	addq	136(%rsp), %rax
	subq	%rbx, %rax
	movq	%r11, %rbx
	movq	%rax, 8(%rsp)
.L48:
	movq	observed(%rip), %rax
	movq	48(%rsp), %rdx
	movq	%r10, 24(%r8)
	movq	%r11, 40(%r8)
	addq	%rdx, %rax
	movq	%rdx, 8(%r8)
	movq	%rax, observed(%rip)
	movq	8(%rsp), %rax
	movq	%r13, 48(%r8)
	movq	%rax, (%r8)
	movq	56(%rsp), %rax
	movq	%r12, 72(%r8)
	movq	%rax, 16(%r8)
	movq	32(%rsp), %rax
	movq	%r15, 80(%r8)
	movq	%rax, 32(%r8)
	movq	24(%rsp), %rax
	movq	%rdi, 88(%r8)
	movq	%rax, 56(%r8)
	movq	16(%rsp), %rax
	movq	%rsi, 96(%r8)
	movq	%rax, 64(%r8)
	movq	40(%rsp), %rax
	movq	%rbx, 104(%r8)
	movq	%rbp, 112(%r8)
	movq	%r14, 120(%r8)
	movq	%r9, 128(%r8)
	movq	%rax, 136(%r8)
	movq	%rcx, 144(%r8)
	movq	568(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L91
	addq	$584, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movq	%r8, %rax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L71:
	.cfi_restore_state
	movq	vstorage_copy@GOTPCREL(%rip), %rax
	movq	bench_adapter_loop@GOTPCREL(%rip), %r13
	movq	%rax, 72(%rsp)
	jmp	.L36
	.p2align 4,,10
	.p2align 3
.L39:
	leaq	272(%rsp), %rbx
	subq	$32, %rsp
	.cfi_def_cfa_offset 672
	movdqu	672(%rsp), %xmm6
	movq	688(%rsp), %rax
	movq	%rbx, %rdi
	movq	%rax, 16(%rsp)
	movups	%xmm6, (%rsp)
	call	bench_open@PLT
	addq	$32, %rsp
	.cfi_def_cfa_offset 640
	movq	8(%rsp), %r8
	testl	%eax, %eax
	je	.L92
	movq	%r8, 8(%rsp)
	cmpl	$2, %r12d
	je	.L93
	movq	272(%rsp), %rsi
	leaq	144(%rsp), %rdi
	call	vstorage_stats@PLT
	leaq	208(%rsp), %rax
	movl	$1, %edi
	movq	%rax, %rsi
	movq	%rax, 16(%rsp)
	call	clock_gettime@PLT
	testl	%eax, %eax
	jne	.L47
	imulq	$1000000000, 208(%rsp), %r14
	addq	216(%rsp), %r14
	cmpl	$1, %r12d
	movq	8(%rsp), %r8
	je	.L53
	xorl	%ebp, %ebp
.L67:
	xorl	%r15d, %r15d
	cmpq	$0, 40(%rsp)
	je	.L59
	movq	%r8, 8(%rsp)
	movq	%rbx, 24(%rsp)
	movq	%r15, %rbx
	movq	40(%rsp), %r15
	.p2align 4,,10
	.p2align 3
.L54:
	addq	$1, %rbx
	movq	%rbp, %rdi
	call	*%r13
	cmpq	%rbx, %r15
	jne	.L54
	movq	8(%rsp), %r8
	movq	24(%rsp), %rbx
.L59:
	leaq	416(%rsp), %rsi
	movl	$1, %edi
	movq	%r8, 32(%rsp)
	call	clock_gettime@PLT
	testl	%eax, %eax
	jne	.L47
	movq	272(%rsp), %rsi
	movq	16(%rsp), %rdi
	imulq	$1000000000, 416(%rsp), %rax
	addq	424(%rsp), %rax
	subq	%r14, %rax
	movq	%rax, 8(%rsp)
	call	vstorage_stats@PLT
	movq	240(%rsp), %rax
	subq	176(%rsp), %rax
	movq	%rax, 24(%rsp)
	movq	248(%rsp), %rax
	subq	184(%rsp), %rax
	movq	224(%rsp), %r11
	movq	%rax, 16(%rsp)
	movq	232(%rsp), %r13
	movq	144(%rsp), %rax
	cmpq	%rax, 208(%rsp)
	jne	.L60
	movq	152(%rsp), %rax
	cmpq	%rax, 216(%rsp)
	movq	32(%rsp), %r8
	jne	.L60
	movq	192(%rsp), %rax
	cmpq	%rax, 256(%rsp)
	jne	.L94
	xorl	%eax, %eax
	cmpl	$1, %r12d
	jne	.L63
	movq	64(%rsp), %rax
	movq	40(%rsp), %rdi
	imulq	%rdi, %rax
.L63:
	cmpq	%rax, 16(%rsp)
	jne	.L95
	movq	16(%rsp), %rdi
	cmpq	%rdi, 24(%rsp)
	jne	.L96
	movq	%rbx, %rdi
	movq	%r8, 40(%rsp)
	movq	%r11, 32(%rsp)
	call	bench_verify@PLT
	movq	32(%rsp), %r11
	movq	40(%rsp), %r8
	testl	%eax, %eax
	je	.L97
	movq	%rbx, %rdi
	movq	%r8, 72(%rsp)
	xorl	%r15d, %r15d
	xorl	%r12d, %r12d
	movq	%r11, 64(%rsp)
	call	bench_observe@PLT
	movq	%rbp, %rdi
	movq	%rax, 48(%rsp)
	movq	392(%rsp), %rax
	movq	%rax, 56(%rsp)
	call	bench_unprepare@PLT
	movq	%rbx, %rsi
	leaq	504(%rsp), %rdi
	call	bench_close@PLT
	movq	552(%rsp), %rax
	xorl	%r10d, %r10d
	movq	$0, 32(%rsp)
	movq	504(%rsp), %rdi
	movq	512(%rsp), %rsi
	movq	%rax, 40(%rsp)
	movq	520(%rsp), %rbx
	movq	528(%rsp), %rbp
	movq	536(%rsp), %r14
	movq	544(%rsp), %r9
	movq	560(%rsp), %rcx
	movq	72(%rsp), %r8
	movq	64(%rsp), %r11
	jmp	.L48
.L53:
	movq	40(%rsp), %rax
	testq	%rax, %rax
	je	.L56
	testb	%bpl, %bpl
	movq	%r8, 8(%rsp)
	movq	72(%rsp), %r15
	sete	%bpl
	xorl	%r13d, %r13d
	movq	%rbx, 24(%rsp)
	movzbl	%bpl, %ebp
	movq	%r13, %rbx
	movq	%rax, %r13
	.p2align 4,,10
	.p2align 3
.L58:
	subq	$80, %rsp
	.cfi_def_cfa_offset 720
	movl	%ebp, %edx
	xorl	%esi, %esi
	movq	432(%rsp), %rax
	movdqa	400(%rsp), %xmm5
	movdqa	416(%rsp), %xmm6
	movq	352(%rsp), %rdi
	movdqu	360(%rsp), %xmm7
	movq	%rax, 72(%rsp)
	movups	%xmm5, 40(%rsp)
	movq	392(%rsp), %rax
	movdqu	376(%rsp), %xmm5
	movups	%xmm6, 56(%rsp)
	movq	%rax, 32(%rsp)
	movups	%xmm7, (%rsp)
	movups	%xmm5, 16(%rsp)
	call	*%r15
	addq	$80, %rsp
	.cfi_def_cfa_offset 640
	testl	%eax, %eax
	jne	.L98
	addq	$1, %rbx
	cmpq	%rbx, %r13
	jne	.L58
	movq	8(%rsp), %r8
	movq	24(%rsp), %rbx
.L56:
	xorl	%ebp, %ebp
	jmp	.L59
.L93:
	movq	%rbx, %rdi
	call	bench_prepare@PLT
	movq	8(%rsp), %r8
	testq	%rax, %rax
	movq	%rax, %rbp
	je	.L99
	movq	272(%rsp), %rsi
	leaq	144(%rsp), %rdi
	movq	%r8, 8(%rsp)
	call	vstorage_stats@PLT
	leaq	208(%rsp), %rax
	movl	$1, %edi
	movq	%rax, %rsi
	movq	%rax, 16(%rsp)
	call	clock_gettime@PLT
	movq	8(%rsp), %r8
	testl	%eax, %eax
	jne	.L47
	imulq	$1000000000, 208(%rsp), %r14
	addq	216(%rsp), %r14
	jmp	.L67
.L77:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$40, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC7(%rip), %rdi
	call	__assert_fail@PLT
.L74:
	movq	$0, 32(%rsp)
	xorl	%r11d, %r11d
	xorl	%r10d, %r10d
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	jmp	.L41
.L90:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$36, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC2(%rip), %rdi
	call	__assert_fail@PLT
.L89:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$35, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC1(%rip), %rdi
	call	__assert_fail@PLT
.L98:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$53, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC2(%rip), %rdi
	call	__assert_fail@PLT
.L95:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$64, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC11(%rip), %rdi
	call	__assert_fail@PLT
.L99:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$48, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC8(%rip), %rdi
	call	__assert_fail@PLT
.L60:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$62, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC9(%rip), %rdi
	call	__assert_fail@PLT
.L96:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$65, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC12(%rip), %rdi
	call	__assert_fail@PLT
.L97:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$66, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC3(%rip), %rdi
	call	__assert_fail@PLT
.L92:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$46, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC1(%rip), %rdi
	call	__assert_fail@PLT
.L47:
	call	now.part.0
.L94:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$63, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC10(%rip), %rdi
	call	__assert_fail@PLT
.L91:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE39:
	.size	sample, .-sample
	.section	.rodata.str1.1
.LC13:
	.string	"--contracts"
	.section	.rodata.str1.8
	.align 8
.LC14:
	.string	"rows cols scalar spad dpad st dt self samples target_ns offset\n"
	.section	.rodata.str1.1
.LC15:
	.string	"lifecycle"
.LC16:
	.string	"checked_call"
	.section	.rodata.str1.8
	.align 8
.LC17:
	.ascii	"phase,scope,implementation,pair,order,repetitions,elapsed_ns"
	.ascii	",checksum,"
	.string	"timed_data_allocations,timed_data_frees,live_bytes,peak_bytes,timed_written_bytes,timed_copied_bytes,timed_metadata_allocations,metadata_bytes,fixture_written_bytes,fixture_data_allocations,fixture_data_frees,fixture_live_bytes,fixture_metadata_allocations"
	.align 8
.LC18:
	.string	"verified all source/output/padding words; sink=%lu\n"
	.section	.rodata.str1.1
.LC19:
	.string	"loop_only"
.LC20:
	.string	"c"
.LC21:
	.string	"warmup"
.LC22:
	.string	"%s,%s,%s,%u,%u,%lu,%lu,%lu"
.LC23:
	.string	",%lu,%lu,%lu,%lu,%lu,%lu"
.LC24:
	.string	",%lu,%lu,%lu,%lu,%lu,%lu,%lu\n"
.LC25:
	.string	"adapter"
.LC26:
	.string	"calibration"
.LC27:
	.string	"measurement"
	.section	.text.startup,"ax",@progbits
	.p2align 4
	.globl	main
	.type	main, @function
main:
.LFB43:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%rsi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$984, %rsp
	.cfi_def_cfa_offset 1040
	movq	%fs:40, %rax
	movq	%rax, 968(%rsp)
	xorl	%eax, %eax
	cmpl	$2, %edi
	je	.L186
	cmpl	$12, %edi
	jne	.L102
	leaq	.LC15(%rip), %rdx
	leaq	.LC16(%rip), %rax
	movq	8(%rsi), %rdi
	movl	$8192, %esi
	movq	%rdx, %xmm6
	movq	%rax, %xmm5
	punpcklqdq	%xmm5, %xmm6
	movaps	%xmm6, 80(%rsp)
	call	number
	movq	16(%rbp), %rdi
	movl	$8192, %esi
	movq	%rax, 64(%rsp)
	call	number
	movq	24(%rbp), %rdi
	movl	$1, %esi
	movq	%rax, 72(%rsp)
	call	number
	movq	32(%rbp), %rdi
	movl	$1, %esi
	movb	%al, 222(%rsp)
	movq	%rax, %r13
	call	number
	movq	40(%rbp), %rdi
	movl	$1, %esi
	movzbl	%r13b, %r13d
	movq	%rax, %rbx
	call	number
	movq	48(%rbp), %rdi
	movl	$1, %esi
	movzbl	%bl, %ebx
	movq	%rax, %r12
	call	number
	movzbl	%r12b, %r12d
	movq	56(%rbp), %rdi
	movl	$1, %esi
	movzbl	%al, %eax
	sall	$8, %eax
	orl	%r12d, %eax
	sall	$8, %eax
	orl	%ebx, %eax
	sall	$8, %eax
	movl	%eax, %ecx
	orl	%r13d, %ecx
	movl	%ecx, 96(%rsp)
	call	number
	movq	64(%rbp), %rdi
	movl	$1, %esi
	movq	%rax, %rbx
	call	number
	movzbl	%bl, %r11d
	movq	72(%rbp), %rdi
	movl	$1000, %esi
	movl	%r11d, %ecx
	movb	%al, 101(%rsp)
	movq	%rax, %r14
	movb	%al, %ch
	movw	%cx, (%rsp)
	call	number
	movq	80(%rbp), %rdi
	movl	$1000000000, %esi
	movl	%eax, %r13d
	call	number
	movq	88(%rbp), %rdi
	movl	$1, %esi
	movq	%rax, %r12
	call	number
	leaq	.LC17(%rip), %rdi
	movl	%eax, %r15d
	call	puts@PLT
	movq	64(%rsp), %rcx
	movl	96(%rsp), %eax
	movb	%bl, 292(%rsp)
	movq	72(%rsp), %rbp
	movb	%r14b, 293(%rsp)
	subq	$32, %rsp
	.cfi_def_cfa_offset 1072
	movq	%rcx, 304(%rsp)
	movq	%rbp, 312(%rsp)
	movl	%eax, 320(%rsp)
	movq	320(%rsp), %rax
	movdqa	304(%rsp), %xmm6
	movq	%rax, 16(%rsp)
	movups	%xmm6, (%rsp)
	call	verify_case
	movq	96(%rsp), %rbx
	addq	$32, %rsp
	.cfi_def_cfa_offset 1040
	testq	%rbp, %rbp
	sete	%al
	movq	%rbp, %rcx
	movzwl	(%rsp), %r11d
	movl	%r13d, 216(%rsp)
	testq	%rbx, %rbx
	movq	%r12, 192(%rsp)
	sete	%dl
	movl	%r15d, 200(%rsp)
	orl	%edx, %eax
	testb	%r14b, %r14b
	movw	%r11w, 102(%rsp)
	setne	%dl
	imulq	%rbx, %rcx
	xorl	%esi, %esi
	orl	%edx, %eax
	movq	%rsi, 56(%rsp)
	movb	%al, 223(%rsp)
	movq	%rcx, 208(%rsp)
.L150:
	xorl	%r10d, %r10d
	cmpq	$2, 56(%rsp)
	je	.L187
.L106:
	movl	%r10d, %r8d
.L133:
	movl	200(%rsp), %eax
	movl	$0, 104(%rsp)
	movl	%r8d, 136(%rsp)
	addl	%r8d, %eax
	movl	%eax, 144(%rsp)
.L135:
	movl	104(%rsp), %ebx
	movl	144(%rsp), %eax
	addl	%ebx, %eax
	movq	64(%rsp), %rbx
	andl	$1, %eax
	movq	%rbx, 304(%rsp)
	movq	72(%rsp), %rbx
	movl	%eax, 112(%rsp)
	movq	%rbx, 312(%rsp)
	movl	96(%rsp), %ebx
	movl	%ebx, 320(%rsp)
	movzwl	102(%rsp), %ebx
	movw	%bx, 324(%rsp)
	je	.L157
	movq	bench_c_copy@GOTPCREL(%rip), %rbx
	movq	bench_c_loop@GOTPCREL(%rip), %r12
.L107:
	xorl	%r13d, %r13d
	cmpb	$0, 101(%rsp)
	jne	.L108
	cmpb	$1, 222(%rsp)
	movq	208(%rsp), %rax
	sbbq	%r13, %r13
	andq	$-8, %r13
	addq	$16, %r13
	imulq	%rax, %r13
.L108:
	cmpq	$0, 56(%rsp)
	jne	.L110
	leaq	224(%rsp), %rsi
	movl	$1, %edi
	call	clock_gettime@PLT
	testl	%eax, %eax
	jne	.L116
	movq	224(%rsp), %rax
	movq	232(%rsp), %r15
	leaq	464(%rsp), %r14
	subq	$32, %rsp
	.cfi_def_cfa_offset 1072
	movq	%r14, %rdi
	movq	%rax, 80(%rsp)
	movq	352(%rsp), %rax
	movdqa	336(%rsp), %xmm0
	movq	%rax, 16(%rsp)
	movups	%xmm0, (%rsp)
	call	bench_open@PLT
	addq	$32, %rsp
	.cfi_def_cfa_offset 1040
	testl	%eax, %eax
	je	.L188
	xorl	%edx, %edx
	cmpb	$0, 101(%rsp)
	sete	%dl
	subq	$80, %rsp
	.cfi_def_cfa_offset 1120
	xorl	%esi, %esi
	movq	624(%rsp), %rax
	movdqa	592(%rsp), %xmm1
	movdqa	608(%rsp), %xmm2
	movq	544(%rsp), %rdi
	movdqu	552(%rsp), %xmm3
	movq	%rax, 72(%rsp)
	movdqu	568(%rsp), %xmm4
	movq	584(%rsp), %rax
	movups	%xmm1, 40(%rsp)
	movups	%xmm2, 56(%rsp)
	movq	%rax, 32(%rsp)
	movups	%xmm3, (%rsp)
	movups	%xmm4, 16(%rsp)
	call	*%rbx
	addq	$80, %rsp
	.cfi_def_cfa_offset 1040
	testl	%eax, %eax
	jne	.L189
	movq	%r14, %rdi
	call	bench_observe@PLT
	leaq	400(%rsp), %rdi
	movq	%r14, %rsi
	movq	%rax, %rbx
	movq	584(%rsp), %rax
	movq	%rax, 24(%rsp)
	call	bench_close@PLT
	movq	432(%rsp), %rbp
	movq	440(%rsp), %r12
	cmpq	%r13, %rbp
	jne	.L165
	cmpq	%r13, %r12
	jne	.L165
	movq	424(%rsp), %rsi
	movq	456(%rsp), %rdi
	movq	408(%rsp), %rax
	movq	416(%rsp), %rcx
	movq	448(%rsp), %rdx
	movq	%rsi, 40(%rsp)
	leaq	240(%rsp), %rsi
	movq	%rdi, 32(%rsp)
	movl	$1, %edi
	movq	400(%rsp), %r13
	movq	%rax, (%rsp)
	movq	%rcx, 16(%rsp)
	movq	%rdx, 8(%rsp)
	call	clock_gettime@PLT
	testl	%eax, %eax
	jne	.L116
	movq	16(%rsp), %rcx
	movq	8(%rsp), %r11
	movq	%r13, 120(%rsp)
	imulq	$1000000000, 240(%rsp), %rdx
	movq	(%rsp), %r10
	imulq	$1000000000, 48(%rsp), %rax
	movq	%rcx, 128(%rsp)
	subq	%r15, %rdx
	addq	248(%rsp), %rdx
	movq	%rdx, %rsi
	subq	%rax, %rsi
	movq	%rsi, 48(%rsp)
.L117:
	movq	observed(%rip), %rax
	movl	112(%rsp), %edx
	leaq	944(%rsp), %r15
	movq	%r11, 152(%rsp)
	movdqa	80(%rsp), %xmm5
	movq	%r10, 112(%rsp)
	addq	%rbx, %rax
	testl	%edx, %edx
	movq	%rax, observed(%rip)
	leaq	.LC19(%rip), %rax
	movq	%rax, 960(%rsp)
	movq	56(%rsp), %rax
	movaps	%xmm5, 944(%rsp)
	movq	(%r15,%rax,8), %rcx
	je	.L130
	pushq	%rbx
	.cfi_def_cfa_offset 1048
	leaq	.LC20(%rip), %r8
	pushq	56(%rsp)
	.cfi_def_cfa_offset 1056
	pushq	$1
	.cfi_def_cfa_offset 1064
	movl	128(%rsp), %eax
	pushq	%rax
	.cfi_def_cfa_offset 1072
	movl	168(%rsp), %r9d
.L182:
	leaq	.LC22(%rip), %rbx
	leaq	.LC21(%rip), %rdx
	movl	$2, %edi
	xorl	%eax, %eax
	movq	%rbx, %rsi
	movq	%rbx, 80(%rsp)
	leaq	.LC23(%rip), %rbx
	call	__printf_chk@PLT
	addq	$32, %rsp
	.cfi_def_cfa_offset 1040
	movq	%r13, %rdx
	movq	%rbx, %rsi
	pushq	%r12
	.cfi_def_cfa_offset 1048
	movl	$2, %edi
	xorl	%eax, %eax
	pushq	%rbp
	.cfi_def_cfa_offset 1056
	movq	56(%rsp), %r9
	leaq	.LC24(%rip), %rbp
	movq	32(%rsp), %r8
	movq	16(%rsp), %rcx
	call	__printf_chk@PLT
	xorl	%eax, %eax
	movq	%rbp, %rsi
	movl	$2, %edi
	movq	168(%rsp), %r11
	movq	%r11, (%rsp)
	pushq	144(%rsp)
	.cfi_def_cfa_offset 1064
	movq	136(%rsp), %r10
	pushq	%r10
	.cfi_def_cfa_offset 1072
	movq	152(%rsp), %r9
	movq	56(%rsp), %r8
	movq	64(%rsp), %rcx
	movq	40(%rsp), %rdx
	call	__printf_chk@PLT
	addq	$32, %rsp
	.cfi_def_cfa_offset 1040
	cmpl	$1, 104(%rsp)
	je	.L190
	movl	$1, 104(%rsp)
	jmp	.L135
	.p2align 4,,10
	.p2align 3
.L157:
	movq	vstorage_copy@GOTPCREL(%rip), %rbx
	movq	bench_adapter_loop@GOTPCREL(%rip), %r12
	jmp	.L107
	.p2align 4,,10
	.p2align 3
.L110:
	leaq	464(%rsp), %r14
	subq	$32, %rsp
	.cfi_def_cfa_offset 1072
	movdqa	336(%rsp), %xmm6
	movq	352(%rsp), %rax
	movq	%r14, %rdi
	movq	%rax, 16(%rsp)
	movups	%xmm6, (%rsp)
	call	bench_open@PLT
	addq	$32, %rsp
	.cfi_def_cfa_offset 1040
	testl	%eax, %eax
	je	.L191
	cmpq	$2, 56(%rsp)
	je	.L192
	movq	464(%rsp), %rsi
	leaq	336(%rsp), %rdi
	call	vstorage_stats@PLT
	leaq	256(%rsp), %rsi
	movl	$1, %edi
	call	clock_gettime@PLT
	testl	%eax, %eax
	jne	.L116
	imulq	$1000000000, 256(%rsp), %rbp
	xorl	%edx, %edx
	addq	264(%rsp), %rbp
	cmpb	$0, 101(%rsp)
	sete	%dl
	subq	$80, %rsp
	.cfi_def_cfa_offset 1120
	xorl	%esi, %esi
	movq	624(%rsp), %rax
	movq	544(%rsp), %rdi
	movdqa	592(%rsp), %xmm5
	movdqa	608(%rsp), %xmm6
	movq	%rax, 72(%rsp)
	movq	584(%rsp), %rax
	movups	%xmm5, 40(%rsp)
	movdqu	552(%rsp), %xmm5
	movups	%xmm6, 56(%rsp)
	movdqu	568(%rsp), %xmm6
	movq	%rax, 32(%rsp)
	movups	%xmm5, (%rsp)
	movups	%xmm6, 16(%rsp)
	call	*%rbx
	addq	$80, %rsp
	.cfi_def_cfa_offset 1040
	testl	%eax, %eax
	jne	.L193
	xorl	%r15d, %r15d
.L122:
	leaq	400(%rsp), %rbx
	movl	$1, %edi
	movq	%rbx, %rsi
	call	clock_gettime@PLT
	testl	%eax, %eax
	jne	.L116
	imulq	$1000000000, 400(%rsp), %rax
	movq	464(%rsp), %rsi
	movq	%rbx, %rdi
	addq	408(%rsp), %rax
	subq	%rbp, %rax
	movq	%rax, 48(%rsp)
	call	vstorage_stats@PLT
	movq	416(%rsp), %rax
	movq	432(%rsp), %rbp
	movq	440(%rsp), %r12
	subq	368(%rsp), %rbp
	movq	%rax, 16(%rsp)
	movq	424(%rsp), %rax
	subq	376(%rsp), %r12
	movq	%rax, 40(%rsp)
	movq	336(%rsp), %rax
	cmpq	%rax, 400(%rsp)
	jne	.L123
	movq	344(%rsp), %rax
	cmpq	%rax, 408(%rsp)
	jne	.L123
	movq	384(%rsp), %rax
	cmpq	%rax, 448(%rsp)
	jne	.L194
	xorl	%eax, %eax
	cmpq	$1, 56(%rsp)
	cmovne	%rax, %r13
	cmpq	%r13, %r12
	jne	.L195
	cmpq	%r13, %rbp
	jne	.L196
	movq	%r14, %rdi
	call	bench_verify@PLT
	testl	%eax, %eax
	je	.L197
	movq	%r14, %rdi
	xorl	%r13d, %r13d
	call	bench_observe@PLT
	movq	%r15, %rdi
	movq	%rax, %rbx
	movq	584(%rsp), %rax
	movq	%rax, 24(%rsp)
	call	bench_unprepare@PLT
	leaq	872(%rsp), %rdi
	movq	%r14, %rsi
	call	bench_close@PLT
	movq	872(%rsp), %rax
	movq	$0, 32(%rsp)
	movq	$0, (%rsp)
	movq	880(%rsp), %r10
	movq	%rax, 120(%rsp)
	movq	888(%rsp), %rax
	movq	$0, 8(%rsp)
	movq	920(%rsp), %r11
	movq	%rax, 128(%rsp)
	jmp	.L117
	.p2align 4,,10
	.p2align 3
.L130:
	pushq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 1048
	leaq	.LC25(%rip), %r8
	pushq	56(%rsp)
	.cfi_def_cfa_offset 1056
	pushq	$1
	.cfi_def_cfa_offset 1064
	movl	128(%rsp), %eax
	pushq	%rax
	.cfi_def_cfa_offset 1072
	movl	168(%rsp), %r9d
	jmp	.L182
	.p2align 4,,10
	.p2align 3
.L190:
	.cfi_restore_state
	movl	136(%rsp), %r8d
	testl	%r8d, %r8d
	jne	.L198
	movl	$1, %r8d
	jmp	.L133
.L187:
	cmpb	$0, 223(%rsp)
	je	.L106
.L178:
	movq	64(%rsp), %rax
	movzwl	102(%rsp), %r11d
	subq	$32, %rsp
	.cfi_def_cfa_offset 1072
	movq	%rax, 304(%rsp)
	movq	104(%rsp), %rax
	movw	%r11w, 324(%rsp)
	movq	%rax, 312(%rsp)
	movl	128(%rsp), %eax
	movl	%eax, 320(%rsp)
	movq	320(%rsp), %rax
	movdqa	304(%rsp), %xmm5
	movq	%rax, 16(%rsp)
	movups	%xmm5, (%rsp)
	call	verify_case
	addq	$32, %rsp
	.cfi_def_cfa_offset 1040
	movl	$2, %esi
	xorl	%eax, %eax
	movq	observed(%rip), %rcx
	movq	stderr(%rip), %rdi
	leaq	.LC18(%rip), %rdx
	call	__fprintf_chk@PLT
.L103:
	xorl	%eax, %eax
.L100:
	movq	968(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L199
	addq	$984, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L198:
	.cfi_restore_state
	movl	56(%rsp), %eax
	movl	%r8d, %r10d
	movq	%rbp, 144(%rsp)
	movl	$1, %r12d
	movl	%r10d, 204(%rsp)
	xorl	%r8d, %r8d
	movl	%eax, 128(%rsp)
	movq	%r15, 168(%rsp)
	movq	%r14, 176(%rsp)
	movq	%rbx, 136(%rsp)
	movq	%r12, %rbx
	.p2align 4,,10
	.p2align 3
.L134:
	movl	200(%rsp), %eax
	movq	$-1, %r12
	xorl	%r13d, %r13d
	movq	%rbx, %r14
	movl	%r8d, 152(%rsp)
	movq	%r12, %r15
	addl	%r8d, %eax
	movl	%eax, 164(%rsp)
.L139:
	movq	64(%rsp), %rbx
	movzwl	102(%rsp), %ecx
	subq	$32, %rsp
	.cfi_def_cfa_offset 1072
	movl	196(%rsp), %eax
	movq	%rbx, 304(%rsp)
	movq	104(%rsp), %rbx
	movw	%cx, 324(%rsp)
	addl	%r13d, %eax
	movq	%r14, %rcx
	movq	%rbx, 312(%rsp)
	movl	128(%rsp), %ebx
	andl	$1, %eax
	movl	%ebx, 320(%rsp)
	movq	320(%rsp), %rdx
	movdqa	304(%rsp), %xmm5
	movl	160(%rsp), %esi
	movl	%eax, 152(%rsp)
	movq	208(%rsp), %rdi
	movq	%rdx, 16(%rsp)
	movl	%eax, %edx
	movups	%xmm5, (%rsp)
	call	sample
	movq	512(%rsp), %rax
	movq	496(%rsp), %rdx
	movq	536(%rsp), %rdi
	movq	520(%rsp), %rbx
	movq	568(%rsp), %rbp
	movq	576(%rsp), %r12
	cmpq	%rdx, %r15
	movq	%rax, 32(%rsp)
	movdqa	112(%rsp), %xmm6
	movq	528(%rsp), %rcx
	movq	%rdi, 56(%rsp)
	leaq	.LC19(%rip), %rdi
	movq	544(%rsp), %r9
	movq	%rbx, 40(%rsp)
	cmova	%rdx, %r15
	movq	584(%rsp), %rax
	movq	%rbp, 72(%rsp)
	movq	%r12, 136(%rsp)
	movq	552(%rsp), %r10
	movq	560(%rsp), %r11
	movq	%rcx, 48(%rsp)
	movq	%r9, 64(%rsp)
	movq	504(%rsp), %rsi
	movq	%rax, 144(%rsp)
	movq	592(%rsp), %rbx
	movq	%rdi, 992(%rsp)
	movq	600(%rsp), %rbp
	movq	632(%rsp), %r12
	movaps	%xmm6, 976(%rsp)
	movl	152(%rsp), %eax
	addq	$32, %rsp
	.cfi_def_cfa_offset 1040
	movq	%r11, 184(%rsp)
	movq	%r10, 120(%rsp)
	testl	%eax, %eax
	je	.L136
	movq	168(%rsp), %r10
	movq	56(%rsp), %r11
	leaq	.LC20(%rip), %r8
	movq	(%r10,%r11,8), %rcx
	pushq	%rsi
	.cfi_def_cfa_offset 1048
	pushq	%rdx
	.cfi_def_cfa_offset 1056
	pushq	%r14
	.cfi_def_cfa_offset 1064
	pushq	%r13
	.cfi_def_cfa_offset 1072
	movl	184(%rsp), %r9d
.L183:
	movq	80(%rsp), %rsi
	leaq	.LC26(%rip), %rdx
	movl	$2, %edi
	xorl	%eax, %eax
	call	__printf_chk@PLT
	addq	$32, %rsp
	.cfi_def_cfa_offset 1040
	movl	$2, %edi
	xorl	%eax, %eax
	movq	184(%rsp), %r11
	pushq	%r11
	.cfi_def_cfa_offset 1048
	movq	128(%rsp), %r10
	pushq	%r10
	.cfi_def_cfa_offset 1056
	movq	48(%rsp), %r9
	movq	40(%rsp), %r8
	movq	32(%rsp), %rcx
	movq	24(%rsp), %rdx
	movq	152(%rsp), %rsi
	call	__printf_chk@PLT
	movq	%r12, (%rsp)
	movl	$2, %edi
	xorl	%eax, %eax
	pushq	%rbp
	.cfi_def_cfa_offset 1064
	pushq	%rbx
	.cfi_def_cfa_offset 1072
	movq	144(%rsp), %r9
	movq	32(%rsp), %r8
	movq	136(%rsp), %rcx
	movq	72(%rsp), %rdx
	movq	176(%rsp), %rsi
	call	__printf_chk@PLT
	addq	$32, %rsp
	.cfi_def_cfa_offset 1040
	cmpl	$1, %r13d
	je	.L175
	movl	204(%rsp), %r13d
	jmp	.L139
	.p2align 4,,10
	.p2align 3
.L136:
	movq	168(%rsp), %rax
	movq	56(%rsp), %rcx
	leaq	.LC25(%rip), %r8
	movq	(%rax,%rcx,8), %rcx
	pushq	%rsi
	.cfi_remember_state
	.cfi_def_cfa_offset 1048
	pushq	%rdx
	.cfi_def_cfa_offset 1056
	pushq	%r14
	.cfi_def_cfa_offset 1064
	pushq	%r13
	.cfi_def_cfa_offset 1072
	movl	184(%rsp), %r9d
	jmp	.L183
	.p2align 4,,10
	.p2align 3
.L175:
	.cfi_restore_state
	movq	192(%rsp), %rax
	movl	152(%rsp), %r8d
	movq	%r14, %rbx
	cmpq	%rax, %r15
	jnb	.L166
	cmpq	$1999999, %r14
	ja	.L166
	testq	%r15, %r15
	je	.L163
	xorl	%edx, %edx
	divq	%r15
	leaq	1(%rax), %rcx
	movl	$10, %eax
	cmpq	%rax, %rcx
	cmova	%rax, %rcx
	movl	$2000000, %eax
	xorl	%edx, %edx
	divq	%rcx
	cmpq	%rbx, %rax
	jb	.L164
.L200:
	imulq	%rcx, %rbx
.L145:
	addl	$1, %r8d
	jmp	.L134
	.p2align 4,,10
	.p2align 3
.L163:
	movl	$200000, %eax
	movl	$10, %ecx
	cmpq	%rbx, %rax
	jnb	.L200
.L164:
	movl	$2000000, %ebx
	jmp	.L145
	.p2align 4,,10
	.p2align 3
.L166:
	movl	216(%rsp), %eax
	movl	204(%rsp), %r10d
	xorl	%edx, %edx
	leaq	624(%rsp), %r9
	movq	168(%rsp), %r11
	testl	%eax, %eax
	je	.L143
	movl	%r10d, 184(%rsp)
	movq	%r11, %r14
	movq	%r9, 168(%rsp)
	.p2align 4,,10
	.p2align 3
.L142:
	movl	200(%rsp), %eax
	movl	%edx, 152(%rsp)
	movq	%r14, %r15
	xorl	%r12d, %r12d
	movq	%rbx, %r14
	addl	%edx, %eax
	movl	%eax, 164(%rsp)
.L149:
	movq	64(%rsp), %rbx
	movq	72(%rsp), %rcx
	subq	$32, %rsp
	.cfi_def_cfa_offset 1072
	movl	196(%rsp), %eax
	movq	%rbx, 304(%rsp)
	movl	128(%rsp), %ebx
	movq	%rcx, 312(%rsp)
	movzwl	134(%rsp), %ecx
	addl	%r12d, %eax
	movl	%ebx, 320(%rsp)
	andl	$1, %eax
	movw	%cx, 324(%rsp)
	movq	320(%rsp), %rdx
	movq	%r14, %rcx
	movdqa	304(%rsp), %xmm7
	movl	160(%rsp), %esi
	movl	%eax, 152(%rsp)
	movq	200(%rsp), %rdi
	movq	%rdx, 16(%rsp)
	movl	%eax, %edx
	movups	%xmm7, (%rsp)
	call	sample
	movq	672(%rsp), %rax
	movq	696(%rsp), %rdi
	movq	680(%rsp), %rbx
	movq	728(%rsp), %rbp
	movq	736(%rsp), %r13
	movdqa	112(%rsp), %xmm7
	movq	%rax, 32(%rsp)
	movq	688(%rsp), %rcx
	movq	704(%rsp), %r9
	movq	%rdi, 56(%rsp)
	leaq	.LC19(%rip), %rdi
	movq	744(%rsp), %rax
	movq	%rbx, 40(%rsp)
	movq	%rbp, 72(%rsp)
	movq	712(%rsp), %r10
	movq	%r13, 136(%rsp)
	movq	720(%rsp), %r11
	movq	%rcx, 48(%rsp)
	movq	656(%rsp), %rdx
	movq	%r9, 64(%rsp)
	movq	664(%rsp), %rsi
	movq	%rax, 144(%rsp)
	movq	752(%rsp), %rbx
	movq	%rdi, 992(%rsp)
	movq	760(%rsp), %rbp
	movq	792(%rsp), %r13
	movaps	%xmm7, 976(%rsp)
	movl	152(%rsp), %eax
	addq	$32, %rsp
	.cfi_def_cfa_offset 1040
	movq	%r11, 176(%rsp)
	movq	%r10, 120(%rsp)
	testl	%eax, %eax
	je	.L146
	movq	56(%rsp), %r10
	leaq	.LC20(%rip), %r8
	movq	(%r15,%r10,8), %rcx
	pushq	%rsi
	.cfi_def_cfa_offset 1048
	pushq	%rdx
	.cfi_def_cfa_offset 1056
	pushq	%r14
	.cfi_def_cfa_offset 1064
	pushq	%r12
	.cfi_def_cfa_offset 1072
	movl	184(%rsp), %r9d
.L185:
	movq	80(%rsp), %rsi
	leaq	.LC27(%rip), %rdx
	movl	$2, %edi
	xorl	%eax, %eax
	call	__printf_chk@PLT
	addq	$32, %rsp
	.cfi_def_cfa_offset 1040
	movl	$2, %edi
	xorl	%eax, %eax
	movq	176(%rsp), %r11
	pushq	%r11
	.cfi_def_cfa_offset 1048
	movq	128(%rsp), %r10
	pushq	%r10
	.cfi_def_cfa_offset 1056
	movq	48(%rsp), %r9
	movq	40(%rsp), %r8
	movq	32(%rsp), %rcx
	movq	24(%rsp), %rdx
	movq	152(%rsp), %rsi
	call	__printf_chk@PLT
	movq	%r13, (%rsp)
	movl	$2, %edi
	xorl	%eax, %eax
	pushq	%rbp
	.cfi_def_cfa_offset 1064
	pushq	%rbx
	.cfi_def_cfa_offset 1072
	movq	144(%rsp), %r9
	movq	32(%rsp), %r8
	movq	136(%rsp), %rcx
	movq	72(%rsp), %rdx
	movq	176(%rsp), %rsi
	call	__printf_chk@PLT
	addq	$32, %rsp
	.cfi_def_cfa_offset 1040
	cmpl	$1, %r12d
	je	.L201
	movl	184(%rsp), %r12d
	jmp	.L149
	.p2align 4,,10
	.p2align 3
.L146:
	movq	56(%rsp), %rax
	leaq	.LC25(%rip), %r8
	movq	(%r15,%rax,8), %rcx
	pushq	%rsi
	.cfi_remember_state
	.cfi_def_cfa_offset 1048
	pushq	%rdx
	.cfi_def_cfa_offset 1056
	pushq	%r14
	.cfi_def_cfa_offset 1064
	pushq	%r12
	.cfi_def_cfa_offset 1072
	movl	184(%rsp), %r9d
	jmp	.L185
	.p2align 4,,10
	.p2align 3
.L201:
	.cfi_restore_state
	movl	152(%rsp), %edx
	movq	%r14, %rbx
	movq	%r15, %r14
	addl	$1, %edx
	cmpl	%edx, 216(%rsp)
	jne	.L142
.L143:
	addq	$1, 56(%rsp)
	movq	56(%rsp), %rax
	cmpq	$3, %rax
	jne	.L150
	jmp	.L178
.L186:
	movq	8(%rsi), %rdi
	leaq	.LC13(%rip), %rsi
	call	strcmp@PLT
	testl	%eax, %eax
	je	.L202
.L102:
	movq	stderr(%rip), %rdi
	leaq	.LC14(%rip), %rdx
	movl	$2, %esi
	xorl	%eax, %eax
	call	__fprintf_chk@PLT
	movl	$2, %eax
	jmp	.L100
.L192:
	movq	%r14, %rdi
	call	bench_prepare@PLT
	movq	%rax, %r15
	testq	%rax, %rax
	je	.L203
	movq	464(%rsp), %rsi
	leaq	336(%rsp), %rdi
	call	vstorage_stats@PLT
	leaq	256(%rsp), %rsi
	movl	$1, %edi
	call	clock_gettime@PLT
	testl	%eax, %eax
	jne	.L116
	imulq	$1000000000, 256(%rsp), %rbp
	movq	%r15, %rdi
	addq	264(%rsp), %rbp
	call	*%r12
	jmp	.L122
.L202:
	call	bench_contract_tests@PLT
	jmp	.L103
.L165:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$40, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC7(%rip), %rdi
	call	__assert_fail@PLT
.L188:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$35, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC1(%rip), %rdi
	call	__assert_fail@PLT
.L189:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$36, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC2(%rip), %rdi
	call	__assert_fail@PLT
.L193:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$53, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC2(%rip), %rdi
	call	__assert_fail@PLT
.L197:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$66, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC3(%rip), %rdi
	call	__assert_fail@PLT
.L196:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$65, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC12(%rip), %rdi
	call	__assert_fail@PLT
.L195:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$64, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC11(%rip), %rdi
	call	__assert_fail@PLT
.L123:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$62, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC9(%rip), %rdi
	call	__assert_fail@PLT
.L191:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$46, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC1(%rip), %rdi
	call	__assert_fail@PLT
.L194:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$63, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC10(%rip), %rdi
	call	__assert_fail@PLT
.L116:
	call	now.part.0
.L199:
	call	__stack_chk_fail@PLT
.L203:
	leaq	__PRETTY_FUNCTION__.2(%rip), %rcx
	movl	$48, %edx
	leaq	.LC0(%rip), %rsi
	leaq	.LC8(%rip), %rdi
	call	__assert_fail@PLT
	.cfi_endproc
.LFE43:
	.size	main, .-main
	.section	.rodata
	.align 8
	.type	__PRETTY_FUNCTION__.0, @object
	.size	__PRETTY_FUNCTION__.0, 12
__PRETTY_FUNCTION__.0:
	.string	"verify_case"
	.type	__PRETTY_FUNCTION__.1, @object
	.size	__PRETTY_FUNCTION__.1, 4
__PRETTY_FUNCTION__.1:
	.string	"now"
	.type	__PRETTY_FUNCTION__.2, @object
	.size	__PRETTY_FUNCTION__.2, 7
__PRETTY_FUNCTION__.2:
	.string	"sample"
	.type	__PRETTY_FUNCTION__.3, @object
	.size	__PRETTY_FUNCTION__.3, 7
__PRETTY_FUNCTION__.3:
	.string	"number"
	.local	observed
	.comm	observed,8,8
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
