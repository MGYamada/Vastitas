	.file	"probe.c"
	.text
	.p2align 4
	.type	c_kernel, @function
c_kernel:
.LFB52:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	32(%rdx), %r15
	testq	%r15, %r15
	je	.L1
	movq	48(%rdx), %rax
	movq	24(%rdx), %rbx
	movq	%rdx, %r11
	movq	%rdi, %r10
	movq	56(%rdx), %r9
	movq	%rsi, %r8
	xorl	%ebp, %ebp
	leaq	0(,%rax,8), %r14
	movq	48(%rcx), %rax
	movq	%r9, %r12
	leaq	0(,%rax,8), %r13
	leaq	0(,%rbx,8), %rax
	movq	%rax, 24(%rsp)
	.p2align 4,,10
	.p2align 3
.L5:
	cmpq	$1, %r12
	je	.L3
	testq	%rbx, %rbx
	je	.L7
	movq	40(%r11), %rax
	movq	%r10, %rsi
	movq	%r8, %rdx
	leaq	0(,%rax,8), %r9
	movq	40(%rcx), %rax
	leaq	0(,%rax,8), %rdi
	xorl	%eax, %eax
	.p2align 4,,10
	.p2align 3
.L12:
	movupd	(%rsi), %xmm1
	addq	$1, %rax
	addq	%r9, %rsi
	movups	%xmm1, (%rdx)
	addq	%rdi, %rdx
	cmpq	%rbx, %rax
	jne	.L12
.L7:
	addq	$1, %rbp
	addq	%r14, %r10
	addq	%r13, %r8
	cmpq	%r15, %rbp
	jne	.L5
.L1:
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L3:
	.cfi_restore_state
	testq	%rbx, %rbx
	je	.L7
	movq	40(%r11), %rdi
	movq	40(%rcx), %r9
	cmpq	$1, %rdi
	jne	.L13
	cmpq	$1, %r9
	jne	.L13
	movq	24(%rsp), %rdx
	movq	%r10, %rsi
	movq	%r8, %rdi
	movq	%rcx, 16(%rsp)
	movq	%r11, 8(%rsp)
	addq	$1, %rbp
	movq	%r10, (%rsp)
	call	memcpy@PLT
	movq	(%rsp), %r10
	movq	8(%rsp), %r11
	movq	%rax, %r8
	movq	16(%rsp), %rcx
	addq	%r14, %r10
	addq	%r13, %r8
	cmpq	%r15, %rbp
	jne	.L5
	jmp	.L1
	.p2align 4,,10
	.p2align 3
.L13:
	salq	$3, %rdi
	salq	$3, %r9
	movq	%r8, %rsi
	movq	%r10, %rdx
	xorl	%eax, %eax
	.p2align 4,,10
	.p2align 3
.L10:
	movsd	(%rdx), %xmm0
	addq	$1, %rax
	addq	%rdi, %rdx
	movsd	%xmm0, (%rsi)
	addq	%r9, %rsi
	cmpq	%rbx, %rax
	jne	.L10
	addq	$1, %rbp
	addq	%r14, %r10
	addq	%r13, %r8
	cmpq	%r15, %rbp
	jne	.L5
	jmp	.L1
	.cfi_endproc
.LFE52:
	.size	c_kernel, .-c_kernel
	.p2align 4
	.type	copy_kernel, @function
copy_kernel:
.LFB38:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movq	%rdx, %r15
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%rsi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	cmpq	$1, 56(%rdx)
	movq	32(%rdx), %r12
	je	.L23
	testq	%r12, %r12
	je	.L22
	movq	24(%rdx), %r8
	testq	%r8, %r8
	je	.L22
	movq	8(%rdx), %r11
	movq	8(%rcx), %r10
	xorl	%r9d, %r9d
	movq	40(%rdx), %rdi
	movq	40(%rcx), %rsi
	movq	48(%rdx), %r14
	movq	48(%rcx), %r13
	shrq	$3, %r11
	shrq	$3, %r10
	salq	$3, %rdi
	salq	$3, %rsi
	.p2align 4,,10
	.p2align 3
.L26:
	movq	%r13, %rax
	imulq	%r9, %rax
	addq	%r10, %rax
	leaq	0(%rbp,%rax,8), %rcx
	movq	%r14, %rax
	imulq	%r9, %rax
	addq	%r11, %rax
	leaq	(%rbx,%rax,8), %rdx
	xorl	%eax, %eax
	.p2align 4,,10
	.p2align 3
.L33:
	movupd	(%rdx), %xmm1
	addq	$1, %rax
	addq	%rdi, %rdx
	movups	%xmm1, (%rcx)
	addq	%rsi, %rcx
	cmpq	%r8, %rax
	jne	.L33
	addq	$1, %r9
	cmpq	%r12, %r9
	jne	.L26
.L22:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
.L23:
	.cfi_restore_state
	testq	%r12, %r12
	je	.L22
	movq	24(%rdx), %r13
	testq	%r13, %r13
	je	.L22
	leaq	0(,%r13,8), %rax
	xorl	%r14d, %r14d
	movq	%rax, 8(%rsp)
	.p2align 4,,10
	.p2align 3
.L28:
	movq	48(%r15), %rax
	movq	8(%r15), %rdx
	movq	48(%rcx), %r9
	movq	40(%r15), %rsi
	imulq	%r14, %rax
	shrq	$3, %rdx
	movq	40(%rcx), %rdi
	imulq	%r14, %r9
	addq	%rax, %rdx
	movq	8(%rcx), %rax
	shrq	$3, %rax
	addq	%r9, %rax
	cmpq	$1, %rsi
	jne	.L31
	cmpq	$1, %rdi
	jne	.L31
	leaq	(%rbx,%rdx,8), %rsi
	movq	8(%rsp), %rdx
	addq	$1, %r14
	movq	%rcx, (%rsp)
	leaq	0(%rbp,%rax,8), %rdi
	call	memcpy@PLT
	movq	(%rsp), %rcx
	cmpq	%r12, %r14
	jne	.L28
	jmp	.L22
	.p2align 4,,10
	.p2align 3
.L31:
	leaq	0(,%rsi,8), %r9
	salq	$3, %rdi
	leaq	(%rbx,%rdx,8), %rsi
	leaq	0(%rbp,%rax,8), %rdx
	xorl	%eax, %eax
	.p2align 4,,10
	.p2align 3
.L29:
	movsd	(%rsi), %xmm0
	addq	$1, %rax
	addq	%r9, %rsi
	movsd	%xmm0, (%rdx)
	addq	%rdi, %rdx
	cmpq	%r13, %rax
	jne	.L29
	addq	$1, %r14
	cmpq	%r12, %r14
	jne	.L28
	jmp	.L22
	.cfi_endproc
.LFE38:
	.size	copy_kernel, .-copy_kernel
	.p2align 4
	.type	vstorage_allocate.constprop.0, @function
vstorage_allocate.constprop.0:
.LFB69:
	.cfi_startproc
	testq	%rdi, %rdi
	je	.L64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 64
	cmpb	$0, 12(%rdi)
	jne	.L65
	movl	%esi, %ebp
	cmpl	$4095, %esi
	ja	.L65
	movl	8(%rdi), %r13d
	cmpl	%r13d, %esi
	jb	.L82
.L54:
	movq	%rdx, %rcx
	movl	$5, %eax
	shrq	$60, %rcx
	jne	.L52
	movq	16(%rbx), %rax
	leaq	0(,%rdx,8), %r12
	subq	40(%rbx), %rax
	cmpq	%r12, %rax
	jb	.L60
	cmpl	%r13d, %ebp
	jb	.L56
	testl	%r13d, %r13d
	je	.L83
	.p2align 4,,10
	.p2align 3
.L59:
	addl	%r13d, %r13d
	cmpl	%r13d, %ebp
	jnb	.L59
.L58:
	movl	%r13d, %eax
	movq	(%rbx), %rdi
	leaq	(%rax,%rax,2), %r14
	salq	$3, %r14
	movq	%r14, %rsi
	call	realloc@PLT
	movq	%rax, %r15
	testq	%rax, %rax
	je	.L60
	movl	8(%rbx), %eax
	leaq	(%rax,%rax,2), %rdi
	movq	%rax, %rdx
	movl	%r13d, %eax
	salq	$3, %rdi
	cmpq	%rdi, %r14
	movq	%rdi, %rcx
	cmovnb	%r14, %rcx
	subl	%edx, %eax
	xorl	%esi, %esi
	addq	$88, %r14
	leaq	(%rax,%rax,2), %rdx
	subq	%rdi, %rcx
	salq	$3, %rdx
	addq	%r15, %rdi
	call	__memset_chk@PLT
	addq	$1, 72(%rbx)
	movq	%r15, (%rbx)
	movl	%r13d, 8(%rbx)
	movq	%r14, 80(%rbx)
.L56:
	xorl	%eax, %eax
	testq	%r12, %r12
	jne	.L84
.L61:
	movq	(%rbx), %rdx
	movl	%ebp, %ebp
	cmpq	$1, %r12
	leaq	0(%rbp,%rbp,2), %rcx
	leaq	(%rdx,%rcx,8), %rdx
	movq	%rax, (%rdx)
	movl	$256, %eax
	movq	%r12, 8(%rdx)
	movw	%ax, 16(%rdx)
	movb	$1, 18(%rdx)
	movq	40(%rbx), %rdx
	sbbq	$-1, 24(%rbx)
	addq	%r12, %rdx
	movq	%rdx, 40(%rbx)
	cmpq	%rdx, 48(%rbx)
	jnb	.L63
	movq	%rdx, 48(%rbx)
.L63:
	xorl	%eax, %eax
.L52:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L82:
	.cfi_restore_state
	movl	%esi, %eax
	movq	(%rdi), %rsi
	leaq	(%rax,%rax,2), %rcx
	movl	$2, %eax
	leaq	(%rsi,%rcx,8), %rcx
	cmpb	$0, 17(%rcx)
	je	.L54
	jmp	.L52
	.p2align 4,,10
	.p2align 3
.L65:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movl	$2, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L84:
	.cfi_restore_state
	movq	%r12, %rdi
	call	malloc@PLT
	testq	%rax, %rax
	jne	.L61
	.p2align 4,,10
	.p2align 3
.L60:
	movl	$1, %eax
	jmp	.L52
	.p2align 4,,10
	.p2align 3
.L64:
	.cfi_def_cfa_offset 8
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	.cfi_restore 14
	.cfi_restore 15
	movl	$2, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L83:
	.cfi_def_cfa_offset 64
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movl	$8, %r13d
	cmpl	$7, %ebp
	ja	.L59
	jmp	.L58
	.cfi_endproc
.LFE69:
	.size	vstorage_allocate.constprop.0, .-vstorage_allocate.constprop.0
	.p2align 4
	.type	prepare.isra.0, @function
prepare.isra.0:
.LFB70:
	.cfi_startproc
	movq	%rdi, %rax
	testq	%rdi, %rdi
	je	.L95
	cmpb	$0, 12(%rdi)
	jne	.L95
	cmpl	8(%rdi), %esi
	jnb	.L95
	movl	%esi, %esi
	movq	(%rax), %rax
	movq	%rdx, %rdi
	leaq	(%rsi,%rsi,2), %rdx
	leaq	(%rax,%rdx,8), %rsi
	cmpb	$0, 18(%rsi)
	je	.L95
	leaq	-1(%r9), %rax
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	cmpq	$2147483646, %rax
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	seta	%al
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	cmpb	$1, 56(%rsp)
	seta	%dl
	orl	%edx, %eax
	cmpq	%rcx, %r9
	setb	%dl
	orb	%dl, %al
	jne	.L96
	movq	%rcx, %rax
	orq	%r8, %rax
	cmpq	$2147483647, %rax
	jbe	.L121
.L96:
	movl	$4, %eax
.L85:
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L95:
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	.cfi_restore 14
	.cfi_restore 15
	movl	$2, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L121:
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movq	8(%rsi), %r12
	movl	$4, %eax
	cmpq	%rdi, %r12
	jb	.L85
	cmpb	$0, 16(%rsi)
	movq	%rcx, %rbx
	movabsq	$9223372036854775791, %rax
	movabsq	$9223372036854775799, %rbp
	movabsq	$1152921504606846975, %rdx
	cmovne	%rax, %rbp
	movabsq	$576460752303423487, %rax
	cmovne	%rax, %rdx
	cmpb	$1, 16(%rsi)
	movl	$5, %eax
	sbbq	%r11, %r11
	addq	$2, %r11
	cmpb	$1, 16(%rsi)
	sbbq	%r10, %r10
	imulq	%r8, %rbx
	andq	$-8, %r10
	addq	$16, %r10
	cmpq	%rbx, %rdx
	jb	.L85
	imulq	%r10, %r9
	imulq	%r10, %rbx
	testq	%r8, %r8
	je	.L100
	testq	%rcx, %rcx
	jne	.L122
.L100:
	movq	%rdi, %rdx
.L88:
	shrq	$3, %r9
	cmpb	$0, 56(%rsp)
	movq	%r11, %rax
	jne	.L91
	movq	%r8, %rax
	movq	%rcx, %r8
	movq	%rax, %rcx
	movq	%r9, %rax
	movq	%r11, %r9
.L91:
	movq	64(%rsp), %r15
	movq	%rax, 48(%r15)
	xorl	%eax, %eax
	movq	%rsi, (%r15)
	movq	%rdi, 8(%r15)
	movq	%rdx, 16(%r15)
	movq	%r8, 24(%r15)
	movq	%rcx, 32(%r15)
	movq	%r9, 40(%r15)
	movq	%r11, 56(%r15)
	movq	%rbx, 64(%r15)
	jmp	.L85
	.p2align 4,,10
	.p2align 3
.L122:
	movabsq	$9223372036854775807, %r14
	xorl	%edx, %edx
	leaq	-1(%r8), %r13
	movq	%r14, %rax
	divq	%r9
	movq	%rax, %r15
	movl	$5, %eax
	cmpq	%r13, %r15
	jb	.L85
	leaq	-1(%rcx), %rdx
	movq	%r14, %r15
	imulq	%r10, %rdx
	subq	%rdx, %r15
	cmpq	%rdi, %r15
	jb	.L85
	imulq	%r9, %r13
	testq	%r13, %r13
	js	.L85
	addq	%rdi, %rdx
	subq	%r13, %r14
	cmpq	%rdx, %r14
	jb	.L85
	addq	%rdx, %r13
	cmpq	%r13, %rbp
	jb	.L85
	leaq	(%r10,%r13), %rdx
	movl	$4, %eax
	cmpq	%rdx, %r12
	jb	.L85
	movq	(%rsi), %r10
	testq	%r10, %r10
	je	.L85
	movq	%r10, %r14
	addq	%rdx, %r14
	jc	.L85
	addq	%rdi, %r10
	andl	$7, %r10d
	je	.L88
	jmp	.L85
	.cfi_endproc
.LFE70:
	.size	prepare.isra.0, .-prepare.isra.0
	.p2align 4
	.type	initialize, @function
initialize:
.LFB57:
	.cfi_startproc
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	movl	$1, %r9d
	movl	%ecx, %r13d
	movq	%rdx, %rcx
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	movq	%rdi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	movq	%r8, %rbp
	movl	$1, %r8d
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	movq	%rdx, %rbx
	subq	$152, %rsp
	.cfi_def_cfa_offset 192
	movq	(%rdi), %rdi
	movq	%fs:40, %rax
	movq	%rax, 136(%rsp)
	xorl	%eax, %eax
	movq	%rsp, %rax
	testq	%rdx, %rdx
	pushq	%rax
	.cfi_def_cfa_offset 200
	cmovne	%rdx, %r9
	xorl	%edx, %edx
	pushq	$0
	.cfi_def_cfa_offset 208
	call	prepare.isra.0
	movl	%eax, %edx
	popq	%rax
	.cfi_def_cfa_offset 200
	xorl	%eax, %eax
	popq	%rcx
	.cfi_def_cfa_offset 192
	testl	%edx, %edx
	jne	.L123
	movq	(%rsp), %rax
	movq	(%rax), %rdi
	movq	%rdi, 0(%rbp)
	cmpb	$0, 128(%r12)
	je	.L125
	addq	%rbx, %rbx
	je	.L126
	testl	%r13d, %r13d
	je	.L149
.L127:
	movdqa	.LC1(%rip), %xmm2
	movdqa	.LC2(%rip), %xmm1
	xorl	%esi, %esi
	xorl	%ecx, %ecx
	movdqa	.LC3(%rip), %xmm0
	movabsq	$5895351198814392785, %r8
	movabsq	$4503599627370495, %r11
	movabsq	$4607182418800017408, %r10
	movabsq	$-7046029254386353131, %r9
	jmp	.L130
	.p2align 4,,10
	.p2align 3
.L150:
	movq	80(%rsp,%rdx,8), %rax
	addq	%r9, %rsi
	movq	%rax, (%rdi,%rcx,8)
	addq	$1, %rcx
	cmpq	%rcx, %rbx
	je	.L126
.L151:
	movq	0(%rbp), %rdi
.L130:
	movq	%rcx, %rax
	movaps	%xmm2, 80(%rsp)
	mulq	%r8
	movq	%rcx, %rax
	movaps	%xmm1, 96(%rsp)
	movaps	%xmm0, 112(%rsp)
	subq	%rdx, %rax
	shrq	%rax
	addq	%rax, %rdx
	shrq	$6, %rdx
	leaq	(%rdx,%rdx,2), %rax
	salq	$5, %rax
	addq	%rdx, %rax
	movq	%rcx, %rdx
	subq	%rax, %rdx
	cmpq	$5, %rdx
	jbe	.L150
	movq	%rsi, %rax
	addq	%r9, %rsi
	andq	%r11, %rax
	orq	%r10, %rax
	movq	%rax, (%rdi,%rcx,8)
	addq	$1, %rcx
	cmpq	%rcx, %rbx
	jne	.L151
.L126:
	salq	$3, %rbx
	addq	%rbx, 120(%r12)
	movl	$1, %eax
.L123:
	movq	136(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L152
	addq	$152, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L125:
	.cfi_restore_state
	testq	%rbx, %rbx
	je	.L126
	testl	%r13d, %r13d
	jne	.L127
	movabsq	$9221120240777019119, %rax
	movq	%rax, (%rdi)
	cmpq	$1, %rbx
	jne	.L128
	jmp	.L126
	.p2align 4,,10
	.p2align 3
.L149:
	movabsq	$9221120240777019119, %rax
	movq	%rax, (%rdi)
.L128:
	movabsq	$9221120240777019119, %rcx
	movl	$1, %eax
	.p2align 4,,10
	.p2align 3
.L132:
	movq	0(%rbp), %rdx
	movq	%rcx, (%rdx,%rax,8)
	addq	$1, %rax
	cmpq	%rax, %rbx
	jne	.L132
	salq	$3, %rbx
	movl	$1, %eax
	addq	%rbx, 120(%r12)
	jmp	.L123
.L152:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE57:
	.size	initialize, .-initialize
	.p2align 4
	.type	vstorage_close.part.0, @function
vstorage_close.part.0:
.LFB68:
	.cfi_startproc
	pushq	%r12
	.cfi_def_cfa_offset 16
	.cfi_offset 12, -16
	movq	%rdi, %r12
	pushq	%rbp
	.cfi_def_cfa_offset 24
	.cfi_offset 6, -24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset 3, -32
	movl	8(%rdi), %ecx
	xorl	%ebx, %ebx
	testl	%ecx, %ecx
	jne	.L154
	jmp	.L157
	.p2align 4,,10
	.p2align 3
.L155:
	addq	$1, %rbx
	cmpl	%ecx, %ebx
	jnb	.L157
.L154:
	movq	(%r12), %rdx
	leaq	(%rbx,%rbx,2), %rax
	leaq	(%rdx,%rax,8), %rbp
	cmpb	$0, 18(%rbp)
	je	.L155
	cmpb	$0, 12(%r12)
	jne	.L155
	movq	0(%rbp), %rdi
	testq	%rdi, %rdi
	je	.L156
	call	free@PLT
	addq	$1, 32(%r12)
	movl	8(%r12), %ecx
.L156:
	addq	$1, %rbx
	movq	8(%rbp), %rax
	subq	%rax, 40(%r12)
	movq	$0, 0(%rbp)
	movb	$0, 18(%rbp)
	cmpl	%ecx, %ebx
	jb	.L154
.L157:
	movb	$1, 12(%r12)
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%rbp
	.cfi_def_cfa_offset 16
	popq	%r12
	.cfi_def_cfa_offset 8
	ret
	.cfi_endproc
.LFE68:
	.size	vstorage_close.part.0, .-vstorage_close.part.0
	.p2align 4
	.globl	bench_c_copy
	.type	bench_c_copy, @function
bench_c_copy:
.LFB53:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$280, %rsp
	.cfi_def_cfa_offset 336
	movq	%fs:40, %rax
	movq	%rax, 264(%rsp)
	xorl	%eax, %eax
	testq	%rdi, %rdi
	je	.L168
	cmpb	$0, 12(%rdi)
	movq	%rdi, %rbx
	jne	.L168
	movl	%esi, %ecx
	movl	8(%rdi), %esi
	cmpl	%esi, %ecx
	jnb	.L168
	movq	(%rdi), %rbp
	movl	%ecx, %eax
	leaq	(%rax,%rax,2), %rax
	leaq	0(%rbp,%rax,8), %r10
	cmpb	$0, 18(%r10)
	je	.L168
	movzbl	368(%rsp), %r12d
	movq	344(%rsp), %r9
	movl	%edx, %r8d
	movq	360(%rsp), %rax
	movq	352(%rsp), %r11
	cmpb	$1, %r12b
	movq	336(%rsp), %rdi
	seta	%dl
	cmpq	%r9, %rax
	setb	%r13b
	orl	%r13d, %edx
	movq	%r9, %r13
	orq	%r11, %r13
	cmpq	$2147483647, %r13
	seta	%r13b
	orb	%r13b, %dl
	jne	.L173
	leaq	-1(%rax), %rdx
	cmpq	$2147483646, %rdx
	jbe	.L171
.L173:
	movl	$4, %eax
.L167:
	movq	264(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L230
	addq	$280, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L171:
	.cfi_restore_state
	movq	8(%r10), %rdx
	movq	%rdx, 24(%rsp)
	cmpq	%rdi, %rdx
	jb	.L173
	movabsq	$9223372036854775799, %r13
	movzbl	16(%r10), %r15d
	movabsq	$9223372036854775791, %rdx
	testb	%r15b, %r15b
	movb	%r15b, 85(%rsp)
	cmove	%r13, %rdx
	movabsq	$576460752303423487, %r13
	movq	%rdx, 32(%rsp)
	movabsq	$1152921504606846975, %rdx
	cmovne	%r13, %rdx
	cmpb	$1, %r15b
	sbbq	%r13, %r13
	addq	$2, %r13
	cmpb	$1, %r15b
	movq	%r9, %r15
	sbbq	%r14, %r14
	imulq	%r11, %r15
	andq	$-8, %r14
	addq	$16, %r14
	cmpq	%r15, %rdx
	jb	.L191
	imulq	%r14, %rax
	imulq	%r14, %r15
	movq	%rax, 16(%rsp)
	movq	%r15, 8(%rsp)
	testq	%r9, %r9
	je	.L196
	testq	%r11, %r11
	jne	.L231
.L196:
	movq	%rdi, 32(%rsp)
.L176:
	movq	16(%rsp), %rdx
	movq	%r13, 24(%rsp)
	shrq	$3, %rdx
	movq	%rdx, 16(%rsp)
	testb	%r12b, %r12b
	jne	.L180
	movq	%rdx, 24(%rsp)
	movq	%r11, %rax
	movq	%r9, %r11
	movq	%r13, 16(%rsp)
	movq	%rax, %r9
.L180:
	movq	32(%rsp), %rax
	movq	%r10, 112(%rsp)
	movq	%rdi, 120(%rsp)
	movq	%rax, 128(%rsp)
	movq	16(%rsp), %rax
	movq	%r11, 136(%rsp)
	movq	%rax, 152(%rsp)
	movq	24(%rsp), %rax
	movq	%r9, 144(%rsp)
	movq	%rax, 160(%rsp)
	movq	8(%rsp), %rax
	movq	%r13, 168(%rsp)
	movq	%rax, 176(%rsp)
	cmpl	%esi, %r8d
	jnb	.L168
	movl	%r8d, %eax
	leaq	(%rax,%rax,2), %rax
	leaq	0(%rbp,%rax,8), %rbp
	cmpb	$0, 18(%rbp)
	je	.L168
	movq	384(%rsp), %rsi
	movq	400(%rsp), %rax
	movq	392(%rsp), %r12
	movq	376(%rsp), %r13
	movzbl	408(%rsp), %r15d
	cmpq	%rsi, %rax
	setb	%dl
	cmpb	$1, %r15b
	movb	%r15b, 87(%rsp)
	seta	%r14b
	orl	%r14d, %edx
	movq	%rsi, %r14
	orq	%r12, %r14
	cmpq	$2147483647, %r14
	seta	%r14b
	orb	%dl, %r14b
	jne	.L173
	leaq	-1(%rax), %rdx
	cmpq	$2147483646, %rdx
	ja	.L173
	movq	8(%rbp), %rdx
	movq	%rdx, 88(%rsp)
	cmpq	%r13, %rdx
	jb	.L173
	movabsq	$9223372036854775799, %r14
	movzbl	16(%rbp), %r15d
	movabsq	$9223372036854775791, %rdx
	testb	%r15b, %r15b
	movb	%r15b, 86(%rsp)
	cmove	%r14, %rdx
	movabsq	$576460752303423487, %r14
	movq	%rdx, 96(%rsp)
	movabsq	$1152921504606846975, %rdx
	cmovne	%r14, %rdx
	cmpb	$1, %r15b
	movl	%r15d, %r14d
	sbbq	%r15, %r15
	addq	$2, %r15
	cmpb	$1, %r14b
	movq	%rsi, %r14
	movq	%r15, 48(%rsp)
	sbbq	%r15, %r15
	imulq	%r12, %r14
	andq	$-8, %r15
	addq	$16, %r15
	cmpq	%r14, %rdx
	jb	.L191
	imulq	%r15, %r14
	imulq	%r15, %rax
	movq	%r14, %xmm1
	movq	%r14, 40(%rsp)
	punpcklqdq	%xmm1, %xmm1
	movq	%rax, 56(%rsp)
	movq	%rax, %rdx
	movaps	%xmm1, 64(%rsp)
	testq	%rsi, %rsi
	je	.L199
	testq	%r12, %r12
	jne	.L232
.L199:
	movq	%r13, %r14
.L182:
	movq	56(%rsp), %rdx
	movq	48(%rsp), %r15
	shrq	$3, %rdx
	cmpb	$0, 87(%rsp)
	movq	%r15, 56(%rsp)
	je	.L185
	movq	%rsi, %rax
	movq	%rdx, 56(%rsp)
	movq	%r12, %rsi
	movq	%r15, %rdx
	movq	%rax, %r12
.L185:
	movq	56(%rsp), %rax
	movq	%rbp, 192(%rsp)
	movq	%r13, 200(%rsp)
	movzbl	86(%rsp), %r15d
	movq	%rax, 232(%rsp)
	movq	48(%rsp), %rax
	movq	%r14, 208(%rsp)
	movq	%rax, 248(%rsp)
	movq	40(%rsp), %rax
	movq	%rsi, 216(%rsp)
	movq	%rax, 256(%rsp)
	movl	$3, %eax
	movq	%r12, 224(%rsp)
	movq	%rdx, 240(%rsp)
	cmpb	%r15b, 85(%rsp)
	jne	.L167
	cmpq	%rsi, %r11
	jne	.L173
	cmpq	%r12, %r9
	jne	.L173
	cmpq	$0, 8(%rsp)
	je	.L186
	cmpl	%r8d, %ecx
	je	.L233
.L187:
	movq	40(%rsp), %rax
	movq	56(%rbx), %r14
	movq	%rax, %rcx
	addq	%r14, %rcx
	jc	.L191
	movq	64(%rbx), %r12
	addq	%r12, %rax
	jc	.L191
	movq	%r13, %rsi
	leaq	192(%rsp), %rcx
	leaq	112(%rsp), %rdx
	andq	$-8, %rdi
	andq	$-8, %rsi
	addq	(%r10), %rdi
	addq	0(%rbp), %rsi
	call	c_kernel
	movq	%r14, %xmm0
	movq	%r12, %xmm2
	punpcklqdq	%xmm2, %xmm0
	paddq	64(%rsp), %xmm0
	movups	%xmm0, 56(%rbx)
.L186:
	xorl	%eax, %eax
	jmp	.L167
	.p2align 4,,10
	.p2align 3
.L168:
	movl	$2, %eax
	jmp	.L167
	.p2align 4,,10
	.p2align 3
.L191:
	movl	$5, %eax
	jmp	.L167
	.p2align 4,,10
	.p2align 3
.L233:
	cmpq	%rdi, %r13
	je	.L234
.L188:
	movq	32(%rsp), %rax
	cmpq	%rax, %r13
	jnb	.L187
	movl	$7, %eax
	cmpq	%r14, %rdi
	jnb	.L187
	jmp	.L167
	.p2align 4,,10
	.p2align 3
.L231:
	movabsq	$9223372036854775807, %rax
	xorl	%edx, %edx
	leaq	-1(%r11), %r15
	divq	16(%rsp)
	cmpq	%r15, %rax
	jb	.L191
	movabsq	$9223372036854775807, %rax
	leaq	-1(%r9), %rdx
	imulq	%r14, %rdx
	subq	%rdx, %rax
	cmpq	%rdi, %rax
	jb	.L191
	movq	16(%rsp), %rax
	imulq	%rax, %r15
	testq	%r15, %r15
	js	.L191
	movabsq	$9223372036854775807, %rax
	addq	%rdi, %rdx
	subq	%r15, %rax
	cmpq	%rdx, %rax
	jb	.L191
	addq	%rdx, %r15
	cmpq	%r15, 32(%rsp)
	jb	.L191
	leaq	(%r14,%r15), %rdx
	movq	%rdx, 32(%rsp)
	cmpq	%rdx, 24(%rsp)
	jb	.L173
	movq	(%r10), %rax
	testq	%rax, %rax
	je	.L173
	addq	%rax, %rdx
	jc	.L173
	addq	%rdi, %rax
	testb	$7, %al
	je	.L176
	jmp	.L173
	.p2align 4,,10
	.p2align 3
.L232:
	leaq	-1(%r12), %rax
	movq	%rdx, %r14
	xorl	%edx, %edx
	movq	%rax, 104(%rsp)
	movabsq	$9223372036854775807, %rax
	divq	%r14
	movq	104(%rsp), %r14
	cmpq	%r14, %rax
	jb	.L191
	movabsq	$9223372036854775807, %rax
	leaq	-1(%rsi), %rdx
	imulq	%r15, %rdx
	subq	%rdx, %rax
	cmpq	%r13, %rax
	jb	.L191
	movq	56(%rsp), %rax
	imulq	%rax, %r14
	movq	%r14, %rax
	testq	%r14, %r14
	js	.L191
	movabsq	$9223372036854775807, %r14
	addq	%r13, %rdx
	subq	%rax, %r14
	cmpq	%rdx, %r14
	jb	.L191
	addq	%rdx, %rax
	cmpq	%rax, 96(%rsp)
	jb	.L191
	leaq	(%r15,%rax), %r14
	cmpq	%r14, 88(%rsp)
	jb	.L173
	movq	0(%rbp), %rdx
	testq	%rdx, %rdx
	je	.L173
	movq	%rdx, %rax
	addq	%r14, %rax
	jc	.L173
	addq	%r13, %rdx
	andb	$7, %dl
	je	.L182
	jmp	.L173
	.p2align 4,,10
	.p2align 3
.L234:
	movq	56(%rsp), %rcx
	cmpq	%rcx, 16(%rsp)
	jne	.L188
	cmpq	%rdx, 24(%rsp)
	jne	.L188
	xorl	%eax, %eax
	jmp	.L167
.L230:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE53:
	.size	bench_c_copy, .-bench_c_copy
	.p2align 4
	.globl	vstorage_copy
	.type	vstorage_copy, @function
vstorage_copy:
.LFB39:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$280, %rsp
	.cfi_def_cfa_offset 336
	movq	%fs:40, %rax
	movq	%rax, 264(%rsp)
	xorl	%eax, %eax
	testq	%rdi, %rdi
	je	.L236
	cmpb	$0, 12(%rdi)
	movq	%rdi, %rbx
	jne	.L236
	movl	%esi, %ecx
	movl	8(%rdi), %esi
	cmpl	%esi, %ecx
	jnb	.L236
	movq	(%rdi), %rbp
	movl	%ecx, %eax
	leaq	(%rax,%rax,2), %rax
	leaq	0(%rbp,%rax,8), %r10
	cmpb	$0, 18(%r10)
	je	.L236
	movzbl	368(%rsp), %r12d
	movq	344(%rsp), %r9
	movl	%edx, %r8d
	movq	360(%rsp), %rax
	movq	352(%rsp), %r11
	cmpb	$1, %r12b
	movq	336(%rsp), %rdi
	seta	%dl
	cmpq	%r9, %rax
	setb	%r13b
	orl	%r13d, %edx
	movq	%r9, %r13
	orq	%r11, %r13
	cmpq	$2147483647, %r13
	seta	%r13b
	orb	%r13b, %dl
	jne	.L241
	leaq	-1(%rax), %rdx
	cmpq	$2147483646, %rdx
	jbe	.L239
.L241:
	movl	$4, %eax
.L235:
	movq	264(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L298
	addq	$280, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L239:
	.cfi_restore_state
	movq	8(%r10), %rdx
	movq	%rdx, 24(%rsp)
	cmpq	%rdi, %rdx
	jb	.L241
	movabsq	$9223372036854775799, %r13
	movzbl	16(%r10), %r15d
	movabsq	$9223372036854775791, %rdx
	testb	%r15b, %r15b
	movb	%r15b, 85(%rsp)
	cmove	%r13, %rdx
	movabsq	$576460752303423487, %r13
	movq	%rdx, 32(%rsp)
	movabsq	$1152921504606846975, %rdx
	cmovne	%r13, %rdx
	cmpb	$1, %r15b
	sbbq	%r13, %r13
	addq	$2, %r13
	cmpb	$1, %r15b
	movq	%r9, %r15
	sbbq	%r14, %r14
	imulq	%r11, %r15
	andq	$-8, %r14
	addq	$16, %r14
	cmpq	%r15, %rdx
	jb	.L259
	imulq	%r14, %rax
	imulq	%r14, %r15
	movq	%rax, 16(%rsp)
	movq	%r15, 8(%rsp)
	testq	%r9, %r9
	je	.L264
	testq	%r11, %r11
	jne	.L299
.L264:
	movq	%rdi, 32(%rsp)
.L244:
	movq	16(%rsp), %rdx
	movq	%r13, 24(%rsp)
	shrq	$3, %rdx
	movq	%rdx, 16(%rsp)
	testb	%r12b, %r12b
	jne	.L248
	movq	%rdx, 24(%rsp)
	movq	%r11, %rax
	movq	%r9, %r11
	movq	%r13, 16(%rsp)
	movq	%rax, %r9
.L248:
	movq	32(%rsp), %rax
	movq	%r10, 112(%rsp)
	movq	%rdi, 120(%rsp)
	movq	%rax, 128(%rsp)
	movq	16(%rsp), %rax
	movq	%r11, 136(%rsp)
	movq	%rax, 152(%rsp)
	movq	24(%rsp), %rax
	movq	%r9, 144(%rsp)
	movq	%rax, 160(%rsp)
	movq	8(%rsp), %rax
	movq	%r13, 168(%rsp)
	movq	%rax, 176(%rsp)
	cmpl	%esi, %r8d
	jnb	.L236
	movl	%r8d, %eax
	leaq	(%rax,%rax,2), %rax
	leaq	0(%rbp,%rax,8), %rbp
	cmpb	$0, 18(%rbp)
	je	.L236
	movq	384(%rsp), %rsi
	movq	400(%rsp), %rax
	movq	392(%rsp), %r12
	movq	376(%rsp), %r13
	movzbl	408(%rsp), %r15d
	cmpq	%rsi, %rax
	setb	%dl
	cmpb	$1, %r15b
	movb	%r15b, 87(%rsp)
	seta	%r14b
	orl	%r14d, %edx
	movq	%rsi, %r14
	orq	%r12, %r14
	cmpq	$2147483647, %r14
	seta	%r14b
	orb	%dl, %r14b
	jne	.L241
	leaq	-1(%rax), %rdx
	cmpq	$2147483646, %rdx
	ja	.L241
	movq	8(%rbp), %rdx
	movq	%rdx, 88(%rsp)
	cmpq	%r13, %rdx
	jb	.L241
	movabsq	$9223372036854775799, %r14
	movzbl	16(%rbp), %r15d
	movabsq	$9223372036854775791, %rdx
	testb	%r15b, %r15b
	movb	%r15b, 86(%rsp)
	cmove	%r14, %rdx
	movabsq	$576460752303423487, %r14
	movq	%rdx, 96(%rsp)
	movabsq	$1152921504606846975, %rdx
	cmovne	%r14, %rdx
	cmpb	$1, %r15b
	movl	%r15d, %r14d
	sbbq	%r15, %r15
	addq	$2, %r15
	cmpb	$1, %r14b
	movq	%rsi, %r14
	movq	%r15, 48(%rsp)
	sbbq	%r15, %r15
	imulq	%r12, %r14
	andq	$-8, %r15
	addq	$16, %r15
	cmpq	%r14, %rdx
	jb	.L259
	imulq	%r15, %r14
	imulq	%r15, %rax
	movq	%r14, %xmm1
	movq	%r14, 40(%rsp)
	punpcklqdq	%xmm1, %xmm1
	movq	%rax, 56(%rsp)
	movq	%rax, %rdx
	movaps	%xmm1, 64(%rsp)
	testq	%rsi, %rsi
	je	.L267
	testq	%r12, %r12
	jne	.L300
.L267:
	movq	%r13, %r14
.L250:
	movq	56(%rsp), %rdx
	movq	48(%rsp), %r15
	shrq	$3, %rdx
	cmpb	$0, 87(%rsp)
	movq	%r15, 56(%rsp)
	je	.L253
	movq	%rsi, %rax
	movq	%rdx, 56(%rsp)
	movq	%r12, %rsi
	movq	%r15, %rdx
	movq	%rax, %r12
.L253:
	movq	56(%rsp), %rax
	movq	%rbp, 192(%rsp)
	movq	%r13, 200(%rsp)
	movzbl	86(%rsp), %r15d
	movq	%rax, 232(%rsp)
	movq	48(%rsp), %rax
	movq	%r14, 208(%rsp)
	movq	%rax, 248(%rsp)
	movq	40(%rsp), %rax
	movq	%rsi, 216(%rsp)
	movq	%rax, 256(%rsp)
	movl	$3, %eax
	movq	%r12, 224(%rsp)
	movq	%rdx, 240(%rsp)
	cmpb	%r15b, 85(%rsp)
	jne	.L235
	cmpq	%rsi, %r11
	jne	.L241
	cmpq	%r12, %r9
	jne	.L241
	cmpq	$0, 8(%rsp)
	je	.L254
	cmpl	%r8d, %ecx
	je	.L301
.L255:
	movq	40(%rsp), %rax
	movq	56(%rbx), %r14
	movq	%rax, %rcx
	addq	%r14, %rcx
	jc	.L259
	movq	64(%rbx), %r12
	addq	%r12, %rax
	jc	.L259
	movq	%r13, %rsi
	andq	$-8, %rdi
	leaq	112(%rsp), %rdx
	addq	(%r10), %rdi
	andq	$-8, %rsi
	addq	0(%rbp), %rsi
	leaq	192(%rsp), %rcx
	movq	$0, 120(%rsp)
	movq	$0, 200(%rsp)
	call	copy_kernel
	movq	%r14, %xmm0
	movq	%r12, %xmm2
	punpcklqdq	%xmm2, %xmm0
	paddq	64(%rsp), %xmm0
	movups	%xmm0, 56(%rbx)
.L254:
	xorl	%eax, %eax
	jmp	.L235
	.p2align 4,,10
	.p2align 3
.L236:
	movl	$2, %eax
	jmp	.L235
	.p2align 4,,10
	.p2align 3
.L259:
	movl	$5, %eax
	jmp	.L235
	.p2align 4,,10
	.p2align 3
.L301:
	cmpq	%rdi, %r13
	je	.L302
.L256:
	movq	32(%rsp), %rax
	cmpq	%rax, %r13
	jnb	.L255
	movl	$7, %eax
	cmpq	%r14, %rdi
	jnb	.L255
	jmp	.L235
	.p2align 4,,10
	.p2align 3
.L299:
	movabsq	$9223372036854775807, %rax
	xorl	%edx, %edx
	leaq	-1(%r11), %r15
	divq	16(%rsp)
	cmpq	%r15, %rax
	jb	.L259
	movabsq	$9223372036854775807, %rax
	leaq	-1(%r9), %rdx
	imulq	%r14, %rdx
	subq	%rdx, %rax
	cmpq	%rdi, %rax
	jb	.L259
	movq	16(%rsp), %rax
	imulq	%rax, %r15
	testq	%r15, %r15
	js	.L259
	movabsq	$9223372036854775807, %rax
	addq	%rdi, %rdx
	subq	%r15, %rax
	cmpq	%rdx, %rax
	jb	.L259
	addq	%rdx, %r15
	cmpq	%r15, 32(%rsp)
	jb	.L259
	leaq	(%r14,%r15), %rdx
	movq	%rdx, 32(%rsp)
	cmpq	%rdx, 24(%rsp)
	jb	.L241
	movq	(%r10), %rax
	testq	%rax, %rax
	je	.L241
	addq	%rax, %rdx
	jc	.L241
	addq	%rdi, %rax
	testb	$7, %al
	je	.L244
	jmp	.L241
	.p2align 4,,10
	.p2align 3
.L300:
	leaq	-1(%r12), %rax
	movq	%rdx, %r14
	xorl	%edx, %edx
	movq	%rax, 104(%rsp)
	movabsq	$9223372036854775807, %rax
	divq	%r14
	movq	104(%rsp), %r14
	cmpq	%r14, %rax
	jb	.L259
	movabsq	$9223372036854775807, %rax
	leaq	-1(%rsi), %rdx
	imulq	%r15, %rdx
	subq	%rdx, %rax
	cmpq	%r13, %rax
	jb	.L259
	movq	56(%rsp), %rax
	imulq	%rax, %r14
	movq	%r14, %rax
	testq	%r14, %r14
	js	.L259
	movabsq	$9223372036854775807, %r14
	addq	%r13, %rdx
	subq	%rax, %r14
	cmpq	%rdx, %r14
	jb	.L259
	addq	%rdx, %rax
	cmpq	%rax, 96(%rsp)
	jb	.L259
	leaq	(%r15,%rax), %r14
	cmpq	%r14, 88(%rsp)
	jb	.L241
	movq	0(%rbp), %rdx
	testq	%rdx, %rdx
	je	.L241
	movq	%rdx, %rax
	addq	%r14, %rax
	jc	.L241
	addq	%r13, %rdx
	andb	$7, %dl
	je	.L250
	jmp	.L241
	.p2align 4,,10
	.p2align 3
.L302:
	movq	56(%rsp), %rcx
	cmpq	%rcx, 16(%rsp)
	jne	.L256
	cmpq	%rdx, 24(%rsp)
	jne	.L256
	xorl	%eax, %eax
	jmp	.L235
.L298:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE39:
	.size	vstorage_copy, .-vstorage_copy
	.p2align 4
	.globl	vstorage_new
	.type	vstorage_new, @function
vstorage_new:
.LFB20:
	.cfi_startproc
	endbr64
	xorl	%eax, %eax
	testq	%rdi, %rdi
	js	.L309
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	movl	$88, %esi
	movq	%rdi, %rbx
	movl	$1, %edi
	call	calloc@PLT
	testq	%rax, %rax
	je	.L303
	movdqa	.LC4(%rip), %xmm0
	movq	%rbx, 16(%rax)
	movups	%xmm0, 72(%rax)
.L303:
	popq	%rbx
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L309:
	.cfi_restore 3
	ret
	.cfi_endproc
.LFE20:
	.size	vstorage_new, .-vstorage_new
	.p2align 4
	.globl	vstorage_drop
	.type	vstorage_drop, @function
vstorage_drop:
.LFB22:
	.cfi_startproc
	endbr64
	testq	%rdi, %rdi
	je	.L315
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	.cfi_offset 3, -24
	movq	%rdi, %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 32
	cmpb	$0, 12(%rdi)
	jne	.L318
	cmpl	8(%rdi), %esi
	jnb	.L318
	movq	(%rdi), %rax
	movl	%esi, %esi
	leaq	(%rsi,%rsi,2), %rdx
	leaq	(%rax,%rdx,8), %rbp
	cmpb	$0, 18(%rbp)
	je	.L318
	movq	0(%rbp), %rdi
	testq	%rdi, %rdi
	je	.L314
	call	free@PLT
	addq	$1, 32(%rbx)
.L314:
	movq	8(%rbp), %rax
	subq	%rax, 40(%rbx)
	xorl	%eax, %eax
	movq	$0, 0(%rbp)
	movb	$0, 18(%rbp)
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L318:
	.cfi_restore_state
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	movl	$2, %eax
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L315:
	.cfi_restore 3
	.cfi_restore 6
	movl	$2, %eax
	ret
	.cfi_endproc
.LFE22:
	.size	vstorage_drop, .-vstorage_drop
	.p2align 4
	.globl	vstorage_close
	.type	vstorage_close, @function
vstorage_close:
.LFB23:
	.cfi_startproc
	endbr64
	testq	%rdi, %rdi
	je	.L326
	cmpb	$0, 12(%rdi)
	jne	.L326
	jmp	vstorage_close.part.0
	.p2align 4,,10
	.p2align 3
.L326:
	ret
	.cfi_endproc
.LFE23:
	.size	vstorage_close, .-vstorage_close
	.p2align 4
	.globl	vstorage_delete
	.type	vstorage_delete, @function
vstorage_delete:
.LFB24:
	.cfi_startproc
	endbr64
	testq	%rdi, %rdi
	je	.L331
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset 3, -16
	cmpb	$0, 12(%rdi)
	movq	%rdi, %rbx
	jne	.L333
	call	vstorage_close.part.0
.L333:
	movq	(%rbx), %rdi
	call	free@PLT
	movq	%rbx, %rdi
	popq	%rbx
	.cfi_restore 3
	.cfi_def_cfa_offset 8
	jmp	free@PLT
	.p2align 4,,10
	.p2align 3
.L331:
	ret
	.cfi_endproc
.LFE24:
	.size	vstorage_delete, .-vstorage_delete
	.p2align 4
	.globl	vstorage_stats
	.type	vstorage_stats, @function
vstorage_stats:
.LFB25:
	.cfi_startproc
	endbr64
	movq	%rdi, %rax
	testq	%rsi, %rsi
	je	.L338
	movdqu	24(%rsi), %xmm1
	movdqu	40(%rsi), %xmm2
	movdqu	56(%rsi), %xmm3
	movdqu	72(%rsi), %xmm4
	movups	%xmm1, (%rdi)
	movups	%xmm2, 16(%rdi)
	movups	%xmm3, 32(%rdi)
	movups	%xmm4, 48(%rdi)
	ret
	.p2align 4,,10
	.p2align 3
.L338:
	pxor	%xmm0, %xmm0
	movups	%xmm0, (%rdi)
	movups	%xmm0, 16(%rdi)
	movups	%xmm0, 32(%rdi)
	movups	%xmm0, 48(%rdi)
	ret
	.cfi_endproc
.LFE25:
	.size	vstorage_stats, .-vstorage_stats
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC5:
	.string	"ok"
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC6:
	.string	"E_NATIVE_ALLOCATION: allocation or live-byte budget failed"
	.align 8
.LC7:
	.string	"E_NATIVE_HANDLE: allocation is absent, closed or already issued"
	.align 8
.LC8:
	.string	"E_NATIVE_SCALAR: scalar representation mismatch"
	.align 8
.LC9:
	.string	"E_NATIVE_LAYOUT: invalid layout, bounds, alignment or narrowing"
	.align 8
.LC10:
	.string	"E_NATIVE_OVERFLOW: native size or accounting overflow"
	.align 8
.LC11:
	.string	"E_NATIVE_BOUNDS: cell index is outside the view"
	.align 8
.LC12:
	.string	"E_NATIVE_ALIAS: accessed regions may overlap"
	.align 8
.LC13:
	.string	"E_NATIVE_EXPECT: stored bit pattern differs"
	.align 8
.LC14:
	.string	"E_NATIVE_ABI: unsupported numerical backend version, ABI or threading"
	.align 8
.LC15:
	.string	"E_NATIVE_SHAPE: numerical operand dimensions differ"
	.align 8
.LC16:
	.string	"E_NATIVE_OPERATION: unsupported numerical operation or layout"
	.align 8
.LC17:
	.string	"E_NATIVE_STATUS: unknown status"
	.text
	.p2align 4
	.globl	vstorage_error
	.type	vstorage_error, @function
vstorage_error:
.LFB26:
	.cfi_startproc
	endbr64
	cmpl	$11, %edi
	ja	.L341
	leaq	.L343(%rip), %rdx
	movl	%edi, %edi
	movslq	(%rdx,%rdi,4), %rax
	addq	%rdx, %rax
	notrack jmp	*%rax
	.section	.rodata
	.align 4
	.align 4
.L343:
	.long	.L354-.L343
	.long	.L355-.L343
	.long	.L352-.L343
	.long	.L351-.L343
	.long	.L350-.L343
	.long	.L349-.L343
	.long	.L348-.L343
	.long	.L347-.L343
	.long	.L346-.L343
	.long	.L345-.L343
	.long	.L344-.L343
	.long	.L342-.L343
	.text
	.p2align 4,,10
	.p2align 3
.L355:
	leaq	.LC6(%rip), %rax
	ret
	.p2align 4,,10
	.p2align 3
.L354:
	leaq	.LC5(%rip), %rax
	ret
	.p2align 4,,10
	.p2align 3
.L342:
	leaq	.LC16(%rip), %rax
	ret
	.p2align 4,,10
	.p2align 3
.L345:
	leaq	.LC14(%rip), %rax
	ret
	.p2align 4,,10
	.p2align 3
.L344:
	leaq	.LC15(%rip), %rax
	ret
	.p2align 4,,10
	.p2align 3
.L352:
	leaq	.LC7(%rip), %rax
	ret
	.p2align 4,,10
	.p2align 3
.L351:
	leaq	.LC8(%rip), %rax
	ret
	.p2align 4,,10
	.p2align 3
.L350:
	leaq	.LC9(%rip), %rax
	ret
	.p2align 4,,10
	.p2align 3
.L349:
	leaq	.LC10(%rip), %rax
	ret
	.p2align 4,,10
	.p2align 3
.L348:
	leaq	.LC11(%rip), %rax
	ret
	.p2align 4,,10
	.p2align 3
.L347:
	leaq	.LC12(%rip), %rax
	ret
	.p2align 4,,10
	.p2align 3
.L346:
	leaq	.LC13(%rip), %rax
	ret
.L341:
	leaq	.LC17(%rip), %rax
	ret
	.cfi_endproc
.LFE26:
	.size	vstorage_error, .-vstorage_error
	.p2align 4
	.globl	vstorage_allocate
	.type	vstorage_allocate, @function
vstorage_allocate:
.LFB27:
	.cfi_startproc
	endbr64
	testq	%rdi, %rdi
	je	.L368
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	cmpb	$0, 12(%rdi)
	jne	.L369
	movl	%esi, %ebp
	cmpl	$4095, %esi
	ja	.L369
	movl	8(%rdi), %r14d
	movl	%edx, %r12d
	cmpl	%r14d, %esi
	jb	.L388
.L358:
	movl	$3, %eax
	cmpb	$1, %r12b
	ja	.L356
	movabsq	$576460752303423487, %rax
	testb	%r12b, %r12b
	movabsq	$1152921504606846975, %rsi
	cmovne	%rax, %rsi
	cmpb	$1, %r12b
	movl	$5, %eax
	sbbq	%rdx, %rdx
	andq	$-8, %rdx
	addq	$16, %rdx
	cmpq	%rcx, %rsi
	jb	.L356
	imulq	%rcx, %rdx
	movq	16(%rbx), %rax
	subq	40(%rbx), %rax
	movq	%rdx, %r13
	cmpq	%rdx, %rax
	jb	.L365
	cmpl	%r14d, %ebp
	jb	.L361
	testl	%r14d, %r14d
	je	.L389
	.p2align 4,,10
	.p2align 3
.L364:
	addl	%r14d, %r14d
	cmpl	%r14d, %ebp
	jnb	.L364
.L363:
	movl	%r14d, %eax
	movq	(%rbx), %rdi
	leaq	(%rax,%rax,2), %r15
	salq	$3, %r15
	movq	%r15, %rsi
	call	realloc@PLT
	movq	%rax, %r8
	testq	%rax, %rax
	je	.L365
	movl	8(%rbx), %eax
	movq	%r8, 8(%rsp)
	leaq	(%rax,%rax,2), %rdi
	movq	%rax, %rdx
	movl	%r14d, %eax
	salq	$3, %rdi
	cmpq	%rdi, %r15
	movq	%rdi, %rcx
	cmovnb	%r15, %rcx
	subl	%edx, %eax
	xorl	%esi, %esi
	addq	$88, %r15
	leaq	(%rax,%rax,2), %rdx
	subq	%rdi, %rcx
	salq	$3, %rdx
	addq	%r8, %rdi
	call	__memset_chk@PLT
	movq	8(%rsp), %r8
	addq	$1, 72(%rbx)
	movl	%r14d, 8(%rbx)
	movq	%r8, (%rbx)
	movq	%r15, 80(%rbx)
.L361:
	xorl	%eax, %eax
	testq	%r13, %r13
	jne	.L390
.L366:
	movq	(%rbx), %rdx
	movl	%ebp, %ebp
	cmpq	$1, %r13
	leaq	0(%rbp,%rbp,2), %rcx
	leaq	(%rdx,%rcx,8), %rdx
	movq	%rax, (%rdx)
	movl	$257, %eax
	movq	%r13, 8(%rdx)
	movb	%r12b, 16(%rdx)
	movw	%ax, 17(%rdx)
	movq	40(%rbx), %rdx
	sbbq	$-1, 24(%rbx)
	addq	%r13, %rdx
	movq	%rdx, 40(%rbx)
	cmpq	%rdx, 48(%rbx)
	jnb	.L367
	movq	%rdx, 48(%rbx)
.L367:
	xorl	%eax, %eax
.L356:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L388:
	.cfi_restore_state
	movl	%esi, %eax
	movq	(%rdi), %rsi
	leaq	(%rax,%rax,2), %rdx
	movl	$2, %eax
	leaq	(%rsi,%rdx,8), %rdx
	cmpb	$0, 17(%rdx)
	je	.L358
	jmp	.L356
	.p2align 4,,10
	.p2align 3
.L369:
	addq	$24, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movl	$2, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L390:
	.cfi_restore_state
	movq	%r13, %rdi
	call	malloc@PLT
	testq	%rax, %rax
	jne	.L366
	.p2align 4,,10
	.p2align 3
.L365:
	movl	$1, %eax
	jmp	.L356
	.p2align 4,,10
	.p2align 3
.L368:
	.cfi_def_cfa_offset 8
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	.cfi_restore 14
	.cfi_restore 15
	movl	$2, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L389:
	.cfi_def_cfa_offset 80
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movl	$8, %r14d
	cmpl	$7, %ebp
	ja	.L364
	jmp	.L363
	.cfi_endproc
.LFE27:
	.size	vstorage_allocate, .-vstorage_allocate
	.p2align 4
	.globl	vstorage_prepare_dense
	.type	vstorage_prepare_dense, @function
vstorage_prepare_dense:
.LFB30:
	.cfi_startproc
	endbr64
	testq	%rdx, %rdx
	je	.L399
	testq	%rdi, %rdi
	je	.L403
	cmpb	$0, 12(%rdi)
	jne	.L403
	cmpl	8(%rdi), %esi
	jnb	.L403
	movl	%esi, %eax
	movq	%rdx, %rcx
	leaq	(%rax,%rax,2), %rdx
	movq	(%rdi), %rax
	leaq	(%rax,%rdx,8), %r10
	cmpb	$0, 18(%r10)
	je	.L403
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movzbl	88(%rsp), %ebp
	movq	64(%rsp), %rdi
	movq	80(%rsp), %r8
	cmpb	$1, %bpl
	movq	72(%rsp), %r9
	seta	%al
	cmpq	%rdi, %r8
	setb	%dl
	orl	%edx, %eax
	movq	%rdi, %rdx
	orq	%r9, %rdx
	cmpq	$2147483647, %rdx
	seta	%dl
	orb	%dl, %al
	jne	.L404
	leaq	-1(%r8), %rax
	cmpq	$2147483646, %rax
	jbe	.L433
.L404:
	movl	$4, %eax
.L391:
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L403:
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	.cfi_restore 14
	.cfi_restore 15
	movl	$2, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L433:
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movq	56(%rsp), %rbx
	movq	8(%r10), %r15
	movl	$4, %eax
	cmpq	%rbx, %r15
	jb	.L391
	movzbl	16(%r10), %r13d
	movl	%ebp, %edx
	movabsq	$9223372036854775799, %r14
	movabsq	$576460752303423487, %r11
	movzbl	%r13b, %r12d
	testb	%r13b, %r13b
	movl	%r12d, %eax
	movb	%dl, %ah
	movl	%eax, %r12d
	movabsq	$9223372036854775791, %rax
	cmove	%r14, %rax
	movq	%r11, %r14
	movq	%rdi, %r11
	movq	%rax, -32(%rsp)
	movabsq	$1152921504606846975, %rax
	cmove	%rax, %r14
	cmpb	$1, %r13b
	movl	$5, %eax
	sbbq	%r13, %r13
	imulq	%r9, %r11
	andq	$-8, %r13
	addq	$16, %r13
	cmpq	%r11, %r14
	jb	.L391
	imulq	%r13, %r11
	testq	%rdi, %rdi
	je	.L408
	testq	%r9, %r9
	jne	.L434
.L408:
	movq	%rbx, %r13
.L394:
	testb	%bpl, %bpl
	je	.L397
	movq	%rdi, %rax
	movq	%r9, %rdi
	movq	%rax, %r9
.L397:
	xorl	%eax, %eax
	testq	%r11, %r11
	je	.L398
	movq	%rbx, %rax
	andq	$-8, %rax
	addq	(%r10), %rax
.L398:
	movq	%rax, (%rcx)
	xorl	%eax, %eax
	movq	%rbx, 8(%rcx)
	movq	%r13, 16(%rcx)
	movq	%rdi, 24(%rcx)
	movq	%r9, 32(%rcx)
	movq	%r8, 40(%rcx)
	movq	%r11, 48(%rcx)
	movl	%esi, 56(%rcx)
	movw	%r12w, 60(%rcx)
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L399:
	.cfi_restore 3
	.cfi_restore 6
	.cfi_restore 12
	.cfi_restore 13
	.cfi_restore 14
	.cfi_restore 15
	movl	$11, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L434:
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	.cfi_offset 6, -48
	.cfi_offset 12, -40
	.cfi_offset 13, -32
	.cfi_offset 14, -24
	.cfi_offset 15, -16
	movq	%r8, %r14
	leaq	-1(%r9), %rdx
	movabsq	$9223372036854775807, %rax
	imulq	%r13, %r14
	movq	%rdx, -24(%rsp)
	xorl	%edx, %edx
	divq	%r14
	movq	-24(%rsp), %rdx
	movq	%r14, -16(%rsp)
	movq	%rax, %r14
	movl	$5, %eax
	cmpq	%rdx, %r14
	jb	.L391
	leaq	-1(%rdi), %rdx
	imulq	%r13, %rdx
	movq	%rdx, %r14
	movabsq	$9223372036854775807, %rdx
	subq	%r14, %rdx
	movq	%r14, -8(%rsp)
	cmpq	%rbx, %rdx
	jb	.L391
	movq	-24(%rsp), %rdx
	movq	-16(%rsp), %r14
	imulq	%rdx, %r14
	movq	%r14, %rdx
	testq	%r14, %r14
	js	.L391
	movq	-8(%rsp), %r14
	movq	%rdx, -16(%rsp)
	addq	%rbx, %r14
	movq	%r14, -24(%rsp)
	movabsq	$9223372036854775807, %r14
	subq	%rdx, %r14
	movq	%r14, %rdx
	movq	-24(%rsp), %r14
	cmpq	%r14, %rdx
	jb	.L391
	movq	-16(%rsp), %rdx
	addq	%r14, %rdx
	cmpq	%rdx, -32(%rsp)
	jb	.L391
	addq	%rdx, %r13
	movl	$4, %eax
	cmpq	%r13, %r15
	jb	.L391
	movq	(%r10), %rdx
	testq	%rdx, %rdx
	je	.L391
	movq	%rdx, %r15
	addq	%r13, %r15
	jc	.L391
	addq	%rbx, %rdx
	andl	$7, %edx
	je	.L394
	jmp	.L391
	.cfi_endproc
.LFE30:
	.size	vstorage_prepare_dense, .-vstorage_prepare_dense
	.p2align 4
	.globl	vstorage_prepare_write
	.type	vstorage_prepare_write, @function
vstorage_prepare_write:
.LFB31:
	.cfi_startproc
	endbr64
	movl	$2, %eax
	testq	%rdi, %rdi
	je	.L435
	cmpb	$0, 12(%rdi)
	jne	.L435
	addq	56(%rdi), %rsi
	jc	.L438
	xorl	%eax, %eax
	ret
	.p2align 4,,10
	.p2align 3
.L435:
	ret
.L438:
	movl	$5, %eax
	ret
	.cfi_endproc
.LFE31:
	.size	vstorage_prepare_write, .-vstorage_prepare_write
	.p2align 4
	.globl	vstorage_record_write
	.type	vstorage_record_write, @function
vstorage_record_write:
.LFB32:
	.cfi_startproc
	endbr64
	addq	%rsi, 56(%rdi)
	ret
	.cfi_endproc
.LFE32:
	.size	vstorage_record_write, .-vstorage_record_write
	.p2align 4
	.globl	vstorage_fill
	.type	vstorage_fill, @function
vstorage_fill:
.LFB35:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	movl	%edx, %r13d
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	subq	$104, %rsp
	.cfi_def_cfa_offset 160
	movq	%rcx, (%rsp)
	movq	160(%rsp), %r12
	movq	%r8, 8(%rsp)
	movq	168(%rsp), %rbp
	movq	176(%rsp), %r14
	movq	184(%rsp), %r15
	movq	%r12, %rdx
	movq	%rbp, %rcx
	movq	%fs:40, %rax
	movq	%rax, 88(%rsp)
	xorl	%eax, %eax
	leaq	16(%rsp), %rax
	movq	%r15, %r9
	movq	%r14, %r8
	pushq	%rax
	.cfi_def_cfa_offset 168
	movzbl	200(%rsp), %eax
	pushq	%rax
	.cfi_def_cfa_offset 176
	call	prepare.isra.0
	popq	%rdx
	.cfi_def_cfa_offset 168
	popq	%rcx
	.cfi_def_cfa_offset 160
	testl	%eax, %eax
	jne	.L443
	movq	16(%rsp), %rdx
	cmpb	16(%rdx), %r13b
	je	.L446
	movl	$3, %eax
.L443:
	movq	88(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L499
	addq	$104, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L446:
	.cfi_restore_state
	movq	80(%rsp), %rcx
	xorl	%esi, %esi
	movq	%rcx, %r9
	addq	56(%rbx), %r9
	setc	%sil
	jc	.L460
	testq	%rcx, %rcx
	je	.L443
	movq	72(%rsp), %r10
	movsd	(%rsp), %xmm0
	shrq	$3, %r12
	movq	(%rdx), %rcx
	imulq	%r10, %r15
	cmpq	$1, %r10
	je	.L450
	testq	%r14, %r14
	je	.L451
	movsd	8(%rsp), %xmm1
	testq	%rbp, %rbp
	je	.L451
	leaq	(%rcx,%r12,8), %r10
	salq	$4, %rbp
	salq	$3, %r15
	unpcklpd	%xmm1, %xmm0
	leaq	0(%rbp,%r10), %rcx
	.p2align 4,,10
	.p2align 3
.L452:
	movq	%rcx, %rdi
	movq	%r10, %rdx
	subq	%r10, %rdi
	andl	$16, %edi
	je	.L458
	leaq	16(%r10), %rdx
	movups	%xmm0, (%r10)
	cmpq	%rcx, %rdx
	je	.L494
	.p2align 4,,10
	.p2align 3
.L458:
	movups	%xmm0, (%rdx)
	addq	$32, %rdx
	movups	%xmm0, -16(%rdx)
	cmpq	%rcx, %rdx
	jne	.L458
.L494:
	addq	$1, %rsi
	addq	%r15, %r10
	addq	%r15, %rcx
	cmpq	%rsi, %r14
	jne	.L452
.L451:
	movq	%r9, 56(%rbx)
	jmp	.L443
.L460:
	movl	$5, %eax
	jmp	.L443
.L450:
	testq	%r14, %r14
	je	.L451
	testq	%rbp, %rbp
	je	.L451
	movq	%rbp, %r11
	movl	%eax, (%rsp)
	movq	%rbp, %rdi
	movapd	%xmm0, %xmm1
	shrq	%r11
	movq	%rbp, %r8
	leaq	(%rcx,%r12,8), %rsi
	andq	$-2, %rdi
	salq	$4, %r11
	xorl	%r10d, %r10d
	unpcklpd	%xmm1, %xmm1
	andl	$1, %r8d
	leaq	0(,%r15,8), %r13
	.p2align 4,,10
	.p2align 3
.L453:
	cmpq	$1, %rbp
	je	.L500
	leaq	(%rsi,%r11), %rdx
	movq	%rsi, %rax
	testb	$16, %r11b
	je	.L454
	leaq	16(%rsi), %rax
	movups	%xmm1, (%rsi)
	cmpq	%rax, %rdx
	je	.L493
	.p2align 4,,10
	.p2align 3
.L454:
	movups	%xmm1, (%rax)
	addq	$32, %rax
	movups	%xmm1, -16(%rax)
	cmpq	%rax, %rdx
	jne	.L454
.L493:
	movq	%rdi, %rax
	testq	%r8, %r8
	je	.L455
.L456:
	addq	%r12, %rax
	movsd	%xmm0, (%rcx,%rax,8)
.L455:
	addq	$1, %r10
	addq	%r15, %r12
	addq	%r13, %rsi
	cmpq	%r10, %r14
	jne	.L453
	movl	(%rsp), %eax
	jmp	.L451
.L500:
	xorl	%eax, %eax
	jmp	.L456
.L499:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE35:
	.size	vstorage_fill, .-vstorage_fill
	.p2align 4
	.globl	vstorage_store
	.type	vstorage_store, @function
vstorage_store:
.LFB36:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	movl	%esi, %eax
	movq	%rdx, %rsi
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	56(%rsp), %rbx
	movq	64(%rsp), %r10
	movq	72(%rsp), %r11
	movq	80(%rsp), %rdx
	movzbl	88(%rsp), %r12d
	testq	%rdi, %rdi
	je	.L517
	cmpb	$0, 12(%rdi)
	jne	.L517
	cmpl	8(%rdi), %eax
	jnb	.L517
	leaq	(%rax,%rax,2), %rbp
	movq	(%rdi), %rax
	leaq	(%rax,%rbp,8), %rbp
	cmpb	$0, 18(%rbp)
	je	.L517
	cmpb	$1, %r12b
	seta	%al
	cmpq	%r10, %rdx
	setb	%r13b
	orl	%r13d, %eax
	movq	%r10, %r13
	orq	%r11, %r13
	cmpq	$2147483647, %r13
	seta	%r13b
	orb	%r13b, %al
	jne	.L518
	leaq	-1(%rdx), %rax
	cmpq	$2147483646, %rax
	jbe	.L544
.L518:
	movl	$4, %eax
.L501:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L517:
	.cfi_restore_state
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	movl	$2, %eax
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L544:
	.cfi_restore_state
	movq	8(%rbp), %r15
	movl	$4, %eax
	movq	%r15, -32(%rsp)
	cmpq	%rbx, %r15
	jb	.L501
	movabsq	$9223372036854775799, %r14
	movzbl	16(%rbp), %r13d
	movabsq	$9223372036854775791, %rax
	testb	%r13b, %r13b
	cmove	%r14, %rax
	movabsq	$1152921504606846975, %r14
	movq	%rax, -24(%rsp)
	movabsq	$576460752303423487, %rax
	cmove	%r14, %rax
	cmpb	$1, %r13b
	movq	%r10, %r14
	sbbq	%r15, %r15
	addq	$2, %r15
	cmpb	$1, %r13b
	movq	%rax, -40(%rsp)
	movl	$5, %eax
	movq	%r15, -48(%rsp)
	sbbq	%r15, %r15
	imulq	%r11, %r14
	andq	$-8, %r15
	addq	$16, %r15
	cmpq	%r14, -40(%rsp)
	jb	.L501
	imulq	%r15, %rdx
	movq	%rdx, -40(%rsp)
	movq	%rdx, %r14
	testq	%r10, %r10
	je	.L504
	testq	%r11, %r11
	jne	.L545
.L504:
	movq	-40(%rsp), %rdx
	movq	-48(%rsp), %r14
	shrq	$3, %rdx
	testb	%r12b, %r12b
	jne	.L507
	movq	%r11, %rax
	movq	%rdx, %r14
	movq	-48(%rsp), %rdx
	movq	%r10, %r11
	movq	%rax, %r10
.L507:
	movl	$3, %eax
	cmpb	%r13b, %r8b
	jne	.L501
	movl	$6, %eax
	cmpq	%r11, %rsi
	jnb	.L501
	cmpq	%r10, %rcx
	jnb	.L501
	movq	%r15, %rax
	addq	56(%rdi), %rax
	jc	.L512
	imulq	%rdx, %rsi
	shrq	$3, %rbx
	movq	0(%rbp), %r8
	imulq	%r14, %rcx
	addq	%rsi, %rcx
	addq	%rcx, %rbx
	cmpq	$2, -48(%rsp)
	movq	%r9, (%r8,%rbx,8)
	leaq	0(,%rbx,8), %rdx
	je	.L546
.L513:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	movq	%rax, 56(%rdi)
	xorl	%eax, %eax
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L546:
	.cfi_restore_state
	movq	96(%rsp), %rcx
	movq	%rcx, 8(%r8,%rdx)
	jmp	.L513
	.p2align 4,,10
	.p2align 3
.L545:
	movabsq	$9223372036854775807, %rax
	leaq	-1(%r11), %rdx
	movq	%rdx, -16(%rsp)
	xorl	%edx, %edx
	divq	%r14
	movq	-16(%rsp), %rdx
	movq	%rax, -8(%rsp)
	movl	$5, %eax
	cmpq	%rdx, -8(%rsp)
	jb	.L501
	movabsq	$9223372036854775807, %r14
	leaq	-1(%r10), %rdx
	imulq	%r15, %rdx
	subq	%rdx, %r14
	movq	%rdx, -8(%rsp)
	cmpq	%rbx, %r14
	jb	.L501
	movq	-16(%rsp), %rdx
	movq	-40(%rsp), %r14
	imulq	%r14, %rdx
	movq	%rdx, -16(%rsp)
	testq	%rdx, %rdx
	js	.L501
	movabsq	$9223372036854775807, %r14
	movq	-8(%rsp), %rdx
	addq	%rbx, %rdx
	movq	%rdx, -8(%rsp)
	movq	-16(%rsp), %rdx
	subq	%rdx, %r14
	movq	-8(%rsp), %rdx
	cmpq	%rdx, %r14
	jb	.L501
	movq	-16(%rsp), %r14
	addq	%rdx, %r14
	movq	%r14, %rdx
	cmpq	%r14, -24(%rsp)
	jb	.L501
	addq	%r15, %rdx
	movl	$4, %eax
	cmpq	%rdx, -32(%rsp)
	jb	.L501
	movq	0(%rbp), %r14
	testq	%r14, %r14
	je	.L501
	addq	%r14, %rdx
	jc	.L501
	movq	%r14, %rdx
	addq	%rbx, %rdx
	andl	$7, %edx
	je	.L504
	jmp	.L501
.L512:
	movl	$5, %eax
	jmp	.L501
	.cfi_endproc
.LFE36:
	.size	vstorage_store, .-vstorage_store
	.p2align 4
	.globl	vstorage_expect
	.type	vstorage_expect, @function
vstorage_expect:
.LFB37:
	.cfi_startproc
	endbr64
	movq	%rdi, %rax
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movl	%esi, %ebx
	movq	56(%rsp), %r11
	movq	%rdx, %rsi
	movq	64(%rsp), %rdi
	movq	72(%rsp), %r10
	movq	80(%rsp), %rdx
	movzbl	88(%rsp), %ebp
	testq	%rax, %rax
	je	.L560
	cmpb	$0, 12(%rax)
	jne	.L560
	cmpl	8(%rax), %ebx
	jnb	.L560
	movq	(%rax), %rax
	leaq	(%rbx,%rbx,2), %rbx
	leaq	(%rax,%rbx,8), %rbx
	cmpb	$0, 18(%rbx)
	je	.L560
	cmpb	$1, %bpl
	seta	%al
	cmpq	%rdi, %rdx
	setb	%r12b
	orl	%r12d, %eax
	movq	%rdi, %r12
	orq	%r10, %r12
	cmpq	$2147483647, %r12
	seta	%r12b
	orb	%r12b, %al
	jne	.L561
	leaq	-1(%rdx), %rax
	cmpq	$2147483646, %rax
	jbe	.L587
.L561:
	movl	$4, %eax
.L547:
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L560:
	.cfi_restore_state
	popq	%rbx
	.cfi_remember_state
	.cfi_def_cfa_offset 48
	movl	$2, %eax
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L587:
	.cfi_restore_state
	movq	8(%rbx), %r15
	movl	$4, %eax
	movq	%r15, -32(%rsp)
	cmpq	%r11, %r15
	jb	.L547
	movabsq	$9223372036854775799, %r13
	movzbl	16(%rbx), %r12d
	movabsq	$9223372036854775791, %rax
	movabsq	$1152921504606846975, %r14
	testb	%r12b, %r12b
	cmove	%r13, %rax
	movq	%rax, -24(%rsp)
	movabsq	$576460752303423487, %rax
	cmove	%r14, %rax
	cmpb	$1, %r12b
	movq	%rdi, %r14
	sbbq	%r15, %r15
	addq	$2, %r15
	cmpb	$1, %r12b
	movq	%rax, %r13
	sbbq	%rax, %rax
	imulq	%r10, %r14
	andq	$-8, %rax
	addq	$16, %rax
	movq	%rax, -40(%rsp)
	movl	$5, %eax
	cmpq	%r14, %r13
	jb	.L547
	movq	-40(%rsp), %r13
	imulq	%r13, %rdx
	movq	%rdx, %r14
	testq	%rdi, %rdi
	je	.L550
	testq	%r10, %r10
	jne	.L588
.L550:
	shrq	$3, %r14
	movq	%r14, %r13
	movq	%r15, %r14
	testb	%bpl, %bpl
	jne	.L553
	movq	%r10, %rax
	movq	%r13, %r14
	movq	%rdi, %r10
	movq	%r15, %r13
	movq	%rax, %rdi
.L553:
	movl	$3, %eax
	cmpb	%r12b, %r8b
	jne	.L547
	movl	$6, %eax
	cmpq	%r10, %rsi
	jnb	.L547
	cmpq	%rdi, %rcx
	jnb	.L547
	imulq	%r14, %rcx
	shrq	$3, %r11
	movq	(%rbx), %rdx
	movl	$8, %eax
	imulq	%r13, %rsi
	addq	%rsi, %rcx
	addq	%rcx, %r11
	leaq	0(,%r11,8), %rcx
	cmpq	%r9, (%rdx,%r11,8)
	jne	.L547
	xorl	%eax, %eax
	cmpq	$2, %r15
	jne	.L547
	movq	96(%rsp), %rax
	cmpq	%rax, 8(%rdx,%rcx)
	setne	%al
	movzbl	%al, %eax
	sall	$3, %eax
	jmp	.L547
	.p2align 4,,10
	.p2align 3
.L588:
	movabsq	$9223372036854775807, %rax
	leaq	-1(%r10), %rdx
	movq	%rdx, -16(%rsp)
	xorl	%edx, %edx
	divq	%r14
	movq	-16(%rsp), %rdx
	movq	%rax, -40(%rsp)
	movl	$5, %eax
	cmpq	%rdx, -40(%rsp)
	jb	.L547
	leaq	-1(%rdi), %rdx
	movq	%r13, -40(%rsp)
	imulq	%r13, %rdx
	movabsq	$9223372036854775807, %r13
	subq	%rdx, %r13
	movq	%rdx, -8(%rsp)
	cmpq	%r11, %r13
	jb	.L547
	movq	-16(%rsp), %rdx
	imulq	%r14, %rdx
	testq	%rdx, %rdx
	js	.L547
	movq	-8(%rsp), %r13
	addq	%r11, %r13
	movq	%r13, -16(%rsp)
	movabsq	$9223372036854775807, %r13
	subq	%rdx, %r13
	movq	%r13, -8(%rsp)
	movq	-16(%rsp), %r13
	cmpq	%r13, -8(%rsp)
	jb	.L547
	addq	%r13, %rdx
	cmpq	%rdx, -24(%rsp)
	jb	.L547
	movq	-40(%rsp), %r13
	movl	$4, %eax
	addq	%r13, %rdx
	cmpq	%rdx, -32(%rsp)
	jb	.L547
	movq	(%rbx), %r13
	testq	%r13, %r13
	je	.L547
	addq	%r13, %rdx
	jc	.L547
	addq	%r11, %r13
	andl	$7, %r13d
	je	.L550
	jmp	.L547
	.cfi_endproc
.LFE37:
	.size	vstorage_expect, .-vstorage_expect
	.p2align 4
	.globl	bench_open
	.type	bench_open, @function
bench_open:
.LFB58:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	xorl	%eax, %eax
	movl	$17, %ecx
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	subq	$8, %rsp
	.cfi_def_cfa_offset 64
	rep stosq
	movzbl	80(%rsp), %r12d
	movzbl	85(%rsp), %r14d
	movzbl	83(%rsp), %r10d
	movq	64(%rsp), %rsi
	movl	%r14d, %edx
	movzbl	%r12b, %eax
	movb	%dl, %ah
	movq	72(%rsp), %rdx
	movw	%ax, 128(%rbx)
	movzbl	81(%rsp), %eax
	testb	%r10b, %r10b
	je	.L618
	movq	%rdx, %rdi
	movq	%rsi, %r9
.L590:
	testq	%rdi, %rdi
	movl	$1, %ecx
	cmovne	%rdi, %rcx
	testb	%al, %al
	je	.L591
	addq	$3, %rcx
	movq	%r9, %rbp
	movl	$2, %r8d
	imulq	%rcx, %rbp
	addq	$5, %rbp
.L593:
	cmpb	$1, %r12b
	movq	%rdi, 16(%rbx)
	movzbl	84(%rsp), %edi
	sbbq	%rax, %rax
	movq	%r9, 24(%rbx)
	andq	$-8, %rax
	movq	%rcx, 32(%rbx)
	addq	$16, %rax
	movb	%r10b, 40(%rbx)
	imulq	%rax, %r8
	movq	%r8, 8(%rbx)
	movzbl	82(%rsp), %r8d
	testb	%dil, %dil
	jne	.L595
	movq	%rsi, %rcx
	movq	%rdx, %rsi
	movq	%rcx, %rdx
.L595:
	testq	%rdx, %rdx
	movl	$1, %ecx
	cmovne	%rdx, %rcx
	testb	%r8b, %r8b
	je	.L596
	addq	$5, %rcx
	leaq	(%rax,%rax,2), %r8
	movq	%rcx, %r13
	imulq	%rsi, %r13
	addq	$6, %r13
.L598:
	movq	%r8, 48(%rbx)
	movq	%rdx, 56(%rbx)
	movq	%rsi, 64(%rbx)
	movq	%rcx, 72(%rbx)
	testb	%r14b, %r14b
	jne	.L599
	movb	%dil, 80(%rbx)
	leaq	0(%r13,%rbp), %rdx
.L600:
	imulq	%rdx, %rax
	movq	%rax, %r15
	testq	%rax, %rax
	js	.L602
	movl	$1, %edi
	movl	$88, %esi
	call	calloc@PLT
	movq	%rax, %rdi
	testq	%rax, %rax
	je	.L602
	movdqa	.LC4(%rip), %xmm0
	movq	%rax, (%rbx)
	xorl	%esi, %esi
	movq	%rbp, %rcx
	movq	%r15, 16(%rax)
	movzbl	%r12b, %r15d
	movups	%xmm0, 72(%rax)
	movl	%r15d, %edx
	call	vstorage_allocate
	testl	%eax, %eax
	jne	.L608
	testb	%r14b, %r14b
	je	.L660
	xorl	%esi, %esi
	leaq	88(%rbx), %r8
	movl	$1, %ecx
	movq	%rbp, %rdx
	movq	%rbx, %rdi
	call	initialize
	testl	%eax, %eax
	je	.L608
	leaq	(%rbp,%rbp), %rax
	testb	%r12b, %r12b
	cmovne	%rax, %rbp
	movq	88(%rbx), %rax
	movq	%rbp, %xmm0
	movq	%rax, 96(%rbx)
	punpcklqdq	%xmm0, %xmm0
	movups	%xmm0, 104(%rbx)
.L615:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movl	$1, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L591:
	.cfi_restore_state
	testq	%rdi, %rdi
	je	.L619
	testq	%r9, %r9
	je	.L619
	movq	%r9, %rbp
	xorl	%r8d, %r8d
	imulq	%rcx, %rbp
	jmp	.L593
	.p2align 4,,10
	.p2align 3
.L618:
	movq	%rsi, %rdi
	movq	%rdx, %r9
	jmp	.L590
	.p2align 4,,10
	.p2align 3
.L596:
	testq	%rdx, %rdx
	je	.L621
	testq	%rsi, %rsi
	je	.L621
	movq	%rsi, %r13
	xorl	%r8d, %r8d
	imulq	%rcx, %r13
	jmp	.L598
	.p2align 4,,10
	.p2align 3
.L660:
	movq	(%rbx), %rdi
	movq	%r13, %rcx
	movl	%r15d, %edx
	movl	$1, %esi
	call	vstorage_allocate
	testl	%eax, %eax
	jne	.L608
	xorl	%esi, %esi
	leaq	88(%rbx), %r8
	movl	$1, %ecx
	movq	%rbp, %rdx
	movq	%rbx, %rdi
	call	initialize
	testl	%eax, %eax
	je	.L608
	xorl	%ecx, %ecx
	leaq	96(%rbx), %r8
	movq	%r13, %rdx
	movl	$1, %esi
	movq	%rbx, %rdi
	call	initialize
	testl	%eax, %eax
	je	.L608
	testb	%r12b, %r12b
	je	.L613
	addq	%rbp, %rbp
	addq	%r13, %r13
.L613:
	movq	%rbp, 104(%rbx)
	movq	%r13, 112(%rbx)
	jmp	.L615
	.p2align 4,,10
	.p2align 3
.L619:
	xorl	%r8d, %r8d
	xorl	%ebp, %ebp
	jmp	.L593
	.p2align 4,,10
	.p2align 3
.L621:
	xorl	%r8d, %r8d
	xorl	%r13d, %r13d
	jmp	.L598
	.p2align 4,,10
	.p2align 3
.L608:
	movq	(%rbx), %rbp
	testq	%rbp, %rbp
	je	.L605
	cmpb	$0, 12(%rbp)
	jne	.L611
	movq	%rbp, %rdi
	call	vstorage_close.part.0
.L611:
	movq	0(%rbp), %rdi
	call	free@PLT
	movq	%rbp, %rdi
	call	free@PLT
.L605:
	movq	$0, (%rbx)
.L602:
	addq	$8, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	xorl	%eax, %eax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L599:
	.cfi_restore_state
	movq	40(%rbx), %rdx
	movdqu	8(%rbx), %xmm1
	xorl	%r13d, %r13d
	movdqu	24(%rbx), %xmm2
	movq	%rdx, 80(%rbx)
	movq	%rbp, %rdx
	movups	%xmm1, 48(%rbx)
	movups	%xmm2, 64(%rbx)
	jmp	.L600
	.cfi_endproc
.LFE58:
	.size	bench_open, .-bench_open
	.section	.rodata.str1.8
	.align 8
.LC18:
	.string	"/workspace/scratch/6f482abd7151/storage-copy-post280/source/experiments/storage_copy/probe.c"
	.align 8
.LC19:
	.string	"!stats.live_bytes && stats.data_allocations == stats.data_frees"
	.text
	.p2align 4
	.globl	bench_close
	.type	bench_close, @function
bench_close:
.LFB59:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	movq	%rdi, %rbp
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rsi, %rbx
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	movq	(%rsi), %r12
	testq	%r12, %r12
	je	.L665
	cmpb	$0, 12(%r12)
	jne	.L664
	movq	%r12, %rdi
	call	vstorage_close.part.0
	movq	(%rbx), %r12
	testq	%r12, %r12
	je	.L665
.L664:
	movq	48(%r12), %rax
	movdqu	24(%r12), %xmm0
	cmpq	$0, 40(%r12)
	movq	64(%r12), %r13
	movq	%rax, (%rsp)
	movq	56(%r12), %rax
	movhlps	%xmm0, %xmm1
	movq	%xmm0, %rcx
	movq	72(%r12), %r14
	movq	80(%r12), %r15
	movq	%xmm1, %rsi
	movq	%rax, 8(%rsp)
	jne	.L666
	cmpq	%rcx, %rsi
	jne	.L666
	cmpb	$0, 12(%r12)
	jne	.L668
	movq	%r12, %rdi
	movaps	%xmm0, 16(%rsp)
	call	vstorage_close.part.0
	movdqa	16(%rsp), %xmm0
.L668:
	movq	(%r12), %rdi
	movaps	%xmm0, 16(%rsp)
	call	free@PLT
	movq	%r12, %rdi
	call	free@PLT
	movdqa	16(%rsp), %xmm0
.L663:
	movq	(%rsp), %rax
	movq	$0, (%rbx)
	movq	$0, 16(%rbp)
	movq	%rax, 24(%rbp)
	movq	8(%rsp), %rax
	movq	%r13, 40(%rbp)
	movq	%rax, 32(%rbp)
	movq	%rbp, %rax
	movq	%r14, 48(%rbp)
	movq	%r15, 56(%rbp)
	movups	%xmm0, 0(%rbp)
	addq	$40, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L665:
	.cfi_restore_state
	pxor	%xmm0, %xmm0
	xorl	%r13d, %r13d
	xorl	%r14d, %r14d
	xorl	%r15d, %r15d
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	jmp	.L663
.L666:
	leaq	__PRETTY_FUNCTION__.1(%rip), %rcx
	movl	$114, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC19(%rip), %rdi
	call	__assert_fail@PLT
	.cfi_endproc
.LFE59:
	.size	bench_close, .-bench_close
	.p2align 4
	.globl	bench_verify
	.type	bench_verify, @function
bench_verify:
.LFB60:
	.cfi_startproc
	endbr64
	pushq	%r13
	.cfi_def_cfa_offset 16
	.cfi_offset 13, -16
	movq	%rdi, %r8
	pushq	%r12
	.cfi_def_cfa_offset 24
	.cfi_offset 12, -24
	pushq	%rbp
	.cfi_def_cfa_offset 32
	.cfi_offset 6, -32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset 3, -40
	subq	$72, %rsp
	.cfi_def_cfa_offset 112
	movq	104(%rdi), %r9
	movq	%fs:40, %rax
	movq	%rax, 56(%rsp)
	xorl	%eax, %eax
	testq	%r9, %r9
	je	.L677
	movq	88(%rdi), %r11
	movdqa	.LC1(%rip), %xmm2
	xorl	%esi, %esi
	xorl	%ecx, %ecx
	movdqa	.LC2(%rip), %xmm1
	movdqa	.LC3(%rip), %xmm0
	movabsq	$5895351198814392785, %r10
	movabsq	$4503599627370495, %r12
	movabsq	$4607182418800017408, %rbp
	movabsq	$-7046029254386353131, %rbx
	jmp	.L681
	.p2align 4,,10
	.p2align 3
.L706:
	movq	(%rsp,%rdx,8), %rax
	cmpq	%rdi, %rax
	jne	.L680
.L707:
	addq	$1, %rcx
	addq	%rbx, %rsi
	cmpq	%rcx, %r9
	je	.L677
.L681:
	movq	%rcx, %rax
	movq	(%r11,%rcx,8), %rdi
	movaps	%xmm2, (%rsp)
	mulq	%r10
	movq	%rcx, %rax
	movaps	%xmm1, 16(%rsp)
	movaps	%xmm0, 32(%rsp)
	subq	%rdx, %rax
	shrq	%rax
	addq	%rax, %rdx
	shrq	$6, %rdx
	leaq	(%rdx,%rdx,2), %rax
	salq	$5, %rax
	addq	%rdx, %rax
	movq	%rcx, %rdx
	subq	%rax, %rdx
	cmpq	$5, %rdx
	jbe	.L706
	movq	%rsi, %rax
	andq	%r12, %rax
	orq	%rbp, %rax
	cmpq	%rdi, %rax
	je	.L707
.L680:
	xorl	%eax, %eax
.L676:
	movq	56(%rsp), %rdx
	subq	%fs:40, %rdx
	jne	.L708
	addq	$72, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%rbp
	.cfi_def_cfa_offset 24
	popq	%r12
	.cfi_def_cfa_offset 16
	popq	%r13
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L677:
	.cfi_restore_state
	cmpb	$0, 129(%r8)
	jne	.L685
	cmpb	$1, 128(%r8)
	movq	112(%r8), %r11
	sbbq	%r9, %r9
	addq	$2, %r9
	testq	%r11, %r11
	je	.L685
	movq	48(%r8), %r10
	movq	96(%r8), %rbp
	xorl	%ecx, %ecx
	movabsq	$9221120240777019119, %rbx
	movdqa	.LC1(%rip), %xmm2
	movdqa	.LC2(%rip), %xmm1
	movabsq	$5895351198814392785, %r12
	movq	%r10, %rsi
	movdqa	.LC3(%rip), %xmm0
	negq	%rsi
	.p2align 4,,10
	.p2align 3
.L691:
	leaq	0(,%rcx,8), %rax
	movq	%rbx, %rdi
	cmpq	%r10, %rax
	jb	.L686
	movq	%rsi, %rax
	xorl	%edx, %edx
	shrq	$3, %rax
	divq	%r9
	movq	%rdx, %r13
	xorl	%edx, %edx
	divq	72(%r8)
	cmpq	56(%r8), %rdx
	jnb	.L686
	cmpq	64(%r8), %rax
	jnb	.L686
	cmpb	$0, 80(%r8)
	movq	%rdx, %rdi
	cmove	%rax, %rdi
	cmovne	%rax, %rdx
	cmpb	$0, 40(%r8)
	je	.L709
.L688:
	imulq	32(%r8), %rdx
	movq	8(%r8), %rax
	movaps	%xmm2, (%rsp)
	movaps	%xmm1, 16(%rsp)
	shrq	$3, %rax
	movaps	%xmm0, 32(%rsp)
	addq	%rdx, %rdi
	addq	%r13, %rax
	imulq	%r9, %rdi
	addq	%rax, %rdi
	movq	%rdi, %rax
	mulq	%r12
	movq	%rdi, %rax
	subq	%rdx, %rax
	shrq	%rax
	addq	%rax, %rdx
	shrq	$6, %rdx
	leaq	(%rdx,%rdx,2), %rax
	salq	$5, %rax
	addq	%rdx, %rax
	movq	%rdi, %rdx
	subq	%rax, %rdx
	cmpq	$5, %rdx
	ja	.L689
	movq	(%rsp,%rdx,8), %rdi
	.p2align 4,,10
	.p2align 3
.L686:
	cmpq	0(%rbp,%rcx,8), %rdi
	jne	.L680
	addq	$1, %rcx
	addq	$8, %rsi
	cmpq	%rcx, %r11
	jne	.L691
.L685:
	movl	$1, %eax
	jmp	.L676
	.p2align 4,,10
	.p2align 3
.L689:
	movabsq	$-7046029254386353131, %rax
	imulq	%rax, %rdi
	movabsq	$4503599627370495, %rax
	andq	%rdi, %rax
	movabsq	$4607182418800017408, %rdi
	orq	%rax, %rdi
	jmp	.L686
	.p2align 4,,10
	.p2align 3
.L709:
	movq	%rdx, %rax
	movq	%rdi, %rdx
	movq	%rax, %rdi
	jmp	.L688
.L708:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE60:
	.size	bench_verify, .-bench_verify
	.p2align 4
	.globl	bench_observe
	.type	bench_observe, @function
bench_observe:
.LFB61:
	.cfi_startproc
	endbr64
	movq	112(%rdi), %rax
	testq	%rax, %rax
	je	.L710
	movq	96(%rdi), %rdx
	movq	%rax, %rcx
	shrq	%rcx
	movq	-8(%rdx,%rax,8), %rax
	xorq	(%rdx,%rcx,8), %rax
	xorq	(%rdx), %rax
.L710:
	ret
	.cfi_endproc
.LFE61:
	.size	bench_observe, .-bench_observe
	.p2align 4
	.globl	bench_prepare
	.type	bench_prepare, @function
bench_prepare:
.LFB62:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	movq	%rdi, %rbx
	subq	$248, %rsp
	.cfi_def_cfa_offset 304
	movq	(%rdi), %rbp
	movq	16(%rdi), %r12
	movq	%fs:40, %rax
	movq	%rax, 232(%rsp)
	xorl	%eax, %eax
	movq	8(%rdi), %rax
	movzbl	129(%rdi), %r15d
	movq	24(%rdi), %r13
	movzbl	40(%rdi), %ecx
	movq	48(%rdi), %rsi
	movq	64(%rbx), %r8
	movq	%rax, 8(%rsp)
	movq	72(%rbx), %r9
	movq	32(%rdi), %rax
	movzbl	80(%rbx), %r10d
	movq	56(%rdi), %rdi
	testq	%rbp, %rbp
	je	.L729
	cmpb	$0, 12(%rbp)
	jne	.L729
	movl	8(%rbp), %r11d
	testl	%r11d, %r11d
	je	.L729
	cmpq	%r12, %rax
	movq	0(%rbp), %r14
	setb	%dl
	cmpb	$1, %cl
	seta	%r11b
	movq	%r14, 16(%rsp)
	orl	%r11d, %edx
	movq	%r12, %r11
	orq	%r13, %r11
	cmpq	$2147483647, %r11
	seta	%r11b
	orl	%r11d, %edx
	leaq	-1(%rax), %r11
	cmpq	$2147483646, %r11
	seta	%r11b
	orb	%dl, %r11b
	jne	.L729
	cmpb	$0, 18(%r14)
	jne	.L799
.L729:
	xorl	%edi, %edi
	.p2align 4,,10
	.p2align 3
.L715:
	movq	232(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L800
	addq	$248, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	movq	%rdi, %rax
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	ret
	.p2align 4,,10
	.p2align 3
.L799:
	.cfi_restore_state
	movq	%r14, %rdx
	movq	8(%r14), %r14
	movq	%r14, 48(%rsp)
	movq	%r14, %r11
	movq	8(%rsp), %r14
	cmpq	%r14, %r11
	jb	.L729
	movabsq	$9223372036854775799, %r11
	movzbl	16(%rdx), %r14d
	movabsq	$9223372036854775791, %rdx
	testb	%r14b, %r14b
	movb	%r14b, 79(%rsp)
	cmove	%r11, %rdx
	movabsq	$576460752303423487, %r11
	movq	%rdx, 56(%rsp)
	movabsq	$1152921504606846975, %rdx
	cmove	%rdx, %r11
	cmpb	$1, %r14b
	sbbq	%rdx, %rdx
	addq	$2, %rdx
	cmpb	$1, %r14b
	movq	%rdx, 40(%rsp)
	movq	%r12, %rdx
	sbbq	%r14, %r14
	imulq	%r13, %rdx
	andq	$-8, %r14
	addq	$16, %r14
	cmpq	%rdx, %r11
	jb	.L729
	imulq	%r14, %rax
	movq	%rax, 24(%rsp)
	movq	%rax, %r11
	movq	%rdx, %rax
	imulq	%r14, %rax
	movq	%rax, 32(%rsp)
	testq	%r12, %r12
	je	.L748
	testq	%r13, %r13
	jne	.L801
.L748:
	movq	8(%rsp), %rax
	movq	%rax, 64(%rsp)
.L718:
	movq	24(%rsp), %rdx
	movq	40(%rsp), %r14
	shrq	$3, %rdx
	movq	%r14, 56(%rsp)
	movq	%rdx, 48(%rsp)
	testb	%cl, %cl
	jne	.L721
	movq	%rdx, 56(%rsp)
	movq	%r13, %rax
	movq	%r12, %r13
	movq	%r14, 48(%rsp)
	movq	%rax, %r12
.L721:
	movq	16(%rsp), %rax
	testb	%r15b, %r15b
	movq	%r13, 104(%rsp)
	movq	%rdi, %rcx
	movq	%r12, 112(%rsp)
	sete	%r14b
	movq	%rsi, %rdx
	movq	%rbp, %rdi
	movq	%rax, 80(%rsp)
	movq	8(%rsp), %rax
	leaq	160(%rsp), %r11
	movzbl	%r14b, %r14d
	sete	24(%rsp)
	movl	%r14d, %esi
	movq	%rax, 88(%rsp)
	movq	64(%rsp), %rax
	movq	%rax, 96(%rsp)
	movq	48(%rsp), %rax
	movq	%rax, 120(%rsp)
	movq	56(%rsp), %rax
	movq	%rax, 128(%rsp)
	movq	40(%rsp), %rax
	movq	%rax, 136(%rsp)
	movq	32(%rsp), %rax
	movq	%rax, 144(%rsp)
	pushq	%r11
	.cfi_def_cfa_offset 312
	movq	%r11, 48(%rsp)
	pushq	%r10
	.cfi_def_cfa_offset 320
	call	prepare.isra.0
	popq	%rdx
	.cfi_def_cfa_offset 312
	popq	%rcx
	.cfi_def_cfa_offset 304
	testl	%eax, %eax
	jne	.L729
	movq	160(%rsp), %rax
	movzbl	79(%rsp), %esi
	cmpb	%sil, 16(%rax)
	jne	.L729
	cmpq	%r13, 184(%rsp)
	jne	.L729
	cmpq	%r12, 192(%rsp)
	jne	.L729
	cmpq	$0, 32(%rsp)
	je	.L722
	testb	%r15b, %r15b
	movq	40(%rsp), %r11
	jne	.L802
.L723:
	movq	56(%rbp), %r13
	movq	224(%rsp), %r12
	movq	%r13, %rcx
	addq	%r12, %rcx
	jc	.L729
	movq	64(%rbp), %rcx
	movq	%rcx, 32(%rsp)
	addq	%r12, %rcx
	jc	.L729
	movq	16(%rsp), %rcx
	movq	8(%rsp), %rdi
	leaq	80(%rsp), %rdx
	movq	$0, 88(%rsp)
	movq	168(%rsp), %rsi
	movq	$0, 168(%rsp)
	andq	$-8, %rdi
	addq	(%rcx), %rdi
	movq	%r11, %rcx
	andq	$-8, %rsi
	addq	(%rax), %rsi
	call	copy_kernel
	movq	%r13, %xmm0
	movq	%r12, %xmm1
	movhps	32(%rsp), %xmm0
	punpcklqdq	%xmm1, %xmm1
	paddq	%xmm1, %xmm0
	movups	%xmm0, 56(%rbp)
.L722:
	movl	$1, %edi
	movl	$168, %esi
	call	calloc@PLT
	movq	%rax, %rdi
	testq	%rax, %rax
	je	.L729
	cmpb	$0, 12(%rbp)
	movq	8(%rbx), %rcx
	movq	16(%rbx), %rsi
	movq	24(%rbx), %r9
	movq	32(%rbx), %rax
	movzbl	40(%rbx), %r11d
	jne	.L732
	movl	8(%rbp), %r10d
	testl	%r10d, %r10d
	je	.L732
	cmpq	%rsi, %rax
	movq	0(%rbp), %r8
	setb	%dl
	cmpb	$1, %r11b
	seta	%bpl
	orl	%ebp, %edx
	movq	%rsi, %rbp
	orq	%r9, %rbp
	cmpq	$2147483647, %rbp
	seta	%bpl
	orl	%ebp, %edx
	leaq	-1(%rax), %rbp
	cmpq	$2147483646, %rbp
	seta	%bpl
	orb	%bpl, %dl
	jne	.L732
	cmpb	$0, 18(%r8)
	jne	.L803
	.p2align 4,,10
	.p2align 3
.L732:
	call	free@PLT
	jmp	.L729
	.p2align 4,,10
	.p2align 3
.L803:
	movq	8(%r8), %rdx
	movq	%rdx, 16(%rsp)
	cmpq	%rcx, %rdx
	jb	.L732
	movabsq	$9223372036854775791, %rdx
	cmpb	$0, 16(%r8)
	movabsq	$9223372036854775799, %rbp
	movq	%rdx, %r13
	movabsq	$1152921504606846975, %rdx
	cmove	%rbp, %r13
	movabsq	$576460752303423487, %rbp
	cmovne	%rbp, %rdx
	cmpb	$1, 16(%r8)
	movq	%rsi, %rbp
	sbbq	%r12, %r12
	movq	%r13, 32(%rsp)
	addq	$2, %r12
	cmpb	$1, 16(%r8)
	sbbq	%r13, %r13
	imulq	%r9, %rbp
	andq	$-8, %r13
	addq	$16, %r13
	cmpq	%rbp, %rdx
	jb	.L732
	imulq	%r13, %rax
	imulq	%r13, %rbp
	movq	%rax, 8(%rsp)
	testq	%rsi, %rsi
	je	.L751
	testq	%r9, %r9
	jne	.L804
.L751:
	movq	%rcx, %rdx
.L734:
	movq	8(%rsp), %rax
	movq	%r12, %r13
	shrq	$3, %rax
	testb	%r11b, %r11b
	je	.L737
	movq	%rax, %r13
	movq	%rsi, %rax
	movq	%r9, %rsi
	movq	%rax, %r9
	movq	%r12, %rax
.L737:
	movq	%r9, 32(%rdi)
	movq	64(%rbx), %r11
	movq	%rax, 48(%rdi)
	movq	56(%rbx), %r9
	movq	%r12, 56(%rdi)
	movq	72(%rbx), %rax
	movq	48(%rbx), %r12
	movq	%r8, (%rdi)
	movq	%rcx, 8(%rdi)
	movzbl	80(%rbx), %ebx
	movq	%rdx, 16(%rdi)
	movq	%rsi, 24(%rdi)
	movq	%r13, 40(%rdi)
	movq	%rbp, 64(%rdi)
	cmpl	%r10d, %r14d
	jnb	.L732
	movq	24(%rsp), %rsi
	salq	$63, %rsi
	sarq	$63, %rsi
	andl	$24, %esi
	addq	%r8, %rsi
	cmpq	%r9, %rax
	setb	%dl
	cmpb	$1, %bl
	seta	%r10b
	orl	%r10d, %edx
	movq	%r9, %r10
	orq	%r11, %r10
	cmpq	$2147483647, %r10
	seta	%r10b
	orl	%r10d, %edx
	leaq	-1(%rax), %r10
	cmpq	$2147483646, %r10
	seta	%r10b
	orb	%r10b, %dl
	jne	.L732
	cmpb	$0, 18(%rsi)
	je	.L732
	movq	8(%rsi), %rdx
	movq	%rdx, 16(%rsp)
	cmpq	%r12, %rdx
	jb	.L732
	movabsq	$9223372036854775791, %rdx
	cmpb	$0, 16(%rsi)
	movq	%r9, %r13
	movabsq	$9223372036854775799, %r10
	movq	%rdx, %r14
	movabsq	$1152921504606846975, %rdx
	cmove	%r10, %r14
	movabsq	$576460752303423487, %r10
	cmovne	%r10, %rdx
	cmpb	$1, 16(%rsi)
	sbbq	%r10, %r10
	movq	%r14, 24(%rsp)
	addq	$2, %r10
	cmpb	$1, 16(%rsi)
	sbbq	%r14, %r14
	imulq	%r11, %r13
	andq	$-8, %r14
	addq	$16, %r14
	cmpq	%r13, %rdx
	jb	.L732
	imulq	%r14, %rax
	movq	%r14, 32(%rsp)
	imulq	%r14, %r13
	movq	%rax, 8(%rsp)
	movq	%rax, %rdx
	testq	%r9, %r9
	je	.L754
	testq	%r11, %r11
	jne	.L805
.L754:
	movq	%r12, %rax
.L739:
	movq	8(%rsp), %rdx
	movq	%r10, %r14
	shrq	$3, %rdx
	testb	%bl, %bl
	je	.L742
	movq	%rdx, %r14
	movq	%r9, %rdx
	movq	%r11, %r9
	movq	%rdx, %r11
	movq	%r10, %rdx
.L742:
	movq	%rsi, 72(%rdi)
	movq	%r12, 80(%rdi)
	movq	%rax, 88(%rdi)
	movq	%r9, 96(%rdi)
	movq	%r11, 104(%rdi)
	movq	%r14, 112(%rdi)
	movq	%rdx, 120(%rdi)
	movq	%r10, 128(%rdi)
	movq	%r13, 136(%rdi)
	testb	%r15b, %r15b
	jne	.L743
	testq	%rbp, %rbp
	jne	.L806
.L743:
	movl	$1, 160(%rdi)
	jmp	.L715
	.p2align 4,,10
	.p2align 3
.L806:
	movq	(%r8), %xmm1
	movq	%rcx, %xmm0
	movq	%r12, %xmm2
	movl	$0, 160(%rdi)
	punpcklqdq	%xmm2, %xmm0
	pand	.LC20(%rip), %xmm0
	movhps	(%rsi), %xmm1
	movq	$0, 80(%rdi)
	paddq	%xmm1, %xmm0
	movq	$0, 8(%rdi)
	movups	%xmm0, 144(%rdi)
	jmp	.L715
	.p2align 4,,10
	.p2align 3
.L802:
	movq	168(%rsp), %rdx
	movq	8(%rsp), %rcx
	cmpq	%rcx, %rdx
	je	.L807
.L724:
	movq	64(%rsp), %rcx
	cmpq	%rcx, %rdx
	jnb	.L723
	movq	8(%rsp), %rcx
	cmpq	176(%rsp), %rcx
	jnb	.L723
	jmp	.L729
	.p2align 4,,10
	.p2align 3
.L801:
	leaq	-1(%r13), %rax
	xorl	%edx, %edx
	movq	%rax, 64(%rsp)
	movabsq	$9223372036854775807, %rax
	divq	%r11
	movq	64(%rsp), %r11
	cmpq	%r11, %rax
	jb	.L729
	leaq	-1(%r12), %rdx
	movq	8(%rsp), %r11
	movabsq	$9223372036854775807, %rax
	imulq	%r14, %rdx
	subq	%rdx, %rax
	cmpq	%r11, %rax
	jb	.L729
	movq	24(%rsp), %rax
	movq	64(%rsp), %r11
	imulq	%rax, %r11
	movq	%r11, %rax
	testq	%r11, %r11
	js	.L729
	movq	8(%rsp), %r11
	addq	%r11, %rdx
	movabsq	$9223372036854775807, %r11
	subq	%rax, %r11
	cmpq	%rdx, %r11
	jb	.L729
	addq	%rdx, %rax
	cmpq	%rax, 56(%rsp)
	jb	.L729
	addq	%r14, %rax
	movq	%rax, 64(%rsp)
	movq	%rax, %r11
	cmpq	%rax, 48(%rsp)
	jb	.L729
	movq	16(%rsp), %rdx
	movq	(%rdx), %rax
	testq	%rax, %rax
	je	.L729
	movq	%r11, %rdx
	addq	%rax, %rdx
	jc	.L729
	movq	8(%rsp), %r11
	addq	%r11, %rax
	testb	$7, %al
	je	.L718
	jmp	.L729
	.p2align 4,,10
	.p2align 3
.L804:
	leaq	-1(%r9), %rax
	xorl	%edx, %edx
	movq	%rax, 40(%rsp)
	movabsq	$9223372036854775807, %rax
	divq	8(%rsp)
	movq	40(%rsp), %rdx
	cmpq	%rdx, %rax
	jb	.L732
	leaq	-1(%rsi), %rax
	imulq	%r13, %rax
	movq	%rax, %rdx
	movabsq	$9223372036854775807, %rax
	subq	%rdx, %rax
	movq	%rdx, 48(%rsp)
	cmpq	%rcx, %rax
	jb	.L732
	movq	40(%rsp), %rax
	movq	8(%rsp), %rdx
	imulq	%rdx, %rax
	movq	%rax, 40(%rsp)
	testq	%rax, %rax
	js	.L732
	movabsq	$9223372036854775807, %rax
	movq	48(%rsp), %rdx
	addq	%rcx, %rdx
	movq	%rdx, 48(%rsp)
	movq	40(%rsp), %rdx
	subq	%rdx, %rax
	movq	48(%rsp), %rdx
	cmpq	%rdx, %rax
	jb	.L732
	movq	%rdx, %rax
	movq	40(%rsp), %rdx
	addq	%rax, %rdx
	cmpq	%rdx, 32(%rsp)
	jb	.L732
	addq	%r13, %rdx
	cmpq	%rdx, 16(%rsp)
	jb	.L732
	movq	(%r8), %r13
	testq	%r13, %r13
	je	.L732
	movq	%r13, %rax
	addq	%rdx, %rax
	jc	.L732
	addq	%rcx, %r13
	andb	$7, %r13b
	je	.L734
	jmp	.L732
	.p2align 4,,10
	.p2align 3
.L805:
	leaq	-1(%r11), %rax
	movq	%rdx, %r14
	xorl	%edx, %edx
	movq	%rax, 40(%rsp)
	movabsq	$9223372036854775807, %rax
	divq	%r14
	movq	40(%rsp), %r14
	cmpq	%r14, %rax
	jb	.L732
	movq	32(%rsp), %rax
	leaq	-1(%r9), %rdx
	imulq	%rax, %rdx
	movabsq	$9223372036854775807, %rax
	subq	%rdx, %rax
	movq	%rdx, 40(%rsp)
	cmpq	%r12, %rax
	jb	.L732
	movq	8(%rsp), %rax
	movq	%r14, %rdx
	imulq	%rax, %rdx
	movq	%rdx, %rax
	testq	%rdx, %rdx
	js	.L732
	movabsq	$9223372036854775807, %r14
	movq	40(%rsp), %rdx
	subq	%rax, %r14
	addq	%r12, %rdx
	cmpq	%rdx, %r14
	jb	.L732
	addq	%rdx, %rax
	cmpq	%rax, 24(%rsp)
	jb	.L732
	movq	32(%rsp), %r14
	addq	%r14, %rax
	cmpq	%rax, 16(%rsp)
	jb	.L732
	movq	(%rsi), %rdx
	testq	%rdx, %rdx
	je	.L732
	movq	%rdx, %r14
	addq	%rax, %r14
	jc	.L732
	addq	%r12, %rdx
	andb	$7, %dl
	je	.L739
	jmp	.L732
	.p2align 4,,10
	.p2align 3
.L807:
	movq	48(%rsp), %rcx
	cmpq	%rcx, 200(%rsp)
	jne	.L724
	movq	56(%rsp), %rcx
	cmpq	%rcx, 208(%rsp)
	jne	.L724
	jmp	.L722
.L800:
	call	__stack_chk_fail@PLT
	.cfi_endproc
.LFE62:
	.size	bench_prepare, .-bench_prepare
	.p2align 4
	.globl	bench_unprepare
	.type	bench_unprepare, @function
bench_unprepare:
.LFB63:
	.cfi_startproc
	endbr64
	jmp	free@PLT
	.cfi_endproc
.LFE63:
	.size	bench_unprepare, .-bench_unprepare
	.p2align 4
	.globl	bench_adapter_loop
	.type	bench_adapter_loop, @function
bench_adapter_loop:
.LFB64:
	.cfi_startproc
	endbr64
	movl	160(%rdi), %eax
	movq	%rdi, %rdx
	testl	%eax, %eax
	je	.L811
	ret
	.p2align 4,,10
	.p2align 3
.L811:
	movq	152(%rdi), %rsi
	leaq	72(%rdi), %rcx
	movq	144(%rdi), %rdi
	jmp	copy_kernel
	.cfi_endproc
.LFE64:
	.size	bench_adapter_loop, .-bench_adapter_loop
	.p2align 4
	.globl	bench_c_loop
	.type	bench_c_loop, @function
bench_c_loop:
.LFB65:
	.cfi_startproc
	endbr64
	movl	160(%rdi), %eax
	movq	%rdi, %rdx
	testl	%eax, %eax
	je	.L814
	ret
	.p2align 4,,10
	.p2align 3
.L814:
	movq	152(%rdi), %rsi
	leaq	72(%rdi), %rcx
	movq	144(%rdi), %rdi
	jmp	c_kernel
	.cfi_endproc
.LFE65:
	.size	bench_c_loop, .-bench_c_loop
	.section	.rodata.str1.1
.LC21:
	.string	"a"
	.section	.rodata.str1.8
	.align 8
.LC22:
	.string	"vstorage_allocate(a, 0, 0, 16) == VS_OK"
	.align 8
.LC23:
	.string	"vstorage_allocate(a, 1, 0, 16) == VS_OK"
	.align 8
.LC27:
	.string	"vstorage_fill(a,0,full,0,sentinel,0) == VS_OK"
	.align 8
.LC31:
	.string	"vstorage_fill(a,1,full,0,sentinel,0) == VS_OK"
	.align 8
.LC37:
	.string	"copies[impl](a,0,x,1,bad[i]) == VS_LAYOUT"
	.align 8
.LC38:
	.string	"copies[impl](a,0,bad[i],1,x) == VS_LAYOUT"
	.align 8
.LC39:
	.string	"copies[impl](a,9,x,1,x) == VS_HANDLE"
	.align 8
.LC40:
	.string	"copies[impl](a,0,x,9,x) == VS_HANDLE"
	.align 8
.LC43:
	.string	"copies[impl](a,0,x,1,full) == VS_LAYOUT"
	.align 8
.LC45:
	.string	"copies[impl](a,0,x,0,overlap) == VS_ALIAS"
	.align 8
.LC46:
	.string	"copies[impl](a,0,x,0,x) == VS_OK"
	.align 8
.LC47:
	.string	"vstorage_stats(a).copied_bytes == 0"
	.align 8
.LC48:
	.string	"vstorage_stats(a).written_bytes == initial.written_bytes"
	.align 8
.LC49:
	.string	"copies[impl](a,0,x,1,x) == VS_OVERFLOW"
	.align 8
.LC51:
	.string	"vstorage_expect(a,0,full,i,0,0,sentinel,0) == VS_OK"
	.align 8
.LC52:
	.string	"vstorage_expect(a,1,full,i,0,0,sentinel,0) == VS_OK"
	.align 8
.LC53:
	.string	"copies[impl](a,0,x,0,y) == VS_OK"
	.section	.rodata.str1.1
.LC54:
	.string	"a->stats.copied_bytes == 32"
	.section	.rodata.str1.8
	.align 8
.LC55:
	.string	"vstorage_allocate(a,2,0,1) == VS_ALLOCATION"
	.align 8
.LC56:
	.string	"vstorage_stats(a).live_bytes == 0 && vstorage_stats(a).data_frees == 2"
	.align 8
.LC57:
	.string	"copies[impl](a,0,x,1,x) == VS_HANDLE"
	.align 8
.LC58:
	.string	"vstorage_allocate(a,0,0,2) == VS_OK"
	.align 8
.LC59:
	.string	"vstorage_allocate(a,1,1,2) == VS_OK"
	.align 8
.LC62:
	.string	"copies[impl](a,0,one,1,one) == VS_SCALAR"
	.align 8
.LC65:
	.string	"bench_open(&f, (BenchCase){2,3,1,1,1,1,0,0})"
	.align 8
.LC66:
	.string	"vstorage_copy(f.arena,0,f.input,1,f.output) == VS_OK"
	.section	.rodata.str1.1
.LC67:
	.string	"bench_verify(&f)"
.LC68:
	.string	"!bench_verify(&f)"
	.section	.rodata.str1.8
	.align 8
.LC69:
	.string	"checked baseline contract: failure-before-write, alias, overflow, self and cleanup passed"
	.text
	.p2align 4
	.globl	bench_contract_tests
	.type	bench_contract_tests, @function
bench_contract_tests:
.LFB66:
	.cfi_startproc
	endbr64
	pushq	%r15
	.cfi_def_cfa_offset 16
	.cfi_offset 15, -16
	leaq	vstorage_copy(%rip), %rdx
	pushq	%r14
	.cfi_def_cfa_offset 24
	.cfi_offset 14, -24
	movq	%rdx, %xmm0
	pushq	%r13
	.cfi_def_cfa_offset 32
	.cfi_offset 13, -32
	pushq	%r12
	.cfi_def_cfa_offset 40
	.cfi_offset 12, -40
	pushq	%rbp
	.cfi_def_cfa_offset 48
	.cfi_offset 6, -48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset 3, -56
	subq	$712, %rsp
	.cfi_def_cfa_offset 768
	movq	%fs:40, %rax
	movq	%rax, 696(%rsp)
	leaq	bench_c_copy(%rip), %rax
	movq	%rax, %xmm7
	leaq	432(%rsp), %rax
	movq	%rax, 8(%rsp)
	leaq	448(%rsp), %rax
	punpcklqdq	%xmm7, %xmm0
	movq	%rax, 24(%rsp)
	movaps	%xmm0, 432(%rsp)
.L877:
	movl	$88, %esi
	movl	$1, %edi
	call	calloc@PLT
	movq	%rax, %rbx
	testq	%rax, %rax
	je	.L920
	movdqa	.LC4(%rip), %xmm4
	xorl	%esi, %esi
	movl	$16, %edx
	movq	%rax, %rdi
	movq	$256, 16(%rax)
	movups	%xmm4, 72(%rax)
	call	vstorage_allocate.constprop.0
	testl	%eax, %eax
	jne	.L921
	movl	$16, %edx
	movl	$1, %esi
	movq	%rbx, %rdi
	call	vstorage_allocate.constprop.0
	testl	%eax, %eax
	jne	.L922
	movdqa	.LC25(%rip), %xmm6
	movdqa	.LC24(%rip), %xmm5
	leaq	288(%rsp), %r13
	movb	$0, 176(%rsp)
	movdqa	.LC26(%rip), %xmm7
	xorl	%esi, %esi
	movq	%rbx, %rdi
	xorl	%edx, %edx
	movb	$0, 224(%rsp)
	movl	$16, %r9d
	movl	$1, %r8d
	movl	$16, %ecx
	movaps	%xmm5, 144(%rsp)
	movaps	%xmm6, 160(%rsp)
	movaps	%xmm7, 192(%rsp)
	movaps	%xmm6, 208(%rsp)
	pushq	%r13
	.cfi_def_cfa_offset 776
	pushq	$0
	.cfi_def_cfa_offset 784
	call	prepare.isra.0
	popq	%rsi
	.cfi_def_cfa_offset 776
	popq	%rdi
	.cfi_def_cfa_offset 768
	testl	%eax, %eax
	jne	.L820
	movq	288(%rsp), %rax
	cmpb	$0, 16(%rax)
	jne	.L820
	movq	352(%rsp), %rcx
	movq	%rcx, %rdx
	addq	56(%rbx), %rdx
	jc	.L820
	testq	%rcx, %rcx
	je	.L823
	cmpq	$1, 344(%rsp)
	movq	(%rax), %rax
	je	.L923
	movq	.LC30(%rip), %xmm0
	movups	%xmm0, (%rax)
	movups	%xmm0, 16(%rax)
	movups	%xmm0, 32(%rax)
	movups	%xmm0, 48(%rax)
	movups	%xmm0, 64(%rax)
	movups	%xmm0, 80(%rax)
	movups	%xmm0, 96(%rax)
	movups	%xmm0, 112(%rax)
	movups	%xmm0, 128(%rax)
	movups	%xmm0, 144(%rax)
	movups	%xmm0, 160(%rax)
	movups	%xmm0, 176(%rax)
	movups	%xmm0, 192(%rax)
	movups	%xmm0, 208(%rax)
	movups	%xmm0, 224(%rax)
	movups	%xmm0, 240(%rax)
.L825:
	movq	%rdx, 56(%rbx)
.L823:
	pushq	%r13
	.cfi_def_cfa_offset 776
	movl	$16, %ecx
	xorl	%edx, %edx
	movl	$16, %r9d
	pushq	$0
	.cfi_def_cfa_offset 784
	movl	$1, %r8d
	movl	$1, %esi
	movq	%rbx, %rdi
	call	prepare.isra.0
	popq	%rdx
	.cfi_def_cfa_offset 776
	popq	%rcx
	.cfi_def_cfa_offset 768
	movl	%eax, %ebp
	testl	%eax, %eax
	jne	.L827
	movq	288(%rsp), %rax
	cmpb	$0, 16(%rax)
	je	.L924
.L827:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$177, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC31(%rip), %rdi
	call	__assert_fail@PLT
	.p2align 4,,10
	.p2align 3
.L820:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$176, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC27(%rip), %rdi
	call	__assert_fail@PLT
	.p2align 4,,10
	.p2align 3
.L924:
	movq	56(%rbx), %rdx
	movq	352(%rsp), %rcx
	movq	%rdx, 16(%rsp)
	addq	%rcx, %rdx
	jc	.L827
	testq	%rcx, %rcx
	je	.L831
	cmpq	$1, 344(%rsp)
	movq	(%rax), %rax
	je	.L925
	movq	.LC30(%rip), %xmm0
	movups	%xmm0, (%rax)
	movups	%xmm0, 16(%rax)
	movups	%xmm0, 32(%rax)
	movups	%xmm0, 48(%rax)
	movups	%xmm0, 64(%rax)
	movups	%xmm0, 80(%rax)
	movups	%xmm0, 96(%rax)
	movups	%xmm0, 112(%rax)
	movups	%xmm0, 128(%rax)
	movups	%xmm0, 144(%rax)
	movups	%xmm0, 160(%rax)
	movups	%xmm0, 176(%rax)
	movups	%xmm0, 192(%rax)
	movups	%xmm0, 208(%rax)
	movups	%xmm0, 224(%rax)
	movups	%xmm0, 240(%rax)
.L833:
	movq	%rdx, 16(%rsp)
	movq	%rdx, 56(%rbx)
.L831:
	movdqa	.LC32(%rip), %xmm0
	movq	8(%rsp), %rax
	movb	$0, 480(%rsp)
	movdqa	.LC25(%rip), %xmm5
	movdqa	.LC24(%rip), %xmm7
	movb	$0, 520(%rsp)
	movups	%xmm0, 504(%rsp)
	movdqa	.LC33(%rip), %xmm0
	movq	(%rax), %r12
	movb	$0, 560(%rsp)
	movaps	%xmm0, 528(%rsp)
	movdqa	.LC34(%rip), %xmm0
	movb	$2, 600(%rsp)
	movaps	%xmm0, 544(%rsp)
	movdqa	.LC35(%rip), %xmm0
	movb	$0, 640(%rsp)
	movaps	%xmm0, 608(%rsp)
	movdqa	.LC36(%rip), %xmm0
	movb	$0, 680(%rsp)
	movaps	%xmm5, 448(%rsp)
	movaps	%xmm5, 464(%rsp)
	movups	%xmm7, 488(%rsp)
	movups	%xmm7, 568(%rsp)
	movups	%xmm5, 584(%rsp)
	movaps	%xmm5, 624(%rsp)
	movups	%xmm7, 648(%rsp)
	movups	%xmm0, 664(%rsp)
	.p2align 4,,10
	.p2align 3
.L836:
	movl	%ebp, %eax
	movl	$1, %edx
	xorl	%esi, %esi
	movq	%rbx, %rdi
	leaq	(%rax,%rax,4), %rcx
	leaq	0(,%rcx,8), %r14
	leaq	448(%rsp,%r14), %r15
	subq	$40, %rsp
	.cfi_def_cfa_offset 808
	movdqu	488(%rsp,%r14), %xmm2
	subq	$40, %rsp
	.cfi_def_cfa_offset 848
	movups	%xmm2, 40(%rsp)
	movdqu	16(%r15), %xmm3
	movups	%xmm3, 56(%rsp)
	movq	32(%r15), %rax
	movq	%rax, 72(%rsp)
	movq	256(%rsp), %rax
	movdqa	224(%rsp), %xmm4
	movdqa	240(%rsp), %xmm5
	movq	%rax, 32(%rsp)
	movups	%xmm4, (%rsp)
	movups	%xmm5, 16(%rsp)
	call	*%r12
	addq	$80, %rsp
	.cfi_def_cfa_offset 768
	cmpl	$4, %eax
	jne	.L926
	subq	$80, %rsp
	.cfi_def_cfa_offset 848
	movl	$1, %edx
	xorl	%esi, %esi
	movq	%rbx, %rdi
	movq	256(%rsp), %rax
	movdqa	224(%rsp), %xmm6
	movdqa	240(%rsp), %xmm7
	movq	%rax, 72(%rsp)
	movups	%xmm6, 40(%rsp)
	movups	%xmm7, 56(%rsp)
	movdqu	528(%rsp,%r14), %xmm2
	movups	%xmm2, (%rsp)
	movdqu	16(%r15), %xmm3
	movups	%xmm3, 16(%rsp)
	movq	32(%r15), %rax
	movq	%rax, 32(%rsp)
	call	*%r12
	addq	$80, %rsp
	.cfi_def_cfa_offset 768
	cmpl	$4, %eax
	jne	.L927
	addl	$1, %ebp
	cmpl	$6, %ebp
	jne	.L836
	subq	$80, %rsp
	.cfi_def_cfa_offset 848
	movl	$1, %edx
	movl	$9, %esi
	movq	%rbx, %rdi
	movdqa	224(%rsp), %xmm1
	movq	256(%rsp), %rax
	movdqa	240(%rsp), %xmm0
	movq	%rax, 72(%rsp)
	movq	%rax, 32(%rsp)
	movups	%xmm1, 40(%rsp)
	movups	%xmm0, 56(%rsp)
	movups	%xmm1, (%rsp)
	movups	%xmm0, 16(%rsp)
	call	*%r12
	addq	$80, %rsp
	.cfi_def_cfa_offset 768
	cmpl	$2, %eax
	jne	.L928
	subq	$80, %rsp
	.cfi_def_cfa_offset 848
	movl	$9, %edx
	xorl	%esi, %esi
	movq	%rbx, %rdi
	movdqa	224(%rsp), %xmm1
	movq	256(%rsp), %rax
	movdqa	240(%rsp), %xmm0
	movq	%rax, 72(%rsp)
	movq	%rax, 32(%rsp)
	movups	%xmm1, 40(%rsp)
	movups	%xmm0, 56(%rsp)
	movups	%xmm1, (%rsp)
	movups	%xmm0, 16(%rsp)
	call	*%r12
	addq	$80, %rsp
	.cfi_def_cfa_offset 768
	cmpl	$2, %eax
	jne	.L929
	subq	$80, %rsp
	.cfi_def_cfa_offset 848
	movl	$1, %edx
	xorl	%esi, %esi
	movq	%rbx, %rdi
	movdqa	.LC41(%rip), %xmm0
	movdqa	.LC42(%rip), %xmm1
	movb	$0, 208(%rsp)
	movaps	%xmm0, 176(%rsp)
	movaps	%xmm1, 192(%rsp)
	movq	208(%rsp), %rax
	movdqa	192(%rsp), %xmm4
	movdqa	224(%rsp), %xmm5
	movups	%xmm0, 40(%rsp)
	movdqa	240(%rsp), %xmm6
	movq	%rax, 72(%rsp)
	movq	256(%rsp), %rax
	movups	%xmm4, 56(%rsp)
	movq	%rax, 32(%rsp)
	movups	%xmm5, (%rsp)
	movups	%xmm6, 16(%rsp)
	call	*%r12
	addq	$80, %rsp
	.cfi_def_cfa_offset 768
	cmpl	$4, %eax
	jne	.L930
	movdqa	.LC44(%rip), %xmm0
	subq	$80, %rsp
	.cfi_def_cfa_offset 848
	xorl	%edx, %edx
	xorl	%esi, %esi
	movdqa	.LC25(%rip), %xmm7
	movb	$0, 352(%rsp)
	movq	%rbx, %rdi
	movaps	%xmm0, 320(%rsp)
	movaps	%xmm7, 336(%rsp)
	movq	352(%rsp), %rax
	movdqa	336(%rsp), %xmm4
	movdqa	224(%rsp), %xmm5
	movups	%xmm0, 40(%rsp)
	movdqa	240(%rsp), %xmm6
	movq	%rax, 72(%rsp)
	movq	256(%rsp), %rax
	movups	%xmm4, 56(%rsp)
	movq	%rax, 32(%rsp)
	movups	%xmm5, (%rsp)
	movups	%xmm6, 16(%rsp)
	call	*%r12
	addq	$80, %rsp
	.cfi_def_cfa_offset 768
	cmpl	$7, %eax
	jne	.L931
	subq	$80, %rsp
	.cfi_def_cfa_offset 848
	xorl	%edx, %edx
	xorl	%esi, %esi
	movq	%rbx, %rdi
	movdqa	224(%rsp), %xmm1
	movq	256(%rsp), %rax
	movdqa	240(%rsp), %xmm0
	movq	%rax, 72(%rsp)
	movq	%rax, 32(%rsp)
	movups	%xmm1, 40(%rsp)
	movups	%xmm0, 56(%rsp)
	movups	%xmm1, (%rsp)
	movups	%xmm0, 16(%rsp)
	call	*%r12
	addq	$80, %rsp
	.cfi_def_cfa_offset 768
	testl	%eax, %eax
	jne	.L932
	movq	64(%rbx), %rbp
	testq	%rbp, %rbp
	jne	.L933
	movq	16(%rsp), %rax
	cmpq	%rax, 56(%rbx)
	jne	.L934
	subq	$80, %rsp
	.cfi_def_cfa_offset 848
	movl	$1, %edx
	xorl	%esi, %esi
	movq	%rbx, %rdi
	movq	256(%rsp), %rax
	movq	$-1, 64(%rbx)
	movdqa	224(%rsp), %xmm1
	movdqa	240(%rsp), %xmm0
	movq	%rax, 72(%rsp)
	movq	%rax, 32(%rsp)
	movups	%xmm1, 40(%rsp)
	movups	%xmm0, 56(%rsp)
	movups	%xmm1, (%rsp)
	movups	%xmm0, 16(%rsp)
	call	*%r12
	addq	$80, %rsp
	.cfi_def_cfa_offset 768
	cmpl	$5, %eax
	jne	.L935
	subq	$80, %rsp
	.cfi_def_cfa_offset 848
	xorl	%edx, %edx
	xorl	%esi, %esi
	movq	%rbx, %rdi
	movdqa	224(%rsp), %xmm1
	movq	256(%rsp), %rax
	movdqa	240(%rsp), %xmm0
	movq	%rax, 72(%rsp)
	movq	%rax, 32(%rsp)
	movups	%xmm1, 40(%rsp)
	movups	%xmm0, 56(%rsp)
	movups	%xmm1, (%rsp)
	movups	%xmm0, 16(%rsp)
	call	*%r12
	addq	$80, %rsp
	.cfi_def_cfa_offset 768
	testl	%eax, %eax
	jne	.L936
	subq	$80, %rsp
	.cfi_def_cfa_offset 848
	movl	$1, %edx
	xorl	%esi, %esi
	movq	%rbx, %rdi
	movdqa	.LC50(%rip), %xmm0
	movq	256(%rsp), %rax
	movdqa	224(%rsp), %xmm1
	movups	%xmm0, 56(%rbx)
	movdqa	240(%rsp), %xmm0
	movq	%rax, 72(%rsp)
	movq	%rax, 32(%rsp)
	movups	%xmm1, 40(%rsp)
	movups	%xmm0, 56(%rsp)
	movups	%xmm1, (%rsp)
	movups	%xmm0, 16(%rsp)
	call	*%r12
	addq	$80, %rsp
	.cfi_def_cfa_offset 768
	cmpl	$5, %eax
	jne	.L937
	movq	16(%rsp), %rax
	cmpb	$0, 12(%rbx)
	movq	%rax, 56(%rbx)
	jne	.L851
	movl	8(%rbx), %edx
	testl	%edx, %edx
	je	.L851
	movabsq	$9221120240777019119, %rdi
	movq	(%rbx), %rax
	.p2align 4,,10
	.p2align 3
.L859:
	cmpb	$0, 18(%rax)
	jne	.L938
.L851:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$201, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC51(%rip), %rdi
	call	__assert_fail@PLT
	.p2align 4,,10
	.p2align 3
.L938:
	movzbl	16(%rax), %ecx
	cmpb	$1, %cl
	sbbq	%r8, %r8
	andq	$-128, %r8
	addq	$256, %r8
	cmpb	$1, %cl
	sbbq	%rsi, %rsi
	addq	$2, %rsi
	cmpq	%r8, 8(%rax)
	jb	.L851
	movq	(%rax), %r9
	testq	%r9, %r9
	je	.L851
	addq	%r9, %r8
	jc	.L851
	testb	$7, %r9b
	jne	.L851
	testb	%cl, %cl
	jne	.L851
	movq	%rsi, %rcx
	imulq	%rbp, %rcx
	leaq	0(,%rcx,8), %r8
	cmpq	%rdi, (%r9,%rcx,8)
	jne	.L851
	cmpq	$2, %rsi
	je	.L939
.L852:
	cmpl	$1, %edx
	je	.L857
	cmpb	$0, 42(%rax)
	jne	.L940
.L857:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$202, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC52(%rip), %rdi
	call	__assert_fail@PLT
	.p2align 4,,10
	.p2align 3
.L925:
	movsd	.LC29(%rip), %xmm0
	unpcklpd	%xmm0, %xmm0
	movups	%xmm0, (%rax)
	movups	%xmm0, 16(%rax)
	movups	%xmm0, 32(%rax)
	movups	%xmm0, 48(%rax)
	movups	%xmm0, 64(%rax)
	movups	%xmm0, 80(%rax)
	movups	%xmm0, 96(%rax)
	movups	%xmm0, 112(%rax)
	jmp	.L833
.L923:
	movsd	.LC29(%rip), %xmm0
	unpcklpd	%xmm0, %xmm0
	movups	%xmm0, (%rax)
	movups	%xmm0, 16(%rax)
	movups	%xmm0, 32(%rax)
	movups	%xmm0, 48(%rax)
	movups	%xmm0, 64(%rax)
	movups	%xmm0, 80(%rax)
	movups	%xmm0, 96(%rax)
	movups	%xmm0, 112(%rax)
	jmp	.L825
	.p2align 4,,10
	.p2align 3
.L940:
	movzbl	40(%rax), %ecx
	cmpb	$1, %cl
	sbbq	%r8, %r8
	andq	$-128, %r8
	addq	$256, %r8
	cmpb	$1, %cl
	sbbq	%rsi, %rsi
	addq	$2, %rsi
	cmpq	%r8, 32(%rax)
	jb	.L857
	movq	24(%rax), %r9
	testq	%r9, %r9
	je	.L857
	addq	%r9, %r8
	jc	.L857
	testb	$7, %r9b
	jne	.L857
	testb	%cl, %cl
	jne	.L857
	movq	%rsi, %rcx
	imulq	%rbp, %rcx
	leaq	0(,%rcx,8), %r8
	cmpq	%rdi, (%r9,%rcx,8)
	jne	.L857
	cmpq	$2, %rsi
	je	.L941
.L858:
	addq	$1, %rbp
	cmpq	$16, %rbp
	jne	.L859
	subq	$80, %rsp
	.cfi_def_cfa_offset 848
	xorl	%edx, %edx
	xorl	%esi, %esi
	movq	%rbx, %rdi
	movdqa	272(%rsp), %xmm7
	movq	304(%rsp), %rax
	movdqa	224(%rsp), %xmm4
	movdqa	240(%rsp), %xmm5
	movq	%rax, 72(%rsp)
	movq	256(%rsp), %rax
	movups	%xmm7, 40(%rsp)
	movdqa	288(%rsp), %xmm7
	movq	%rax, 32(%rsp)
	movups	%xmm7, 56(%rsp)
	movups	%xmm4, (%rsp)
	movups	%xmm5, 16(%rsp)
	call	*%r12
	addq	$80, %rsp
	.cfi_def_cfa_offset 768
	testl	%eax, %eax
	jne	.L942
	cmpq	$32, 64(%rbx)
	jne	.L943
	movl	$1, %edx
	movl	$2, %esi
	movq	%rbx, %rdi
	call	vstorage_allocate.constprop.0
	cmpl	$1, %eax
	jne	.L944
	cmpb	$0, 12(%rbx)
	jne	.L864
	movq	%rbx, %rdi
	call	vstorage_close.part.0
.L864:
	cmpq	$0, 40(%rbx)
	jne	.L865
	cmpq	$2, 32(%rbx)
	jne	.L865
	subq	$80, %rsp
	.cfi_def_cfa_offset 848
	movl	$1, %edx
	xorl	%esi, %esi
	movq	%rbx, %rdi
	movdqa	224(%rsp), %xmm1
	movq	256(%rsp), %rax
	movdqa	240(%rsp), %xmm0
	movq	%rax, 72(%rsp)
	movq	%rax, 32(%rsp)
	movups	%xmm1, 40(%rsp)
	movups	%xmm0, 56(%rsp)
	movups	%xmm1, (%rsp)
	movups	%xmm0, 16(%rsp)
	call	*%r12
	addq	$80, %rsp
	.cfi_def_cfa_offset 768
	cmpl	$2, %eax
	jne	.L945
	cmpb	$0, 12(%rbx)
	jne	.L868
	movq	%rbx, %rdi
	call	vstorage_close.part.0
.L868:
	movq	(%rbx), %rdi
	call	free@PLT
	movq	%rbx, %rdi
	call	free@PLT
	movl	$88, %esi
	movl	$1, %edi
	call	calloc@PLT
	movq	%rax, %rbx
	testq	%rax, %rax
	je	.L869
	movdqa	.LC4(%rip), %xmm6
	xorl	%esi, %esi
	movl	$2, %edx
	movq	%rax, %rdi
	movq	$64, 16(%rax)
	movups	%xmm6, 72(%rax)
	call	vstorage_allocate.constprop.0
	testl	%eax, %eax
	jne	.L946
	movl	$2, %ecx
	movl	$1, %edx
	movl	$1, %esi
	movq	%rbx, %rdi
	call	vstorage_allocate
	testl	%eax, %eax
	jne	.L947
	subq	$80, %rsp
	.cfi_def_cfa_offset 848
	movl	$1, %edx
	xorl	%esi, %esi
	movq	%rbx, %rdi
	movdqa	.LC60(%rip), %xmm0
	movb	$0, 400(%rsp)
	movaps	%xmm0, 368(%rsp)
	movdqa	%xmm0, %xmm1
	movdqa	.LC61(%rip), %xmm0
	movaps	%xmm0, 384(%rsp)
	movq	400(%rsp), %rax
	movdqa	384(%rsp), %xmm0
	movups	%xmm1, 40(%rsp)
	movq	%rax, 72(%rsp)
	movq	%rax, 32(%rsp)
	movups	%xmm0, 56(%rsp)
	movups	%xmm1, (%rsp)
	movups	%xmm0, 16(%rsp)
	call	*%r12
	addq	$80, %rsp
	.cfi_def_cfa_offset 768
	cmpl	$3, %eax
	jne	.L948
	cmpb	$0, 12(%rbx)
	jne	.L874
	movq	%rbx, %rdi
	call	vstorage_close.part.0
	movq	(%rbx), %rdi
	call	free@PLT
	movq	%rbx, %rdi
	call	free@PLT
	addq	$8, 8(%rsp)
	movq	8(%rsp), %rax
	cmpq	%rax, 24(%rsp)
	jne	.L877
.L876:
	movdqa	.LC63(%rip), %xmm0
	xorl	%eax, %eax
	subq	$32, %rsp
	.cfi_def_cfa_offset 800
	movq	%r13, %rdi
	movl	$16843009, 288(%rsp)
	movaps	%xmm0, 272(%rsp)
	movw	%ax, 292(%rsp)
	movq	288(%rsp), %rax
	movups	%xmm0, (%rsp)
	movq	%rax, 16(%rsp)
	call	bench_open
	addq	$32, %rsp
	.cfi_def_cfa_offset 768
	testl	%eax, %eax
	je	.L949
	subq	$80, %rsp
	.cfi_def_cfa_offset 848
	movl	$1, %edx
	xorl	%esi, %esi
	movq	448(%rsp), %rax
	movdqa	416(%rsp), %xmm4
	movdqa	432(%rsp), %xmm5
	movq	368(%rsp), %rdi
	movdqu	376(%rsp), %xmm6
	movq	%rax, 72(%rsp)
	movdqu	392(%rsp), %xmm2
	movq	408(%rsp), %rax
	movups	%xmm4, 40(%rsp)
	movups	%xmm5, 56(%rsp)
	movq	%rax, 32(%rsp)
	movups	%xmm6, (%rsp)
	movups	%xmm2, 16(%rsp)
	call	vstorage_copy
	addq	$80, %rsp
	.cfi_def_cfa_offset 768
	testl	%eax, %eax
	jne	.L950
	movq	%r13, %rdi
	call	bench_verify
	testl	%eax, %eax
	je	.L951
	movq	384(%rsp), %rbx
	movq	400(%rsp), %rax
	movq	%r13, %rdi
	movq	336(%rsp), %r12
	movq	(%rbx), %r14
	leaq	-1(%rax), %rbp
	shrq	$3, %r12
	movq	%r14, %rax
	xorq	$1, %rax
	movq	%rax, (%rbx)
	call	bench_verify
	testl	%eax, %eax
	jne	.L881
	movq	%r14, (%rbx)
	movq	%r13, %rdi
	call	bench_verify
	testl	%eax, %eax
	je	.L882
	leaq	(%rbx,%r12,8), %r12
	movq	%r13, %rdi
	movq	(%r12), %r14
	movq	%r14, %rax
	xorq	$1, %rax
	movq	%rax, (%r12)
	call	bench_verify
	testl	%eax, %eax
	jne	.L881
	movq	%r14, (%r12)
	movq	%r13, %rdi
	call	bench_verify
	testl	%eax, %eax
	je	.L882
	leaq	(%rbx,%rbp,8), %rbx
	movq	%r13, %rdi
	movq	(%rbx), %rbp
	movq	%rbp, %rax
	xorq	$1, %rax
	movq	%rax, (%rbx)
	call	bench_verify
	testl	%eax, %eax
	jne	.L881
	movq	%rbp, (%rbx)
	movq	%r13, %rdi
	call	bench_verify
	testl	%eax, %eax
	je	.L882
	movq	376(%rsp), %rbx
	movq	%r13, %rdi
	movq	(%rbx), %rbp
	movq	%rbp, %rax
	xorq	$1, %rax
	movq	%rax, (%rbx)
	call	bench_verify
	testl	%eax, %eax
	jne	.L952
	movq	%rbp, (%rbx)
	movq	%r13, %rdi
	call	bench_verify
	testl	%eax, %eax
	je	.L953
	leaq	32(%rsp), %rdi
	movq	%r13, %rsi
	call	bench_close
	movq	696(%rsp), %rax
	subq	%fs:40, %rax
	jne	.L954
	addq	$712, %rsp
	.cfi_remember_state
	.cfi_def_cfa_offset 56
	leaq	.LC69(%rip), %rdi
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%rbp
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	jmp	puts@PLT
	.p2align 4,,10
	.p2align 3
.L941:
	.cfi_restore_state
	cmpq	$0, 8(%r9,%r8)
	je	.L858
	jmp	.L857
	.p2align 4,,10
	.p2align 3
.L939:
	cmpq	$0, 8(%r9,%r8)
	je	.L852
	jmp	.L851
	.p2align 4,,10
	.p2align 3
.L874:
	movq	(%rbx), %rdi
	call	free@PLT
	movq	%rbx, %rdi
	call	free@PLT
	addq	$8, 8(%rsp)
	movq	24(%rsp), %rsi
	movq	8(%rsp), %rax
	cmpq	%rsi, %rax
	jne	.L877
	jmp	.L876
.L926:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$182, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC37(%rip), %rdi
	call	__assert_fail@PLT
.L927:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$183, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC38(%rip), %rdi
	call	__assert_fail@PLT
.L932:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$190, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC46(%rip), %rdi
	call	__assert_fail@PLT
.L929:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$186, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC40(%rip), %rdi
	call	__assert_fail@PLT
.L930:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$187, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC43(%rip), %rdi
	call	__assert_fail@PLT
.L935:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$194, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC49(%rip), %rdi
	call	__assert_fail@PLT
.L934:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$192, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC48(%rip), %rdi
	call	__assert_fail@PLT
.L933:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$191, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC47(%rip), %rdi
	call	__assert_fail@PLT
.L945:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$209, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC57(%rip), %rdi
	call	__assert_fail@PLT
.L865:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$208, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC56(%rip), %rdi
	call	__assert_fail@PLT
.L921:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$173, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC22(%rip), %rdi
	call	__assert_fail@PLT
.L920:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$172, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC21(%rip), %rdi
	call	__assert_fail@PLT
.L936:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$195, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC46(%rip), %rdi
	call	__assert_fail@PLT
.L928:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$185, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC39(%rip), %rdi
	call	__assert_fail@PLT
.L937:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$198, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC49(%rip), %rdi
	call	__assert_fail@PLT
.L931:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$189, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC45(%rip), %rdi
	call	__assert_fail@PLT
.L922:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$174, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC23(%rip), %rdi
	call	__assert_fail@PLT
.L949:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$220, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC65(%rip), %rdi
	call	__assert_fail@PLT
.L951:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$222, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC67(%rip), %rdi
	call	__assert_fail@PLT
.L950:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$221, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC66(%rip), %rdi
	call	__assert_fail@PLT
.L948:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$215, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC62(%rip), %rdi
	call	__assert_fail@PLT
.L947:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$213, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC59(%rip), %rdi
	call	__assert_fail@PLT
.L946:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$212, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC58(%rip), %rdi
	call	__assert_fail@PLT
.L869:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$211, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC21(%rip), %rdi
	call	__assert_fail@PLT
.L944:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$206, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC55(%rip), %rdi
	call	__assert_fail@PLT
.L943:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$205, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC54(%rip), %rdi
	call	__assert_fail@PLT
.L942:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$204, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC53(%rip), %rdi
	call	__assert_fail@PLT
.L954:
	call	__stack_chk_fail@PLT
.L953:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$231, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC67(%rip), %rdi
	call	__assert_fail@PLT
.L952:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$230, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC68(%rip), %rdi
	call	__assert_fail@PLT
.L882:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$227, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC67(%rip), %rdi
	call	__assert_fail@PLT
.L881:
	leaq	__PRETTY_FUNCTION__.0(%rip), %rcx
	movl	$226, %edx
	leaq	.LC18(%rip), %rsi
	leaq	.LC68(%rip), %rdi
	call	__assert_fail@PLT
	.cfi_endproc
.LFE66:
	.size	bench_contract_tests, .-bench_contract_tests
	.section	.rodata
	.align 16
	.type	__PRETTY_FUNCTION__.0, @object
	.size	__PRETTY_FUNCTION__.0, 21
__PRETTY_FUNCTION__.0:
	.string	"bench_contract_tests"
	.align 8
	.type	__PRETTY_FUNCTION__.1, @object
	.size	__PRETTY_FUNCTION__.1, 12
__PRETTY_FUNCTION__.1:
	.string	"bench_close"
	.section	.rodata.cst16,"aM",@progbits,16
	.align 16
.LC1:
	.quad	0
	.quad	-9223372036854775808
	.align 16
.LC2:
	.quad	9218868437227405312
	.quad	-4503599627370496
	.align 16
.LC3:
	.quad	9221120237041090626
	.quad	9218868437227405313
	.align 16
.LC4:
	.quad	1
	.quad	88
	.align 16
.LC20:
	.quad	-8
	.quad	-8
	.align 16
.LC24:
	.quad	0
	.quad	4
	.align 16
.LC25:
	.quad	1
	.quad	4
	.align 16
.LC26:
	.quad	32
	.quad	4
	.set	.LC29,.LC30
	.align 16
.LC30:
	.long	-559038737
	.long	2146959360
	.long	0
	.long	0
	.align 16
.LC32:
	.quad	1
	.quad	3
	.align 16
.LC33:
	.quad	0
	.quad	32
	.align 16
.LC34:
	.quad	1
	.quad	32
	.align 16
.LC35:
	.quad	-1
	.quad	4
	.align 16
.LC36:
	.quad	1
	.quad	2147483648
	.align 16
.LC41:
	.quad	0
	.quad	16
	.align 16
.LC42:
	.quad	1
	.quad	16
	.align 16
.LC44:
	.quad	8
	.quad	4
	.align 16
.LC50:
	.quad	-1
	.quad	0
	.align 16
.LC60:
	.quad	0
	.quad	1
	.align 16
.LC61:
	.quad	1
	.quad	1
	.align 16
.LC63:
	.quad	2
	.quad	3
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
