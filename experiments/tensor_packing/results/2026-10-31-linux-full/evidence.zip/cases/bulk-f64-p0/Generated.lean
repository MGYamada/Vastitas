import VastitasStorageNative
import VastitasGemmNative
import VastitasKernel.IndexedRuntime

set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
set_option linter.unusedVariables false

namespace VastitasGenerated

def f_0 : Int :=
  (0 : Int)

end VastitasGenerated

open VastitasStorageNative

def main : IO Unit := do
  let arena ← newArena 9223372036854775807
  try
    allocate arena 0 0 36864
    fill arena 0 0 36864 1 36864 false 0 13842939354630062080 0
    fill arena 0 0 32 1152 32 false 0 4593671619917905920 0
    store arena 0 0 32 1152 32 false 0 0 0 4607182418800017408 0
    store arena 0 0 32 1152 32 false 31 1 0 13826050856027422720 0
    allocate arena 1 0 1920
    fill arena 1 0 1920 1 1920 false 0 13842939354630062080 0
    fill arena 1 0 48 40 48 false 0 13821547256400052224 0
    store arena 1 0 48 40 48 false 0 39 0 4602678819172646912 0
    store arena 1 0 48 40 48 false 47 0 0 13828302655841107968 0
    allocate arena 2 0 36864
    fill arena 2 0 36864 1 36864 false 0 13842939354630062080 0
    allocate arena 3 0 30720
    fill arena 3 0 30720 1 30720 false 0 13842939354630062080 0
    pack3 arena 0 0 32 1152 32 false 2 0 768 48 768 false 32 48 24
    VastitasGemmNative.gemm arena 2 0 768 48 768 false false 1 0 48 40 48 false false 3 0 768 40 768 false 0
    drop arena 3
    drop arena 2
    drop arena 1
    drop arena 0
    IO.println (VastitasGenerated.f_0)
  finally
    close arena
