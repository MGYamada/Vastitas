import VastitasStorageNative
import VastitasGemmNative
import VastitasKernel.IndexedRuntime

set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
set_option linter.unusedVariables false

namespace VastitasGenerated

def f_0 : Int :=
  (0 : Int)

end VastitasGenerated

open VastitasStorageNative


@[extern "bench_begin_lean"] opaque benchBegin (scope : UInt32) (reps : UInt64) (verify : Bool) : IO Unit
@[extern "bench_stop_lean"] opaque benchStop : IO Unit
@[extern "bench_report_lean"] opaque benchReport : IO Unit
@[extern "bench_c_run_lean"] opaque benchCRun (scope : UInt32) (reps : UInt64) (verify : Bool) : IO Unit
@[extern "bench_verify_lean"] opaque benchVerify (arena : @& Arena) (reps : UInt64) : IO Unit

@[noinline] def generatedOnce : IO Unit := do
  let arena ← newArena 9223372036854775807
  try
    allocate arena 0 0 39172
    fill arena 0 0 39172 1 39172 false 0 13842939354630062080 0
    fill arena 0 8 32 1152 34 false 0 4593671619917905920 0
    store arena 0 8 32 1152 34 false 0 0 0 4607182418800017408 0
    store arena 0 8 32 1152 34 false 31 1 0 13826050856027422720 0
    allocate arena 1 0 2045
    fill arena 1 0 2045 1 2045 false 0 13842939354630062080 0
    fill arena 1 16 48 40 51 false 0 13821547256400052224 0
    store arena 1 16 48 40 51 false 0 39 0 4602678819172646912 0
    store arena 1 16 48 40 51 false 47 0 0 13828302655841107968 0
    allocate arena 2 0 37062
    fill arena 2 0 37062 1 37062 false 0 13842939354630062080 0
    allocate arena 3 0 30927
    fill arena 3 0 30927 1 30927 false 0 13842939354630062080 0
    pack3 arena 0 8 32 1152 34 false 2 24 768 48 772 false 32 48 24
    VastitasGemmNative.gemm arena 2 24 768 48 772 false false 1 16 48 40 51 false false 3 32 768 40 773 false 0
    drop arena 3
    drop arena 2
    drop arena 1
    drop arena 0
    pure ()
  finally
    close arena

def main (args : List String) : IO Unit := do
  let impl := args[0]!
  let scope := args[1]!.toNat!
  let reps := args[2]!.toNat!
  let verify := args[3]! == "1"
  generatedOnce
  if impl == "c" then
    benchCRun scope.toUInt32 reps.toUInt64 verify
  else if scope == 0 then
    benchBegin 0 reps.toUInt64 verify
    for _ in [:reps] do generatedOnce
    benchStop
  else
    let arena ← newArena 9223372036854775807
    try
      allocate arena 0 0 39172
      fill arena 0 0 39172 1 39172 false 0 13842939354630062080 0
      fill arena 0 8 32 1152 34 false 0 4593671619917905920 0
      store arena 0 8 32 1152 34 false 0 0 0 4607182418800017408 0
      store arena 0 8 32 1152 34 false 31 1 0 13826050856027422720 0
      allocate arena 1 0 2045
      fill arena 1 0 2045 1 2045 false 0 13842939354630062080 0
      fill arena 1 16 48 40 51 false 0 13821547256400052224 0
      store arena 1 16 48 40 51 false 0 39 0 4602678819172646912 0
      store arena 1 16 48 40 51 false 47 0 0 13828302655841107968 0
      allocate arena 2 0 37062
      fill arena 2 0 37062 1 37062 false 0 13842939354630062080 0
      allocate arena 3 0 30927
      fill arena 3 0 30927 1 30927 false 0 13842939354630062080 0
      benchBegin scope.toUInt32 reps.toUInt64 verify
      for _ in [:reps] do
        pack3 arena 0 8 32 1152 34 false 2 24 768 48 772 false 32 48 24
        VastitasGemmNative.gemm arena 2 24 768 48 772 false false 1 16 48 40 51 false false 3 32 768 40 773 false 0
      benchStop
      benchVerify arena reps.toUInt64
      drop arena 3
      drop arena 2
      drop arena 1
      drop arena 0
    finally
      close arena
  benchReport
