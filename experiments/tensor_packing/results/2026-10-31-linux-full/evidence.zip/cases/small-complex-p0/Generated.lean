import VastitasStorageNative
import VastitasGemmNative
import VastitasKernel.IndexedRuntime

set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
set_option linter.unusedVariables false

namespace VastitasGenerated

def f_0 : Int :=
  (0 : Int)

end VastitasGenerated

open VastitasStorageNative

def main : IO Unit := do
  let arena ← newArena 9223372036854775807
  try
    allocate arena 0 1 385
    fill arena 0 0 385 1 385 false 1 13842939354630062080 4613937818241073152
    fill arena 0 0 7 55 7 false 1 4593671619917905920 4598175219545276416
    store arena 0 0 7 55 7 false 0 0 1 4607182418800017408 13826050856027422720
    store arena 0 0 7 55 7 false 6 1 1 13826050856027422720 4604930618986332160
    allocate arena 1 1 143
    fill arena 1 0 143 1 143 false 1 13842939354630062080 4613937818241073152
    fill arena 1 0 11 13 11 false 1 13821547256400052224 4593671619917905920
    store arena 1 0 11 13 11 false 0 12 1 4602678819172646912 4598175219545276416
    store arena 1 0 11 13 11 false 10 0 1 13828302655841107968 13826050856027422720
    allocate arena 2 1 385
    fill arena 2 0 385 1 385 false 1 13842939354630062080 4613937818241073152
    allocate arena 3 1 455
    fill arena 3 0 455 1 455 false 1 13842939354630062080 4613937818241073152
    pack3 arena 0 0 7 55 7 false 2 0 35 11 35 false 7 11 5
    VastitasGemmNative.gemm arena 2 0 35 11 35 false false 1 0 11 13 11 false false 3 0 35 13 35 false 0
    drop arena 3
    drop arena 2
    drop arena 1
    drop arena 0
    IO.println (VastitasGenerated.f_0)
  finally
    close arena
