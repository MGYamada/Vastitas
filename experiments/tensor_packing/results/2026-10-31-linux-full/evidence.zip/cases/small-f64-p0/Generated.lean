import VastitasStorageNative
import VastitasGemmNative
import VastitasKernel.IndexedRuntime

set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
set_option linter.unusedVariables false

namespace VastitasGenerated

def f_0 : Int :=
  (0 : Int)

end VastitasGenerated

open VastitasStorageNative

def main : IO Unit := do
  let arena ← newArena 9223372036854775807
  try
    allocate arena 0 0 385
    fill arena 0 0 385 1 385 false 0 13842939354630062080 0
    fill arena 0 0 7 55 7 false 0 4593671619917905920 0
    store arena 0 0 7 55 7 false 0 0 0 4607182418800017408 0
    store arena 0 0 7 55 7 false 6 1 0 13826050856027422720 0
    allocate arena 1 0 143
    fill arena 1 0 143 1 143 false 0 13842939354630062080 0
    fill arena 1 0 11 13 11 false 0 13821547256400052224 0
    store arena 1 0 11 13 11 false 0 12 0 4602678819172646912 0
    store arena 1 0 11 13 11 false 10 0 0 13828302655841107968 0
    allocate arena 2 0 385
    fill arena 2 0 385 1 385 false 0 13842939354630062080 0
    allocate arena 3 0 455
    fill arena 3 0 455 1 455 false 0 13842939354630062080 0
    pack3 arena 0 0 7 55 7 false 2 0 35 11 35 false 7 11 5
    VastitasGemmNative.gemm arena 2 0 35 11 35 false false 1 0 11 13 11 false false 3 0 35 13 35 false 0
    drop arena 3
    drop arena 2
    drop arena 1
    drop arena 0
    IO.println (VastitasGenerated.f_0)
  finally
    close arena
