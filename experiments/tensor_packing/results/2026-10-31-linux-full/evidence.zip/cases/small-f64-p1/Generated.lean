import VastitasStorageNative
import VastitasGemmNative
import VastitasKernel.IndexedRuntime

set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
set_option linter.unusedVariables false

namespace VastitasGenerated

def f_0 : Int :=
  (0 : Int)

end VastitasGenerated

open VastitasStorageNative

def main : IO Unit := do
  let arena ← newArena 9223372036854775807
  try
    allocate arena 0 0 499
    fill arena 0 0 499 1 499 false 0 13842939354630062080 0
    fill arena 0 8 7 55 9 false 0 4593671619917905920 0
    store arena 0 8 7 55 9 false 0 0 0 4607182418800017408 0
    store arena 0 8 7 55 9 false 6 1 0 13826050856027422720 0
    allocate arena 1 0 187
    fill arena 1 0 187 1 187 false 0 13842939354630062080 0
    fill arena 1 16 11 13 14 false 0 13821547256400052224 0
    store arena 1 16 11 13 14 false 0 12 0 4602678819172646912 0
    store arena 1 16 11 13 14 false 10 0 0 13828302655841107968 0
    allocate arena 2 0 435
    fill arena 2 0 435 1 435 false 0 13842939354630062080 0
    allocate arena 3 0 527
    fill arena 3 0 527 1 527 false 0 13842939354630062080 0
    pack3 arena 0 8 7 55 9 false 2 24 35 11 39 false 7 11 5
    VastitasGemmNative.gemm arena 2 24 35 11 39 false false 1 16 11 13 14 false false 3 32 35 13 40 false 0
    drop arena 3
    drop arena 2
    drop arena 1
    drop arena 0
    IO.println (VastitasGenerated.f_0)
  finally
    close arena
