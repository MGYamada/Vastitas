import VastitasStorageNative
import VastitasGemmNative
import VastitasKernel.IndexedRuntime

set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
set_option linter.unusedVariables false

namespace VastitasGenerated

def f_0 : Int :=
  (0 : Int)

end VastitasGenerated

open VastitasStorageNative

def main : IO Unit := do
  let arena ← newArena 9223372036854775807
  try
    allocate arena 0 0 24
    fill arena 0 0 24 1 24 false 0 13842939354630062080 0
    fill arena 0 0 2 12 2 false 0 4593671619917905920 0
    store arena 0 0 2 12 2 false 0 0 0 4607182418800017408 0
    store arena 0 0 2 12 2 false 1 1 0 13826050856027422720 0
    allocate arena 1 0 15
    fill arena 1 0 15 1 15 false 0 13842939354630062080 0
    fill arena 1 0 3 5 3 false 0 13821547256400052224 0
    store arena 1 0 3 5 3 false 0 4 0 4602678819172646912 0
    store arena 1 0 3 5 3 false 2 0 0 13828302655841107968 0
    allocate arena 2 0 24
    fill arena 2 0 24 1 24 false 0 13842939354630062080 0
    allocate arena 3 0 40
    fill arena 3 0 40 1 40 false 0 13842939354630062080 0
    pack3 arena 0 0 2 12 2 false 2 0 8 3 8 false 2 3 4
    VastitasGemmNative.gemm arena 2 0 8 3 8 false false 1 0 3 5 3 false false 3 0 8 5 8 false 0
    drop arena 3
    drop arena 2
    drop arena 1
    drop arena 0
    IO.println (VastitasGenerated.f_0)
  finally
    close arena
