import VastitasStorageNative
import VastitasGemmNative
import VastitasKernel.IndexedRuntime

set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
set_option linter.unusedVariables false

namespace VastitasGenerated

def f_0 : Int :=
  (0 : Int)

end VastitasGenerated

open VastitasStorageNative

def main : IO Unit := do
  let arena ← newArena 9223372036854775807
  try
    allocate arena 0 0 52
    fill arena 0 0 52 1 52 false 0 13842939354630062080 0
    fill arena 0 8 2 12 4 false 0 4593671619917905920 0
    store arena 0 8 2 12 4 false 0 0 0 4607182418800017408 0
    store arena 0 8 2 12 4 false 1 1 0 13826050856027422720 0
    allocate arena 1 0 35
    fill arena 1 0 35 1 35 false 0 13842939354630062080 0
    fill arena 1 16 3 5 6 false 0 13821547256400052224 0
    store arena 1 16 3 5 6 false 0 4 0 4602678819172646912 0
    store arena 1 16 3 5 6 false 2 0 0 13828302655841107968 0
    allocate arena 2 0 42
    fill arena 2 0 42 1 42 false 0 13842939354630062080 0
    allocate arena 3 0 72
    fill arena 3 0 72 1 72 false 0 13842939354630062080 0
    pack3 arena 0 8 2 12 4 false 2 24 8 3 12 false 2 3 4
    VastitasGemmNative.gemm arena 2 24 8 3 12 false false 1 16 3 5 6 false false 3 32 8 5 13 false 0
    drop arena 3
    drop arena 2
    drop arena 1
    drop arena 0
    IO.println (VastitasGenerated.f_0)
  finally
    close arena
