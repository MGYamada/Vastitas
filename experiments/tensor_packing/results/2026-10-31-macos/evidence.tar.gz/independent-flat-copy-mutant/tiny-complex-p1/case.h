/* Independently constructed from cases.json, not emitted instructions. */
static const unsigned scalar = 1;
static const uint64_t dim_i = 2, dim_k = 3, dim_j = 4;
static const VStorageLayout views[4] = {{16,2,12,4,0},{32,3,5,6,0},{48,8,3,12,0},{64,8,5,13,0}};
static const uint64_t elements[4] = {52,35,42,72};
static const double values[2][2] = {{0x1.0000000000000p-3,0x1.0000000000000p-2},{-0x1.0000000000000p-2,0x1.0000000000000p-3}};
static const double sentinel[2] = {-0x1.c000000000000p+2,0x1.8000000000000p+1};
static const double alpha[2] = {1,0}, beta[2] = {0,0};
typedef struct { uint64_t row, col; double value[2]; } Patch;
static const Patch patches[2][2] = {{{0,0,{0x1.0000000000000p+0,-0x1.0000000000000p-1}},{1,1,{-0x1.0000000000000p-1,0x1.8000000000000p-1}}},{{0,4,{0x1.0000000000000p-1,0x1.0000000000000p-2}},{2,0,{-0x1.8000000000000p-1,-0x1.0000000000000p-1}}}};
